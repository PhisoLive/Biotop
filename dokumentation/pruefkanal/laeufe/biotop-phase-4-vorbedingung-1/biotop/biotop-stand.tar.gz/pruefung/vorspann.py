"""Vollständiger Vorspann „Generation minus eins" an einem Lauf (F5 3.5) — zugleich die Nachmessung der vier
Tor-2-Zeilen Nebenwirkung, Regression, Norm und Vertrag mit den gehärteten Proben (Vorgabe Philipp, Punkt 9).

Reihenfolge wie in 3.5: Rauschmessung → Eichgegenstand → Fund-Neubewertung → vier Proben.
Aufruf: vorspann.py <ausgaben-dir> <lauf_id>
"""
import sys
import time
from pathlib import Path
sys.path.insert(0, "/root/biotop")
from biotop.kern.datenbank import verbinden, lj
from biotop.organe import eichgegenstand, eichproben, eichung, fundpruefung, landkarte
from biotop import lauf as L

A = Path(sys.argv[1]); LAUF = int(sys.argv[2])
con = verbinden()
lauf = L._lauf(con, LAUF); werk = L._werk(con, lauf["werk_id"]); pfad = Path(werk["pfad"])
mass = lj(lauf["mass"]); paket, bereiche = mass["paket"], mass["bereiche"]
ref = L._referenzlast(werk["name"], paket)
basis_gen = L.letzte_angenommene(con, LAUF); basis = lj(basis_gen["masse"])
ausgang = lj(con.execute("SELECT masse FROM generationen WHERE lauf_id=? AND nummer=0", (LAUF,)).fetchone()["masse"])
kanten = [(z["von"], z["nach"], z["art"]) for z in con.execute("SELECT von, nach, art FROM strassen WHERE werk_id=?", (werk["id"],))]
bstr = landkarte.bereichs_strassen(kanten, paket)

z = [f"# Generation minus eins — vollständiger Vorspann, Lauf {LAUF}, Werk {werk['name']}",
     f"# Zugleich Nachmessung der Tor-2-Zeilen Nebenwirkung, Regression, Norm, Vertrag (Vorgabe Philipp)"]

z.append("\n## 1. Rauschmessung (Toleranz je Bereich, bereichsweise Sperre)")
r = eichung.rauschmessung(con, LAUF, werk["id"], pfad, bereiche, paket, ref)
z += ["  " + s for s in eichung.text(r)]

z.append("\n## 2. Eichgegenstand (versiegelt, je Werk einmal)")
g = eichgegenstand.sichern(con, werk["id"], LAUF, pfad)
z += ["  " + s for s in eichgegenstand.text(g)]

z.append("\n## 3. Fund-Neubewertung (offene Funde am Ausgang nachmessen)")
t0 = time.time()
f = fundpruefung.bewerten(con, werk["id"], LAUF, pfad)
eichung.kosten_buchen(con, LAUF, werk["id"], "fundpruefung", f["kammerlaeufe"], time.time() - t0, modellaufrufe=0, kosten_eur=0.0)
z.append(f"  {f['bezugsgroesse']}, {f['kammerlaeufe']} Kammerläufe")
for e in f["ergebnisse"]:
    if e["geaendert"]:
        z.append(f"    {e['name']}: {e['alt']} → {e['neu']}")

z.append("\n## 4. Die vier Proben am versiegelten Gegenstand (= Tor-2-Zeilen, nachgemessen)")
p = eichproben.proben(con, LAUF, werk["id"], pfad, paket, bereiche, bstr, basis, ausgang, ref,
                      mass.get("grenzen") or {}, generation=basis_gen["nummer"])
z += ["  " + s for s in eichproben.text(p)]

z.append("\n## Ergebnis des Vorspanns")
z.append(f"  Lauf startet: {r['lauf_startet'] and p['bestanden']} "
         f"(Rauschmessung {r['lauf_startet']}, Proben {p['bestanden']})")
z.append("\n## Eichkosten (getrennt von der Laufsumme)")
z += ["  " + s for s in eichung.kosten_text(eichung.kosten(con, LAUF), bereiche=len(bereiche))]
(A / f"15-vorspann-lauf{LAUF}.txt").write_text("\n".join(z) + "\n")
print("\n".join(z))
