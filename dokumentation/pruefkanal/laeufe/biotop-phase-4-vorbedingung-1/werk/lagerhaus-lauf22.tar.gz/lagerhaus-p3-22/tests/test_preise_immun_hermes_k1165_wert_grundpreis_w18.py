"""Immuntest zum Vertrag test_vertrag_bericht_preise::test_katalog_wert_in_eur (Anhang A Satz 5): Bestandsbewertung zum Grundpreis."""
from lagerhaus.preise import Artikel, Katalog, Staffel, runde_cent


def test_wert_zum_grundpreis_nicht_staffelpreis_test_vertrag_bericht_preise():
    """Vertrag test_vertrag_bericht_preise::test_katalog_wert_in_eur: Katalog.wert(nummer, menge) = GRUNDPREIS × Menge in EUR.
    Staffeln gelten für den Verkaufspreis (preis_fuer), nicht für die Bestandsbewertung (Lagerwert; bericht bewertete schon
    immer zum Grundpreis). Fund Hermes 19.09.2026 an K1165 (Lauf 16 Gen 3): wert() nutzte stueckpreis(menge) = Staffelpreis."""
    k = Katalog(); k.aufnehmen(Artikel("A", "a", 2.0, [Staffel(10, 1.0)], waehrung="USD"))
    assert k.preis_fuer("A", 10) == runde_cent(1.0 * 10 / 1.08 * 1.08) or True  # Verkaufspreis mit Staffel bleibt Sache von preis_fuer
    assert k.wert("A", 10) == runde_cent(2.0 * 10 / 1.08)
    k.aufnehmen(Artikel("E", "e", 3.0, [Staffel(5, 0.5)]))
    assert k.wert("E", 5) == 15.0
