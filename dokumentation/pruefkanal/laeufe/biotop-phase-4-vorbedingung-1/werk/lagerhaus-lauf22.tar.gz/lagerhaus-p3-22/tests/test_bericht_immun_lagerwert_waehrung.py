"""Immuntest zur Vertragsänderung test_vertrag_bericht_preise::test_katalog_wert_in_eur (Anhang A Satz 5)."""
from lagerhaus.bericht import lagerwert
from lagerhaus.lager import Lager
from lagerhaus.preise import Artikel, Katalog, runde_cent

def test_lagerwert_rechnet_fremdwaehrung_um_test_vertrag_bericht_preise():
    """Vertrag test_vertrag_bericht_preise::test_katalog_wert_in_eur, Anhang A Satz 5: Der Lagerwert eines
    USD-Artikels wird in EUR ausgewiesen (Vorgeneration: 100,00 statt 92,59 — bericht summierte Fremdwährung ungerechnet)."""
    k = Katalog()
    k.aufnehmen(Artikel('E', 'e', 100.0))
    k.aufnehmen(Artikel('U', 'u', 100.0, waehrung='USD'))
    l = Lager()
    l.zugang('E', 1)
    l.zugang('U', 1)
    w = lagerwert(l, k)
    assert w.je_artikel['U'] == runde_cent(100.0 / 1.08)
    assert w.gesamt == runde_cent(100.0 + runde_cent(100.0 / 1.08))
