import pytest
from lagerhaus.lager import Lager


@pytest.fixture
def lager():
    l = Lager()
    l.zugang("A1", 100)
    return l


def test_freigeben_genau_alles(lager):
    lager.reservieren("A1", 40)
    assert lager.freigeben("A1", 40) == 0
    assert lager.reserviert("A1") == 0


def test_freigeben_ungueltig_zu_viel(lager):
    lager.reservieren("A1", 40)
    with pytest.raises(ValueError):
        lager.freigeben("A1", 41)
    assert lager.reserviert("A1") == 40
