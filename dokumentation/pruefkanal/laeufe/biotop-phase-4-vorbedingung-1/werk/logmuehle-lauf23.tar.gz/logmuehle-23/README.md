# logmuehle

Befehlszeilenwerkzeug zur Auswertung von Zugriffsprotokollen (Common Log Format), Python, ohne Abhängigkeiten.

- `logmuehle/lesen` — Zeilen in Einträge zerlegen (Zeit UTC-normalisiert)
- `logmuehle/filtern` — Zeitfenster, Status(-klassen), Pfadmuster, externer Filter (nutzt lesen)
- `logmuehle/zaehlen` — Zähler je Status/Pfad, Top-Listen, Perzentile, Bytes (nutzt lesen)
- `logmuehle/ausgabe` — Befehlszeile, Text/CSV/JSON (nutzt lesen, filtern, zaehlen)

Aufruf: `python -m logmuehle.ausgabe.befehl zugriff.log --status 4xx,5xx --format json`
Tests: `python -m pytest`
