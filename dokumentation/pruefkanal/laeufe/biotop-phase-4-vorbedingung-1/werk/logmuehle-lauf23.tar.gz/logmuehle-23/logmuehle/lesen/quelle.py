"""Quellen: Dateien und Zeilenfolgen einlesen, unlesbare Zeilen zählen statt verschlucken."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from .eintrag import Eintrag, LeseFehler, zeile_lesen


@dataclass
class Leseergebnis:
    eintraege: list[Eintrag] = field(default_factory=list)
    unlesbar: int = 0
    fehler: list[str] = field(default_factory=list)  # erste Fehlermeldungen (höchstens 20)

    @property
    def gesamt(self) -> int:
        return len(self.eintraege) + self.unlesbar


def zeilen_lesen(zeilen: Iterable[str]) -> Leseergebnis:
    """Liest alle Zeilen; Einträge in Eingabereihenfolge, unlesbare gezählt."""
    ergebnis = Leseergebnis()
    for nummer, zeile in enumerate(zeilen, 1):
        if not zeile.strip():
            continue
        try:
            ergebnis.eintraege.append(zeile_lesen(zeile))
        except LeseFehler as exc:
            ergebnis.unlesbar += 1
            if len(ergebnis.fehler) < 20:
                ergebnis.fehler.append(f"Zeile {nummer}: {exc}")
    return ergebnis


def datei_lesen(pfad: str | Path) -> Leseergebnis:
    """Liest eine Protokolldatei (UTF-8, Fehler werden ersetzt)."""
    p = Path(pfad)
    if not p.is_file():
        raise FileNotFoundError(str(p))
    with p.open("r", encoding="utf-8", errors="replace") as f:
        return zeilen_lesen(f)
