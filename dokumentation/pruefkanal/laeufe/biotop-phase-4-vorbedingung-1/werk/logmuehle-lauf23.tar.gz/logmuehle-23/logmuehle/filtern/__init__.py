"""Bereich filtern — Einträge nach Zeitfenster, Status und Pfadmuster auswählen.

Vertrag (abgeleitet):
- Jeder Filter liefert eine neue Liste in Eingabereihenfolge; die Eingabe bleibt unverändert.
- Zeitfenster [von, bis] ist an BEIDEN Enden einschließlich: ein Eintrag exakt auf `bis` gehört dazu.
- Statusfilter nimmt einzelne Codes (404) oder Klassen ("4xx").
- Pfadmuster sind Glob-Muster (fnmatch) auf dem Pfad ohne Abfrageteil.
"""

from .auswahl import (
    FilterFehler,
    nach_pfad,
    nach_status,
    nach_zeit,
    status_passt,
)
from .extern import extern_filtern

__all__ = ["FilterFehler", "nach_pfad", "nach_status", "nach_zeit", "status_passt", "extern_filtern"]
