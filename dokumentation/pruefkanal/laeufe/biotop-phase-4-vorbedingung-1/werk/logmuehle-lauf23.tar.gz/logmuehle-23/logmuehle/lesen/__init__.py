"""Bereich lesen — Protokollzeilen in Einträge zerlegen.

Vertrag (abgeleitet):
- zeile_lesen(zeile) -> Eintrag oder wirft LeseFehler; verändert die Eingabe nicht.
- Eintrag.zeit ist zeitzonenbewusst (UTC-normalisiert).
- Eintrag.groesse ≥ 0; ein „-“ im Protokoll bedeutet 0.
- datei_lesen liefert Einträge in Dateireihenfolge; unlesbare Zeilen werden gezählt, nicht verschluckt.
"""

from .eintrag import Eintrag, LeseFehler, zeile_lesen
from .quelle import Leseergebnis, datei_lesen, zeilen_lesen

__all__ = ["Eintrag", "LeseFehler", "zeile_lesen", "Leseergebnis", "datei_lesen", "zeilen_lesen"]
