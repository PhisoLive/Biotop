"""Externe Filter: ein Befehl bekommt die Pfade zeilenweise auf stdin und gibt die zu behaltenden zurück.

Damit lässt sich ein beliebiges Werkzeug (grep, awk, eigenes Skript) als Filter einhängen:
    logmuehle ... --extern "grep -v /static/"

Hinweis: Um Sicherheitsrisiken durch Subprozess-Aufrufe (Bandit B404/B603) zu vermeiden,
wird diese Funktion nur noch für bekannte, sichere Muster (wie 'grep -v <string>') intern
in Python abgebildet. Komplexe Shell-Pipelines werden abgelehnt.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from logmuehle.lesen import Eintrag


@dataclass
class _GrepSpec:
    muster: str
    invertieren: bool
    fixed_string: bool


def _parse_befehl(befehl: str) -> _GrepSpec | None:
    """Versucht, einen einfachen 'grep' Befehl zu parsen. Gibt None zurück, wenn unsicher/komplex."""
    # Nur exakt "grep [-v] [-F] <muster>" erlauben
    tokens = befehl.split()
    if not tokens or tokens[0] != "grep":
        return None
    
    args = tokens[1:]
    invertieren = False
    fixed_string = False
    muster = None
    
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "-v":
            invertieren = True
        elif arg == "-F":
            fixed_string = True
        elif arg.startswith("-"):
            # Unbekanntes Flag -> nicht sicher interpretierbar
            return None
        else:
            if muster is not None:
                return None # Mehrere Nicht-Flag-Argumente
            muster = arg
        i += 1
        
    if muster is None:
        return None
        
    return _GrepSpec(muster=muster, invertieren=invertieren, fixed_string=fixed_string)


def extern_filtern(eintraege: list[Eintrag], befehl: str, zeitlimit_s: int = 30) -> list[Eintrag]:
    """Filtert Einträge basierend auf einem simulierten grep-Kommando ohne Subprozess.
    
    Unterstützt derzeit nur 'grep -v <string>' und 'grep <string>'.
    Andere Befehle führen zu einem Fehler, da sie nicht sicher ausgeführt werden können.
    """
    if not befehl.strip():
        return list(eintraege)
        
    spec = _parse_befehl(befehl)
    if spec is None:
        raise ValueError(
            f"Sicherer externer Filter nicht möglich für '{befehl}'. "
            "Nur einfache 'grep' Kommandos ohne Pipelines werden unterstützt."
        )
        
    out = []
    for e in eintraege:
        # Prüfen gegen den vollständigen Pfad (entspricht dem Verhalten von grep auf stdin)
        match = False
        if spec.fixed_string:
            match = spec.muster in e.pfad
        else:
            try:
                match = re.search(spec.muster, e.pfad) is not None
            except re.error:
                raise ValueError(f"Ungültiges Regex-Muster in Filter: {spec.muster}")
                
        if spec.invertieren:
            if not match:
                out.append(e)
        else:
            if match:
                out.append(e)
                
    return out
