"""Auswahlfilter über Einträge."""

from __future__ import annotations

import fnmatch
import functools
from datetime import datetime, timezone

from logmuehle.lesen import Eintrag


class FilterFehler(ValueError):
    """Ungültige Filterangabe."""


@functools.lru_cache(maxsize=1024)
def _utc(t: datetime) -> datetime:
    if t.tzinfo is None:
        return t.replace(tzinfo=timezone.utc)
    return t.astimezone(timezone.utc)


def nach_zeit(eintraege: list[Eintrag], von: datetime | None, bis: datetime | None) -> list[Eintrag]:
    """Einträge im Zeitfenster [von, bis], beide Enden einschließlich; None = offen."""
    v = _utc(von) if von is not None else None
    b = _utc(bis) if bis is not None else None
    if v is not None and b is not None and v > b:
        raise FilterFehler("von liegt nach bis")
    out = []
    for e in eintraege:
        if v is not None and e.zeit < v:
            continue
        if b is not None and e.zeit > b:
            continue
        out.append(e)
    return out


@functools.lru_cache(maxsize=1024)
def status_passt(status: int, angabe: str | int) -> bool:
    """404 oder '404' oder '4xx' (Klasse)."""
    s = str(angabe).strip().lower()
    if len(s) == 3 and s[0].isdigit() and s[1:] == "xx":
        return status // 100 == int(s[0])
    if s.isdigit() and len(s) == 3:
        return status == int(s)
    raise FilterFehler(f"ungültige Statusangabe: {angabe!r}")


@functools.lru_cache(maxsize=1024)
def _match_pattern(pfad: str, muster: str) -> bool:
    return fnmatch.fnmatchcase(pfad, muster)


def nach_status(eintraege: list[Eintrag], angaben: list[str | int]) -> list[Eintrag]:
    """Einträge, deren Status zu mindestens einer Angabe passt; leere Angabenliste = alle."""
    if not angaben:
        return list(eintraege)
    for a in angaben:
        status_passt(200, a)  # validiert die Angabe
    return [e for e in eintraege if any(status_passt(e.status, a) for a in angaben)]


def nach_pfad(eintraege: list[Eintrag], muster: str) -> list[Eintrag]:
    """Glob-Muster auf dem Pfad ohne Abfrageteil; '*' = alle."""
    if not muster:
        raise FilterFehler("leeres Pfadmuster")
    return [e for e in eintraege if _match_pattern(e.pfad_ohne_abfrage, muster)]
