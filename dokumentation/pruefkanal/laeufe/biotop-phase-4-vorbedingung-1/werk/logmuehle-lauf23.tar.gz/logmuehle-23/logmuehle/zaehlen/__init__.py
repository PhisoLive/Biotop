"""Bereich zaehlen — Kennzahlen über Einträge.

Vertrag (abgeleitet):
- Alle Funktionen sind rein (keine Nebenwirkungen, Eingabe unverändert).
- je_status / je_pfad liefern Zähler, Summe der Werte = Anzahl Einträge.
- top(n) liefert höchstens n Paare, absteigend nach Zahl, bei Gleichstand alphabetisch.
- perzentil(werte, p) mit 0 ≤ p ≤ 100: nächster Rang (nearest rank); leere Liste → None.
- bytes_gesamt ≥ 0.
"""

from .kennzahlen import (
    Zusammenfassung,
    bytes_gesamt,
    je_pfad,
    je_status,
    perzentil,
    top,
    zusammenfassen,
)

__all__ = ["Zusammenfassung", "bytes_gesamt", "je_pfad", "je_status", "perzentil", "top", "zusammenfassen"]
