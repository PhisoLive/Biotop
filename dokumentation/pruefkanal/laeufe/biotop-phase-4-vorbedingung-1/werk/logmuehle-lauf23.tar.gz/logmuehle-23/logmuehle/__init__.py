"""logmuehle — Befehlszeilenwerkzeug zur Auswertung von Zugriffsprotokollen.

Bereiche:
- lesen:   Protokollzeilen (Common Log Format) in Einträge zerlegen.
- filtern: Einträge nach Zeitfenster, Status, Pfadmuster auswählen.
- zaehlen: Kennzahlen bilden (Treffer je Status, je Pfad, Perzentile der Antwortgröße).
- ausgabe: Befehlszeile und Formate (Text, CSV, JSON).
"""

__version__ = "1.0.0"
