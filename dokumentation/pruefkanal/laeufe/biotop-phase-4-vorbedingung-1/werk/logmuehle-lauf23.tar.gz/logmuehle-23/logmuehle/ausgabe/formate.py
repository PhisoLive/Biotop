"""Ausgabeformate über einer Zusammenfassung."""

from __future__ import annotations

import csv
import io
import json

from logmuehle.zaehlen import Zusammenfassung


def als_text(z: Zusammenfassung) -> str:
    zeilen = [
        f"Einträge: {z.anzahl} (unlesbar: {z.unlesbar})",
        f"Bytes: {z.bytes}",
        f"Fehleranteil (4xx+5xx): {z.fehleranteil * 100:.1f} %",
        "Status:",
    ]
    for s, n in z.status.items():
        zeilen.append(f"  {s}: {n}")
    zeilen.append("Häufigste Pfade:")
    for p, n in z.top_pfade:
        zeilen.append(f"  {n:6d}  {p}")
    p50 = "-" if z.p50_groesse is None else f"{z.p50_groesse:.0f}"
    p95 = "-" if z.p95_groesse is None else f"{z.p95_groesse:.0f}"
    zeilen.append(f"Antwortgröße p50/p95: {p50}/{p95}")
    return "\n".join(zeilen)


def als_csv(z: Zusammenfassung) -> str:
    puffer = io.StringIO()
    w = csv.writer(puffer, lineterminator="\n")
    w.writerow(["art", "schluessel", "wert"])
    w.writerow(["anzahl", "", z.anzahl])
    w.writerow(["unlesbar", "", z.unlesbar])
    w.writerow(["bytes", "", z.bytes])
    w.writerow(["fehleranteil", "", f"{z.fehleranteil:.4f}"])
    for s, n in z.status.items():
        w.writerow(["status", s, n])
    for p, n in z.top_pfade:
        w.writerow(["pfad", p, n])
    w.writerow(["p50_groesse", "", "" if z.p50_groesse is None else z.p50_groesse])
    w.writerow(["p95_groesse", "", "" if z.p95_groesse is None else z.p95_groesse])
    return puffer.getvalue()


def als_json(z: Zusammenfassung) -> str:
    return json.dumps({
        "anzahl": z.anzahl, "unlesbar": z.unlesbar, "bytes": z.bytes,
        "status": {str(s): n for s, n in z.status.items()},
        "top_pfade": [[p, n] for p, n in z.top_pfade],
        "p50": z.p50_groesse, "p95": z.p95_groesse, "fehleranteil": round(z.fehleranteil, 4),
    }, ensure_ascii=False, indent=1)
