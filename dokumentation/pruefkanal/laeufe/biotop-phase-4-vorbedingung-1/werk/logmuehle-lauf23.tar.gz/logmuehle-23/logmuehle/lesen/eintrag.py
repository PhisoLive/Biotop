"""Ein Protokolleintrag und das Zerlegen einer Zeile im Common Log Format (mit optionalem Referer/Agent).

Beispielzeile:
    203.0.113.7 - anna [19/Sep/2026:10:15:32 +0200] "GET /api/werke?seite=2 HTTP/1.1" 200 1532 "-" "curl/8.5"
"""

from __future__ import annotations

import functools
import re
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

_MONATE = {"Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6, "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12}

_MUSTER = re.compile(
    r'^(?P<host>\S+) (?P<ident>\S+) (?P<nutzer>\S+) \[(?P<zeit>[^\]]+)\] '
    r'"(?P<methode>[A-Z]+) (?P<pfad>\S+)(?: (?P<protokoll>HTTP/\d\.\d))?" '
    r'(?P<status>\d{3}) (?P<groesse>\d+|-)'
    r'(?: "(?P<referer>[^"]*)" "(?P<agent>[^"]*)")?\s*$'
)


class LeseFehler(ValueError):
    """Zeile entspricht nicht dem Protokollformat."""


@dataclass(frozen=True)
class Eintrag:
    host: str
    nutzer: str | None
    zeit: datetime
    methode: str
    pfad: str
    status: int
    groesse: int
    referer: str | None = None
    agent: str | None = None

    @property
    def pfad_ohne_abfrage(self) -> str:
        return self.pfad.split("?", 1)[0]


@functools.lru_cache(maxsize=1024)
def zeit_lesen(text: str) -> datetime:
    """'19/Sep/2026:10:15:32 +0200' -> zeitzonenbewusstes datetime, nach UTC normalisiert."""
    m = re.match(r"^(\d{2})/([A-Z][a-z]{2})/(\d{4}):(\d{2}):(\d{2}):(\d{2}) ([+-])(\d{2})(\d{2})$", text)
    if not m:
        raise LeseFehler(f"ungültige Zeit: {text!r}")
    tag, mon, jahr, h, mi, s, vz, oh, om = m.groups()
    if mon not in _MONATE:
        raise LeseFehler(f"unbekannter Monat: {mon!r}")
    versatz = timedelta(hours=int(oh), minutes=int(om))
    if vz == "-":
        versatz = -versatz
    try:
        lokal = datetime(int(jahr), _MONATE[mon], int(tag), int(h), int(mi), int(s), tzinfo=timezone(versatz))
    except ValueError as exc:
        raise LeseFehler(f"ungültige Zeit: {text!r} ({exc})") from exc
    return lokal.astimezone(timezone.utc)


@functools.lru_cache(maxsize=4096)
def zeile_lesen(zeile: str) -> Eintrag:
    """Zerlegt eine Protokollzeile. Wirft LeseFehler bei jeder Abweichung vom Format."""
    if not zeile or not zeile.strip():
        raise LeseFehler("leere Zeile")
    m = _MUSTER.match(zeile.rstrip("\n"))
    if not m:
        raise LeseFehler(f"Zeile passt nicht zum Format: {zeile[:80]!r}")
    g = m.groupdict()
    groesse = 0 if g["groesse"] == "-" else int(g["groesse"])
    status = int(g["status"])
    if not 100 <= status <= 599:
        raise LeseFehler(f"Status außerhalb 100–599: {status}")
    nutzer = None if g["nutzer"] == "-" else g["nutzer"]
    referer = None if g["referer"] in (None, "-") else g["referer"]
    agent = None if g["agent"] in (None, "-") else g["agent"]
    return Eintrag(g["host"], nutzer, zeit_lesen(g["zeit"]), g["methode"], g["pfad"], status, groesse, referer, agent)
