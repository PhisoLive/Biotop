"""Befehlszeile: logmuehle <datei> [--von ISO] [--bis ISO] [--status 4xx,500] [--pfad MUSTER] [--format text|csv|json] [--top N]"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timezone

from logmuehle.filtern import FilterFehler, nach_pfad, nach_status, nach_zeit
from logmuehle.lesen import datei_lesen
from logmuehle.zaehlen import zusammenfassen

from .formate import als_csv, als_json, als_text

FORMATE = {"text": als_text, "csv": als_csv, "json": als_json}


def _zeit(text: str | None) -> datetime | None:
    if text is None:
        return None
    try:
        t = datetime.fromisoformat(text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"ungültige Zeit: {text!r}") from exc
    return t if t.tzinfo else t.replace(tzinfo=timezone.utc)


def parser_bauen() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="logmuehle", description="Zugriffsprotokolle auswerten")
    p.add_argument("datei")
    p.add_argument("--von", type=_zeit, default=None)
    p.add_argument("--bis", type=_zeit, default=None)
    p.add_argument("--status", default="", help="Kommaliste, z. B. 404,5xx")
    p.add_argument("--pfad", default="*", help="Glob-Muster auf dem Pfad")
    p.add_argument("--format", choices=sorted(FORMATE), default="text")
    p.add_argument("--top", type=int, default=5)
    return p


def hauptprogramm(argv: list[str] | None = None, out=None) -> int:
    out = out or sys.stdout
    p = parser_bauen()
    try:
        a = p.parse_args(argv)
    except SystemExit as exc:
        return int(exc.code) if exc.code else 0
    try:
        gelesen = datei_lesen(a.datei)
    except FileNotFoundError:
        print(f"Datei nicht gefunden: {a.datei}", file=sys.stderr)
        return 1
    try:
        e = nach_zeit(gelesen.eintraege, a.von, a.bis)
        e = nach_status(e, [s for s in a.status.split(",") if s.strip()])
        e = nach_pfad(e, a.pfad)
    except FilterFehler as exc:
        print(f"Filterfehler: {exc}", file=sys.stderr)
        return 2
    z = zusammenfassen(e, unlesbar=gelesen.unlesbar, top_n=a.top)
    print(FORMATE[a.format](z), file=out)
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(hauptprogramm())
