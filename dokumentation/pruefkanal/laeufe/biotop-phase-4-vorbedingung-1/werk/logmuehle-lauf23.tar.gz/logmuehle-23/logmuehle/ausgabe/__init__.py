"""Bereich ausgabe — Befehlszeile und Ausgabeformate. Nur Darstellung, keine eigene Rechnung.

Vertrag (abgeleitet):
- als_text/als_csv/als_json sind reine Funktionen über einer Zusammenfassung; sie rechnen nichts nach.
- als_json ist gültiges JSON mit festen Schlüsseln (anzahl, unlesbar, bytes, status, top_pfade, p50, p95, fehleranteil).
- hauptprogramm(argv) -> Rückgabecode 0 (ok), 2 (Bedienfehler), 1 (Datei fehlt).
"""

from .befehl import hauptprogramm
from .formate import als_csv, als_json, als_text

__all__ = ["hauptprogramm", "als_csv", "als_json", "als_text"]
