import pytest
from datetime import datetime, timezone

from logmuehle.filtern import FilterFehler, nach_pfad, nach_status, nach_zeit, status_passt, extern_filtern
from logmuehle.lesen import zeile_lesen


def z(stunde, status=200, pfad="/a"):
    return zeile_lesen(f'h - - [19/Sep/2026:{stunde:02d}:00:00 +0000] "GET {pfad} HTTP/1.1" {status} 10')


@pytest.fixture
def eintraege():
    return [z(8), z(9, 404, "/b?x=1"), z(10, 500, "/api/x"), z(11, 200, "/static/app.js"), z(12, 201, "/api/y")]


def test_nach_zeit_von_bis(eintraege):
    von = datetime(2026, 9, 19, 9, 0, tzinfo=timezone.utc)
    bis = datetime(2026, 9, 19, 11, 30, tzinfo=timezone.utc)
    r = nach_zeit(eintraege, von, bis)
    assert [e.zeit.hour for e in r] == [9, 10, 11]


def test_nach_zeit_von_einschliesslich(eintraege):
    von = datetime(2026, 9, 19, 10, 0, tzinfo=timezone.utc)
    assert [e.zeit.hour for e in nach_zeit(eintraege, von, None)] == [10, 11, 12]


def test_nach_zeit_offen(eintraege):
    assert nach_zeit(eintraege, None, None) == eintraege
    assert nach_zeit(eintraege, None, None) is not eintraege


def test_nach_zeit_naiv_wird_utc(eintraege):
    assert len(nach_zeit(eintraege, datetime(2026, 9, 19, 11, 30), None)) == 1


def test_nach_zeit_verkehrt(eintraege):
    with pytest.raises(FilterFehler):
        nach_zeit(eintraege, datetime(2026, 9, 19, 12, tzinfo=timezone.utc), datetime(2026, 9, 19, 8, tzinfo=timezone.utc))


def test_status_passt():
    assert status_passt(404, "404") and status_passt(404, 404) and status_passt(404, "4xx")
    assert not status_passt(200, "4xx")
    with pytest.raises(FilterFehler):
        status_passt(200, "abc")
    with pytest.raises(FilterFehler):
        status_passt(200, "44")


def test_nach_status(eintraege):
    assert [e.status for e in nach_status(eintraege, ["4xx", "5xx"])] == [404, 500]
    assert nach_status(eintraege, []) == eintraege
    assert [e.status for e in nach_status(eintraege, [201])] == [201]


def test_nach_pfad(eintraege):
    assert [e.pfad for e in nach_pfad(eintraege, "/api/*")] == ["/api/x", "/api/y"]
    assert [e.pfad for e in nach_pfad(eintraege, "/b")] == ["/b?x=1"]
    assert nach_pfad(eintraege, "*") == eintraege
    with pytest.raises(FilterFehler):
        nach_pfad(eintraege, "")


def test_eingabe_unveraendert(eintraege):
    kopie = list(eintraege)
    nach_status(eintraege, ["4xx"]); nach_pfad(eintraege, "/api/*"); nach_zeit(eintraege, None, None)
    assert eintraege == kopie


def test_extern_filtern_grep(eintraege):
    r = extern_filtern(eintraege, "grep -v /static/")
    assert all("/static/" not in e.pfad for e in r) and len(r) == 4


def test_extern_leer(eintraege):
    assert extern_filtern(eintraege, "  ") == eintraege
