# Immuntest der Befundklasse B602 (Kern: biotop/kern/befundklassen.py) — Shell-Verkettungen duerfen NICHT ausgefuehrt werden.
import os
import tempfile
from logmuehle.filtern import extern_filtern
from logmuehle.lesen import zeile_lesen

def _nicht_ausgefuehrt(befehl_vorlage):
    marker = os.path.join(tempfile.gettempdir(), 'biotop_umgehung_B602_' + str(os.getpid()))
    if os.path.exists(marker): os.remove(marker)
    befehl = befehl_vorlage.replace('{marker}', marker)
    try:
        extern_filtern([zeile_lesen('h - - [19/Sep/2026:10:00:00 +0000] "GET /a HTTP/1.1" 200 1')], befehl, zeitlimit_s=10)
    except Exception:
        pass  # Abweisen ist erlaubt; entscheidend ist, dass die Shell den zweiten Befehl nicht ausgefuehrt hat
    assert not os.path.exists(marker), 'Shell-Verkettung wurde AUSGEFUEHRT (Marker-Datei entstanden): ' + befehl_vorlage

def test_umgehung_B602_verkettung_semikolon():
    _nicht_ausgefuehrt('cat; touch {marker}')

def test_umgehung_B602_verkettung_und():
    _nicht_ausgefuehrt('cat && touch {marker}')

def test_umgehung_B602_kommandosubstitution():
    _nicht_ausgefuehrt('cat $(touch {marker})')

def test_umgehung_B602_backticks():
    _nicht_ausgefuehrt('cat `touch {marker}`')

def test_umgehung_B602_umleitung():
    _nicht_ausgefuehrt('cat > {marker}')
