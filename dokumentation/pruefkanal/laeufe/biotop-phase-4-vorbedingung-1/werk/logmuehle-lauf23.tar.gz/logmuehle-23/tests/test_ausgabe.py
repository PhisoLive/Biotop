import io
import json

import pytest

from logmuehle.ausgabe import als_csv, als_json, als_text, hauptprogramm
from logmuehle.lesen import zeile_lesen
from logmuehle.zaehlen import zusammenfassen

ZEILEN = [
    'h - - [19/Sep/2026:08:00:00 +0000] "GET /a HTTP/1.1" 200 100',
    'h - - [19/Sep/2026:09:00:00 +0000] "GET /b HTTP/1.1" 404 0',
    'h - - [19/Sep/2026:10:00:00 +0000] "GET /api/x HTTP/1.1" 500 50',
    "kaputt",
]


@pytest.fixture
def zusammenfassung():
    return zusammenfassen([zeile_lesen(z) for z in ZEILEN[:3]], unlesbar=1, top_n=2)


@pytest.fixture
def logdatei(tmp_path):
    p = tmp_path / "zugriff.log"
    p.write_text("\n".join(ZEILEN) + "\n", encoding="utf-8")
    return p


def test_als_text(zusammenfassung):
    t = als_text(zusammenfassung)
    assert "Einträge: 3 (unlesbar: 1)" in t
    assert "Bytes: 150" in t
    assert "  404: 1" in t
    assert "Fehleranteil (4xx+5xx): 66.7 %" in t


def test_als_csv(zusammenfassung):
    zeilen = als_csv(zusammenfassung).splitlines()
    assert zeilen[0] == "art,schluessel,wert"
    assert "anzahl,,3" in zeilen and "status,404,1" in zeilen and "bytes,,150" in zeilen


def test_als_json(zusammenfassung):
    d = json.loads(als_json(zusammenfassung))
    assert d["anzahl"] == 3 and d["unlesbar"] == 1 and d["bytes"] == 150
    assert d["status"] == {"200": 1, "404": 1, "500": 1}
    assert d["p50"] == 50.0 and d["p95"] == 100.0
    assert set(d) == {"anzahl", "unlesbar", "bytes", "status", "top_pfade", "p50", "p95", "fehleranteil"}


def test_hauptprogramm_text(logdatei):
    out = io.StringIO()
    assert hauptprogramm([str(logdatei)], out=out) == 0
    assert "Einträge: 3 (unlesbar: 1)" in out.getvalue()


def test_hauptprogramm_json_mit_filtern(logdatei):
    out = io.StringIO()
    rc = hauptprogramm([str(logdatei), "--status", "4xx,5xx", "--format", "json"], out=out)
    assert rc == 0
    d = json.loads(out.getvalue())
    assert d["anzahl"] == 2 and d["status"] == {"404": 1, "500": 1}


def test_hauptprogramm_pfad_und_zeit(logdatei):
    out = io.StringIO()
    rc = hauptprogramm([str(logdatei), "--pfad", "/api/*", "--von", "2026-09-19T09:30:00+00:00", "--format", "csv"], out=out)
    assert rc == 0 and "anzahl,,1" in out.getvalue()


def test_hauptprogramm_datei_fehlt(tmp_path):
    assert hauptprogramm([str(tmp_path / "nein.log")], out=io.StringIO()) == 1


def test_hauptprogramm_bedienfehler(logdatei):
    assert hauptprogramm([str(logdatei), "--status", "abc"], out=io.StringIO()) == 2
    assert hauptprogramm([str(logdatei), "--format", "xml"], out=io.StringIO()) == 2
