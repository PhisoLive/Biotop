import pytest

from logmuehle.lesen import zeile_lesen
from logmuehle.zaehlen import bytes_gesamt, je_pfad, je_status, perzentil, top, zusammenfassen


def z(status=200, pfad="/a", groesse=10):
    return zeile_lesen(f'h - - [19/Sep/2026:10:00:00 +0000] "GET {pfad} HTTP/1.1" {status} {groesse}')


@pytest.fixture
def eintraege():
    return [z(200, "/a", 100), z(200, "/a?x=1", 200), z(404, "/b", 0), z(500, "/c", 50), z(200, "/b", 300)]


def test_je_status(eintraege):
    assert je_status(eintraege) == {200: 3, 404: 1, 500: 1}
    assert sum(je_status(eintraege).values()) == len(eintraege)


def test_je_pfad_ohne_abfrage(eintraege):
    assert je_pfad(eintraege) == {"/a": 2, "/b": 2, "/c": 1}


def test_top_reihenfolge():
    assert top({"/x": 3, "/a": 5, "/b": 5, "/c": 1}, 3) == [("/a", 5), ("/b", 5), ("/x", 3)]
    assert top({"/x": 3}, 0) == []
    with pytest.raises(ValueError):
        top({}, -1)


def test_perzentil_naechster_rang():
    w = [15, 20, 35, 40, 50]
    assert perzentil(w, 40) == 20.0
    assert perzentil(w, 100) == 50.0
    assert perzentil(w, 0) == 15.0
    assert perzentil(w, 50) == 35.0


def test_perzentil_leer_und_grenzen():
    assert perzentil([], 50) is None
    with pytest.raises(ValueError):
        perzentil([1], 101)


def test_bytes_gesamt(eintraege):
    assert bytes_gesamt(eintraege) == 650
    assert bytes_gesamt([]) == 0


def test_zusammenfassen(eintraege):
    z_ = zusammenfassen(eintraege, unlesbar=2, top_n=2)
    assert z_.anzahl == 5 and z_.unlesbar == 2 and z_.bytes == 650
    assert z_.top_pfade == [("/a", 2), ("/b", 2)]
    assert z_.p50_groesse == 100.0
    assert z_.p95_groesse == 300.0
    assert z_.fehleranteil == pytest.approx(0.4)


def test_zusammenfassen_leer():
    z_ = zusammenfassen([])
    assert z_.anzahl == 0 and z_.p50_groesse is None and z_.fehleranteil == 0.0


def test_rein(eintraege):
    kopie = list(eintraege)
    zusammenfassen(eintraege)
    assert eintraege == kopie
