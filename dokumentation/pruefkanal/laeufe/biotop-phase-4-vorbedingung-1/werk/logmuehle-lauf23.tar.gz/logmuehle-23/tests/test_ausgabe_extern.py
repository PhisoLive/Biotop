"""Belegt: der unsichere Shell-Pfad `--extern` ist aus `ausgabe` entfernt (Verfassung Satz 2).

An der Vorgeneration schlägt dieser Test fehl, weil `--extern` dort akzeptiert wird und
`extern_filtern` aufruft; mit der Änderung liefert argparse einen Bedienfehler (Rückgabecode 2).
"""
import io
from logmuehle.ausgabe import hauptprogramm
ZEILEN = ['h - - [19/Sep/2026:08:00:00 +0000] "GET /a HTTP/1.1" 200 100', 'h - - [19/Sep/2026:09:00:00 +0000] "GET /b HTTP/1.1" 404 0']

def test_extern_ist_kein_argument_mehr(tmp_path):
    p = tmp_path / 'zugriff.log'
    p.write_text('\n'.join(ZEILEN) + '\n', encoding='utf-8')
    out = io.StringIO()
    rc = hauptprogramm([str(p), '--extern', 'cat'], out=out)
    assert rc == 2
    assert out.getvalue() == ''
