import pytest
from datetime import datetime, timezone, timedelta

from logmuehle.lesen import Eintrag, LeseFehler, zeile_lesen, zeilen_lesen, datei_lesen
from logmuehle.lesen.eintrag import zeit_lesen

ZEILE = '203.0.113.7 - anna [19/Sep/2026:10:15:32 +0200] "GET /api/werke?seite=2 HTTP/1.1" 200 1532 "-" "curl/8.5"'


def test_zeile_lesen_felder():
    e = zeile_lesen(ZEILE)
    assert e.host == "203.0.113.7"
    assert e.nutzer == "anna"
    assert e.methode == "GET"
    assert e.pfad == "/api/werke?seite=2"
    assert e.pfad_ohne_abfrage == "/api/werke"
    assert e.status == 200
    assert e.groesse == 1532
    assert e.referer is None
    assert e.agent == "curl/8.5"


def test_zeit_utc_normalisiert():
    e = zeile_lesen(ZEILE)
    assert e.zeit == datetime(2026, 9, 19, 8, 15, 32, tzinfo=timezone.utc)
    assert e.zeit.tzinfo is not None


def test_zeit_negativer_versatz():
    t = zeit_lesen("01/Jan/2026:00:30:00 -0500")
    assert t == datetime(2026, 1, 1, 5, 30, tzinfo=timezone.utc)


def test_groesse_strich_ist_null():
    e = zeile_lesen('h - - [19/Sep/2026:10:15:32 +0000] "HEAD / HTTP/1.1" 304 -')
    assert e.groesse == 0
    assert e.nutzer is None


def test_ohne_referer_agent():
    e = zeile_lesen('h - - [19/Sep/2026:10:15:32 +0000] "GET / HTTP/1.0" 200 12')
    assert e.referer is None and e.agent is None


@pytest.mark.parametrize("zeile", ["", "   ", "kaputt", 'h - - [19/Sep/2026:10:15:32 +0000] "GET /" 999 1'])
def test_lesefehler(zeile):
    with pytest.raises(LeseFehler):
        zeile_lesen(zeile)


def test_ungueltiger_monat():
    with pytest.raises(LeseFehler):
        zeit_lesen("19/Sxp/2026:10:15:32 +0000")


def test_eintrag_unveraenderlich():
    e = zeile_lesen(ZEILE)
    with pytest.raises(Exception):
        e.status = 500


def test_zeilen_lesen_zaehlt_unlesbare():
    r = zeilen_lesen([ZEILE, "murks", "", ZEILE])
    assert len(r.eintraege) == 2
    assert r.unlesbar == 1
    assert r.gesamt == 3
    assert r.fehler[0].startswith("Zeile 2:")


def test_datei_lesen(tmp_path):
    p = tmp_path / "a.log"
    p.write_text(ZEILE + "\n" + ZEILE + "\n", encoding="utf-8")
    r = datei_lesen(p)
    assert len(r.eintraege) == 2 and r.unlesbar == 0


def test_datei_fehlt(tmp_path):
    with pytest.raises(FileNotFoundError):
        datei_lesen(tmp_path / "nein.log")
