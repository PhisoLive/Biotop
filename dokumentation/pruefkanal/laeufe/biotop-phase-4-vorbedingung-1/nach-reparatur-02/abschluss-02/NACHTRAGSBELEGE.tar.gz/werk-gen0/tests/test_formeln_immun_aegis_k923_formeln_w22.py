from lagerhaus.formeln import auswerten, FormelFehler
import pytest

def test_unerlaubte_funktion_loest_formelfehler_aus():
    with pytest.raises(FormelFehler):
        auswerten('abs(summe)', 1, 10.0, 10.0)
