import pytest
from lagerhaus.formeln import auswerten, FormelFehler, pruefen

def test_auswerten_attribute_access_bypass():
    assert pruefen('[1, 2]') is False
