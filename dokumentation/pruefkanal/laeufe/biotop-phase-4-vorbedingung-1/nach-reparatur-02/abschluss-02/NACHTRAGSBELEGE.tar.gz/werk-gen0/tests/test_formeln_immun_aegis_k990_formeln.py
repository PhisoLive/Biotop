import pytest
from lagerhaus.formeln import auswerten, FormelFehler

def test_pruefen_laesst_unbekannte_namen_durch():
    from lagerhaus.formeln.auswertung import pruefen
    assert pruefen('unbekannter_name + 1') is False
