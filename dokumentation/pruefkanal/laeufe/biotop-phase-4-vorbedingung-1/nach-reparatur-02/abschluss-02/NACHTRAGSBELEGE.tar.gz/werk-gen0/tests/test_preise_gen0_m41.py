import pytest
from lagerhaus.preise import umrechnen


def test_umrechnen_usd_eur_richtung():
    # 108 USD -> 100 EUR (Kurs 1/1.08)
    assert umrechnen(108.0, "USD", "EUR") == pytest.approx(100.0)


def test_umrechnen_usd_eur_rundung():
    # 1 USD -> 0.9259... -> 0.93 EUR
    assert umrechnen(1.0, "USD", "EUR") == pytest.approx(0.93)
