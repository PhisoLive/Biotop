import pytest
from lagerhaus.preise import umrechnen


def test_umrechnen_eur_chf():
    # 100 EUR * 0.96 = 96.00 CHF (Original); Mutant 1.96 -> 196.00
    assert umrechnen(100.0, "EUR", "CHF") == 96.0


def test_umrechnen_eur_chf_klein():
    # 50 EUR * 0.96 = 48.00 CHF (Original); Mutant 1.96 -> 98.00
    assert umrechnen(50.0, "EUR", "CHF") == 48.0
