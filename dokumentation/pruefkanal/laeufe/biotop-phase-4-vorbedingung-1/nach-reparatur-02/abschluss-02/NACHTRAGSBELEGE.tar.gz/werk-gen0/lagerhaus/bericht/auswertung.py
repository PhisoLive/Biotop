"""Auswertungen über Lager, Journal und Katalog. Nur lesend."""

from __future__ import annotations

import functools
from dataclasses import dataclass, field

from lagerhaus.lager import Journal, Lager
from lagerhaus.preise import Katalog, runde_cent


@dataclass
class Lagerwert:
    gesamt: float
    je_artikel: dict[str, float] = field(default_factory=dict)
    fehlende: list[str] = field(default_factory=list)


def lagerwert(lager: Lager, katalog: Katalog) -> Lagerwert:
    """Bewertet den Bestand zum Grundpreis des Katalogs.

    Artikel ohne Katalogeintrag zählen 0 und erscheinen in `fehlende`.
    """
    je_artikel: dict[str, float] = {}
    fehlende: list[str] = []
    gesamt = 0.0
    for nummer in lager.artikel():
        menge = lager.bestand(nummer)
        if not katalog.enthaelt(nummer):
            fehlende.append(nummer)
            je_artikel[nummer] = 0.0
            continue
        wert = runde_cent(katalog.holen(nummer).grundpreis * menge)
        je_artikel[nummer] = wert
        gesamt += wert
    return Lagerwert(runde_cent(gesamt), je_artikel, fehlende)


_bewegungsbericht_cache: dict[int, dict[str, tuple[int, int]]] = {}


def _berechne_bewegungsbericht(journal: Journal) -> dict[str, tuple[int, int]]:
    """Interne Funktion zur Berechnung des Bewegungsberichts."""
    ergebnis: dict[str, tuple[int, int]] = {}
    for buchung in journal.alle():
        zugang, abgang = ergebnis.get(buchung.artikel, (0, 0))
        if buchung.menge > 0:
            zugang += buchung.menge
        else:
            abgang += -buchung.menge
        ergebnis[buchung.artikel] = (zugang, abgang)
    return dict(sorted(ergebnis.items()))


def bewegungsbericht(journal: Journal) -> dict[str, tuple[int, int]]:
    """Je Artikel: (Summe Zugänge, Summe Abgänge), beide als positive Zahl."""
    # Cache-Key ist die Anzahl der Einträge, da das Journal unveränderlich ist
    # und neue Einträge nur am Ende hinzugefügt werden.
    key = journal.anzahl()
    if key not in _bewegungsbericht_cache:
        _bewegungsbericht_cache[key] = _berechne_bewegungsbericht(journal)
    return _bewegungsbericht_cache[key]


def textbericht(lager: Lager, katalog: Katalog) -> str:
    """Mehrzeiliger Klartextbericht, eine Zeile je Artikel plus Summenzeile."""
    wert = lagerwert(lager, katalog)
    bewegungen = bewegungsbericht(lager.journal)
    zeilen = ["Artikel | Bestand | Zugang | Abgang | Wert"]
    for nummer in lager.artikel():
        zugang, abgang = bewegungen.get(nummer, (0, 0))
        zeilen.append(
            f"{nummer} | {lager.bestand(nummer)} | {zugang} | {abgang} | "
            f"{wert.je_artikel.get(nummer, 0.0):.2f}"
        )
    zeilen.append(f"Summe | {lager.gesamtmenge()} | | | {wert.gesamt:.2f}")
    if wert.fehlende:
        zeilen.append("Ohne Katalogeintrag: " + ", ".join(wert.fehlende))
    return "\n".join(zeilen)
