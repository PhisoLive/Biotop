import pytest
from lagerhaus.formeln import auswerten, FormelFehemer

def test_auswerten_eq_operator():
    # Testet die Behauptung auswerten|Eq: Der Gleichheits-Operator == muss korrekt ausgewertet werden.
    ergebnis = auswerten("menge == 10", 10, 5.0, 50.0)
    assert ergebnis is True

    ergebnis_falsch = auswerten("menge == 10", 5, 5.0, 25.0)
    assert ergebnis_falsch is False
