"""Schlanke neue Revision; alte Lieferung bleibt unverändert."""
from pathlib import Path
import sys,json,hashlib,tarfile,shutil,os,grp,urllib.request
N=Path(__file__).resolve().parent;P=N.parent;B=N/'belege'
PUB=Path('/var/pruefkanal/oeffentlich/_akte/3qfc8gxpdvjsqxcbuj39mupe92a82agy/laeufe/biotop-phase-4-vorbedingung-1/nach-reparatur-02/abschluss-02')
URL='https://milieulux-reinigung-muenchen.de/_akte/3qfc8gxpdvjsqxcbuj39mupe92a82agy/laeufe/biotop-phase-4-vorbedingung-1/nach-reparatur-02/abschluss-02/'
ALT=URL.replace('abschluss-02/','abschluss-01/')
modus=sys.argv[1];assert modus in ('entwurf','schluss');O=N/'entwurf' if modus=='entwurf' else PUB
assert not (PUB/'MANIFEST.sha256').exists(),'Versiegelte Revision nicht überschreiben'
O.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
a=json.loads((N/'AUSGANG.json').read_text());r=json.loads((B/'AUSWERTUNG.json').read_text());q=r['nachtragsquote'];v=r['historische_quote']
review=json.loads((N/'review/REVIEW.json').read_text()) if (N/'review/REVIEW.json').exists() else None
if modus=='schluss':
    assert review is not None and type(review.get('passed')) is bool and review.get('abgeschlossen') is True
    assert {x['id'] for x in review['pruefpunkte']}==set(range(1,9))
    assert (N/'review/REVIEW-RUECKSETZUNG.json').exists()
review_ok=bool(review and review.get('abgeschlossen') is True and review.get('passed') is True and not review.get('security_concerns') and not review.get('logic_errors'))
erfuellt=bool(r['enger_ausfuehrungsanteil_erfuellt'] and review_ok)
assert r['neue_biotop_modellkosten_eur']<=2
for n,src in [('MESSPLAN.md',N/'MESSPLAN.md'),('AUSWERTUNG.json',B/'AUSWERTUNG.json'),('REVIEW-AUFTRAG.md',N/'review/PRUEFAUFTRAG.md'),('REVIEW-VORPRUEFUNG.json',N/'review/REVIEW-VORPRUEFUNG.json')]:shutil.copy2(src,O/n)
if review:dump(O/'REVIEW.json',review)
if (N/'review/REVIEW-RUECKSETZUNG.json').exists():shutil.copy2(N/'review/REVIEW-RUECKSETZUNG.json',O/'REVIEW-RUECKSETZUNG.json')
dump(O/'TORZEILEN.json',{'massstab':'Philipps ausdrücklicher enger Nachtrag: K2689 ausgeführt, Anteil strikt unter20Prozent und vollständiger Review','vorher':{k:v[k] for k in ('anzahl','doppelungen','anteil_prozent')},'nachher':{k:q[k] for k in ('anzahl','doppelungen','anteil_prozent','unter_20_prozent')},'korrigierte_ausfuehrungen_bestanden':r['korrigiert_bestanden'],'korrigierte_ausfuehrungen_gefordert':2,'gueltig_fehlgeschlagene_gegenproben':r['gegenproben_gueltig_fehlgeschlagen'],'gegenproben_gefordert':2,'review_abgeschlossen':bool(review and review.get('abgeschlossen')),'review_bestanden':review_ok,'zeile_im_engen_nachtrag_erfuellt':erfuellt,'gesamtfreigabe_biotop':False,'historischer_sammlungsabbruch_bleibt_erhalten':True,'artgedaechtnis_unveraendert':{'richtungen_mit_fremdverweis':3,'richtungen':5,'beleg':ALT+'ERGEBNIS-DETAIL.md'},'ansageabweichung_eigener_auftrag_nach_vorbedingung2':r['folgerest_ansage']})
kasse={'budget_eur':2,'neue_biotop_modellkosten_eur':r['neue_biotop_modellkosten_eur'],'kassenabgleiche':r['kasse'],'kammeraufrufe':r['kammern'],'kammersekunden':r['kammerdauer_s'],'traeger_review_hostkosten':'monetär nicht ermittelt','keine_biotop_modellaufrufe':True}
dump(O/'KASSE.json',kasse)
text=['# Kasse — enger Nachtrag',f'**{r["neue_biotop_modellkosten_eur"]:.2f} EUR von 2,00 EUR** neue Biotop-Modellkosten. Keine Biotop-/Anbieter-Modellaufrufe in diesem Nachtrag. Zwei getrennte DB-Kassenabgleiche, keine doppelte Addition historischer Beträge.']
for x in r['kasse']:text.append(f'- `{x["db"]}`: {x["vorher"]["anzahl"]} → {x["nachher"]["anzahl"]} Buchungen; letzte ID {x["vorher"]["letzte_id"]} → {x["nachher"]["letzte_id"]}; Rohsumme {x["vorher"]["summe_eur"]!r} → {x["nachher"]["summe_eur"]!r} EUR. Differenz: {x["neue_buchungen"]} Buchungen / {x["neue_eur"]!r} EUR.')
text += [f'{r["kammern"]} von {r["kammern"]} eindeutigen Kammern: 2 Originalabbrüche, 2 positive Ausführungen, 2 gültig fehlgeschlagene Gegenproben. Gemessene Kammerlaufzeit {r["kammerdauer_s"]:.6f} Sekunden. Keine dieser Gegenproben zählt als natürlicher neuer Angriffstest.','Träger-/Review- und Hostkosten monetär nicht ermittelt, nicht als null behauptet. Die alte Kampagne mit 0,4467924074074074 EUR wird nicht dem neuen Budget zugeschlagen; sie ist separat in der Vorrevision abgerechnet.','Eigene Arbeitsfehler bleiben benannt: einmal falscher Vergleich von Archiv- und Werkbaum-SHA vor Kammerbeginn; einmal zu enge Prüfung des Wortes AssertionError statt des tatsächlichen JUnit-Assertionsfehlers. Keine zusätzlichen Modellbuchungen, kein erneutes Ausführen der bereits belegten Kammerfälle.']
(O/'KASSE.md').write_text('\n\n'.join(text)+'\n')
offen='''# Offen — ausdrücklich nicht Teil des engen Nachtrags

## Eigener Auftrag NACH Vorbedingung 2
**9 von 11** Angriffstests weichen vom Schlüssel ihrer eigenen Ansage ab. Philipps Wertung: Die Vorab-Ansage als Filter ist entwertet; zum fünften Mal dieselbe Fehlerklasse **Ankündigung statt Sache**. Diese Wertung wird nicht zurückgenommen oder in eine bloße kosmetische Abweichung umbenannt. Hier nur als Auftrag erfasst; keine Änderung der Ansage-/Aufnahmefilter und keine neue Kampagne. Quelle: Philipps aktueller Nachtragsauftrag und die vollständigen Identitätszeilen in AUSWERTUNG.json.

## Unverändert aus der bisherigen Liste
19 bestätigte Außenorte (11 Prüfskriptorte plus8 Produktorte), vier Phase-4-Lücken (Wirkungskreis, Vertragsidentität, bereichsweises Rauschen, Gen0-Erfolgsbindung), acht semantische Kandidaten und45 breite ungeklärte Zeilen. Keine Vollständigkeitsentwarnung und keine Reparatur in diesem Nachtrag. Vollständige nummerierte Liste mit Quellen in der vorherigen Übergabe.

Der Importfehler von K2689 ist am konkreten Erzeugnis behoben, nicht als generelle Härtung aller Ausführungsleser verkauft. Das ursprüngliche Organprotokoll mit gesamt=0 bei Sammlungsabbruch bleibt unverändert in Lauf26; die Nachtragsausführung erfolgt isoliert mit echten Abschlusszeugen. Keine DB-Umwertung und keine rückwirkende neue Immunisierung. Im natürlichen Lauf gab es weiterhin keinen neuen bestätigten Behebungsgegenstand; Philipp hat für diesen engen Nachtrag ausdrücklich K2689-Ausführung plus Anteil unter20Prozent als Zeilenkriterium festgelegt.
'''
(O/'OFFEN.md').write_text(offen+'\nBisherige vollständige Liste:\n'+ALT+'UEBERGABE-PHASE-4.md\n')
ueber=['# UEBERGABE PHASE 4 — enger Nachtrag zur vollständigen Übergabe','Dies ist die neue Statusergänzung, keine erneute Bestandsaufnahme. Die vollständigen Abschnitte a–f mit gemessenem Bestand, Phasenwertungen, Ordnern/Prüfsummen,2a/F7 und Arbeitsorten stehen unverändert hier:',ALT+'UEBERGABE-PHASE-4.md','Deren historische rote K2689-/Reviewwertung gehört zu abschluss-01. Für den ausdrücklich autorisierten Nachtrag gelten TORZEILEN.json und REVIEW.json dieser neuen Revision; keine rückwirkende Änderung des natürlichen Laufs.',f'Aktuell: K2689 korrigiert {r["korrigiert_bestanden"]} von2 positiven Ausführungen; Gegenproben {r["gegenproben_gueltig_fehlgeschlagen"]} von2 gültig fehlgeschlagen. Doppelung {q["doppelungen"]} von{q["anzahl"]}={q["anteil_prozent"]:.2f}%. '+('Enger Nachtrag zur Abnahme vorgelegt.' if erfuellt else 'Review noch offen oder Nachtrag nicht freigegeben.'),'9von11 Ansageabweichungen: eigener Auftrag erst nach Vorbedingung2; siehe OFFEN.md. Die übrigen19Außenorte/4Lücken und Suchgrenzen bleiben erhalten.','Nächster fachlicher Schritt bleibt in FRISCHER Sitzung Vorbedingung2: Philipp schreibt/entscheidet die Verfassung des Handelssystems, einschließlich tragendem Orderpfad, Risikoprüfungen und Verlustgrenze für den Eichgegenstand. Keine automatische Mess-/Handelsfreigabe und keine Übertragung der Übungswerk-Vollmacht.','Aktuelle Dateiliste:',URL+'DATEIEN.txt']
(O/'UEBERGABE-PHASE-4.md').write_text('\n\n'.join(ueber)+'\n')
report=['# Vorbedingung 1 — enger Nachtrag', '**Enger Nachtrag erfüllt; zur Abnahme vorgelegt.**' if erfuellt else '**Ausführungsnachtrag gemessen; vollständiger Review noch offen oder nicht bestanden.**',
'Die vorherige Revision bleibt unverändert nicht abgenommen. Dieser Nachtrag führt keinen natürlichen Lauf fort. Lauf26 bleibt nach Gen5 gesättigt; sein ursprünglicher Sammlungsabbruch wird nicht überschrieben.',
'## K2689 tatsächlich ausgeführt',
'Einzige Reparatur am erzeugten Test: Importname FormelFehemer → FormelFehler. Name, Funktionskörper, beide Assertions und Aufrufargumente sind AST-identisch. Kein Produktpatch. Die Gen0-Basis ist mit lazarus.pruefsumme_werk gegen die gespeicherte Originalprüfsumme gebunden; der per unveränderter Diff-Anwendung rekonstruierte Kandidat stimmt mit der gespeicherten Datei überein.',
'Original: 0 von2 Ausführungen gültig, beide pytest-/Kammer-Exit2 beim Import. Korrigiert: 2 von2 Ausführungen gültig und bestanden, jeweils1von1 Test mit innerem/äußerem Exit0, vollständigen setup/call/teardown-Zeugen und JUnit. Beide ursprünglichen Assertions werden ohne Änderung erreicht.',
'Gegenproben: 2 von2 gültig ausgeführt und mit Exit1 fehlgeschlagen. Gleiche Testfunktion: vertauschte Gleichheit in einer Wegwerf-Basiskopie scheitert an der ersten Assertion; fälschlich wahr gesetzte Ungleichheit in einer Wegwerf-Kandidatenkopie an der zweiten. Kein Import-/Infrastrukturfehler als Gegenprobe verwendet.',
'## Vollständiger Doppelungsanteil',f'Historisch **{v["doppelungen"]} von{v["anzahl"]}={v["anteil_prozent"]:.2f}%**; nach Importkorrektur erneut **{q["doppelungen"]} von{q["anzahl"]}={q["anteil_prozent"]:.2f}%**. Grenze unverändert strikt unter20Prozent. Dieselben11 Testidentitäten in derselben Reihenfolge, genau1 Quellfassung ersetzt, alle11 Behauptungsschlüssel unverändert. Kein Herausnehmen fehlerhafter/normativer Tests; keine Gegenprobe oder Wiederholung als zusätzlicher natürlicher Nenner. Der alte rote Ausführungszustand bleibt als eigener historischer Befund sichtbar.',
'Der aktuelle Anteil ist die Reparaturauswertung derselben vollständigen Erzeugnispopulation, KEIN neuer natürlicher Lauf. Der Zähler und aegis.behauptung sind unverändert. Jede Test-ID samt Schlüssel und Doppelungsmarkierung steht in AUSWERTUNG.json.',
'## Ein vollständiger Review',('Abgeschlossen: '+str(review.get('abgeschlossen'))+'; Urteil passed='+str(review['passed'])+'. Zusammenfassung: '+review.get('summary','') if review else 'Noch offen; keine Freigabe aus einem unvollständigen Review.'),
'Vor Start real auf1800Sekunden gesetzt, durch die Laufzeitfunktion als1800 aufgelöst und dokumentiert;1500Sekunden interne Abschlussreserve. Kein nachträgliches Verlängern. Der vorherige180-Sekunden-Abbruch ist nicht als abgeschlossen umetikettiert. Neuer Durchgang ausschließlich auf ausdrücklichen Auftrag Philipps.',
'## Geltungsbereich und offene Arbeit',
'Philipps enger Maßstab: „K2689 zur Ausführung bringen, Anteil danach erneut ausweisen — bleibt er unter20%, ist die Zeile erfüllt, steigt er darüber, gilt das gemessene Ergebnis ohne Umdeutung.“ Keine neue Abnahme des gesamten Biotops und keine historische Neubewertung aller Phasen. Artgedächtnis bleibt beim belegten3von5; keine erneute Mentorantwort erzeugt.',
'9von11 Ansage-/Erzeugnisabweichungen sind als eigener Auftrag NACH Vorbedingung2 erfasst, mit Philipps Wertung der fünften Wiederkehr der Fehlerklasse. Nicht hier repariert. Weitere19Außenorte,4P4-Lücken und die unvollständige Suche bleiben offen.',
'## Kasse und unveränderter Bestand',f'{r["neue_biotop_modellkosten_eur"]:.2f} EUR von2,00EUR neue Biotop-Modellkosten; null neue DB-Buchungen. Träger-/Review-/Hostkosten monetär nicht ermittelt. {sum(r["schutz"].values())} von{len(r["schutz"])} Schutzgruppen unverändert: Produktquellen, beide DBs, Originalwerke, alte Lieferung und Angriffsrohstrom. Die sechs Kammerausführungen sowie beide eigenen Arbeitsfehler sind vollständig benannt.',
'## Bezug und Abholung','Vorrevision, nicht überschrieben:',ALT+'DATEIEN.txt','Manifest-SHA der Vorrevision: c520b090fbec5d75062261bf64cf2961da4bd2eba92c6c54df7b9790b482e14d',URL+'DATEIEN.txt']
(O/'ZWISCHENBERICHT.md').write_text('\n\n'.join(report)+'\n')
quellen={}
for p in sorted((N/'privat/basis').rglob('*')):
    if p.is_file():quellen['werk-gen0/'+str(p.relative_to(N/'privat/basis'))]=p
for p in B.iterdir():
    if p.is_file():quellen['belege/'+p.name]=p
for name in ('vorbereiten.py','ausfuehren.py','auswerten.py','liefern.py','review_vorpruefen.py','AUSGANG.json','VORBEREITUNGSFEHLER.json','AUSWERTUNGSFEHLER.json'):quellen['nachtrag/'+name]=N/name
for name in ('zaehlen.py','zaehler_pruefen.py'):quellen['ursprung/'+name]=P/name
quellen['ursprung/angriffe.jsonl']=P/'belege/angriffe.jsonl';quellen['ursprung/zaehler-gruen.json']=P/'belege/zaehler-gruen.json'
for name in ('organe/aegis.py','organe/kammer.py','organe/lazarus.py','kern/diffwerk.py'):quellen['biotop/'+name]=Path('/root/biotop/biotop')/name
mitglieder={name:sha(p) for name,p in sorted(quellen.items())};assert not any('.env' in Path(n).parts for n in mitglieder)
with tarfile.open(O/'NACHTRAGSBELEGE.tar.gz','w:gz') as tar:
    for name,p in sorted(quellen.items()):tar.add(p,arcname=name,recursive=False)
with tarfile.open(O/'NACHTRAGSBELEGE.tar.gz') as tar:assert {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers()}==mitglieder
dump(O/'ARCHIV-INHALT.json',{'NACHTRAGSBELEGE.tar.gz':mitglieder})
namen=sorted(p.name for p in O.iterdir() if p.is_file() and p.name not in ('DATEIEN.txt','MANIFEST.sha256','PRUEFSUMME-ORDNER.txt'))
(O/'DATEIEN.txt').write_text(('VERSIEGELTER ENGER NACHTRAG' if modus=='schluss' else 'ARBEITSENTWURF — REVIEW OFFEN')+'\n'+URL+'\n\n'+'\n'.join(namen+['DATEIEN.txt']+(['MANIFEST.sha256','PRUEFSUMME-ORDNER.txt'] if modus=='schluss' else []))+'\n')
if modus=='entwurf':
    for p in O.iterdir():
        if p.is_file():shutil.copy2(p,PUB/p.name)
else:
    nutz=sorted(p for p in O.iterdir() if p.is_file());(O/'MANIFEST.sha256').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in nutz));(O/'PRUEFSUMME-ORDNER.txt').write_text(f'{sha(O/"MANIFEST.sha256")}  MANIFEST.sha256\n{len(nutz)} Nutzdateien, zusätzlich Manifest und Prüfsummenhülle.\n')
gid=grp.getgrnam('caddy').gr_gid;os.chown(PUB,0,gid);os.chmod(PUB,0o750);https=[]
for p in sorted(PUB.iterdir()):
    if p.is_file():
        os.chown(p,0,gid);os.chmod(p,0o640)
        with urllib.request.urlopen(URL+p.name,timeout=45) as resp:inhalt=resp.read()
        assert inhalt==p.read_bytes(),p.name
        https.append({'datei':p.name,'sha256':hashlib.sha256(inhalt).hexdigest()})
res={'modus':modus,'enger_nachtrag_erfuellt':erfuellt,'dateien':len(https),'https_bytegleich':len(https),'archivmitglieder':len(mitglieder),'manifest_sha256':sha(PUB/'MANIFEST.sha256') if modus=='schluss' else None,'abholung':URL+'DATEIEN.txt','modellkosten_neu_eur':r['neue_biotop_modellkosten_eur'],'https':https}
dump(N/('LIEFERUNG-'+modus+'.json'),res);print(json.dumps({k:v for k,v in res.items() if k!='https'},ensure_ascii=False,indent=2))
