"""Reviewzeitfenster VOR dem Start real setzen und auflösen; danach rücksetzen."""
from pathlib import Path
import sys,os,json,hashlib,subprocess,datetime,yaml
sys.dont_write_bytecode=True
N=Path(__file__).resolve().parent
sys.path.insert(0,'/usr/local/lib/hermes-agent')
from tools.delegate_tool_config import _get_child_timeout
C=Path('/root/.hermes/config.yaml');ziel='delegation.child_timeout_seconds'
def cfg():return yaml.safe_load(C.read_text())
def sign(c):return hashlib.sha256(json.dumps(c,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def run(*args):
    p=subprocess.run(['hermes','config',*args],capture_output=True,text=True,timeout=60)
    assert p.returncode==0,(p.returncode,p.stderr)
    return {'befehl':['hermes','config',*args],'rc':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
modus=sys.argv[1]
if modus=='vorher':
    assert not (N/'review/REVIEW-VORPRUEFUNG.json').exists()
    c=cfg();d=c.get('delegation',{});vorhanden='child_timeout_seconds' in d
    a=json.loads((N/'AUSGANG.json').read_text());assert a['reviewzeitlimit_s']==1800 and a['review_abschlussreserve_ab_s']==1500
    vorher={'schluessel_vorhanden':vorhanden,'wert':d.get('child_timeout_seconds'),'gesamtstruktur_sha256':sign(c)}
    b=run('set',ziel,'1800');nach=cfg();aufgeloest=_get_child_timeout()
    assert nach['delegation']['child_timeout_seconds']==1800 and aufgeloest==1800
    aus={'zeit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'planlimit_s':1800,'abschlussreserve_ab_s':1500,'plan_sha256':hashlib.sha256((N/'MESSPLAN.md').read_bytes()).hexdigest(),'konfigurationsdatei':str(C),'vorher':vorher,'setzung':b,'aufgeloeste_reale_grenze_s':aufgeloest,'iterationsbudget':nach.get('delegation',{}).get('max_iterations'),'konflikt_mit_frueherem_limit':False,'geprueft_vor_dispatch':True,'produktquellen_geaendert':False,'hermes_funktion':'tools.delegate_tool_config._get_child_timeout','hermes_quelle_sha256':hashlib.sha256(Path('/usr/local/lib/hermes-agent/tools/delegate_tool_config.py').read_bytes()).hexdigest()}
    (N/'review/REVIEW-VORPRUEFUNG.json').write_text(json.dumps(aus,ensure_ascii=False,indent=2)+'\n');print(json.dumps(aus,ensure_ascii=False,indent=2))
elif modus=='nachher':
    a=json.loads((N/'review/REVIEW-VORPRUEFUNG.json').read_text());vor=a['vorher']
    b=run('set',ziel,json.dumps(vor['wert'])) if vor['schluessel_vorhanden'] else run('unset',ziel)
    c=cfg();assert sign(c)==vor['gesamtstruktur_sha256'],'Konfigurationsstruktur nicht gleich Ausgang'
    aus={'zeit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ruecksetzung':b,'ausgangsstruktur_wiederhergestellt':True,'aufgeloeste_grenze_s':_get_child_timeout(),'nach_reviewabschluss':True}
    (N/'review/REVIEW-RUECKSETZUNG.json').write_text(json.dumps(aus,ensure_ascii=False,indent=2)+'\n');print(json.dumps(aus,ensure_ascii=False,indent=2))
else:raise ValueError(modus)
