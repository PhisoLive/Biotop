"""Genau K2689 in der echten Kammer: Original, Importkorrektur, Gegenproben."""
from pathlib import Path
import sys,json,re,ast,hashlib,xml.etree.ElementTree as ET,difflib
from dataclasses import asdict
sys.dont_write_bytecode=True
sys.path.insert(0,'/root/biotop')
from biotop.organe import kammer
N=Path(__file__).resolve().parent;B=N/'belege'
TEST='tests/test_K2689.py'
PLUGIN='''import json
from pathlib import Path
berichte=[]
sammlung=[]
fehler=[]
def pytest_collection_finish(session):
    sammlung.extend(x.nodeid for x in session.items)
def pytest_collectreport(report):
    if report.failed:fehler.append(str(report.longrepr))
def pytest_runtest_logreport(report):
    berichte.append({'nodeid':report.nodeid,'phase':report.when,'outcome':report.outcome,'wasxfail':getattr(report,'wasxfail',None),'meldung':str(report.longrepr) if report.failed else ''})
def pytest_sessionfinish(session,exitstatus):
    Path('/tmp/zeugen.json').write_text(json.dumps({'exitstatus':int(exitstatus),'testscollected':session.testscollected,'sammlung':sammlung,'sammlungsfehler':fehler,'berichte':berichte}))
'''
RUNNER='''import sys,subprocess,json,os
from pathlib import Path
kommando=[sys.executable,'-m','pytest','-q','-p','no:cacheprovider','-p','_k2689_plugin','--tb=short','--junitxml=/tmp/junit.xml','tests/test_K2689.py']
p=subprocess.run(kommando,env={**os.environ,'PYTHONPATH':str(Path.cwd())})
print('@@EXIT@@'+str(p.returncode)+'@@ENDE@@',flush=True)
print('@@ZEUGE@@'+(Path('/tmp/zeugen.json').read_text() if Path('/tmp/zeugen.json').exists() else 'null')+'@@ENDE@@',flush=True)
print('@@JUNIT@@'+(Path('/tmp/junit.xml').read_text() if Path('/tmp/junit.xml').exists() else '')+'@@ENDE@@',flush=True)
sys.exit(p.returncode)
'''
def ausfuehren(name,werk,code,zusatz=None):
    ziel=B/(name+'.json');assert not ziel.exists(),'Keine Ausführung überschreiben'
    dateien={TEST:code,'_k2689_plugin.py':PLUGIN,'_messgeraet/k2689.py':RUNNER,**(zusatz or {})}
    ergebnis=kammer.ausfuehren(werk,['python','_messgeraet/k2689.py'],zeitlimit_s=120,dateien=dateien)
    def block(marker):
        m=re.search('@@'+marker+'@@(.*?)@@ENDE@@',ergebnis.stdout,re.S)
        return m.group(1).strip() if m else None
    inner=int(block('EXIT')) if block('EXIT') is not None else None
    zeuge=json.loads(block('ZEUGE') or 'null');junit=block('JUNIT');faelle=list(ET.fromstring(junit).iter('testcase')) if junit else []
    calls=[r for r in zeuge['berichte'] if r['phase']=='call'] if zeuge else []
    sammlung=zeuge['sammlung'] if zeuge else []
    gueltig=bool(not ergebnis.zeitlimit and ergebnis.rc==inner and inner in (0,1) and zeuge and zeuge['exitstatus']==inner and zeuge['testscollected']==len(sammlung)==len(calls)==len(faelle)==1 and not zeuge['sammlungsfehler'] and {r['nodeid'] for r in calls}==set(sammlung) and all(r['outcome']!='skipped' and not r['wasxfail'] for r in zeuge['berichte']) and {r['nodeid'] for r in zeuge['berichte'] if r['phase']=='setup' and r['outcome']=='passed'}==set(sammlung) and {r['nodeid'] for r in zeuge['berichte'] if r['phase']=='teardown' and r['outcome']=='passed'}==set(sammlung) and all(tc.find('error') is None and tc.find('skipped') is None for tc in faelle))
    bestanden=bool(gueltig and inner==0 and all(r['outcome']=='passed' for r in calls) and all(tc.find('failure') is None for tc in faelle))
    out={'fall':name,'werk':str(werk),'test_sha256':hashlib.sha256(code.encode()).hexdigest(),'datei_overlays':{k:hashlib.sha256(v.encode()).hexdigest() for k,v in dateien.items()},'kammer':asdict(ergebnis),'pytest_rc':inner,'zeuge':zeuge,'junit':junit,'gueltig_ausgefuehrt':gueltig,'test_bestanden':bestanden,'ausgefuehrte_tests':len(calls),'gestellte_gegenprobe':name.startswith('gegenprobe')}
    ziel.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ('fall','pytest_rc','gueltig_ausgefuehrt','test_bestanden','ausgefuehrte_tests')},ensure_ascii=False),flush=True)
    return out
if __name__=='__main__':
    modus=sys.argv[1];assert modus in ('rot','gruen','gruen-rest')
    original=(B/'K2689-original.py').read_text()
    basis=N/'privat/basis';kandidat=N/'privat/kandidat'
    if modus=='rot':
        for name,werk in [('original-basis',basis),('original-kandidat',kandidat)]:
            r=ausfuehren(name,werk,original)
            assert r['pytest_rc']==2 and not r['gueltig_ausgefuehrt'] and r['ausgefuehrte_tests']==0 and 'FormelFehemer' in r['kammer']['stdout'],r['fall']
    else:
        for name in ('original-basis','original-kandidat'):
            r=json.loads((B/(name+'.json')).read_text());assert r['pytest_rc']==2 and not r['gueltig_ausgefuehrt']
        korrigiert=(B/'K2689-korrigiert.py').read_text()
        assert original.replace('FormelFehemer','FormelFehler')==korrigiert
        tests=lambda s:[ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)]
        assert tests(original)==tests(korrigiert),'Testbehauptung/Assertions verändert'
        (B/'IMPORTKORREKTUR.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),korrigiert.splitlines(True),fromfile='K2689-original.py',tofile='K2689-korrigiert.py')))
        for name,werk in [('korrigiert-basis',basis),('korrigiert-kandidat',kandidat)]:
            r=ausfuehren(name,werk,korrigiert) if modus=='gruen' else json.loads((B/(name+'.json')).read_text())
            assert r['gueltig_ausgefuehrt'] and r['test_bestanden'],r['fall']
        rel='lagerhaus/formeln/auswertung.py'
        anker='if isinstance(op, ast.Eq):\n                if not (left == right):\n                    return False'
        for name,werk,neu in [('gegenprobe-basis-gleichheit-vertauscht',basis,anker.replace('left == right','left != right')),('gegenprobe-kandidat-ungleichheit-als-wahr',kandidat,anker.replace('return False','return True'))]:
            text=(werk/rel).read_text();assert text.count(anker)==1
            mutant=text.replace(anker,neu)
            (B/(name+'.diff')).write_text(''.join(difflib.unified_diff(text.splitlines(True),mutant.splitlines(True),fromfile='original/'+rel,tofile='wegwerf-gegenprobe/'+rel)))
            r=json.loads((B/(name+'.json')).read_text()) if modus=='gruen-rest' and (B/(name+'.json')).exists() else ausfuehren(name,werk,korrigiert,{rel:mutant})
            assert r['datei_overlays'][rel]==hashlib.sha256(mutant.encode()).hexdigest()
            fehler=list(ET.fromstring(r['junit']).iter('failure'))
            assert r['gueltig_ausgefuehrt'] and not r['test_bestanden'] and r['pytest_rc']==1 and len(fehler)==1 and fehler[0].get('message','').startswith('assert '),r['fall']
