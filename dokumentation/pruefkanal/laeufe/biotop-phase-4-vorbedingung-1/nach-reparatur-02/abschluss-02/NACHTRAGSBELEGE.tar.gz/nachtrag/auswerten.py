"""Vollständige Quote nach Importkorrektur; unveränderte Originale nachweisen."""
from pathlib import Path
import sys,json,ast,datetime,copy
sys.dont_write_bytecode=True
N=Path(__file__).resolve().parent;P=N.parent;B=N/'belege'
sys.path.insert(0,str(P));from zaehlen import zaehlen
sys.path.insert(0,str(N));from vorbereiten import bestand,sha,dump
alt=json.loads((N/'AUSGANG.json').read_text());neu=bestand()
schutz={k:neu[k]==alt[k] for k in neu};assert all(schutz.values()),schutz
angriffe=[json.loads(l) for l in (P/'belege/angriffe.jsonl').read_text().splitlines()]
nach=copy.deepcopy(angriffe);ersetzt=0
for a in nach:
    if a.get('kandidat')==2689 and a['art']=='ergebnis':a['code']=(B/'K2689-korrigiert.py').read_text();ersetzt+=1
assert ersetzt==1
vor=zaehlen(angriffe);danach=zaehlen(nach)
assert [x['id'] for x in vor['tests']]==[x['id'] for x in danach['tests']]
assert [(a['kandidat'],a.get('code')) for a in angriffe if a.get('kandidat')!=2689]==[(a['kandidat'],a.get('code')) for a in nach if a.get('kandidat')!=2689]
faelle=[json.loads((B/(name+'.json')).read_text()) for name in ('original-basis','original-kandidat','korrigiert-basis','korrigiert-kandidat','gegenprobe-basis-gleichheit-vertauscht','gegenprobe-kandidat-ungleichheit-als-wahr')]
assert len({r['kammer']['container'] for r in faelle})==len(faelle)
kasse=[]
for zuvor,jetzt in zip(alt['dbs'],neu['dbs']):
    assert zuvor['pfad']==jetzt['pfad'];kasse.append({'db':jetzt['pfad'],'vorher':zuvor['kasse'],'nachher':jetzt['kasse'],'neue_buchungen':jetzt['kasse']['anzahl']-zuvor['kasse']['anzahl'],'neue_eur':jetzt['kasse']['summe_eur']-zuvor['kasse']['summe_eur']})
assert all(x['neue_buchungen']==0 and x['neue_eur']==0 for x in kasse)
result={'zeit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'art':'isolierter autorisierter Ausführungsnachtrag, kein natürlicher Neustart','historische_quote':vor,'nachtragsquote':danach,'testidentitaeten_identisch':True,'quellfassungen_ersetzt':ersetzt,'behauptungsschluessel_unveraendert':[x['schluessel'] for x in vor['tests']]==[x['schluessel'] for x in danach['tests']], 'quellen_korrigiert':[{'kandidat':a['kandidat'],'protokoll_vor':a['protokoll_vor'],'bereich':a['bereich'],'paket':a['paket'],'code':a['code']} for a in nach if a['art']=='ergebnis' and a.get('code') is not None], 'faelle':[{k:r[k] for k in ('fall','pytest_rc','gueltig_ausgefuehrt','test_bestanden','ausgefuehrte_tests','gestellte_gegenprobe')} for r in faelle], 'original_ausgefuehrt':sum(r['gueltig_ausgefuehrt'] for r in faelle[:2]),'korrigiert_bestanden':sum(r['gueltig_ausgefuehrt'] and r['test_bestanden'] for r in faelle[2:4]),'gegenproben_gueltig_fehlgeschlagen':sum(r['gueltig_ausgefuehrt'] and not r['test_bestanden'] and r['pytest_rc']==1 for r in faelle[4:]),'kammern':len(faelle),'kammerdauer_s':sum(r['kammer']['dauer_s'] for r in faelle),'schutz':schutz,'kasse':kasse,'budget_eur':2,'neue_biotop_modellkosten_eur':sum(x['neue_eur'] for x in kasse),'review_zum_auswertungszeitpunkt_offen':True,'folgerest_ansage':{'abweichungen':danach['ansageabweichungen'],'nenner':danach['anzahl'],'wertungsautor':'Philipp','wertung':'Vorab-Ansage als Filter entwertet; fünfte Wiederkehr der Fehlerklasse Ankündigung statt Sache','zeitpunkt':'Eigener Auftrag nach Vorbedingung 2','in_diesem_nachtrag_bearbeitet':False}}
result['enger_ausfuehrungsanteil_erfuellt']=bool(result['korrigiert_bestanden']==2 and result['gegenproben_gueltig_fehlgeschlagen']==2 and danach['unter_20_prozent'] and all(schutz.values()))
dump(B/'AUSWERTUNG.json',result);dump(B/'BESTAND-NACHHER.json',neu)
print(json.dumps({k:v for k,v in result.items() if k not in ('historische_quote','nachtragsquote','quellen_korrigiert','kasse')},ensure_ascii=False,indent=2));print(json.dumps({'quote_vorher':{k:v for k,v in vor.items() if k!='tests'},'quote_nachher':{k:v for k,v in danach.items() if k!='tests'}},ensure_ascii=False))
