"""Enger Nachtrag: gebundene Originale lesen, nur separate Kopien erzeugen."""
from pathlib import Path
import sys,sqlite3,json,hashlib,tarfile,datetime,shutil,subprocess,os,grp,urllib.request
sys.dont_write_bytecode=True
sys.path.insert(0,'/root/biotop')
from biotop.organe import aegis,lazarus
P=Path('/root/phase-4-vorbedingung-1');N=P/'nachtrag-01';R=Path('/root/biotop')
O=Path('/var/pruefkanal/oeffentlich/_akte/3qfc8gxpdvjsqxcbuj39mupe92a82agy/laeufe/biotop-phase-4-vorbedingung-1/nach-reparatur-02/abschluss-02')
ALT=O.parent/'abschluss-01';URL='https://milieulux-reinigung-muenchen.de/_akte/3qfc8gxpdvjsqxcbuj39mupe92a82agy/laeufe/biotop-phase-4-vorbedingung-1/nach-reparatur-02/abschluss-02/'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def dbstand(p):
    with sqlite3.connect(f'file:{p}?mode=ro',uri=True) as c:
        c.row_factory=sqlite3.Row
        return {'pfad':str(p),'dump_sha256':hashlib.sha256('\n'.join(c.iterdump()).encode()).hexdigest(),'kasse':dict(c.execute('select count(*) anzahl,max(id) letzte_id,sum(kosten_eur) summe_eur from kasse').fetchone())}
def bestand():
    aa=json.loads((P/'AUSGANG.json').read_text())
    werkpfade=[P/'privat/werkquelle',Path(aa['produktives_werk'])]
    with sqlite3.connect(f'file:{P}/privat/biotop.db?mode=ro',uri=True) as c:werkpfade.append(Path(c.execute('select pfad from werke where id=23').fetchone()[0]))
    return {'produktquellen':{str(f.relative_to(R)):sha(f) for d in ('biotop','pruefung','tests') for f in sorted((R/d).rglob('*.py'))},'dbs':[dbstand(p) for p in (R/'daten/biotop.db',P/'privat/biotop.db')], 'werke':{str(w):{str(f.relative_to(w)):sha(f) for f in sorted(w.rglob('*')) if f.is_file()} for w in werkpfade},'altlieferung':{f.name:sha(f) for f in ALT.iterdir() if f.is_file()},'ursprungsangriffe_sha256':sha(P/'belege/angriffe.jsonl')}
if __name__=='__main__':
    assert not (N/'AUSGANG.json').exists() and not O.exists(),'Kein Überschreiben vorheriger Arbeit'
    for name in ('belege','privat','review','entwurf'):(N/name).mkdir(exist_ok=True)
    out=bestand();out.update({'zeit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'budget_eur':2,'reviewzeitlimit_s':1800,'review_abschlussreserve_ab_s':1500,'biotop_modellaufrufe_erlaubt':0,'messplan_sha256':sha(N/'MESSPLAN.md')})
    c=sqlite3.connect(f'file:{P}/privat/biotop.db?mode=ro',uri=True);c.row_factory=sqlite3.Row
    la=dict(c.execute('select id,archiv,pruefsumme from lazarus where lauf_id=26 and generation=0').fetchone());k=dict(c.execute('select id,generation,diff,status,grund,masse from kandidaten where id=2689').fetchone())
    out['lazarus_gen0']={**la,'archiv_sha256':sha(Path(la['archiv']))}
    basis=N/'privat/basis';basis.mkdir()
    with tarfile.open(la['archiv']) as tar:
        for m in tar.getmembers():assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts,m.name
        tar.extractall(basis,filter='data')
    gemessen,anzahl=lazarus.pruefsumme_werk(basis)
    assert gemessen==la['pruefsumme'],'Lazarus-Werkbindung verletzt'
    out['lazarus_gen0']['werkbindung']={'gemessen':gemessen,'dateien':anzahl,'identisch':True}
    aenderungen=aegis.kandidat_dateien(basis,k['diff']);assert aenderungen and all(isinstance(v,str) for v in aenderungen.values())
    gespeichert=json.loads(k.pop('masse'))['_dateien'];assert aenderungen==gespeichert,'Originaler Kandidat nicht exakt rekonstruiert'
    kandidat=N/'privat/kandidat';shutil.copytree(basis,kandidat)
    for rel,text in aenderungen.items():(kandidat/rel).write_text(text)
    dump(N/'belege/KANDIDAT.json',{**k,'dateien':aenderungen,'rekonstruktion_identisch_zu_db':True})
    angriffe=[json.loads(l) for l in (P/'belege/angriffe.jsonl').read_text().splitlines()]
    treffer=[a for a in angriffe if a.get('kandidat')==2689 and a['art']=='ergebnis'];assert len(treffer)==1
    dump(N/'belege/K2689-ORIGINAL.json',treffer[0]);(N/'belege/K2689-original.py').write_text(treffer[0]['code'])
    assert treffer[0]['code'].count('FormelFehemer')==1
    out['basis_dateien']={str(f.relative_to(basis)):sha(f) for f in sorted(basis.rglob('*')) if f.is_file()}
    out['kandidat_dateien']={str(f.relative_to(kandidat)):sha(f) for f in sorted(kandidat.rglob('*')) if f.is_file()}
    out['docker_image']=subprocess.run(['docker','image','inspect','biotop-kammer:1','--format','{{.Id}}'],capture_output=True,text=True,check=True).stdout.strip()
    dump(N/'AUSGANG.json',out)
    O.mkdir();(O/'MESSPLAN.md').write_bytes((N/'MESSPLAN.md').read_bytes())
    (O/'ZWISCHENBERICHT.md').write_text('# Enger Nachtrag — Arbeitsstand\n\nNoch keine Abnahme. K2689-Ausführungsnachtrag und ein vollständiger Review offen. Keine Produktänderung, kein natürlicher Laufneustart. Die 9-von-11-Ansageabweichung bleibt eigener Folgeauftrag nach Vorbedingung 2.\n')
    (O/'KASSE.md').write_text('# Kasse\n\n2,00 EUR hart für neue Biotop-Modellaufrufe. Keine solchen Aufrufe geplant oder erlaubt. Kassen-Ausgang und Schutzbelege in der privaten AUSGANG.json. Träger-/Reviewer-/Hostkosten monetär nicht ermittelt.\n')
    (O/'DATEIEN.txt').write_text('ARBEITSSTAND — nicht versiegelt\n'+URL+'\nDATEIEN.txt\nZWISCHENBERICHT.md\nMESSPLAN.md\nKASSE.md\n')
    gid=grp.getgrnam('caddy').gr_gid;os.chown(O,0,gid);os.chmod(O,0o750)
    for f in O.iterdir():
        os.chown(f,0,gid);os.chmod(f,0o640)
        with urllib.request.urlopen(URL+f.name,timeout=30) as r:assert r.read()==f.read_bytes()
    print(json.dumps({'basis_dateien':len(out['basis_dateien']),'kandidat_aus_db_identisch':True,'produktquellen':len(out['produktquellen']),'budget_eur':2,'reviewlimit_s':1800,'entwurf_https_dateien':len(list(O.iterdir()))},ensure_ascii=False))
