"""Tor-2-Zähler: vollständig erfasste, erzeugte Testfunktionen."""
from collections import Counter
import ast
import sys
sys.path.insert(0, '/root/biotop')
from biotop.organe.aegis import behauptung

def zaehlen(angriffe):
    tests, probleme, gesehen = [], [], {}
    for a in angriffe:
        if a.get('art') != 'ergebnis' or a.get('code') is None:
            continue
        ident = f"K{a['kandidat']}@{a['protokoll_vor']}"
        try:baum = ast.parse(a['code'])
        except SyntaxError as e:
            probleme.append({'angriff':ident, 'grund':'Syntaxfehler', 'meldung':str(e)})
            continue
        funktionen = [n for n in ast.walk(baum) if isinstance(n, (ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
        if not funktionen:probleme.append({'angriff':ident,'grund':'Erzeugter Code ohne Testfunktion'})
        namen = Counter(n.name for n in funktionen)
        for i, fn in enumerate(funktionen, 1):
            schl = behauptung(a['code'], fn.name, a['paket'])
            if '?' in schl or len(schl.split('|'))!=2 or not all(schl.split('|')) or namen[fn.name]>1 or isinstance(fn,ast.AsyncFunctionDef):
                probleme.append({'angriff':ident,'test':fn.name,'grund':'Behauptung nicht eindeutig mit vorhandenem Schlüssel ableitbar','schluessel':schl})
            gruppe = (a['bereich'],schl)
            zeile = {'id':f'{ident}:{i}:{fn.name}','kandidat':a['kandidat'],'protokoll_vor':a['protokoll_vor'],'bereich':a['bereich'],
                     'test':fn.name,'schluessel':schl,'doppelung':gruppe in gesehen,'erste_erzeugte':gesehen.get(gruppe),
                     'bereits_im_vorrat':schl in a['vorrat_vor'],'ansage':a['ansage'],'abweichung_von_ansage':schl!=a['ansage']}
            tests.append(zeile);gesehen.setdefault(gruppe,zeile['id'])
    n=len(tests);d=sum(t['doppelung'] for t in tests)
    return {'tests':tests,'anzahl':n,'behauptungen':len(gesehen),'doppelungen':d,'anteil_prozent':100*d/n if n else None,
            'unter_20_prozent':bool(n and not probleme and d*5<n),'probleme':probleme,
            'gegen_vorrat':sum(t['bereits_im_vorrat'] for t in tests),'ansageabweichungen':sum(t['abweichung_von_ansage'] for t in tests)}
