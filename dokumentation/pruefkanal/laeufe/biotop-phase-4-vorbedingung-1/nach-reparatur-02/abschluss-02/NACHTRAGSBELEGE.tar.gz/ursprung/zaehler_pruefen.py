"""Gestellte Zählerkontrolle, getrennt vom natürlichen Lauf."""
import json
from pathlib import Path
from zaehlen import zaehlen

def angriff(kandidat,ziel):
    return {'art':'ergebnis','kandidat':kandidat,'bereich':'lager','paket':'lagerhaus','protokoll_vor':kandidat,'vorrat_vor':[],
            'ansage':f'{ziel}|Eq:zahl','code':f'def test_wert():\n    assert {ziel}() == 1\n'}
# Zwei identische Behauptungen plus vier andere: eine Doppelung von sechs Funktionen.
a=[angriff(i,z) for i,z in enumerate(['wert','wert','b','c','d','e'],1)]
r=zaehlen(a)
assert r['anzahl']==6 and r['doppelungen']==1,r
assert len(r['tests'])==6 and len({x['id'] for x in r['tests']})==6,r
assert r['unter_20_prozent'] is True,r
# Derselbe Nenner, zwei Wiederholungen: echte Gegenkontrolle über der Grenze.
a[2]=angriff(3,'wert');r2=zaehlen(a)
assert r2['anzahl']==6 and r2['doppelungen']==2 and r2['unter_20_prozent'] is False,r2
# Kein Gegenstand und syntaktisch kaputtes Modellprodukt dürfen nicht grün werden.
r0=zaehlen([]);rb=zaehlen([{**angriff(1,'wert'),'code':'def test_kaputt(:'}])
assert r0['anteil_prozent'] is None and not r0['unter_20_prozent'],r0
assert rb['probleme'] and not rb['unter_20_prozent'],rb
print(json.dumps({'art':'gestellte Zählerkontrollen, keine natürliche Wirkung','positiv':r,'gegenkontrolle':r2,'leer':r0,'kaputter_code':rb},ensure_ascii=False,indent=2))
