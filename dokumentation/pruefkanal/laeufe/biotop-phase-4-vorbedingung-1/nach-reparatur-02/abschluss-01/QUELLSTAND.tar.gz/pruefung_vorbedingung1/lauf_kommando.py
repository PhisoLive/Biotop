"""Native CLI auf Privatbestand; vorab festgelegter passiver Mitschnitt."""
from pathlib import Path
import os, sys, json, hashlib, time, traceback, gzip
P=Path('/root/phase-4-vorbedingung-1');R=Path('/root/biotop');B=P/'belege'
A=json.loads((P/'AUSGANG.json').read_text())
os.environ.update(BIOTOP_DB=str(P/'privat/biotop.db'),BIOTOP_AUFTRAG_LAUF_AB=str(A['erster_neuer_lauf']),BIOTOP_AUFTRAG_BUDGET_EUR='3',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(P/'temp'),PYTHONPATH=str(R))
sys.path.insert(0,str(R));sys.dont_write_bytecode=True
assert all(hashlib.sha256((R/n).read_bytes()).hexdigest()==h for n,h in A['quellen'].items()), 'Quellwechsel: Messung nicht fortsetzen'
phase=os.environ['MESSPHASE']
def prot(datei,obj):
    with (B/datei).open('a') as f:f.write(json.dumps({'phase':phase,**obj},ensure_ascii=False,default=str)+'\n')
from biotop import anbieter
from biotop.kern import kasse
katalog={x['id']:x for x in json.loads((B/'modellkatalog.json').read_text())['data']}
budgetpfad=B/'budget-obergrenze.json'
if not budgetpfad.exists():budgetpfad.write_text(json.dumps({'obergrenze_eur':0.0,'aufrufe':0,'offene_reservierungen':[]}))
original_aufrufen=anbieter.aufrufen
def aufrufen(con,lauf_id,anbietername,modell,system,nutzer,zweck,max_tokens=4000,temperatur=0.2):
    assert lauf_id>=A['erster_neuer_lauf'], 'Kein Aufruf auf historischer Lauf-ID'
    preise=katalog[modell]['pricing'];Varianten=[preise]+preise.get('overrides',[])
    p_e=max(float(x.get('prompt',preise['prompt'])) for x in Varianten)
    p_a=max(float(x.get('completion',preise['completion'])) for x in Varianten)
    # Konservativ: UTF-8-Bytes plus Formatreserve, höchste veröffentlichte Preisvariante.
    reserve=((len((system+nutzer).encode())+2048)*p_e+max_tokens*p_a)/kasse.USD_JE_EUR
    bud=json.loads(budgetpfad.read_text())
    if bud['obergrenze_eur']+reserve>3:
        prot('modellaufrufe.jsonl',{'art':'budget_vorab_gesperrt','modell':modell,'zweck':zweck,'bisher_obergrenze_eur':bud['obergrenze_eur'],'reserve_eur':reserve})
        raise kasse.BudgetErschoepft('Harte 3-Euro-Auftragsgrenze einschließlich konservativer Preis-/Tokenreserve')
    nummer=bud['aufrufe']+1
    bud['aufrufe']=nummer;bud['obergrenze_eur']+=reserve;bud['offene_reservierungen'].append(nummer)
    budgetpfad.write_text(json.dumps(bud,ensure_ascii=False,indent=2)+'\n')
    basis={'nr':nummer,'lauf_id':lauf_id,'modell':modell,'zweck':zweck,'max_tokens':max_tokens,'temperatur':temperatur,'reserve_eur':reserve,'prompt_preis_max':p_e,'completion_preis_max':p_a}
    prot('modellaufrufe.jsonl',{**basis,'art':'anfragematerial','system':system,'nutzer':nutzer})
    t=time.monotonic()
    try:r=original_aufrufen(con,lauf_id,anbietername,modell,system,nutzer,zweck,max_tokens,temperatur)
    except BaseException as e:
        prot('modellaufrufe.jsonl',{**basis,'art':'fehler','fehler':str(e),'dauer_s':time.monotonic()-t})
        raise
    obere_kosten=(r.tokens_ein*p_e+r.tokens_aus*p_a)/kasse.USD_JE_EUR
    prot('modellaufrufe.jsonl',{**basis,'art':'antwort','antwort':r.text,'tokens_ein':r.tokens_ein,'tokens_aus':r.tokens_aus,'gebucht_eur':r.kosten_eur,'obere_kosten_eur':obere_kosten,'protokoll_nr':r.protokoll_nr,'dauer_s':time.monotonic()-t})
    if r.tokens_ein<=0 or r.tokens_aus<0 or obere_kosten>reserve:
        raise RuntimeError('Token-/Reservierungsbeleg ungültig; Messlauf stoppen')
    bud['obergrenze_eur']+=obere_kosten-reserve;bud['offene_reservierungen'].remove(nummer)
    budgetpfad.write_text(json.dumps(bud,ensure_ascii=False,indent=2)+'\n')
    return r
anbieter.aufrufen=aufrufen
from biotop.organe import aufnahme,lazarus,aegis,kammer
aufnahme.WERKE=P/'privat/werke';lazarus.ARCHIV=P/'privat/lazarus'
original_angriff=aegis._angriff
def angriff(con,lauf_id,werk_id,paket,bereich,diff,dateien,werk,klassen,**kw):
    vorrat=aegis.bisherige_behauptungen(con,werk_id,bereich,lauf_id,limit=None)
    vor=con.execute('SELECT COALESCE(MAX(nr),0) FROM protokoll').fetchone()[0]
    basis={'lauf_id':lauf_id,'werk_id':werk_id,'kandidat':kw.get('kandidat_id'),'bereich':bereich,'paket':paket,'protokoll_vor':vor,'vorrat_vor':vorrat}
    prot('angriffe.jsonl',{**basis,'art':'beginn'})
    try:r=original_angriff(con,lauf_id,werk_id,paket,bereich,diff,dateien,werk,klassen,**kw)
    except BaseException as e:
        prot('angriffe.jsonl',{**basis,'art':'fehler','fehler':str(e)})
        raise
    prot('angriffe.jsonl',{**basis,'art':'ergebnis','code':r[0],'modell':r[1],'ansage':r[2],'ansage_kontext':kw.get('ansage_kontext'),'protokoll_nach':con.execute('SELECT MAX(nr) FROM protokoll').fetchone()[0]})
    return r
aegis._angriff=angriff
from biotop.__main__ import main
rc=1;t=time.monotonic()
with kammer.zaehlung() as zaehler:
    try:rc=main(sys.argv[1:])
    except BaseException:
        traceback.print_exc();rc=1
    finally:
        with gzip.open(B/'kammern.jsonl.gz','at',encoding='utf-8') as f:
            for e in zaehler:f.write(json.dumps({'phase':phase,**e},ensure_ascii=False)+'\n')
        prot('kommandos.jsonl',{'argumente':sys.argv[1:],'rc':rc,'kammerlaeufe':len(zaehler),'dauer_s':time.monotonic()-t})
sys.exit(rc)
