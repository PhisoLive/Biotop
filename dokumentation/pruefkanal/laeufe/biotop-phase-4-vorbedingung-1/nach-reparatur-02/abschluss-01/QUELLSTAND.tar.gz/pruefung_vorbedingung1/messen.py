"""Ein neuer natürlicher Messlauf, keine Ergebnisauswahl und kein automatischer Neustart."""
from pathlib import Path
import os,sys,json,sqlite3,subprocess,time,traceback,re,hashlib
P=Path('/root/phase-4-vorbedingung-1');B=P/'belege';A=json.loads((P/'AUSGANG.json').read_text())
PY='/root/reparatur-01/venv/bin/python'
DB=P/'privat/biotop.db'
def con():
    c=sqlite3.connect(f'file:{DB}?mode=ro',uri=True);c.row_factory=sqlite3.Row;return c
schritte=[];lid=None;wid=None;zaehler=0
assert not (B/'laufabschluss.json').exists()
mechanik=json.loads((B/'bauteile.json').read_text())
assert mechanik['rc']==0 and mechanik['sammlung'] and all(x['outcome']=='passed' for x in mechanik['berichte'])
def kommando(name,*args):
    global zaehler
    zaehler+=1;phase=f'{zaehler:02d}-{name}';t=time.monotonic()
    with con() as c:vor=c.execute('SELECT MAX(nr) FROM protokoll').fetchone()[0]
    cmd=[PY,str(P/'lauf_kommando.py'),*[str(x) for x in args]]
    with (B/(phase+'.stdout.txt')).open('x') as out,(B/(phase+'.stderr.txt')).open('x') as err:
        r=subprocess.run(cmd,cwd='/root/biotop',env=dict(os.environ,MESSPHASE=phase),stdout=out,stderr=err,timeout=3600)
    with con() as c:
        modellfehler=[dict(x) for x in c.execute("SELECT nr,inhalt FROM protokoll WHERE nr>? AND art='modell.fehler'",(vor,))]
        kosten=dict(c.execute('SELECT COUNT(*) aufrufe,COALESCE(SUM(kosten_eur),0) euro FROM kasse WHERE id>?',(A['kasse']['max_id'],)).fetchone())
    s={'phase':phase,'befehl':cmd,'rc':r.returncode,'dauer_s':time.monotonic()-t,'modellfehler':modellfehler,'kasse':kosten}
    schritte.append(s);print(json.dumps(s,ensure_ascii=False),flush=True)
    if r.returncode or modellfehler:raise RuntimeError(f'{phase}: Exit {r.returncode}, {len(modellfehler)} Modellfehler; keine Fortsetzung')
    return json.loads((B/(phase+'.stdout.txt')).read_text())
try:
    lid=kommando('anlegen','lauf','anlegen','--budget','3')['lauf']
    assert lid==A['erster_neuer_lauf']
    kommando('aufnahme','einlegen',lid,f'lagerhaus-vorbedingung1-{lid}',P/'privat/werkquelle')
    kommando('landkarte','kartieren',lid)
    with con() as c:
        wid=c.execute('SELECT werk_id FROM laeufe WHERE id=?',(lid,)).fetchone()[0]
        v=dict(c.execute('SELECT * FROM verfassung_werk WHERE werk_id=22').fetchone())
    (P/'privat/verfassung.md').write_text(v['text']);(P/'privat/verfassung.regeln.json').write_text(v['regeln'])
    kommando('verfassung','verfassung',lid,P/'privat/verfassung.md',P/'privat/verfassung.regeln.json','--von','Hermes: unverändert bestätigter Anhang A, Übungswerk-Vollmacht')
    kommando('vertraege','vertraege',lid,P/'privat/werkquelle/tests/vertraege','--von','Hermes: unveränderte bestätigte Übungswerkverträge')
    kommando('vorspann','vorspann',lid)
    g0=kommando('gen0','gen0',lid)
    assert g0.get('erreicht') is True and g0.get('nicht_aequivalent',0)>0, 'Gen0-Ziel nicht erreicht; kein Freeze trotz existierendem Ereignis'
    kommando('mass','mass',lid,'--bestaetigt-von','Hermes unter Übungswerk-Vollmacht')
    # Lesende Vorlage zum identischen Zeitpunkt unmittelbar vor dem einmaligen Mentor.
    os.environ.update(BIOTOP_DB=str(DB),PYTHONDONTWRITEBYTECODE='1');sys.path.insert(0,'/root/biotop');sys.dont_write_bytecode=True
    from biotop.organe import gedaechtnis
    c=sqlite3.connect(DB,isolation_level=None);c.row_factory=sqlite3.Row
    text=gedaechtnis.art_text(c,wid);ids=[int(x) for x in re.findall(r'\[A(\d+)\]',text)]
    vorlage={'werk_id':wid,'werkname':gedaechtnis.werkname(c,wid),'text':text,'ids':ids,'eintraege':[dict(c.execute('SELECT * FROM artgedaechtnis WHERE id=?',(i,)).fetchone()) for i in ids]}
    c.close();(B/'mentor-vorlage.json').write_text(json.dumps(vorlage,ensure_ascii=False,indent=2)+'\n')
    m=kommando('mentor','mentor',lid)
    rs=m['richtungen'];wahl=next((r for r in rs if r['name']==m.get('empfehlung') and r.get('bereiche') and 'sättigung' not in r['name'].lower()),None)
    if wahl is None:wahl=next((r for r in rs if r.get('bereiche') and 'sättigung' not in r['name'].lower()),None)
    assert wahl is not None, 'Mentor hat keine ausführbare Richtung angeboten'
    (B/'richtungswahl.json').write_text(json.dumps({'von':'Hermes unter Übungswerk-Vollmacht','empfehlung':m.get('empfehlung'),'gewaehlt':wahl['name'],'regel':'ausführbare Empfehlung, sonst erste ausführbare Richtung in Antwortreihenfolge'},ensure_ascii=False,indent=2)+'\n')
    kommando('richtung','richtung',lid,wahl['name'],'--von','Hermes unter Übungswerk-Vollmacht')
    ende='Hoechstzahl sechs Generationen'
    for nummer in range(1,7):
        with con() as c:status=c.execute('SELECT status FROM laeufe WHERE id=?',(lid,)).fetchone()[0]
        if status=='gesaettigt':ende='Natürliche Sättigung';break
        if status not in ('bereit','laeuft'):raise RuntimeError(f'Laufstatus {status}: keine neue Generation')
        g=kommando(f'generation-{nummer}','generation',lid)
        if g['status']=='vorgelegt':
            kommando(f'freigabe-{nummer}','freigabe',lid,g['nummer'],'frei','--von','Hermes unter Übungswerk-Vollmacht','--grund','Native harte Generalprobe bestanden; keine neue Regel und kein echtes Werk')
        elif g['status']!='abgelehnt':raise RuntimeError(f'Unerwarteter Generationsstatus {g["status"]}')
    with con() as c:
        status=c.execute('SELECT status FROM laeufe WHERE id=?',(lid,)).fetchone()[0]
    if status=='gesaettigt':ende='Natürliche Sättigung'
    elif status=='bereit':kommando('messende','abbrechen',lid,'--grund','Vorab festgelegtes Messende nach höchstens sechs Generationen','--von','Hermes','--art','sonst')
    ergebnis={'erfolgreich_ausgefuehrt':True,'ende':ende}
except BaseException as e:
    traceback.print_exc();ergebnis={'erfolgreich_ausgefuehrt':False,'fehler':str(e),'fehlertyp':type(e).__name__}
    if lid is not None:
        try:kommando('abbruch','abbrechen',lid,'--grund','Vorbedingung-1-Messlauf gestoppt: '+str(e)[:300],'--von','Hermes','--art','sonst')
        except BaseException as ende:ergebnis['abbruch_fehler']=str(ende)
finally:
    with con() as c:
        kasse=[dict(x) for x in c.execute('SELECT * FROM kasse WHERE id>? ORDER BY id',(A['kasse']['max_id'],))]
    ergebnis.update(lauf_id_nur_privat=lid,werk_id_nur_privat=wid,schritte=schritte,kasse=kasse,gebucht_eur=sum(x['kosten_eur'] for x in kasse))
    (B/'laufabschluss.json').write_text(json.dumps(ergebnis,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in ergebnis.items() if k not in ('schritte','kasse')},ensure_ascii=False,indent=2),flush=True)
sys.exit(0 if ergebnis['erfolgreich_ausgefuehrt'] else 1)
