"""Nach dem Messende: Torzeilen aus echten Rohbelegen und Privat-DB ableiten."""
from pathlib import Path
from collections import Counter
import sqlite3,json,re,hashlib,ast,gzip,sys
sys.dont_write_bytecode=True
from zaehlen import zaehlen
P=Path('/root/phase-4-vorbedingung-1');B=P/'belege';R=Path('/root/biotop')
A=json.loads((P/'AUSGANG.json').read_text());E=json.loads((B/'laufabschluss.json').read_text());lid=E['lauf_id_nur_privat'];wid=E['werk_id_nur_privat']
def laden(n,default=None):return json.loads((B/n).read_text()) if (B/n).exists() else default
def zeilen(n):return [json.loads(x) for x in (B/n).read_text().splitlines()] if (B/n).exists() else []
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def baum(p):return {str(f.relative_to(p)):sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
c=sqlite3.connect(f'file:{P}/privat/biotop.db?mode=ro',uri=True);c.row_factory=sqlite3.Row
qs={}
for tab,feld,wert in [('laeufe','id',lid),('werke','id',wid),('generationen','lauf_id',lid),('kandidaten','lauf_id',lid),('immunsystem','werk_id',wid),('vorspann_nachweise','lauf_id',lid),('verfassung_werk','werk_id',wid),('vertraege_explizit','werk_id',wid),('eichgegenstand','werk_id',wid),('mentor','lauf_id',lid),('lazarus','lauf_id',lid)]:
    # Tabellen- und Spaltennamen stammen ausschließlich aus der konstanten Liste oben.
    vorhanden=c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(tab,)).fetchone()
    qs[tab]=[dict(x) for x in c.execute(f'SELECT * FROM {tab} WHERE {feld}=?',(wert,))] if vorhanden else []
qs['kasse']=[dict(x) for x in c.execute('SELECT * FROM kasse WHERE id>? ORDER BY id',(A['kasse']['max_id'],))]
pro=[dict(x) for x in c.execute("SELECT * FROM protokoll WHERE json_extract(inhalt,'$.lauf_id')=? OR json_extract(inhalt,'$.werk_id')=? ORDER BY nr",(lid,wid))]
qs['protokoll']=pro
with gzip.open(B/'DB-AUSZUG.json.gz','wt',encoding='utf-8') as f:json.dump(qs,f,ensure_ascii=False,indent=2)
ang=zeilen('angriffe.jsonl');ang_end=[a for a in ang if a['art']=='ergebnis'];mk=zeilen('modellaufrufe.jsonl')
z=zaehlen(ang)
pd=[{**x,'daten':json.loads(x['inhalt'])} for x in pro]
ans=[x for x in pd if x['art']=='aegis.ansage'];entscheidungen=[]
for a in ang_end:
    treffer=[x for x in ans if a['protokoll_vor']<x['nr']<=a['protokoll_nach'] and x['daten'].get('kandidat')==a['kandidat'] and x['daten'].get('bereich')==a['bereich']]
    if len(treffer)!=1:entscheidungen.append({'kandidat':a['kandidat'],'fehler':'Ansagezuordnung nicht eindeutig','anzahl':len(treffer)});continue
    x=treffer[0];d=x['daten'];erwartet=bool(d.get('behauptung') and d['behauptung'] not in a['vorrat_vor'])
    art='zugelassen' if d['ausgefuehrt'] else ('bekannt_gesperrt' if d.get('behauptung') else 'ohne_behauptung')
    antworten=[m for m in mk if m['art']=='antwort' and a['protokoll_vor']<m['protokoll_nr']<=a['protokoll_nach']]
    entscheidungen.append({'kandidat':a['kandidat'],'bereich':a['bereich'],'protokoll_nr':x['nr'],'behauptung':d.get('behauptung'),'art':art,
                          'vorrat_groesse':len(a['vorrat_vor']),'entscheidung_richtig':d['ausgefuehrt']==erwartet,
                          'modellaufrufe':[{'protokoll_nr':m['protokoll_nr'],'zweck':m['zweck']} for m in antworten],
                          'angriff_generiert':a['code'] is not None})
verteilung=dict(Counter(x.get('art','zuordnungsfehler') for x in entscheidungen))
vorlage=laden('mentor-vorlage.json');mentor=next((json.loads((B/(s['phase']+'.stdout.txt')).read_text()) for s in E['schritte'] if s['phase'].endswith('-mentor') and s['rc']==0),None)
bwert={'vorlage':vorlage is not None,'mentor_ausgefuehrt':mentor is not None,'mindestanteil_erfuellt':False,'richtungen_mit_fremdverweis':0,'richtungen_gesamt':0,'verweise':[],'ungueltige_verweise':[]}
if vorlage is not None:
    eigenes=vorlage['werkname'];fremd=[x for x in vorlage['eintraege'] if x['werk']!=eigenes];eigen=[x for x in vorlage['eintraege'] if x['werk']==eigenes]
    # Fremdpopulation bleibt durch einen reinen lagerhaus-Lauf unverändert. Quellenliste mitliefern.
    population=[dict(x) for x in c.execute("SELECT * FROM artgedaechtnis WHERE werk!=? AND ergebnis='angenommen' AND muster IS NOT NULL AND trim(muster)!='' ORDER BY id DESC",(eigenes,))]
    eindeutig={x['muster'].lower()[:80] for x in population};gesamt=len(fremd)+len(eigen)
    mindest=min(len(eindeutig),max(5,(gesamt+1)//2))
    bwert.update(fremd_gezeigt=len(fremd),eigen_gezeigt=len(eigen),gesamt_gezeigt=gesamt,fremde_muster_verfuegbar=len(eindeutig),mindestzahl=mindest,
                 fremde_ids=[x['id'] for x in fremd],eigene_ids=[x['id'] for x in eigen],mindestanteil_erfuellt=len(fremd)>=mindest)
    (B/'FREMDMUSTER-QUELLEN.json').write_text(json.dumps(population,ensure_ascii=False,indent=2)+'\n')
    if mentor is not None:
        gezeigt={f"A{x['id']}":x for x in vorlage['eintraege']};fremdid={f"A{x['id']}" for x in fremd}
        bwert['richtungen_gesamt']=len(mentor['richtungen'])
        for r in mentor['richtungen']:
            refs=list(r.get('artgedaechtnis') or [])+list(r.get('projektgedaechtnis') or [])
            gut=[x for x in refs if x in fremdid]
            bwert['richtungen_mit_fremdverweis']+=bool(gut)
            bwert['verweise'].append({'richtung':r['name'],'fremd':gut,'eigen':[x for x in refs if x in gezeigt and x not in fremdid]})
            bwert['ungueltige_verweise'] += [{'richtung':r['name'],'id':x} for x in refs if x not in gezeigt]
        material=[x for x in mk if x['art']=='anfragematerial' and x['zweck']=='schwer.mentor']
        bwert['vorlage_im_originalen_aufruf']=len(material)==1 and vorlage['text'] in material[0]['nutzer']
        bwert['tor_verweis_erfuellt']=bool(bwert['richtungen_mit_fremdverweis']>=1 and not bwert['ungueltige_verweise'] and bwert['vorlage_im_originalen_aufruf'])
gens=[]
for g in sorted(qs['generationen'],key=lambda g:g['nummer']):
    if g['status']!='angenommen':continue
    m=json.loads(g['masse']) if g['masse'] else {};w=m.get('werk',{});bs=m.get('bereiche',{})
    zahlen_vollstaendig=bool(bs) and all(all(type(v.get(k)) is int for k in ('tests_bestanden','tests_fehlgeschlagen','tests_gesamt')) for v in bs.values())
    total=sum(v['tests_gesamt'] for v in bs.values()) if zahlen_vollstaendig else None
    bestanden=sum(v['tests_bestanden'] for v in bs.values()) if zahlen_vollstaendig else None
    fehl=sum(v['tests_fehlgeschlagen'] for v in bs.values()) if zahlen_vollstaendig else None
    raw=re.search(r'(?m)^(\d+) passed(?:,|\s|$)',w.get('pytest_tail',''))
    roh_bestanden=int(raw.group(1)) if raw else None
    stimmig=bool(zahlen_vollstaendig and not w.get('tests_ohne_bereich') and bestanden==roh_bestanden and total==bestanden+fehl)
    gens.append({'generation':g['nummer'],'pruefsumme':g['pruefsumme'],'gueltig':m.get('gueltig'),'tests_bestanden':bestanden,
                 'tests_fehlgeschlagen':fehl,'tests_gesamt':total,'pytest_rc':w.get('pytest_rc'),'pytest_rohausgabe':w.get('pytest_tail'),
                 'zaehlung_stimmig':stimmig,'baut':w.get('baut'),'besteht':bool(stimmig and total and m.get('gueltig') is True and w.get('pytest_rc')==0 and fehl==0)})
immun=[]
werk=Path(qs['werke'][0]['pfad']) if qs['werke'] else None
for x in qs['immunsystem']:
    pfad=f"tests/test_{x['bereich']}_immun_{x['name']}.py";f=werk/pfad if werk else None
    immun.append({'id':x['id'],'name':x['name'],'status':x['status'],'bereich':x['bereich'],'ursprung':x['ursprung'],'datei':pfad,
                  'datei_vorhanden':bool(f and f.exists()),'datei_sha256':sha(f) if f and f.exists() else None})
kandidaten=[x for x in qs['kandidaten'] if not x.get('ist_probe')]
aufteilung=dict(Counter(x['status'] for x in kandidaten))
assert sum(aufteilung.values())==len(kandidaten)
fehlerdateien=[{'datei':f.name,'inhalt':f.read_text()} for f in sorted(B.glob('*.stderr.txt')) if f.stat().st_size]
with sqlite3.connect('file:/root/biotop/daten/biotop.db?mode=ro',uri=True) as prod:
    dbhash=hashlib.sha256('\n'.join(prod.iterdump()).encode()).hexdigest()
schutz={'produktive_db_unveraendert':dbhash==A['produktive_db_dump_sha256'],'produktives_werk_unveraendert':baum(Path(A['produktives_werk']))==A['produktives_werk_hashes'],
        'werkquelle_unveraendert':baum(Path(A['werkquelle']))==A['werkquelle_hashes'],'quellen_unveraendert':all(sha(R/n)==h for n,h in A['quellen'].items())}
result={'auftrag':'Phase 4 Vorbedingung 1 nach Reparatur-02','lauf_id_nur_privat':lid,'werk_id_nur_privat':wid,'laufabschluss':{k:v for k,v in E.items() if k not in ('kasse','schritte')},
        'bauteiltests':{'gesammelt':len(laden('bauteile.json')['sammlung']),'rc':laden('bauteile.json')['rc']},'bauteil_a':{'ansagen':len(ans),'entscheidungen':entscheidungen,'aufschluesselung':verteilung},
        'tor2_zeile8_doppelungsanteil':z,'bauteil_b':bwert,'angenommene_generationen':gens,'immuntests':immun,'kandidaten':{'gesamt':len(kandidaten),'aufschluesselung':aufteilung},
        'fehlerausgaben':fehlerdateien,'schutz':schutz,'budget_obergrenze':laden('budget-obergrenze.json'),'offen':['19 Außenleserorte','Vier Phase-4-Lücken: Wirkungskreis, Vertragsbindung, bereichsweiser Rauschfehler, Gen0-Freeze-Bindung']}
(B/'TORZEILEN.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k in ('lauf_id_nur_privat','bauteiltests','bauteil_b','kandidaten','schutz','budget_obergrenze')},ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in z.items() if k!='tests'},ensure_ascii=False,indent=2))
c.close()
