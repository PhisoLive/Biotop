"""Vollständige Schlussdiagnosen, ausschließlich aus vorhandenen Laufbelegen."""
from pathlib import Path
from collections import Counter,defaultdict
import sqlite3,json,re,subprocess,datetime,gzip,hashlib
P=Path('/root/phase-4-vorbedingung-1'); B=P/'belege'
def laden(n):return json.loads((B/n).read_text())
def zeilen(n):return [json.loads(x) for x in (B/n).read_text().splitlines()]
def dump(n,x):(B/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def gruppe(status,grund):
    if status=='leer':return 'kein Vorschlag (keine inhaltliche Ablehnung)'
    if status!='abgelehnt':return 'Status '+status
    if grund.startswith('Kammer (Kandidat): Kammer abgebrochen'):return 'Ausführungsabbruch (kein fachlicher Kill)'
    for p,n in [('Wiederholung eines gescheiterten Wegs','Projektgedächtnis-Wiederholung'),('Pareto verletzt','Pareto-Verletzung'),('Grenzmaß gerissen','Grenzmaß-Verletzung'),('Diff nicht anwendbar','Diff nicht anwendbar'),('Diff berührt fremde Dateien','Diff außerhalb des erlaubten Bereichs'),('Kernmaß unverändert','kein Kernmaßgewinn'),('Nische schnell: Laufzeit nicht','kein ausreichender Laufzeitgewinn')]:
        if grund.startswith(p):return n
    return 'sonstige Ablehnung (Wortlaut beibehalten)'
def zerlegen(rows):
    gs=defaultdict(list);w=defaultdict(list)
    for r in rows:
        gs[gruppe(r['status'],r['grund'] or '')].append(r['id'])
        w[(r['status'],r['grund'])].append(r['id'])
    assert sum(map(len,gs.values()))==len(rows)
    return {'gesamt':len(rows),'status':dict(Counter(r['status'] for r in rows)),
            'gruppen':[{'grundgruppe':k,'anzahl':len(v),'ids':v} for k,v in sorted(gs.items())],
            'wortlaute':[{'status':s,'grund':g,'anzahl':len(ids),'ids':ids} for (s,g),ids in sorted(w.items())]}
e=laden('laufabschluss.json');t=laden('TORZEILEN.json')
c=sqlite3.connect(f'file:{P}/privat/biotop.db?mode=ro',uri=True);c.row_factory=sqlite3.Row
lauf=dict(c.execute('SELECT id,werk_id,status,grund,begonnen_am,beendet_am FROM laeufe WHERE id=26').fetchone())
ps=subprocess.run(['ps','-p','1921606','-o','pid=,stat=,etime=,args='],capture_output=True,text=True)
assert lauf['status'] not in ('laeuft','bereit'),lauf
assert not ps.stdout.strip(),'Messprozess noch aktiv'
ks=[dict(r) for r in c.execute('SELECT * FROM kandidaten WHERE lauf_id=26 ORDER BY id')]
rows=[r for r in ks if not r['ist_probe']];byid={r['id']:r for r in rows}
pr=[dict(r) for r in c.execute("SELECT nr,zeit,art,inhalt FROM protokoll WHERE json_extract(inhalt,'$.lauf_id')=26 OR json_extract(inhalt,'$.werk_id')=? ORDER BY nr",(lauf['werk_id'],))]
for r in pr:r['daten']=json.loads(r.pop('inhalt'))
urs=[r for r in pr if r['art']=='aegis.urteil'];gener=[];alle_haupt=set()
for g in c.execute('SELECT nummer,status,grund,kandidaten FROM generationen WHERE lauf_id=26 ORDER BY nummer'):
    a=json.loads(g['kandidaten']) if g['kandidaten'] else {}
    ids=[r['kandidat'] for k,v in a.items() if not k.startswith('_') and isinstance(v,list) for r in v]
    assert len(set(ids))==len(ids)
    alle_haupt.update(ids)
    gr=[r for r in rows if r['generation']==g['nummer']];extra=[r for r in gr if r['id'] not in ids]
    uu=[u for u in urs if u['daten']['kandidat'] in {r['id'] for r in gr}]
    gener.append({'nummer':g['nummer'],'status':g['status'],'grund':g['grund'],'db_gesamt':zerlegen(gr),'hauptliste':zerlegen([byid[i] for i in ids]),
                  'zusaetzlich':zerlegen(extra),'aegis_urteile':len(uu),'urteile_mit_generiertem_angriff':sum(bool(u['daten'].get('angriff')) for u in uu),
                  'gewaehlte_ids':a.get('_gewaehlt',{}),'generalprobe':a.get('_generalprobe')})
assert sum(x['db_gesamt']['gesamt'] for x in gener)==len(rows)
a=zeilen('angriffe.jsonl');mk=zeilen('modellaufrufe.jsonl');ident=lambda r:(r['phase'],r['kandidat'],r['bereich'],r['protokoll_vor'])
beg=Counter(ident(x) for x in a if x['art']=='beginn');end=Counter(ident(x) for x in a if x['art']=='ergebnis');err=[x for x in a if x['art']=='fehler']
modelan=[x for x in mk if x['art']=='anfragematerial'];modelant=[x for x in mk if x['art']=='antwort'];modellfehl=[x for x in mk if x['art'] in ('fehler','budget_vorab_gesperrt')]
ledger=[dict(x) for x in c.execute('SELECT * FROM kasse WHERE id>4070 ORDER BY id')]
assert ledger==e['kasse']
antwortnr={x['protokoll_nr'] for x in modelant};kassennr={x['protokoll_nr'] for x in ledger}
mentorantwort=[x for x in modelant if x['zweck']=='schwer.mentor'];assert len(mentorantwort)==1
s=mentorantwort[0]['antwort'];m=re.search(r'\{.*\}',s,re.S);original=json.loads(m.group(0) if m else s)
v=laden('mentor-vorlage.json');gezeigt={f"A{x['id']}":x for x in v['eintraege']};alle={f"A{x['id']}":dict(x) for x in c.execute('SELECT * FROM artgedaechtnis')}
richtungen=[]
for i,r in enumerate(original['richtungen'],1):
    refs=[{'feld':f,'id':x} for f in ('artgedaechtnis','projektgedaechtnis') for x in r.get(f,[])]
    for x in refs:
        eintrag=alle.get(x['id']);x.update(vorgelegt=x['id'] in gezeigt,werk=eintrag['werk'] if eintrag else None,
             klasse='erfunden' if eintrag is None else ('eigen' if eintrag['werk']==v['werkname'] else 'werkuebergreifend'))
    richtungen.append({'nummer':i,'name':r['name'],'verweise':refs,'fremd':sum(x['klasse']=='werkuebergreifend' for x in refs),'eigen':sum(x['klasse']=='eigen' for x in refs),'erfunden':sum(x['klasse']=='erfunden' for x in refs),'nicht_vorgelegt':sum(not x['vorgelegt'] for x in refs)})
refsum={k:sum(r[k] for r in richtungen) for k in ('fremd','eigen','erfunden','nicht_vorgelegt')}
auf=[r for r in pr if r['art'].startswith('immun.aufnahme_')]
behebungen=[r for r in pr if r['art']=='immun.gefunden']
kammern=[json.loads(l) for l in gzip.open(B/'kammern.jsonl.gz','rt')]
angriffsausfuehrung=[]
for test in t['tor2_zeile8_doppelungsanteil']['tests']:
    marker=f"aegis_k{test['kandidat']}_{test['bereich']}.py"
    treffer=[(i,x) for i,x in enumerate(kammern,1) if any(marker in str(arg) for arg in x['befehl'])]
    abbruch=[{'kammer_index':i,**x} for i,x in treffer if x['rc'] not in (0,1) or x['zeitlimit']]
    originalurteil=[u for u in urs if u['daten']['kandidat']==test['kandidat']][-1]['daten'].get('angriff') or {}
    klasse=('Sammlungs-/Ausführungsabbruch' if abbruch else 'vom Organ als fehlerhaft eingestuft' if test['test'] in originalurteil.get('fehlerhaft',[]) else 'Norm ohne Behebungsnachweis' if test['test'] in originalurteil.get('norm_am_kandidaten',[]) else 'kein bestätigter neuer Fund')
    angriffsausfuehrung.append({'test_id':test['id'],'kandidat':test['kandidat'],'klasse':klasse,'kammer_indizes':[i for i,x in treffer],'kammer_rc':[x['rc'] for i,x in treffer],'abbruchbelege':abbruch})
assert len(angriffsausfuehrung)==t['tor2_zeile8_doppelungsanteil']['anzahl']
abgebrochene=[x for x in angriffsausfuehrung if x['abbruchbelege']]
kammerabbrueche=[{'kammer_index':i,**x} for i,x in enumerate(kammern,1) if x['phase'].endswith('generation-5') and x['rc']!=0]
status={'zeit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ps':{'befehl':ps.args,'rc':ps.returncode,'stdout':ps.stdout,'stderr':ps.stderr},'lauf':lauf,
        'generationen':[{k:g[k] for k in ('nummer','status','grund')} for g in gener],
        'buchungen':{'anzahl':len(ledger),'erste_id':ledger[0]['id'] if ledger else None,'letzte_id':ledger[-1]['id'] if ledger else None,'summe_eur':sum(r['kosten_eur'] for r in ledger),'budget_eur':3},
        'budget_obergrenze':laden('budget-obergrenze.json'),'stoppereignisse':[r for r in pr if 'abbruch' in r['art'] or r['art']=='entropie.saettigung'],
        'laufabschluss':{k:v for k,v in e.items() if k not in ('schritte','kasse')}}
voll={'angriffe_beginn':sum(beg.values()),'angriffe_ergebnis':sum(end.values()),'paarung_vollstaendig':beg==end,'angriffsfehler':err,
      'modell_anfragen':len(modelan),'modell_antworten':len(modelant),'modell_fehler_oder_vorabstopp':modellfehl,'modellnummern_identisch':Counter(x['nr'] for x in modelan)==Counter(x['nr'] for x in modelant),
      'antworten_zu_kasse_identisch':antwortnr==kassennr and len(modelant)==len(ledger),
      'probekandidaten':sum(bool(x['ist_probe']) for x in ks),'natuerliche_kandidaten':len(rows),'hauptliste_gesamt':len(alle_haupt),'zusaetzliche_gesamt':len(rows)-len(alle_haupt),
      'nichtleere_stderr':[{'datei':f.name,'text':f.read_text()} for f in sorted(B.glob('*.stderr.txt')) if f.stat().st_size]}
rez={'zeit_utc':status['zeit_utc'],'vollstaendigkeit':voll,'gesamt':zerlegen(rows),'generationen':gener,
     'kandidaten':[ {k:r[k] for k in ('id','generation','bereich','nische','status','grund','ist_probe')} for r in rows],
     'urteile':urs,'artgedaechtnis':{'richtungen':richtungen,'summen_verweisvorkommen':refsum,'richtungen_gesamt':len(richtungen),'richtungen_mit_fremdverweis':sum(r['fremd']>0 for r in richtungen),
                                 'modellantwort_protokoll_nr':mentorantwort[0]['protokoll_nr'],'einzigartige_refs':sorted({x['id'] for r in richtungen for x in r['verweise']})},
     'angriffsausfuehrung':angriffsausfuehrung,'angriffsklassen':dict(Counter(x['klasse'] for x in angriffsausfuehrung)),
     'angriffsausfuehrungsabbrueche':len(abgebrochene),'kammerabbrueche_generation5':kammerabbrueche,
     'aufnahme_c_ereignisse':auf,'bestaetigte_fundereignisse':behebungen,
     'grenze':'Dokumentierte Gründe des unveränderten Organs, keine neue inhaltliche Nachbewertung oder Kausalstudie. Leere Vorschläge sind keine getöteten Änderungen. Gen-Liste und zusätzliche DB-Zeilen bleiben getrennt.'}
dump('SCHLUSSSTATUS.json',status);dump('ABLEHNUNGEN-UND-VERWEISE.json',rez)
print(json.dumps({'status':status,'vollstaendigkeit':voll,'gesamt':{k:v for k,v in rez['gesamt'].items() if k!='wortlaute'},'generation2':{k:v for k,v in gener[2].items() if k not in ('db_gesamt','hauptliste','zusaetzlich')} ,'artgedaechtnis':rez['artgedaechtnis'],'bestaetigte_fundereignisse':len(behebungen)},ensure_ascii=False,indent=2))
