"""Lesende Bestandszählung für die Übergabe; keine Produkt-/DB-Schreibzugriffe."""
from pathlib import Path
from collections import Counter, defaultdict
import ast, io, tokenize, json, hashlib, sqlite3, subprocess, datetime, re, urllib.request
P=Path('/root/phase-4-vorbedingung-1'); R=Path('/root/biotop'); B=P/'belege'
ROOT=Path('/var/pruefkanal/oeffentlich/_akte/3qfc8gxpdvjsqxcbuj39mupe92a82agy/laeufe')
BASE='https://milieulux-reinigung-muenchen.de/_akte/3qfc8gxpdvjsqxcbuj39mupe92a82agy/laeufe/'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name,obj): (B/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def cmd(*args):
    q=subprocess.run(args,text=True,capture_output=True);return {'befehl':list(args),'rc':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
start=json.loads((P/'AUSGANG.json').read_text())
c=sqlite3.connect(f'file:{P}/privat/biotop.db?mode=ro',uri=True);c.row_factory=sqlite3.Row
pro=[dict(z) for z in c.execute('SELECT nr,zeit,art,inhalt FROM protokoll ORDER BY nr')]
for z in pro:z['daten']=json.loads(z.pop('inhalt'))
wid=c.execute('SELECT werk_id FROM laeufe WHERE id=26').fetchone()[0]
jetzt=[z for z in pro if z['daten'].get('lauf_id')==26 or z['daten'].get('werk_id')==wid]
tracked=set(cmd('git','-C',str(R),'ls-files','-z')['stdout'].split('\0'))
eigenpfade=sorted(set(cmd('git','-C',str(R),'ls-files','--cached','--others','--exclude-standard','-z')['stdout'].split('\0'))-{''})
gesamtdateien=[]
for name in eigenpfade:
    f=R/name
    if f.name.startswith('.env'):raise RuntimeError('Geheimnisdatei in Quellauswahl; nicht veröffentlichen')
    text=f.read_text()
    gesamtdateien.append({'pfad':name,'gruppe':name.split('/')[0] if '/' in name else 'wurzel','physisch':len(text.splitlines()),'sha256':sha(f),'git_erfasst':name in tracked})
gesamtsicht={'dateien':len(gesamtdateien),'physisch':sum(x['physisch'] for x in gesamtdateien),'git_erfasst':sum(x['git_erfasst'] for x in gesamtdateien),'dateiliste':gesamtdateien}
gesamtsicht['gruppen']={g:{'dateien':sum(x['gruppe']==g for x in gesamtdateien),'physisch':sum(x['physisch'] for x in gesamtdateien if x['gruppe']==g)} for g in sorted({x['gruppe'] for x in gesamtdateien})}
files=[]
for teil in ('biotop','tests','pruefung'):
    for f in sorted((R/teil).rglob('*.py')):
        if any(x in ('__pycache__','.venv','venv','node_modules') for x in f.relative_to(R).parts):continue
        text=f.read_text();tree=ast.parse(text);docs=set()
        for node in ast.walk(tree):
            if isinstance(node,(ast.Module,ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and node.body:
                n=node.body[0]
                if isinstance(n,ast.Expr) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str):
                    docs.update(range(n.lineno,n.end_lineno+1))
        code=set();comments=set()
        for t in tokenize.generate_tokens(io.StringIO(text).readline):
            if t.type==tokenize.COMMENT:comments.update(range(t.start[0],t.end[0]+1))
            elif t.type not in (tokenize.ENCODING,tokenize.ENDMARKER,tokenize.NEWLINE,tokenize.NL,tokenize.INDENT,tokenize.DEDENT):
                code.update(set(range(t.start[0],t.end[0]+1))-docs)
        lines=text.splitlines();blank={i for i,l in enumerate(lines,1) if not l.strip()}
        # Disjunkte physische Kategorien: Code hat Vorrang vor Inlinekommentar; reine Doku gesondert.
        commentonly=comments-code;doconly=docs-code-commentonly;empty=blank-code-commentonly-doconly
        other=set(range(1,len(lines)+1))-code-commentonly-doconly-empty
        assert not other,(str(f),other)
        files.append({'pfad':str(f.relative_to(R)),'gruppe':teil,'git_erfasst':str(f.relative_to(R)) in tracked,'sha256':sha(f),'physisch':len(lines),'codezeilen':len(code),'kommentarzeilen':len(commentonly),'dokuzeilen':len(doconly),'leerzeilen':len(empty)})
numkeys=('physisch','codezeilen','kommentarzeilen','dokuzeilen','leerzeilen')
gruppen={teil:{'dateien':sum(x['gruppe']==teil for x in files),**{k:sum(x[k] for x in files if x['gruppe']==teil) for k in numkeys}} for teil in ('biotop','tests','pruefung')}
gesamt={'dateien':len(files),**{k:sum(x[k] for x in files) for k in numkeys}}
assert gesamt['physisch']==sum(gesamt[k] for k in numkeys if k!='physisch')
organe=[]
for f in sorted((R/'biotop/organe').glob('*.py')):
    if f.name=='__init__.py':continue
    tree=ast.parse(f.read_text());events=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='schreiben' and len(node.args)>1:
            arg=node.args[1]
            if isinstance(arg,ast.Constant) and isinstance(arg.value,str):events.append(arg.value)
    match=[z for z in pro if z['art'] in events];neu=[z for z in jetzt if z['art'] in events]
    organe.append({'datei':str(f.relative_to(R)),'physische_zeilen':len(f.read_text().splitlines()),'ereignisarten_literal':sorted(set(events)),
                   'historische_ereignisse':len(match),'lauf26_ereignisse':len(neu),'lauf26_nummern':[z['nr'] for z in neu],
                   'letztes_historisches_ereignis':{k:match[-1][k] for k in ('nr','zeit','art')} if match else None,
                   'grenze':'Keine Ereignisse ist kein Beweis toten Codes. Kammer läuft über separaten Mitschnitt; Eichproben in isolierten DBs. Ereignisse beweisen Aufruf, nicht fachliche Abnahme.'})
rawps=cmd('ps','-eo','pid,ppid,stat,etime,args')
pslines=[l for l in rawps['stdout'].splitlines() if ('biotop' in l or 'phase-4-vorbedingung-1/messen.py' in l or 'phase-4-vorbedingung-1/lauf_kommando.py' in l) and 'bestand_erheben.py' not in l and 'python3 -c' not in l and 'bash -lc' not in l]
service=cmd('systemctl','show','biotop.service','-p','LoadState','-p','ActiveState','-p','SubState','-p','MainPID','-p','ExecMainStartTimestamp')
inv={'zeit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'git_head':cmd('git','-C',str(R),'rev-parse','HEAD'),
     'definition':'Python-Dateien unter biotop/, tests/, pruefung/, ohne Caches/Abhängigkeiten. Physische Zeilen=splitlines; Codezeilen=Token-belegte Zeilen ohne reine AST-Docstrings, einschließlich Code-Strings. Keine pygount-SLOC-Behauptung. Sonstige Formate separat, Laufdaten/Git/Archive und fremde Werke ausgeschlossen.',
     'gesamtsicht_eigene_quellen':gesamtsicht,'gesamt':gesamt,'gruppen':gruppen,'dateien':files,'organe':organe,'organdateien_ohne_init':len(organe),
     'quellstand_anschluss':{'ausgang_dateien':len(start['quellen']),'aktuell_pythondateien':len(files),'fehlend':sorted(set(start['quellen'])-{x['pfad'] for x in files}),'zusaetzlich':sorted({x['pfad'] for x in files}-set(start['quellen'])),'geaendert':[n for n,h in start['quellen'].items() if sha(R/n)!=h]},
     'betrieb':{'ps_befehl':rawps['befehl'],'ps_rc':rawps['rc'],'ps_erfasste_prozesszeilen':max(0,len(rawps['stdout'].splitlines())-1),'passende_prozesse':pslines,'dienst':service,'docker_image':cmd('docker','image','inspect','biotop-kammer:1','--format','{{.Id}}'),'docker_laufend':cmd('docker','ps','--format','{{.ID}} {{.Image}} {{.Names}}')},
     'ereignisnenner':{'gesamte_private_db':len(pro),'lauf26':len(jetzt)},
     'weitere_quellformate':[{'pfad':str(f.relative_to(R)),'physisch':len(f.read_text().splitlines()),'sha256':sha(f)} for f in sorted(R.rglob('*')) if f.is_file() and str(f.relative_to(R)) in tracked and f.suffix in ('.md','.html','.css','.js','.sh','.toml','.ini')],
     'protokoll_art_haeufigkeiten_lauf26':dict(Counter(z['art'] for z in jetzt))}
dump('BESTAND.json',inv)
ordner=['biotop-phase-1','biotop-phase-1-nachlauf','biotop-phase-2','biotop-phase-3','biotop-phase-3-nachlauf','biotop-phase-4-vorbedingung-1','biotop-reparatur-01/eskalation-runde-02','biotop-reparatur-02','biotop-gesamtstand','biotop-wiedereinstieg-2026-09-20-01']
phasen=[]
for o in ordner:
    q=ROOT/o;pruefsummen=[]
    for pf in sorted(q.glob('PRUEFSUMME-ORDNER*.txt')):
        text=pf.read_text();matches=[]
        for l in text.splitlines():
            m=re.match(r'^([a-f0-9]{64})\s+(.+?)\s*$',l)
            if not m:continue
            name=m.group(2).lstrip('*');mf=q/name
            if not mf.is_file():continue
            # Nur genau bezeichnetes Manifest nachlesen, keine historische Kampagne wiederholen.
            with urllib.request.urlopen(BASE+o+'/'+name,timeout=30) as r:data=r.read()
            matches.append({'datei':name,'angegebene_sha256':m.group(1),'gemessene_sha256':sha(mf),'https_sha256':hashlib.sha256(data).hexdigest(),'passt':m.group(1)==sha(mf)==hashlib.sha256(data).hexdigest()})
        if not matches:
            hashes=re.findall(r'\b[a-f0-9]{64}\b',text)
            kandidaten=sorted(set(q.glob('DATEIEN*.txt'))|set(q.glob('MANIFEST*.sha256'))|set(q.glob('PRUEFSUMMEN*.sha256')))
            for h in hashes:
                passende=[mf for mf in kandidaten if sha(mf)==h]
                for mf in passende:
                    with urllib.request.urlopen(BASE+o+'/'+mf.name,timeout=30) as r:data=r.read()
                    matches.append({'datei':mf.name,'angegebene_sha256':h,'gemessene_sha256':sha(mf),'https_sha256':hashlib.sha256(data).hexdigest(),'passt':h==sha(mf)==hashlib.sha256(data).hexdigest(),'zuordnung':'genannter Hash gegen vorhandene Dateilisten/Inhaltsmanifeste abgeglichen'})
        pruefsummen.append({'datei':pf.name,'url':BASE+o+'/'+pf.name,'inhalt':text,'manifest_pruefung':matches})
    phasen.append({'ordner':o,'basis_url':BASE+o+'/','pruefsummen':pruefsummen,'berichte_vorhanden':[f.name for f in sorted(q.glob('*.md'))],'dateilisten':[f.name for f in sorted(q.glob('DATEIEN*.txt'))]})
dump('PHASEN-QUELLEN.json',phasen)
print(json.dumps({'bestand':gesamt,'gruppen':gruppen,'organdateien':len(organe),'anschluss':inv['quellstand_anschluss'],'prozesse':pslines,'dienst':service,'phasen_ordner':len(phasen),'manifeste':[{'ordner':p['ordner'],'pruefsummen':p['pruefsummen']} for p in phasen]},ensure_ascii=False,indent=2))
