"""Auftragsbeginn: unveränderten Bestand sichern, Privatkopie, Lieferentwurf."""
from pathlib import Path
import datetime, hashlib, json, sqlite3, shutil, os, grp, urllib.request
P = Path('/root/phase-4-vorbedingung-1')
R = Path('/root/biotop')
Q = Path('/root/reparatur-01/teil-eichung/werk-lauf25-kopie')
O = Path('/var/pruefkanal/oeffentlich/_akte/3qfc8gxpdvjsqxcbuj39mupe92a82agy/laeufe/biotop-phase-4-vorbedingung-1/nach-reparatur-02')
URL = 'https://milieulux-reinigung-muenchen.de/_akte/3qfc8gxpdvjsqxcbuj39mupe92a82agy/laeufe/biotop-phase-4-vorbedingung-1/nach-reparatur-02/'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def baum(p): return {str(f.relative_to(p)): sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
assert not (P/'AUSGANG.json').exists() and not O.exists()
for n in ('ausgang', 'belege', 'temp', 'privat', 'review'):
    (P/n).mkdir()
quellen = {}
for n in ('biotop', 'tests', 'pruefung'):
    for f in sorted((R/n).rglob('*.py')):
        rel = f.relative_to(R)
        quellen[str(rel)] = sha(f)
        z = P/'ausgang'/rel
        z.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(f, z)
with sqlite3.connect(f'file:{R}/daten/biotop.db?mode=ro', uri=True) as c:
    c.row_factory = sqlite3.Row
    k = dict(c.execute('SELECT MAX(id) max_id,COUNT(*) anzahl,SUM(kosten_eur) summe_eur FROM kasse').fetchone())
    maxlauf = c.execute('SELECT MAX(id) FROM laeufe').fetchone()[0]
    db_sha = hashlib.sha256('\n'.join(c.iterdump()).encode()).hexdigest()
    prodwerk = Path(c.execute('SELECT pfad FROM werke WHERE id=22').fetchone()[0])
    with sqlite3.connect(P/'privat'/'biotop.db') as ziel: c.backup(ziel)
os.chmod(P/'privat'/'biotop.db', 0o600)
shutil.copytree(Q, P/'privat'/'werkquelle')
a = {'zeit':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'budget_eur':3,
     'review_maximal':1, 'fixagenten_maximal':0, 'quellen':quellen,
     'kasse':k, 'erster_neuer_lauf':maxlauf+1, 'produktive_db_dump_sha256':db_sha,
     'produktives_werk':str(prodwerk), 'produktives_werk_hashes':baum(prodwerk),
     'werkquelle':str(Q), 'werkquelle_hashes':baum(Q),
     'private_db':'privat/biotop.db', 'neuer_natuerlicher_lauf':True}
(P/'AUSGANG.json').write_text(json.dumps(a, ensure_ascii=False, indent=2)+'\n')
plan = '''# Vorbedingung 1 — Messplan vor Ausführung

## Auftrag und Grenzen
Fassung 6, Abschnitte 3.7, 3.10, 3.12 und Vorbedingung 1. Bauteil A: Behauptung vor Testgenerierung nennen, bereits bekannte Behauptung ohne teuren Angriff zurückhalten. Bauteil B: fremde Muster belegen mindestens die Hälfte des Fensters, mindestens fünf, soweit vorhanden; kein Zitat wird erzwungen. Beide Bauteile sind im übernommenen Quellstand vorhanden; ihre Anwesenheit ist kein natürlicher Wirkungsnachweis.

Budget 3,00 EUR hart für alle neuen Biotop-Aufrufe dieses Auftrags; frische private DB-Kopie, neues lagerhaus-Werk und neuer Lauf. Kein Fortsetzen von Lauf 24/25. Produktionsdatenbank, ursprüngliche Werkquelle und echtes Handelssystem bleiben unberührt. Träger-/Hostkosten nicht monetär ermittelt. Genau ein begrenzter lesender Schlussreview, keine Fixagenten, keine Nachreview-Kaskade.

## Eigene Entscheidungen von Hermes vor den Ergebnissen
- Vorhandene Mechanik an den bestehenden Tests test_ansage_aufnahme.py und test_artvorlage.py prüfen. Keine neue Gesamt-Reparaturprüfung und keine Umdefinition der abgenommenen Batterie. Reparatur-02 bleibt Ausgang.
- Quelle: unveränderte private Eich-/Werkquelle aus Reparatur-02. Native Aufnahme, Landkarte, Verfassung/Verträge, Vorspann, Gen0, Maß-Freeze, Mentor und natürliche Generationen; keine eingespeisten Schwarmvorschläge oder Angriffstests. Gen0 darf nur mit ausdrücklich erreichtem ursprünglichem Ziel zum Freeze führen; Existenz eines Abschlussereignisses allein genügt nicht.
- Genau ein Messlauf bis zur natürlichen Sättigung, Budget-/Infrastrukturabbruch oder höchstens sechs Generationen. Kein Abbruch beim ersten günstigen Prozentwert, keine Auswahl einer günstigen Teilmenge, kein Neustart zur Ergebniskosmetik. Mentor einmal; Wahl der Empfehlung unter Übungswerk-Vollmacht, sofern sie eine ausführbare Richtung ist. Alle Versuche bleiben sichtbar.
- Passiver Mitschnitt steht vor Laufbeginn fest: tatsächliche Modellanfragen/-antworten ohne Zugangsdaten; Angriffscode und Schlüsselvorrat vor dem Angriff, Kandidatenkennung und eigene Ansagekennung; vollständige Kammerergebnisse und native CLI-Ausgaben. Keine Ersetzung einer Modellantwort, kein Eingriff in Testurteile. Privatpfade für Werk und Lazarus verhindern produktive Schreibzugriffe.

## Tor 2, Zeile 8 — keine Ersatzkennzahl
Doppelungsanteil = wiederholte (Bereich, Behauptung)-Schlüssel / alle tatsächlich vom Ankläger erzeugten Testfunktionen des neuen Laufs. Schlüssel ausschließlich mit der bestehenden Funktion aegis.behauptung, nicht anhand der Fundstelle. Gleiche Behauptung: erste erzeugte Funktion zählt einmal, jede weitere ist Doppelung; alle erzeugten Funktionen einschließlich verworfener, normativer oder am Ausgang bestehender bleiben im Nenner. Ein Codeblock ohne prüfbare Tests, Syntaxfehler und Ausführungsabbrüche werden eigens ausgewiesen, nicht als Nullmessung grün. Keine Verwendung aller Ablehnungen als Nenner. Zusätzlich Wiederholungen gegen den vollständigen Vorrat am jeweiligen Entscheidungszeitpunkt sowie Ansage/Code-Abweichungen ausweisen; das ersetzt nicht den verlangten Anteil unter 20 Prozent. Null erzeugte Tests oder eine nur durch Kleinstnenner scheinbar grüne Zahl tragen keine Abnahme.

Die anderen Bestandteile derselben Zeile bleiben sichtbar: Liste bestätigter und tatsächlich angenommener Behebungen samt Immuntestdatei; an jeder angenommenen Generation vollständige Messung und null fehlgeschlagene Tests. Kein unübernommener offener Fund wird als im Werk befindlicher Test ausgegeben. Fehlender Gegenstand bleibt benannt.

## Werkübergreifender Verweis
Mindestens eine Richtung des einmalig aufgerufenen lagerhaus-Mentors nennt mindestens einen tatsächlich vorgelegten, vorhandenen Eintrag eines anderen Werks. Vorlagenfenster und Eintragsquellen vollständig auflisten; Erfindungen, eigene Einträge und nicht vorgelegte IDs getrennt. Mindestanteil der Vorlage und tatsächlicher Verweis sind verschiedene Zeilen. Keine Pflichtzitate und keine nachträgliche Ergänzung einer Modellantwort.

## Abbruch und offene Arbeit
Keine Regeln oder Schwellen während der Messung ändern. Bei auftragsrelevantem Fehler: rote Torzeile, gesicherte Belege und Entscheidungsvorlage statt automatischer Reparatur-/Reviewkaskade. Die 19 Außenorte und vier bekannten Phase-4-Lücken bleiben unverändert offen; dieser Auftrag zertifiziert nicht das ganze Biotop.
'''
(P/'MESSPLAN.md').write_text(plan)
O.mkdir()
(O/'MESSPLAN.md').write_text(plan)
bericht = '''# Phase 4 — Vorbedingung 1: Arbeitsentwurf

Noch keine Abnahme. Vorhandene Bauteile A/B werden geprüft, danach ein neuer natürlicher lagerhaus-Lauf am privaten Übungsbestand unter 3,00 EUR Auftragsbudget. Messplan vor Ergebnissen: MESSPLAN.md.

- Ansage vor Angriff / bekannte Behauptung unterdrückt: offen.
- Mindestanteil fremder Muster in der Vorlage: offen.
- Tor 2 Zeile 8, Doppelungen unter 20 Prozent der erzeugten Angriffstests und Immunisierungsbelege: offen.
- Mindestens ein echter werkübergreifender Verweis im lagerhaus-Lauf: offen.
- Ein Schlussreview: offen.

Die 19 Außenleserorte und vier Phase-4-Lücken bleiben offen. Das echte Werk wird nicht angefasst. Keine Gesamtentwarnung.
'''
(O/'ZWISCHENBERICHT.md').write_text(bericht)
(O/'KASSE.md').write_text(f'# Kasse — Auftragsbeginn\n\n3,00 EUR hart. DB-Ausgang: Buchungs-ID {k["max_id"]}, {k["anzahl"]} Datensätze. Neue Biotop-Buchungen noch 0, Kosten 0,00 EUR. Neuer privater Lauf frühestens {maxlauf+1}. Kosten aller Versuche einschließlich Vorstufen zählen gegen dasselbe Budget. Träger-/Hostkosten nicht monetär ermittelt.\n')
(O/'DATEIEN.txt').write_text('ARBEITSENTWURF — noch nicht versiegelt\nDATEIEN.txt\nZWISCHENBERICHT.md\nMESSPLAN.md\nKASSE.md\n')
gid = grp.getgrnam('caddy').gr_gid
os.chown(O,0,gid); os.chmod(O,0o750)
for f in O.iterdir():
    os.chown(f,0,gid); os.chmod(f,0o640)
    with urllib.request.urlopen(URL+f.name, timeout=30) as r:
        assert r.read() == f.read_bytes(), f.name
print(json.dumps({'ausgangsquellen':len(quellen),'erster_neuer_lauf':maxlauf+1,'kasse':k,'entwurf_https_dateien':len(list(O.iterdir()))},ensure_ascii=False,indent=2))
