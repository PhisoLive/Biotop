"""Schlanke tortragende Lieferung; versiegelte Altlieferung bleibt unverändert."""
from pathlib import Path
from collections import Counter,defaultdict
import json,hashlib,tarfile,io,gzip,os,grp,urllib.request,sys,datetime
P=Path('/root/phase-4-vorbedingung-1');B=P/'belege';R=Path('/root/biotop')
O=Path('/var/pruefkanal/oeffentlich/_akte/3qfc8gxpdvjsqxcbuj39mupe92a82agy/laeufe/biotop-phase-4-vorbedingung-1/nach-reparatur-02/abschluss-01') if sys.argv[1]=='schluss' else P/'abschluss-entwurf'
URL='https://milieulux-reinigung-muenchen.de/_akte/3qfc8gxpdvjsqxcbuj39mupe92a82agy/laeufe/biotop-phase-4-vorbedingung-1/nach-reparatur-02/abschluss-01/'
modus=sys.argv[1];assert modus in ('entwurf','schluss')
O.mkdir(parents=True,exist_ok=True)
assert not (O/'MANIFEST.sha256').exists(), 'Versiegelte Bytes nicht überschreiben'
a=json.loads((P/'AUSGANG.json').read_text());t=json.loads((B/'TORZEILEN.json').read_text());e=json.loads((B/'laufabschluss.json').read_text())
z=t['tor2_zeile8_doppelungsanteil'];b=t['bauteil_b'];aa=t['bauteil_a'];g=t['angenommene_generationen']
diagnose=json.loads((B/'ABLEHNUNGEN-UND-VERWEISE.json').read_text())
# Die Steuerungsnotiz bei Abbruch ist KEIN unabhängiges Prüfungsurteil.
reviewpfad=P/'review/REVIEW-ABBRUCH.json' if (P/'review/REVIEW-ABBRUCH.json').exists() else P/'review/REVIEW.json'
review=json.loads(reviewpfad.read_text()) if reviewpfad.exists() else None
review_abgebrochen=bool(review and review.get('review_abgeschlossen') is False)
if modus=='schluss':assert review is not None and type(review.get('passed')) is bool
rows=e['kasse'];summe=sum(x['kosten_eur'] for x in rows)
assert summe==e['gebucht_eur'] and summe<=3
assert sum(t['kandidaten']['aufschluesselung'].values())==t['kandidaten']['gesamt']
mechanik=json.loads((B/'bauteile.json').read_text());tests_aus=sum(x['phase']=='call' for x in mechanik['berichte']);tests_ok=sum(x['phase']=='call' and x['outcome']=='passed' for x in mechanik['berichte'])
a_ok=bool(aa['ansagen'] and len(aa['entscheidungen'])==aa['ansagen'] and all(x.get('entscheidung_richtig') is True for x in aa['entscheidungen']))
g_ok=bool(g and all(x['besteht'] for x in g))
numerisch=z['unter_20_prozent'];hinreichender_nenner=z['anzahl']>=6
messwerte_erfuellt=bool(e['erfolgreich_ausgefuehrt'] and mechanik['rc']==0 and a_ok and numerisch and hinreichender_nenner and b.get('tor_verweis_erfuellt') and b['mindestanteil_erfuellt'] and g_ok and all(t['schutz'].values()))
ausfuehrung_durchgehend=diagnose['angriffsausfuehrungsabbrueche']==0
immunisierung_mit_gegenstand=bool(diagnose['bestaetigte_fundereignisse'])
technisch=messwerte_erfuellt and ausfuehrung_durchgehend and immunisierung_mit_gegenstand
endgueltig=bool(technisch and review and review['passed'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def status(x):return 'erfüllt' if x else 'NICHT erfüllt'
# Alle nativen Kommandoströme, auch die leeren Fehlerströme, als ein übersichtlicher Rohbeleg.
cli=[]
for s in e['schritte']:
    cli.append({**s,'stdout':(B/(s['phase']+'.stdout.txt')).read_text(),'stderr':(B/(s['phase']+'.stderr.txt')).read_text()})
dump(B/'CLI-AUSGABEN.json',cli)
# Unveränderte einschlägige F6-Abschnitte statt der gesamten Historie.
f6=Path('/root/.hermes/cache/documents/doc_8d640daa6c3c_INFINITE-EVOLUTION-BIOTOP-Masterprompt-v6.md');ls=f6.read_text().splitlines();aus=[];aktiv=False
for nr,zeile in enumerate(ls,1):
    if zeile.startswith('### '):aktiv=any(zeile.startswith(x) for x in ('### 3.7 ','### 3.10 ','### 3.12 '))
    if aktiv or zeile.startswith('- Immunisierung:') or zeile.startswith('1. **Zwei offene Bauteile'):
        aus.append(f'{nr}|{zeile}')
(B/'MASTERPROMPT-F6-AUSZUG.md').write_text('# Maßgeblicher F6-Auszug\n\nQuell-SHA256: '+sha(f6)+'\n\n'+'\n'.join(aus)+'\n')
# Belegklassen bleiben getrennt: natürliche Ausgaben, Eigentests, Zählerkontrollen.
belegnamen=['CLI-AUSGABEN.json','DB-AUSZUG.json.gz','kammern.jsonl.gz','kommandos.jsonl','modellaufrufe.jsonl','angriffe.jsonl',
             'mentor-vorlage.json','FREMDMUSTER-QUELLEN.json','richtungswahl.json','budget-obergrenze.json','reparatur02-anschluss.json',
             'bauteile.txt','bauteile.xml','bauteile.json','zaehler-gruen.json','zaehler-rot.txt','MASTERPROMPT-F6-AUSZUG.md','laufabschluss.json','SCHLUSSSTATUS.json','ABLEHNUNGEN-UND-VERWEISE.json']
belegdateien={n:B/n for n in belegnamen if (B/n).exists()}
belegdateien.update({'AUSGANG.json':P/'AUSGANG.json'})
bestand=json.loads((B/'BESTAND.json').read_text())
quellendateien={x['pfad']:R/x['pfad'] for x in bestand['gesamtsicht_eigene_quellen']['dateiliste']}
for n in ('kammer/Dockerfile','pyproject.toml','requirements.txt','README.md'):
    if (R/n).is_file():quellendateien[n]=R/n
for n in ('vorbereiten.py','bauteile_pruefen.py','lauf_kommando.py','messen.py','zaehlen.py','zaehler_pruefen.py','auswerten.py','schlussdiagnose.py','bestand_erheben.py','uebergabe_schreiben.py','liefern.py'):
    quellendateien['pruefung_vorbedingung1/'+n]=P/n
werkdateien={}
with gzip.open(B/'DB-AUSZUG.json.gz','rt',encoding='utf-8') as f:db=json.load(f)
endwerk=Path(db['werke'][0]['pfad']) if db['werke'] else None
for marke,pfad in [('ausgang',P/'privat/werkquelle'),('endstand',endwerk)]:
    if pfad:
        for f in sorted(pfad.rglob('*')):
            if f.is_file() and not any(x in ('.git','__pycache__','.pytest_cache','.venv','venv','node_modules','dist','coverage') for x in f.relative_to(pfad).parts) and not f.name.startswith('.env'):
                werkdateien[marke+'/'+str(f.relative_to(pfad))]=f
ueberquellen={f.name:f for f in sorted((P/'uebergabe-quellen').iterdir()) if f.is_file()}
ueberquellen.update({n:B/n for n in ('BESTAND.json','PHASEN-QUELLEN.json')})
ueberquellen['quellenregister.json']=P/'quellenregister.json'
mitglieder={}
for name,dateien in [('MESSBELEGE.tar.gz',belegdateien),('QUELLSTAND.tar.gz',quellendateien),('WERK.tar.gz',werkdateien),('UEBERGABE-BELEGE.tar.gz',ueberquellen)]:
    mitglieder[name]={n:sha(p) for n,p in sorted(dateien.items())}
    with tarfile.open(O/name,'w:gz') as tar:
        for n,p in sorted(dateien.items()):tar.add(p,arcname=n,recursive=False)
    with tarfile.open(O/name,'r:gz') as tar:
        gelesen={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers() if m.isfile()}
    assert gelesen==mitglieder[name]
dump(O/'ARCHIV-INHALT.json',mitglieder)
(O/'MESSPLAN.md').write_bytes((P/'MESSPLAN.md').read_bytes())
dump(O/'TORZEILEN.json',{**t,'bewertung':{'geforderte_messwerte_erfuellt':messwerte_erfuellt,'technische_torzeilen_erfuellt':technisch,'ausfuehrung_durchgehend':ausfuehrung_durchgehend,'immunisierung_neuer_gegenstand':immunisierung_mit_gegenstand,'hinreichender_nenner':hinreichender_nenner,'review_bestanden':review['passed'] if review else None,'review_abgeschlossen':False if review_abgebrochen else (True if review else None),'abnahme_beantragt':endgueltig}})
for n in ('UEBERGABE-PHASE-4.md','ERGEBNIS-DETAIL.md','AUFTRAG-REGELN.md'):(O/n).write_bytes((P/n).read_bytes())
for n in ('SCHLUSSSTATUS.json','ABLEHNUNGEN-UND-VERWEISE.json','BESTAND.json','PHASEN-QUELLEN.json'):(O/n).write_bytes((B/n).read_bytes())
dump(O/'KASSE.json',{'budget_eur':3,'gebucht_eur':summe,'buchungen':rows,'konservative_obergrenze':t['budget_obergrenze']})
if review:dump(O/'REVIEW.json',review)
(O/'REVIEW-AUFTRAG.md').write_bytes((P/'review/PRUEFAUFTRAG.md').read_bytes())
gruppen=defaultdict(list)
for r in rows:gruppen[(r['anbieter'],r['modell'])].append(r)
kassenzeilen=['# Kasse — Vorbedingung 1 nach Reparatur-02','',f'Budget **3,00 EUR hart**. Neue DB-Buchungen: **{len(rows)} von {len(rows)}**, IDs '+(', '.join(str(r['id']) for r in rows) if rows else 'keine')+'.',
               f'Gebucht: **{summe:.6f} EUR von 3,00 EUR**. Datensätze vollständig in KASSE.json; keine Kosten aus früheren Läufen eingerechnet.',
               f'Konservative Preisvarianten-/Tokenkostenobergrenze: **{t["budget_obergrenze"]["obergrenze_eur"]:.6f} EUR von 3,00 EUR**. Offene Reservierungen: {t["budget_obergrenze"]["offene_reservierungen"]}.',
               'Die zusätzliche Budgetwache reserviert vor jedem realen Aufruf UTF-8-Bytes plus Formatreserve und maximalen Output zum höchsten veröffentlichten Preis einschließlich Katalogvarianten. Die native Kasse bleibt unverändert. Ungeklärte fehlgeschlagene Aufrufe behalten ihre volle Reserve.',
               'Träger-/Review-, Host- und Abokosten sind nicht monetär ermittelt; sie werden nicht als kostenlos behauptet.','', '## Aufschlüsselung nach Anbieter/Modell']
for (anbieter,modell),rs in sorted(gruppen.items()):
    kassenzeilen.append(f'- {anbieter}/{modell}: {len(rs)} von {len(rows)} Buchungen, {sum(r["tokens_ein"] for r in rs)} Eingabe- und {sum(r["tokens_aus"] for r in rs)} Ausgabetoken, {sum(r["kosten_eur"] for r in rs):.6f} EUR.')
kassenzeilen+=['',f'Summenprüfung: {sum(len(rs) for rs in gruppen.values())} von {len(rows)} Buchungen; Rohsumme {summe!r} EUR.','## Kammern und Vorstufen']
kk=[json.loads(l) for l in (B/'kommandos.jsonl').read_text().splitlines()]
with gzip.open(B/'kammern.jsonl.gz','rt',encoding='utf-8') as f:kammern=[json.loads(l) for l in f]
assert len(kammern)==sum(x['kammerlaeufe'] for x in kk)
for x in kk:kassenzeilen.append(f'- {x["phase"]}: {x["kammerlaeufe"]} von {len(kammern)} erfassten Kammeraufrufen; Kommando {x["dauer_s"]:.3f} s; Exit {x["rc"]}.')
kassenzeilen.append(f'Abgleich: {len(kammern)} von {len(kammern)} Kammeraufrufen in beiden Belegströmen. Vorstufen, Tests und Messlauf bleiben getrennt; alle Modellbuchungen zählen gegen dieselben 3,00 EUR.')
kassenzeilen.append('Abgrenzung der Fehler: Der Gesamtprozess endet natürlich gesättigt, CLI-Schritte alle Exit 0. K2689 erzeugt zwei abgebrochene Angriffstest-Sammlungen (Exit 2, kein gültiger Nachweis); K2817 wird wegen Kammer-/Sammlungsabbruch gesperrt (äußerer Exit 1, innerer pytest-Exit 2). Rohbelege in ABLEHNUNGEN-UND-VERWEISE.json. Ihre Kosten sind in den hier gebuchten Schritten enthalten, nicht herausgerechnet.')
(O/'KASSE.md').write_text('\n\n'.join(kassenzeilen)+'\n')
anteil=f'{z["anteil_prozent"]:.2f} %' if z['anteil_prozent'] is not None else 'nicht bestimmbar'
kopf='Vorbedingung 1 — zur Abnahme vorgelegt' if endgueltig else ('Technische Torzeilen erfüllt — einziger Schlussreview offen' if technisch and not review else 'Vorbedingung 1 NICHT abgenommen')
bericht=[f'# {kopf}','', '**Die beiden geforderten Zahlen sind erreicht, aber keine uneingeschränkte Gesamtfreigabe:** 1 von 11 erzeugten Angriffstests bricht bei der Sammlung ab (K2689); neue bestätigte Behebungen/Immuntestübernahmen fehlen als Gegenstand. Der numerische Doppelungsanteil wird deshalb nicht geändert. Vollständige Ablehnungsgründe, Artverweise je Richtung und F7-Grenzen: ERGEBNIS-DETAIL.md; eigenständig lesbarer Folgekontext: UEBERGABE-PHASE-4.md.',f'Neuer natürlicher **lagerhaus-Lauf {e["lauf_id_nur_privat"]} ausschließlich in der privaten Auftrags-DB**, nicht Fortsetzung von Lauf 24/25. '+('Der native Ablauf ist abgeschlossen.' if e['erfolgreich_ausgefuehrt'] else 'Der Ablauf ist fehlgeschlagen: '+e.get('fehler','unbekannt')),
         '## Ergebnis',f'- Bestehende Bauteiltests: **{tests_ok} von {len(mechanik["sammlung"])} grün**, {tests_aus} ausgeführt; netzfreie Eigentests, keine natürliche Wirkungsmessung.',
         f'- A, Vorab-Ansage: **{status(a_ok)}**. {aa["ansagen"]} Entscheidungen, Aufteilung {json.dumps(aa["aufschluesselung"],ensure_ascii=False)}. Jede Entscheidung mit Kandidat, zeitlichem Schlüsselvorrat und ursprünglichem Protokollbezug in TORZEILEN.json.',
         f'- Tor 2 Zeile 8, verlangter Anteil: **{status(numerisch and hinreichender_nenner)}** — **{z["doppelungen"]} von {z["anzahl"]} tatsächlich erzeugten Angriffstestfunktionen = {anteil}**, Grenze strikt unter 20 %. {len(z["probleme"])} nicht eindeutig auswertbare Fälle. Ein leerer oder kleinster Nenner trägt keine Abnahme.',
         f'- B, Vorlage: **{status(b["mindestanteil_erfuellt"])}** — {b.get("fremd_gezeigt",0)} fremde von {b.get("gesamt_gezeigt",0)} gezeigten Einträgen; {b.get("fremde_muster_verfuegbar",0)} verschiedene fremde Muster verfügbar, damit {b.get("mindestzahl",0)} gefordert. Alle verfügbaren fremden Muster und gezeigten IDs beigefügt.',
         f'- B, tatsächlicher Verweis: **{status(b.get("tor_verweis_erfuellt",False))}** — **{b["richtungen_mit_fremdverweis"]} von {b["richtungen_gesamt"]} Richtungen** mit vorgelegtem, vorhandenem Eintrag eines anderen Werks; {len(b["ungueltige_verweise"])} nicht vorgelegte/ungültige Verweise. Mentor nur einmal, kein Pflichtzitat und keine nachträgliche Ergänzung.',
         f'- Testbestand angenommener Generationen einschließlich Gen0: **{status(g_ok)}**, {sum(x["besteht"] for x in g)} von {len(g)} gespeicherten Messständen vollständig grün.',
         ('- Ein unabhängiger Schlussreview: **ABGEBROCHEN, kein fachliches Ergebnisurteil.** 1 von 1 beauftragten Durchgängen gestartet, 0 von 1 vollständig belegt. Eigene Grenze 180 Sekunden, Steuerung erst bei gemeldeten 202,7 Sekunden; danach Stopp angefordert. Zu späte Kontrolle ist ein Verfahrensfehler von Hermes. REVIEW.json ist eine ausdrücklich benannte Steuerungsnotiz, kein unabhängiges Urteil. Kein Ersatzreview, keine Fixagenten und keine Nachreparatur.' if review_abgebrochen else f'- Ein unabhängiger Schlussreview: **{status(review["passed"]) if review else "noch offen"}**. Keine Fixagenten, keine erneute Prüfungskampagne nach dem Review.'),
         '## Was gebaut wurde und was nicht',
         f'**Keine Produktänderung:** {len(a["quellen"])} von {len(a["quellen"])} Pythonquellen stimmen mit dem abgenommenen Reparatur-02-Endstand überein (reparatur02-anschluss.json). A/B waren in diesem Stand bereits implementiert. Neu sind ausschließlich Auftragssteuerung, passive Belegerfassung und Auswertung außerhalb des Repositorys. Das ist ein neuer Ausführungsnachweis vorhandener Bauteile, kein behaupteter erneuter Bau oder isolierter Kausalvergleich.',
         'Die bestehende Aufnahmesperre C bleibt unverändert aktiv. Ihre Wirkung wird nicht der Ansage zugeschrieben. Ansage/Code-Abweichungen und Wiederholungen gegen den gesamten Entscheidungsvorrat stehen als eigene Diagnosen neben dem verlangten Anteil.',
         f'Diagnosen: {z["gegen_vorrat"]} von {z["anzahl"]} erzeugten Funktionen wiederholen den vorher vorhandenen Vorrat; {z["ansageabweichungen"]} von {z["anzahl"]} weichen von ihrer Ansage ab. Kein solcher Fall wird aus dem Nenner entfernt.',
         '## Immunisierung und Laufbestand']
for x in g:bericht.append(f'- Generation {x["generation"]}: {x["tests_bestanden"]} von {x["tests_gesamt"]} Tests bestanden, {x["tests_fehlgeschlagen"]} fehlgeschlagen; native pytest-Rückgabe {x["pytest_rc"]}; Werkprüfsumme {x["pruefsumme"]}.')
im_werk=[x for x in t['immuntests'] if x['status']=='im_werk'];offen=[x for x in t['immuntests'] if x['status']!='im_werk']
bericht.append(f'Immunsystem des neuen Werks: {len(im_werk)} von {len(t["immuntests"])} Einträgen als im Werk geführt, {len(offen)} mit anderem/offenem Status. Einzelstatus, Ursprung und tatsächlicher Dateipfad stehen in TORZEILEN.json. Offene Funde werden nicht als behobene Fehler oder übernommene Tests ausgegeben; Gen0-Tests bleiben von Anklägerprodukten getrennt.')
bericht += ['## Vollständigkeit und Kasse',f'Kandidaten: {t["kandidaten"]["gesamt"]}; Aufteilung {json.dumps(t["kandidaten"]["aufschluesselung"],ensure_ascii=False)}, Summe deckungsgleich. Geschlossene CLI-Schritte: {len(e["schritte"])}; nichtleere Fehlerausgaben: {len(t["fehlerausgaben"])} (vollständig in CLI-AUSGABEN.json).',
            f'Gebuchte neue Biotop-Modellkosten **{summe:.6f} EUR von 3,00 EUR**. Konservative Obergrenze **{t["budget_obergrenze"]["obergrenze_eur"]:.6f} EUR**; alle Vorstufen und Versuche enthalten. Träger-/Hostkosten nicht monetär ermittelt.',
            f'Schutzabgleich: {sum(t["schutz"].values())} von {len(t["schutz"])} unverändert: {json.dumps(t["schutz"],ensure_ascii=False)}.',
            '## Eigene Entscheidungen und Messgrenzen',
            'Messplan vor Ergebnissen in MESSPLAN.md. Neue private Aufnahme mit nativen Vorstufen und unverändertem Instrument; passiver Mitschnitt vor dem Start. Nur eine natürliche Kampagne bis Sättigung, Budgetabbruch oder höchstens sechs Generationen; keine nachträgliche Wahl einer günstigen Teilserie. Ein bestehender versiegelter Ordner war am gewünschten Hauptpfad vorhanden. Die Schutzprüfung stoppte den ersten Entwurfsversuch vor jeder Änderung; diese neue Revision liegt daher unter nach-reparatur-02. Versiegelte Altdateien werden nicht überschrieben.',
            'Die Zählerimplementierung ist separat mit erwartet rotem Anfang und ausgeführtem positiven/negativen Anteil sowie leerem/kaputtem Gegenstand geprüft. Diese gestellten Kontrollen zählen nicht in die natürliche Quote.',
            '## Unangetastet und offen',
            '- 19 bestätigte Außenleserorte: 11 in Prüfskripten und 8 in drei Produktdateien. Kein neuer Außenscan, keine Vollständigkeitsentwarnung.',
            '- Vier Phase-4-Lücken: kumulativer/transitiver Wirkungskreis; Vertragsidentität zwischen Vorspann und Freeze; bereichsweise NaN-/Null-Rauschbehandlung; Gen0-Erfolgsbindung am Freeze. Kein Fix und keine Abnahme dieser Mechanismen. Die Steuerung verlangt in diesem Lauf ausdrücklich ein erreichtes Gen0-Ziel, ohne das Produkt-Gate umzubauen.',
            '- Echtes Handelssystem sowie Vorbedingungen 2–5 nicht angefasst. Festlegung Philipps: Dieser Messauftrag endet einschließlich Review und Versiegelung in dieser Sitzung; kein Umzug des laufenden Versuchs. Die anschließende Arbeit an Phase 4 / dem echten Werk beginnt erst in einer frischen Sitzung anhand des versiegelten Abschlusses. Kein Folgeauftrag wird hier automatisch gestartet.',
            '## Abholung und Belegumfang',URL+'DATEIEN.txt',
            'MESSBELEGE.tar.gz enthält ausschließlich native Tor-/Vorstufenbelege, reale Modellmaterialien/Antworten, den dazugehörigen DB-Ausschnitt sowie getrennte Bauteil- und Zählerkontrollen. Kein voller historischer DB-Dump und keine Kopie aller Arbeitszwischenstufen.',
            'Archivmitglieder mit Einzelprüfsummen in ARCHIV-INHALT.json: '+', '.join(f'{n}: {len(v)}' for n,v in mitglieder.items())+'.']
text='\n\n'.join(bericht)+'\n';(O/'ZWISCHENBERICHT.md').write_text(text);(O/'BERICHT.md').write_text(text)
namen=sorted(p.name for p in O.iterdir() if p.is_file() and p.name not in ('DATEIEN.txt','MANIFEST.sha256','PRUEFSUMME-ORDNER.txt'))
(O/'DATEIEN.txt').write_text(('VERSIEGELTE SCHLUSSLIEFERUNG' if modus=='schluss' else 'ARBEITSENTWURF — Schlussreview/Versiegelung offen')+'\n'+URL+'\n\n'+'\n'.join(namen+['DATEIEN.txt','MANIFEST.sha256','PRUEFSUMME-ORDNER.txt'])+'\n\nArchivmitglieder: ARCHIV-INHALT.json\n')
if modus=='schluss':
    nutz=sorted(p for p in O.iterdir() if p.is_file())
    manifest=''.join(f'{sha(p)}  {p.name}\n' for p in nutz)
    (O/'MANIFEST.sha256').write_text(manifest)
    ms=sha(O/'MANIFEST.sha256')
    (O/'PRUEFSUMME-ORDNER.txt').write_text(f'{ms}  MANIFEST.sha256\n{len(nutz)} Nutzdateien; zusätzlich Manifest und diese Prüfsummenhülle.\n')
gid=grp.getgrnam('caddy').gr_gid;os.chown(O,0,gid);os.chmod(O,0o750)
https=[]
for p in sorted(O.iterdir()):
    if p.is_file():
        os.chown(p,0,gid);os.chmod(p,0o640)
        if modus!='schluss':continue
        with urllib.request.urlopen(URL+p.name,timeout=45) as r:d=r.read()
        assert d==p.read_bytes(),p.name
        https.append({'datei':p.name,'sha256':hashlib.sha256(d).hexdigest()})
res={'modus':modus,'technische_torzeilen_erfuellt':technisch,'abnahme_beantragt':endgueltig,'dateien':len(https),'https_bytegleich':len(https),
     'manifest_sha256':sha(O/'MANIFEST.sha256') if modus=='schluss' else None,'abholung':URL+'DATEIEN.txt','gebucht_eur':summe,'archivmitglieder':{k:len(v) for k,v in mitglieder.items()},'https':https}
dump(P/('LIEFERUNG-'+modus+'.json'),res)
print(json.dumps({k:v for k,v in res.items() if k!='https'},ensure_ascii=False,indent=2))
