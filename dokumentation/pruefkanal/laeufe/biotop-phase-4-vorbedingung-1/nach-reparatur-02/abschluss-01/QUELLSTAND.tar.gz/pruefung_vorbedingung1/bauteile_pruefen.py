"""Netzfreie Ausführung der vorhandenen zwei Bauteil-Testmodule."""
from pathlib import Path
import os, sys, socket, contextlib, json, time
P=Path('/root/phase-4-vorbedingung-1'); R=Path('/root/biotop')
os.environ.update(PYTHONPATH=str(R),PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(P/'temp'),BIOTOP_DB=str(P/'privat/unbenutzt.db'))
sys.path.insert(0,str(R));sys.dont_write_bytecode=True;os.chdir(R)
def verboten(*a,**k):raise AssertionError('Bauteilkontrolle: Netzaufruf gesperrt')
socket.socket.connect=verboten;socket.create_connection=verboten
import pytest
sammlung=[];berichte=[]
class Nachweis:
    @pytest.hookimpl(trylast=True)
    def pytest_collection_finish(self,session):sammlung.extend(x.nodeid for x in session.items)
    def pytest_runtest_logreport(self,report):berichte.append({'nodeid':report.nodeid,'phase':report.when,'outcome':report.outcome})
args=['-v','--tb=short','-p','no:cacheprovider','tests/test_ansage_aufnahme.py','tests/test_artvorlage.py','--junitxml='+str(P/'belege/bauteile.xml')]
t=time.monotonic()
with (P/'belege/bauteile.txt').open('x') as f,contextlib.redirect_stdout(f),contextlib.redirect_stderr(f):
    print('BEFEHL:',sys.executable,*args)
    rc=int(pytest.main(args,plugins=[Nachweis()]))
    print('RUECKGABEWERT:',rc)
r={'rc':rc,'sammlung':sammlung,'berichte':berichte,'dauer_s':time.monotonic()-t,'netz_gesperrt':True,'art':'gestellte Eigentests, kein natürlicher Lauf'}
(P/'belege/bauteile.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'rc':rc,'gesammelt':len(sammlung),'ausgefuehrt':sum(x['phase']=='call' for x in berichte),'bestanden':sum(x['phase']=='call' and x['outcome']=='passed' for x in berichte)},ensure_ascii=False,indent=2))
sys.exit(rc)
