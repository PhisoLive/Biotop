"""Organ 3.7: Aegis — der Ankläger. Fassung 2 (Masterprompt v2).

Schritte 1 (Wirkungskreis), 3 (Verfassung: mechanisch prüfbare Sätze), 4 (Angriff)
und 5 (Ausführung, paarweise Messung nach 3.5 F2). Schritt 2 (explizite Verträge) = Phase 2.

Paarweise Messung: Vorgeneration und Kandidat werden mit DEMSELBEN Testbestand
gemessen — dem des Kandidaten: vorhandene Tests + gültige neue Tests des Kandidaten
+ offene Immuntests des Bereichs + Befundklassen-Immuntests (3.5 „behoben heißt
verschwunden") + Angriffstests, die einen Fehler bestätigen. Zuwachs = Differenz
des Kernmaßes F2. Bestandene Tests zählen nicht.

Sicherheitsbefunde (3.7 F2): Trägt der Bereich in der Vorgeneration einen
statischen Befund, bekommt der Ankläger die Befundklasse mit Beschreibung, muss
deren bekannte Umgehungen angreifen, und der Angriff läuft mit einem schweren Modell.

Klassifikation von Angriffstests: nur AssertionError oder Ausnahme im Werk zählt
als bestätigter Fehler; ein Test, der an sich selbst stirbt, zählt nicht.
"""

from __future__ import annotations

import ast
import re
import sqlite3
import xml.etree.ElementTree as ET
from pathlib import Path

from ..anbieter import AnbieterFehler, aufrufen
from ..kern import befundklassen, diffwerk, messgeraet, protokoll
from ..kern.datenbank import j, lj, transaktion
from . import kammer, landkarte, verfassung

MODELL_ANGRIFF = ("openrouter", "google/gemini-2.5-flash")
MODELL_ANGRIFF_SCHWER = ("openrouter", "anthropic/claude-sonnet-4.5")

ANGRIFF_SYSTEM = """Du bist der Ankläger. Dein einziger Auftrag: den Fehler, den Grenzfall, die Nebenwirkung in einem vorgeschlagenen Änderungssatz finden.
Du wirst nach Fehlern bewertet, die sich durch Ausführung BESTÄTIGEN lassen — nicht nach Bedenken. Ein Test, der an einem falschen Import oder falschen Methodennamen stirbt, zählt gegen dich.
Du bekommst den Quelltext des Bereichs (nach Anwendung des Diffs), den Diff selbst, die Verträge des Bereichs und — falls vorhanden — die statische Befundklasse der berührten Stelle mit ihren bekannten Umgehungen.
Benutze NUR die Klassen, Funktionen und Signaturen, die im Quelltext stehen.
Liefere bis zu 4 pytest-Tests, die je einen konkreten Vertragsbruch, Fehler oder eine Sicherheits-Umgehung NACHWEISEN: Der Test schlägt mit AssertionError fehl (oder pytest.raises greift nicht), wenn der Fehler vorliegt, und besteht, wenn das Verhalten dem Vertrag entspricht.
Bei einer Befundklasse mit eval/exec: greife die Erreichbarkeit von Objektklassen über Introspektion an (().__class__.__base__.__subclasses__(), __globals__ von Funktionen, Format-String-Zugriffe, Ausdrucks-Explosion), nicht nur den naiven __import__-Aufruf. Der Vertrag verlangt, dass jede solche Eingabe mit der Fehlerklasse des Bereichs abgewiesen wird.
Keine Stilkritik, keine Tests über Sortierreihenfolgen, die kein Vertrag zusichert.
Wenn du nichts findest, antworte genau: KEIN ANGRIFF.

Antwortformat:
```python
# je Test eine Funktion test_..., Importe aus dem Werk-Paket
```
"""


# ---------------------------------------------------------------- Diff
def kandidat_dateien(werk: Path, diff: str) -> dict[str, str | None] | None:
    try:
        out: dict[str, str | None] = {}
        for d in diffwerk.parsen(diff):
            f = werk / d.pfad
            out[d.pfad] = diffwerk.anwenden(f.read_text() if f.exists() else None, d)
        return out if out else None
    except Exception:  # noqa: BLE001
        return None


def diff_grund(werk: Path, diff: str) -> str:
    try:
        for d in diffwerk.parsen(diff):
            f = werk / d.pfad
            diffwerk.anwenden(f.read_text() if f.exists() else None, d)
        return ""
    except Exception as e:  # noqa: BLE001
        return str(e)[:300]


# ---------------------------------------------------------------- Testläufe
def junit_lauf(werk: Path, paket: str, dateien: dict[str, str], testdateien: list[str]) -> dict[str, dict]:
    """Führt `testdateien` in der Kammer aus. Rückgabe je „datei::name“ → {ok, bestaetigt, meldung}."""
    if not testdateien:
        return {}
    skript = ("import subprocess,sys;subprocess.run([sys.executable,'-m','pytest','-q','-p','no:cacheprovider','--tb=short',"
              "'--junitxml=/tmp/j.xml',*sys.argv[1:]]);print('@@J@@'+open('/tmp/j.xml').read()+'@@E@@')")
    e = kammer.ausfuehren(werk, ["python", "_messgeraet/lauf.py", *testdateien], zeitlimit_s=120,
                          dateien={**dateien, "_messgeraet/lauf.py": skript})
    m = re.search(r"@@J@@(.*)@@E@@", e.stdout, re.S)
    out: dict[str, dict] = {}
    if not m:
        for t in testdateien:
            out[f"{t}::*"] = {"ok": False, "bestaetigt": False, "meldung": "Sammelfehler/Zeitlimit: " + (e.stderr or e.stdout)[-300:]}
        return out
    for tc in ET.fromstring(m.group(1)).iter("testcase"):
        datei = (tc.get("classname") or "").replace(".", "/") + ".py"
        name = tc.get("name")
        f = tc.find("failure"); er = tc.find("error")
        if f is None and er is None:
            out[f"{datei}::{name}"] = {"ok": True, "bestaetigt": False, "meldung": ""}
            continue
        kn = f if f is not None else er
        msg = (kn.get("message") or "")[:300]
        text = kn.text or ""
        orte = re.findall(r"^([\w./-]+\.py):\d+: in ", text, re.M)
        im_werk = bool(orte) and orte[-1].startswith(paket + "/")
        bestaetigt = msg.startswith(("AssertionError", "assert", "Failed", "TimeoutError")) or im_werk
        out[f"{datei}::{name}"] = {"ok": False, "bestaetigt": bestaetigt, "meldung": msg, "ort": orte[-1] if orte else ""}
    for t in testdateien:
        if not any(k.startswith(t + "::") for k in out):
            out[f"{t}::*"] = {"ok": False, "bestaetigt": False, "meldung": "Sammelfehler (Import) in " + t}
    return out


def nur_funktionen(code: str, behalten: set[str]) -> str | None:
    try:
        baum = ast.parse(code)
    except SyntaxError:
        return None
    koerper = [k for k in baum.body if not (isinstance(k, ast.FunctionDef) and k.name.startswith("test")) or k.name in behalten]
    if not any(isinstance(k, ast.FunctionDef) and k.name.startswith("test") for k in koerper):
        return None
    return ast.unparse(ast.Module(body=koerper, type_ignores=[])) + "\n"


def _namen(r: dict, praefix: str, **filt) -> set[str]:
    out = set()
    for n, x in r.items():
        if not n.startswith(praefix + "::") or n.endswith("::*"):
            continue
        if all(x.get(k) == v for k, v in filt.items()):
            out.add(n.split("::")[1])
    return out


# ---------------------------------------------------------------- Befundklassen
def befundklassen_tests(con, werk_id: int, bereich: str, basis: dict) -> dict[str, str]:
    """Befundklassen-Immuntests für alle statischen Befunde des Bereichs in der Vorgeneration,
    sofern die Verfassung einen Einstieg für die Klasse nennt."""
    verf = verfassung.lesen(con, werk_id)
    einstiege = ((verf or {}).get("regeln") or {}).get("einstiege", {})
    out = {}
    for b in basis["bereiche"][bereich].get("sicherheit_befunde", []):
        kl = b["test"]
        e = einstiege.get(kl, {}).get(bereich) or einstiege.get(kl, {}).get("*")
        if not e:
            continue
        code = befundklassen.immuntest_code(kl, e["import"], e["aufruf"], e["fehler_import"], e["fehler"])
        if code:
            out[f"tests/test_{bereich}_immun_befundklasse_{kl}.py"] = code
    return out


# ---------------------------------------------------------------- Angriff
def _angriff(con, lauf_id, werk_id, paket, bereich, diff, dateien, werk, klassen: list[str]) -> tuple[str | None, str]:
    quelle = []
    for d in sorted((werk / paket / bereich).rglob("*.py")):
        rel = str(d.relative_to(werk))
        inhalt = dateien.get(rel, d.read_text())
        if inhalt is not None:
            quelle.append(f"### {rel}\n```python\n{inhalt}\n```")
    vertraege = "\n".join(f"- {z['text']} ({z['quelle']})" for z in con.execute(
        "SELECT text, quelle FROM vertraege WHERE werk_id=? AND bereich=? AND herkunft='docstring'", (werk_id, bereich)))
    verf = verfassung.lesen(con, werk_id)
    verf_text = ("\n\nVERFASSUNG DES WERKS:\n" + verf["text"]) if verf else ""
    befund_text = ""
    modell = MODELL_ANGRIFF
    if klassen:
        befund_text = "\n\nSTATISCHE BEFUNDKLASSE(N) DER BERÜHRTEN STELLE (3.7 F2 — greife die bekannten Umgehungen an):\n" + "\n".join(
            "- " + befundklassen.beschreibung(k) for k in klassen)
        modell = MODELL_ANGRIFF_SCHWER
    try:
        a = aufrufen(con, lauf_id, *modell, ANGRIFF_SYSTEM,
                     f"BEREICH {bereich} (Paket {paket})\n\nVERTRÄGE:\n{vertraege or 'keine dokumentiert'}{verf_text}{befund_text}\n\nDIFF:\n```diff\n{diff}\n```\n\nQUELLTEXT NACH DIFF:\n" + "\n\n".join(quelle),
                     zweck=("schwer." if klassen else "") + f"aegis.angriff.{bereich}", max_tokens=2500, temperatur=0.3)
    except AnbieterFehler as e:
        protokoll.schreiben(con, "aegis.fehler", lauf_id=lauf_id, fehler=str(e)[:300])
        return None, modell[1]
    if "KEIN ANGRIFF" in a.text[:200]:
        return None, modell[1]
    m = re.search(r"```python\s*\n(.*?)```", a.text, re.S)
    return (m.group(1) if m else None), modell[1]


# ---------------------------------------------------------------- Anklage
def pruefen(con: sqlite3.Connection, lauf_id: int, werk_id: int, kandidat_id: int, werk: Path, paket: str,
            bereiche: list[str], bstrassen: list[tuple[str, str]], basis: dict, ausgang: dict,
            referenzlast: str | None, tausch: dict | None) -> dict:
    """Vollständige Anklage (F2). Rückgabe: Urteil mit Belegen; Status in der DB gesetzt."""
    k = con.execute("SELECT * FROM kandidaten WHERE id=?", (kandidat_id,)).fetchone()
    bereich = k["bereich"]
    urteil = {"kandidat": kandidat_id, "bereich": bereich, "status": "abgelehnt", "grund": "", "wirkungskreis": [],
              "immun": [], "tests_neu": [], "tests_verworfen": [], "immun_bestanden": [], "befundklassen": [],
              "verfassung_verstoesse": [], "angriff": None, "mass": None, "tests_offen": []}

    def fertig(status, grund, masse=None, dateien_final=None, basis_paar=None):
        urteil["status"], urteil["grund"] = status, grund
        if masse is not None:
            masse = {**masse, "_dateien": dateien_final or {}, "_basis_paar": basis_paar, "_urteil_f2": urteil["mass"]}
        with transaktion(con):
            con.execute("UPDATE kandidaten SET status=?, grund=?, masse=?, wirkungskreis=? WHERE id=?",
                        (status, grund, j(masse) if masse else None, j(urteil["wirkungskreis"]), kandidat_id))
        protokoll.schreiben(con, "aegis.urteil", lauf_id=lauf_id, kandidat=kandidat_id, bereich=bereich, status=status,
                            grund=grund[:500], wirkungskreis=urteil["wirkungskreis"], immun=urteil["immun"],
                            tests_neu=urteil["tests_neu"], tests_verworfen=urteil["tests_verworfen"],
                            immun_bestanden=urteil["immun_bestanden"], befundklassen=urteil["befundklassen"],
                            verfassung=urteil["verfassung_verstoesse"], angriff=urteil["angriff"], mass=urteil["mass"], tests_offen=urteil["tests_offen"])
        return urteil

    if k["status"] != "erzeugt":
        return fertig(k["status"], k["grund"] or "nicht geprüft")

    # Schritt 1: Wirkungskreis
    urteil["wirkungskreis"] = landkarte.wirkungskreis(bereich, bstrassen)

    dateien = kandidat_dateien(werk, k["diff"])
    if dateien is None:
        return fertig("abgelehnt", "Diff nicht anwendbar: " + (diff_grund(werk, k["diff"]) or "kein Inhalt"))
    code = {p: (i if i is not None else "") for p, i in dateien.items() if not p.startswith("tests/")}
    tests_kandidat = {p: i for p, i in dateien.items() if p.startswith("tests/") and i is not None}
    if not code and not tests_kandidat:
        return fertig("abgelehnt", "Diff ändert nichts")

    # Schritt 3: Verfassung (mechanisch prüfbare Sätze)
    verf = verfassung.lesen(con, werk_id)
    urteil["verfassung_verstoesse"] = verfassung.mechanisch_pruefen(verf, k["diff"], dateien, paket, bereich)
    if urteil["verfassung_verstoesse"]:
        return fertig("abgelehnt", "Verfassung verletzt: " + "; ".join(urteil["verfassung_verstoesse"]))

    # Testbestand des Kandidaten aufbauen
    testbestand: dict[str, str] = {}
    # a) Befundklassen-Immuntests (Bereich trägt in der Vorgeneration einen statischen Befund)
    bk = befundklassen_tests(con, werk_id, bereich, basis)
    testbestand.update(bk)
    urteil["befundklassen"] = sorted({b["test"] for b in basis["bereiche"][bereich].get("sicherheit_befunde", [])})
    # b) offene Immuntests des Bereichs
    for z in con.execute("SELECT name, code FROM immunsystem WHERE werk_id=? AND bereich=? AND status IN ('gefunden','offen')", (werk_id, bereich)):
        testbestand[f"tests/test_{bereich}_immun_{z['name']}.py"] = z["code"]
    # c) neue Tests des Kandidaten: nur die, die an der Vorgeneration FEHLSCHLAGEN (bestätigt) und am Kandidaten BESTEHEN
    if tests_kandidat:
        r_b = junit_lauf(werk, paket, tests_kandidat, list(tests_kandidat))
        r_k = junit_lauf(werk, paket, {**code, **tests_kandidat}, list(tests_kandidat))
        for p, inhalt in tests_kandidat.items():
            faellt_b = _namen(r_b, p, ok=False, bestaetigt=True)
            ok_k = _namen(r_k, p, ok=True)
            fehl_k = _namen(r_k, p, ok=False)
            if fehl_k:
                urteil["angriff"] = {"eigene_tests_fehlgeschlagen": sorted(fehl_k)}
                return fertig("abgelehnt", f"eigene Tests des Kandidaten schlagen am Kandidaten fehl: {sorted(fehl_k)}")
            gueltig = faellt_b & ok_k
            urteil["tests_verworfen"] += [f"{p}::{n} (besteht schon an der Vorgeneration — zählt nicht)" for n in sorted(_namen(r_b, p, ok=True))]
            urteil["tests_verworfen"] += [f"{p}::{n} (fehlerhafter Test)" for n in sorted(_namen(r_b, p, ok=False, bestaetigt=False))]
            g = nur_funktionen(inhalt, gueltig) if gueltig else None
            if g:
                testbestand[p] = g
                urteil["tests_neu"] += [f"{p}::{n}" for n in sorted(gueltig)]

    # Schritt 4: Angriff (schweres Modell bei Befundklasse)
    angriff, angriff_modell = _angriff(con, lauf_id, werk_id, paket, bereich, k["diff"], dateien, werk, urteil["befundklassen"])
    if angriff:
        ad = f"tests/test_{bereich}_immun_aegis_k{kandidat_id}_{bereich}.py"
        r_k = junit_lauf(werk, paket, {**code, ad: angriff}, [ad])
        r_b = junit_lauf(werk, paket, {ad: angriff}, [ad])
        best_k = _namen(r_k, ad, ok=False, bestaetigt=True)
        best_b = _namen(r_b, ad, ok=False, bestaetigt=True)
        fehlerhaft = _namen(r_k, ad, ok=False, bestaetigt=False) | _namen(r_b, ad, ok=False, bestaetigt=False)
        urteil["angriff"] = {"modell": angriff_modell, "bestaetigt_kandidat": sorted(best_k), "bestaetigt_basis": sorted(best_b),
                             "fehlerhaft": sorted(fehlerhaft), "gesamt": len(_namen(r_k, ad))}
        # Fund (3.5 F2): ein Test, der an der Vorgeneration fällt und am Kandidaten besteht, beweist eine Behebung
        # (+1 durch die Behebung, nicht durch den Test); ein Test, der am Kandidaten fällt, ist ein Angriffstreffer.
        # Beides geht ins Immunsystem. Gegen das Lauf-7-Problem (Kandidat kodiert sein eigenes Fehlverhalten als
        # „Behebung“) schützt jetzt die Pareto-Prüfung JE TEST: bricht er einen vorhandenen Test, ist er tot.
        gefunden = (best_k | best_b) - fehlerhaft
        if gefunden:
            name = f"aegis_k{kandidat_id}_{bereich}"
            code_immun = nur_funktionen(angriff, gefunden)
            if code_immun:
                with transaktion(con):
                    con.execute("INSERT OR IGNORE INTO immunsystem(werk_id, lauf_id, bereich, name, code, ursprung, status, erstellt_am, generation) VALUES (?,?,?,?,?,?,?,?,?)",
                                (werk_id, lauf_id, bereich, name, code_immun,
                                 f"Ankläger ({angriff_modell}), Kandidat {kandidat_id}: am Kandidaten {sorted(best_k)}, an der Vorgeneration {sorted(best_b)}",
                                 "gefunden", protokoll.jetzt(), k["generation"]))
                urteil["immun"].append(name)
                protokoll.schreiben(con, "immun.gefunden", lauf_id=lauf_id, kandidat=kandidat_id, bereich=bereich, name=name,
                                    modell=angriff_modell, bestaetigt_kandidat=sorted(best_k), bestaetigt_basis=sorted(best_b), fehlerhaft=sorted(fehlerhaft))
                # Bestätigte Angriffe gehören in den paarweisen Testbestand: sie zählen als Fehlschlag am Kandidaten
                # (und, falls der Fehler schon in der Vorgeneration lag, auch dort — dann neutral).
                testbestand[ad] = code_immun

    # Schritt 5: paarweise Messung — Vorgeneration und Kandidat mit demselben Testbestand
    basis_paar = messgeraet.messen(werk, bereiche, paket, referenzlast, dateien=testbestand)
    mess = messgeraet.messen(werk, bereiche, paket, referenzlast, dateien={**code, **testbestand})
    for name, mm in (("Vorgeneration", basis_paar), ("Kandidat", mess)):
        if not mm["gueltig"]:
            return fertig("abgelehnt", f"Kammer ({name}): {mm['grund']} (rc={mm.get('rc')})", mess if name == "Kandidat" else None)
    u = messgeraet.urteil_f2(basis_paar, mess, ausgang, bereiche, urteil["wirkungskreis"], tausch)
    urteil["mass"] = u
    # Ins Werk kommt nur, was der Kandidat BESTEHT (3.10: der Test beweist, dass der Fehler das Werk nicht
    # mehr trifft). Tests, die auch am Kandidaten fehlschlagen, bleiben im Immunsystem ('offen') und werden
    # späteren Kandidaten des Bereichs paarweise vorgelegt — sie kommen erst mit ihrer Behebung ins Werk.
    # (Lehre aus Lauf 6: sonst landen Fehler verworfener Kandidaten und unbelegte Modell-„Verträge" als rote Tests im Werk.)
    fehl_dateien = {f.split("::")[0] for f in mess["werk"]["tests_fehlgeschlagen_liste"]}
    tests_ins_werk = {p: c for p, c in testbestand.items() if p.split("/")[-1] not in fehl_dateien}
    urteil["tests_offen"] = sorted(p for p in testbestand if p not in tests_ins_werk)
    for p in tests_ins_werk:
        if "_immun_" in p and p not in bk:
            urteil["immun_bestanden"].append(p.split("_immun_")[1][:-3])
    dateien_final = {**code, **tests_ins_werk}
    if not u["ok"]:
        return fertig("abgelehnt", u["grund"], mess, dateien_final, basis_paar)
    return fertig("ueberlebt", u["grund"], mess, dateien_final, basis_paar)
