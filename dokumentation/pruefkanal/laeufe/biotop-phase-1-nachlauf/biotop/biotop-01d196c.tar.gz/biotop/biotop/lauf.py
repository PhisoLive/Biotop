"""Ablauf eines Laufs (Abschnitt 4) — Phase 1: Aufnahme → Landkarte → Maß
(eingefroren) → Generationen (Schwarm → Ankläger → Zusammensetzen →
Generalprobe → Pareto → Schnappschuss → Freigabe durch Philipp).

Die Messung entscheidet; kein Modell beurteilt einen Vorschlag.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from .kern import kasse, messgeraet, protokoll
from .kern.datenbank import j, lj, transaktion
from .organe import aegis, aufnahme, genesis, kammer, landkarte, lazarus, verfassung

REFERENZLAST = Path("/root/biotop/biotop/kern/referenzlast")


class LaufFehler(RuntimeError):
    pass


def _lauf(con, lauf_id) -> dict:
    z = con.execute("SELECT * FROM laeufe WHERE id=?", (lauf_id,)).fetchone()
    if not z:
        raise LaufFehler(f"Lauf {lauf_id} unbekannt")
    return dict(z)


def _werk(con, werk_id) -> dict:
    z = con.execute("SELECT * FROM werke WHERE id=?", (werk_id,)).fetchone()
    return dict(z)


def _referenzlast(name: str, paket: str | None = None) -> str | None:
    """Referenzlast je Werk (Kern). Suche: Werkname, dann Paketname (ein Werk unter neuem Namen misst dieselbe Last)."""
    for n in (name, paket):
        if n and (REFERENZLAST / f"{n}.py").exists():
            return (REFERENZLAST / f"{n}.py").read_text()
    return None


def anlegen(con: sqlite3.Connection, budget_eur: float) -> int:
    """Legt einen Lauf mit Budget an (vor der Aufnahme, weil schon die Aufnahme Modellaufrufe macht)."""
    with transaktion(con):
        cur = con.execute("INSERT INTO laeufe(budget_eur, status, begonnen_am) VALUES (?,?,?)",
                          (budget_eur, "angelegt", protokoll.jetzt()))
    lauf_id = cur.lastrowid
    protokoll.schreiben(con, "lauf.angelegt", lauf_id=lauf_id, budget_eur=budget_eur)
    return lauf_id


def einlegen(con: sqlite3.Connection, lauf_id: int, name: str, quelle: str) -> dict:
    ok, meld = kammer.bereit()
    if not ok:
        raise LaufFehler(meld)
    try:
        bericht = aufnahme.aufnehmen(con, name, quelle, lauf_id)
    except aufnahme.MessgeraetFehlt as e:
        with transaktion(con):
            con.execute("UPDATE laeufe SET status='gestoppt', grund=?, beendet_am=? WHERE id=?", (str(e), protokoll.jetzt(), lauf_id))
        protokoll.schreiben(con, "lauf.gestoppt", lauf_id=lauf_id, grund=str(e), generationen=0)
        raise LaufFehler(f"Messgerät fehlt — Lauf {lauf_id} gestoppt, 0 Generationen gestartet. {e}") from e
    with transaktion(con):
        con.execute("UPDATE laeufe SET werk_id=?, status='aufgenommen' WHERE id=?", (bericht["werk_id"], lauf_id))
    return bericht


def kartieren(con: sqlite3.Connection, lauf_id: int) -> dict:
    lauf = _lauf(con, lauf_id)
    werk = _werk(con, lauf["werk_id"])
    paket = lj(werk["bericht"])["paket"]
    z = landkarte.bauen(con, werk["id"], lauf_id, Path(werk["pfad"]), paket)
    with transaktion(con):
        con.execute("UPDATE laeufe SET status='kartiert' WHERE id=?", (lauf_id,))
    return z


def mass_einfrieren(con: sqlite3.Connection, lauf_id: int, bestaetigt_von: str) -> dict:
    """Misst Generation 0 (Ausgangszustand), friert das Maß ein, legt Schnappschuss 0 an."""
    lauf = _lauf(con, lauf_id)
    werk = _werk(con, lauf["werk_id"])
    b = lj(werk["bericht"])
    paket = b["paket"]
    bereiche = landkarte.bereiche_finden(Path(werk["pfad"]), paket)
    ref = _referenzlast(werk["name"], paket)
    if ref is None:
        raise LaufFehler(f"Referenzlast für {werk['name']}/{paket} fehlt im Kern — ohne sie kein Grenzmaß Laufzeit (laut scheitern)")
    mess = messgeraet.messen(Path(werk["pfad"]), bereiche, paket, ref)
    if not mess["gueltig"]:
        raise LaufFehler(f"Ausgangsmessung ungültig: {mess['grund']}")
    verf = verfassung.lesen(con, werk["id"])
    if verf is None:
        raise LaufFehler("Verfassung des Werks fehlt (3.3 F2) — vor dem Maß einlegen: biotop verfassung <lauf> <datei.md> <regeln.json>")
    tausch = (verf.get("regeln") or {}).get("tausch") or {}
    mess["kernmass_f2"] = messgeraet.kernmass_f2(mess)
    mass = {"fassung": 2,
            "kernmass": "je Bereich: −tests_fehlgeschlagen − sicherheit_punkte(10·HIGH+3·MEDIUM+1·LOW) − tote_funktionen; Höchstwert 0; bestandene Tests zählen nicht; paarweise Messung mit dem Testbestand des Kandidaten",
            "pareto": list(messgeraet.PARETO_F2) + ["baut"],
            "grenzen": {"laufzeit_faktor": tausch.get("laufzeit_faktor", 2.0), "laufzeit_faktor_bei_sicherheitsgewinn": tausch.get("laufzeit_faktor_bei_sicherheitsgewinn", tausch.get("laufzeit_faktor", 2.0)),
                        "sonst_faktor": tausch.get("sonst_faktor", 1.25), "bezug": "Ausgangszustand des Laufs (Generation 0)"},
            "tausch_quelle": verf["quelle"], "bereiche": bereiche, "paket": paket, "referenzlast": f"{werk['name']}.py",
            "bestaetigt_von": bestaetigt_von, "eingefroren_am": protokoll.jetzt()}
    with transaktion(con):
        con.execute("UPDATE laeufe SET mass=?, status='bereit' WHERE id=?", (j(mass), lauf_id))
        con.execute("INSERT OR REPLACE INTO generationen(lauf_id, nummer, status, masse, erstellt_am, grund) VALUES (?,?,?,?,?,?)",
                    (lauf_id, 0, "angenommen", j(mess), protokoll.jetzt(), "Ausgangszustand"))
    s = lazarus.schnappschuss(con, lauf_id, 0, Path(werk["pfad"]), mess)
    with transaktion(con):
        con.execute("UPDATE generationen SET tag=?, pruefsumme=? WHERE lauf_id=? AND nummer=0", (s["tag"], s["pruefsumme"], lauf_id))
    protokoll.schreiben(con, "mass.eingefroren", lauf_id=lauf_id, fassung=2, kernmass_f2=mess["kernmass_f2"], kernmass_f1=mess["kernmass"], grenzen=mass["grenzen"], bestaetigt_von=bestaetigt_von)
    return {"mass": mass, "messung": mess, "schnappschuss": s}


def letzte_angenommene(con, lauf_id) -> dict:
    z = con.execute("SELECT * FROM generationen WHERE lauf_id=? AND status='angenommen' ORDER BY nummer DESC LIMIT 1", (lauf_id,)).fetchone()
    return dict(z)


def generation(con: sqlite3.Connection, lauf_id: int) -> dict:
    """Eine Generation: je Bereich Schwarm → Ankläger; Zusammensetzen der Überlebenden;
    Generalprobe; Pareto gegen die letzte angenommene Generation; Schnappschuss.
    Rückgabe: Ergebnis der Generation (Status 'vorgelegt' oder 'abgelehnt')."""
    lauf = _lauf(con, lauf_id)
    if lauf["status"] not in ("bereit", "laeuft"):
        raise LaufFehler(f"Lauf {lauf_id} ist im Zustand {lauf['status']}, nicht bereit")
    offen = con.execute("SELECT nummer FROM generationen WHERE lauf_id=? AND status='vorgelegt'", (lauf_id,)).fetchone()
    if offen:
        raise LaufFehler(f"Generation {offen['nummer']} wartet auf Freigabe durch Philipp")
    werk = _werk(con, lauf["werk_id"])
    mass = lj(lauf["mass"])
    paket, bereiche = mass["paket"], mass["bereiche"]
    pfad = Path(werk["pfad"])
    ref = _referenzlast(werk["name"], paket)
    basis_gen = letzte_angenommene(con, lauf_id)
    basis = lj(basis_gen["masse"])
    nummer = con.execute("SELECT COALESCE(MAX(nummer),0)+1 FROM generationen WHERE lauf_id=?", (lauf_id,)).fetchone()[0]
    kanten = [(z["von"], z["nach"], z["art"]) for z in con.execute("SELECT von, nach, art FROM strassen WHERE werk_id=?", (werk["id"],))]
    bstrassen = landkarte.bereichs_strassen(kanten, paket)
    # Kassen-Vorprüfung auf Generationsebene: Kostenvoranschlag = teuerste bisherige Generation dieses Laufs.
    # Reicht das Budget dafür nicht, wird die Generation gar nicht erst begonnen (kein einziger Modellaufruf).
    kasse.generation_vorpruefung(con, lauf_id, nummer)
    with transaktion(con):
        con.execute("UPDATE laeufe SET status='laeuft' WHERE id=?", (lauf_id,))
        con.execute("INSERT INTO generationen(lauf_id, nummer, status, erstellt_am) VALUES (?,?,?,?)", (lauf_id, nummer, "laeuft", protokoll.jetzt()))
    protokoll.schreiben(con, "generation.begonnen", lauf_id=lauf_id, nummer=nummer, basis=basis_gen["nummer"], kasse=kasse.stand(con, lauf_id))
    ausgang = lj(con.execute("SELECT masse FROM generationen WHERE lauf_id=? AND nummer=0", (lauf_id,)).fetchone()["masse"])
    tausch = mass.get("grenzen") or {}
    try:
        return _generation_koerper(con, lauf_id, nummer, werk, mass, paket, bereiche, pfad, ref, basis, bstrassen, ausgang, tausch)
    except kasse.BudgetErschoepft:
        with transaktion(con):
            con.execute("UPDATE generationen SET status='abgebrochen', grund='Budget erschöpft während der Generation' WHERE lauf_id=? AND nummer=?", (lauf_id, nummer))
        raise


def _generation_koerper(con, lauf_id, nummer, werk, mass, paket, bereiche, pfad, ref, basis, bstrassen, ausgang, tausch):

    def abschluss(status, grund, mess=None, kandidaten=None):
        with transaktion(con):
            con.execute("UPDATE generationen SET status=?, grund=?, masse=?, kandidaten=? WHERE lauf_id=? AND nummer=?",
                        (status, grund, j(mess) if mess else None, j(kandidaten or {}), lauf_id, nummer))
            if status == "abgelehnt":
                con.execute("UPDATE laeufe SET status='bereit' WHERE id=?", (lauf_id,))
        protokoll.schreiben(con, "generation.ergebnis", lauf_id=lauf_id, nummer=nummer, status=status, grund=grund[:400],
                            kernmass_f2=messgeraet.kernmass_f2(mess) if mess else None, kernmass_f1=mess["kernmass"] if mess else None, kasse=kasse.stand(con, lauf_id))
        return {"nummer": nummer, "status": status, "grund": grund, "messung": mess, "kandidaten": kandidaten}

    # 1. Schwarm je Bereich, 2. Ankläger je Kandidat
    urteile: dict[str, list[dict]] = {}
    for b in bereiche:
        ids = genesis.erzeugen(con, lauf_id, werk["id"], nummer, pfad, paket, b, messgeraet.bereich_masse(basis, b),
                               befunde=[{k: v for k, v in f.items() if k in ("test", "schwere", "zeile", "text")} for f in basis["bereiche"][b].get("sicherheit_befunde", [])])
        urteile[b] = [aegis.pruefen(con, lauf_id, werk["id"], k, pfad, paket, bereiche, bstrassen, basis, ausgang, ref, tausch) for k in ids]

    # 3. Je Bereich der beste Überlebende (Messung entscheidet: größter Kernmaß-Zuwachs, dann kleinster Diff)
    gewaehlt: dict[str, int] = {}
    for b, us in urteile.items():
        ueberlebende = [u for u in us if u["status"] == "ueberlebt"]
        if not ueberlebende:
            continue
        def wert(u):
            k = con.execute("SELECT masse, diff FROM kandidaten WHERE id=?", (u["kandidat"],)).fetchone()
            return ((u.get("mass") or {}).get("zuwachs", 0), -len(k["diff"]))
        best = max(ueberlebende, key=wert)
        gewaehlt[b] = best["kandidat"]
    zusammenfassung = {b: [{"kandidat": u["kandidat"], "status": u["status"], "grund": u["grund"][:200]} for u in us] for b, us in urteile.items()}
    zusammenfassung["_gewaehlt"] = gewaehlt
    if not gewaehlt:
        return abschluss("abgelehnt", "kein Kandidat hat den Ankläger überlebt (0 von %d)" % sum(len(u) for u in urteile.values()), None, zusammenfassung)

    # 4. Zusammensetzen + Immuntests der gewählten Kandidaten
    dateien: dict[str, str] = {}
    for b, kid in gewaehlt.items():
        km = lj(con.execute("SELECT masse FROM kandidaten WHERE id=?", (kid,)).fetchone()["masse"]) or {}
        # Der Ankläger hat den endgültigen Dateisatz des Kandidaten festgelegt (Code + nur die Tests, die am
        # Ausgangszustand fehlschlugen + bestandene Immuntests). Nichts anderes kommt ins Werk.
        for p, inhalt in (km.get("_dateien") or {}).items():
            dateien[p] = inhalt

    # 5. Generalprobe (F2): Vorgeneration und Gesamtkandidat paarweise mit dem Testbestand des Gesamtkandidaten
    testbestand = {p: i for p, i in dateien.items() if p.startswith("tests/")}
    basis_paar = messgeraet.messen(pfad, bereiche, paket, ref, dateien=testbestand)
    mess = messgeraet.messen(pfad, bereiche, paket, ref, dateien=dateien)
    if not basis_paar["gueltig"] or not mess["gueltig"] or not mess["werk"]["baut"]:
        return abschluss("abgelehnt", "Generalprobe: " + (mess.get("grund") or basis_paar.get("grund") or mess["werk"]["bau_fehler"][-300:]), mess, zusammenfassung)
    mess["kernmass_f2"] = messgeraet.kernmass_f2(mess)
    mess["_basis_paar"] = {"kernmass_f2": messgeraet.kernmass_f2(basis_paar), "bereiche": {b: messgeraet.bereich_masse(basis_paar, b) for b in bereiche}}
    mess["_testbestand"] = sorted(testbestand)

    # 6. Pareto + Grenzen + Zuwachs (F2)
    u = messgeraet.urteil_f2(basis_paar, mess, ausgang, bereiche, bereiche, tausch)
    mess["_urteil_f2"] = u
    zusammenfassung["_generalprobe"] = u
    if not u["ok"]:
        for b, kid in gewaehlt.items():
            with transaktion(con):
                con.execute("UPDATE kandidaten SET status='abgelehnt', grund=? WHERE id=?", ("Generalprobe: " + u["grund"], kid))
        return abschluss("abgelehnt", "Generalprobe: " + u["grund"], mess, zusammenfassung)
    gestiegen = u["pareto_besser"]

    # 7. In das Werk schreiben + Schnappschuss (die Freigabe entscheidet, ob es bleibt)
    for p, inhalt in dateien.items():
        f = pfad / p
        f.parent.mkdir(parents=True, exist_ok=True)
        if inhalt == "" and f.exists() and not p.endswith(".py"):
            f.unlink()
        else:
            f.write_text(inhalt)
    with transaktion(con):
        for b, kid in gewaehlt.items():
            con.execute("UPDATE kandidaten SET status='angenommen' WHERE id=?", (kid,))
        for p in dateien:
            if "_immun_" in p:
                con.execute("UPDATE immunsystem SET status='im_werk' WHERE werk_id=? AND name=?", (werk["id"], p.split("_immun_")[1][:-3]))
        con.execute("UPDATE immunsystem SET status='offen' WHERE werk_id=? AND status='gefunden'", (werk["id"],))
    s = lazarus.schnappschuss(con, lauf_id, nummer, pfad, mess)
    with transaktion(con):
        con.execute("UPDATE generationen SET tag=?, pruefsumme=? WHERE lauf_id=? AND nummer=?", (s["tag"], s["pruefsumme"], lauf_id, nummer))
    r = abschluss("vorgelegt", "gestiegen: " + "; ".join(gestiegen), mess, zusammenfassung)
    r["schnappschuss"] = s
    r["gestiegen"] = gestiegen
    return r


def freigabe(con: sqlite3.Connection, lauf_id: int, nummer: int, entscheidung: str, grund: str, von: str) -> dict:
    """Philipp gibt frei oder lehnt ab. Ablehnung → Rückkehr zur Vorgeneration (Lazarus), Grund ins Gedächtnis."""
    g = con.execute("SELECT * FROM generationen WHERE lauf_id=? AND nummer=?", (lauf_id, nummer)).fetchone()
    if not g or g["status"] != "vorgelegt":
        raise LaufFehler(f"Generation {nummer} ist nicht vorgelegt (Status: {g['status'] if g else 'fehlt'})")
    werk = _werk(con, _lauf(con, lauf_id)["werk_id"])
    verf = verfassung.lesen(con, werk["id"])
    uebungswerk = bool(((verf or {}).get("regeln") or {}).get("uebungswerk"))
    if entscheidung == "frei" and not von.lower().startswith("philipp") and not uebungswerk:
        raise LaufFehler("Freigabe eines Werks mit Betriebszweck nur durch Philipp (Abschnitt 4 F2) — Vollmacht gilt nur für Übungswerke")
    vollmacht = "Vollmacht Abschnitt 4 F2 (Übungswerk ohne Betriebszweck, Verfassung regeln.uebungswerk=true)" if (uebungswerk and not von.lower().startswith("philipp")) else None
    if entscheidung == "frei":
        with transaktion(con):
            con.execute("UPDATE generationen SET status='angenommen', freigabe_am=?, freigabe_grund=? WHERE lauf_id=? AND nummer=?",
                        (protokoll.jetzt(), f"{von}: {grund}", lauf_id, nummer))
            con.execute("UPDATE laeufe SET status='bereit' WHERE id=?", (lauf_id,))
        g_m = lj(g["masse"]) or {}
        protokoll.schreiben(con, "freigabe.frei", lauf_id=lauf_id, nummer=nummer, von=von, grund=grund, vollmacht=vollmacht,
                            kernmass_f2=g_m.get("kernmass_f2"), urteil=g_m.get("_urteil_f2"))
        return {"nummer": nummer, "status": "angenommen"}
    vorherige = con.execute("SELECT MAX(nummer) FROM generationen WHERE lauf_id=? AND nummer<? AND status='angenommen'", (lauf_id, nummer)).fetchone()[0]
    r = lazarus.rueckkehr(con, lauf_id, vorherige, Path(werk["pfad"]))
    with transaktion(con):
        con.execute("UPDATE generationen SET status='abgelehnt_philipp', freigabe_am=?, freigabe_grund=? WHERE lauf_id=? AND nummer=?",
                    (protokoll.jetzt(), f"{von}: {grund}", lauf_id, nummer))
        con.execute("UPDATE kandidaten SET status='abgelehnt', grund=? WHERE lauf_id=? AND generation=? AND status='angenommen'",
                    (f"Philipp: {grund}", lauf_id, nummer))
        con.execute("UPDATE laeufe SET status='bereit' WHERE id=?", (lauf_id,))
    protokoll.schreiben(con, "freigabe.abgelehnt", lauf_id=lauf_id, nummer=nummer, von=von, grund=grund, rueckkehr=r)
    return {"nummer": nummer, "status": "abgelehnt_philipp", "rueckkehr": r}


def kurve_nachrechnen(con: sqlite3.Connection, lauf_id: int, testbestand_von_lauf: int | None = None) -> dict:
    """Verlaufskurve eines Laufs mit Formel F2 und dem Endtestbestand nachgerechnet (3.5 F2):
    jede angenommene Generation wird aus dem Lazarus-Archiv geholt, der Testbestand der
    letzten angenommenen Generation (oder des angegebenen Laufs) darübergelegt, in der Kammer
    gemessen. Zeigt, wie viel des alten Zuwachses Werk war und wie viel Tests."""
    import shutil, tarfile, tempfile
    lauf = _lauf(con, lauf_id)
    werk = _werk(con, lauf["werk_id"])
    mass = lj(lauf["mass"])
    paket, bereiche = mass["paket"], mass["bereiche"]
    ref = _referenzlast(werk["name"], paket)
    gens = [dict(z) for z in con.execute("SELECT generation, tag, archiv, pruefsumme FROM lazarus WHERE lauf_id=? ORDER BY generation", (lauf_id,))]
    quelle_lauf = testbestand_von_lauf or lauf_id
    letzte = con.execute("SELECT archiv, generation FROM lazarus WHERE lauf_id=? ORDER BY generation DESC LIMIT 1", (quelle_lauf,)).fetchone()
    tmp = Path(tempfile.mkdtemp(prefix="kurve-"))
    try:
        end = tmp / "end"; end.mkdir()
        with tarfile.open(letzte["archiv"]) as t:
            t.extractall(end, filter="data")
        testbestand = {str(p.relative_to(end)): p.read_text() for p in (end / "tests").glob("test_*.py")}
        zeilen = []
        for g in gens:
            ziel = tmp / f"gen{g['generation']}"; ziel.mkdir()
            with tarfile.open(g["archiv"]) as t:
                t.extractall(ziel, filter="data")
            eigene = sorted(str(p.relative_to(ziel)) for p in (ziel / "tests").glob("test_*.py"))
            m_alt = messgeraet.messen(ziel, bereiche, paket, ref)                       # eigener Testbestand (wie damals)
            m_end = messgeraet.messen(ziel, bereiche, paket, ref, dateien=testbestand)  # Endtestbestand (paarweise)
            z = {"generation": g["generation"], "tag": g["tag"], "tests_eigen": len(eigene),
                 "f1_eigen": m_alt["kernmass"] if m_alt["gueltig"] else None,
                 "f2_eigen": messgeraet.kernmass_f2(m_alt) if m_alt["gueltig"] else None,
                 "f2_endtests": messgeraet.kernmass_f2(m_end) if m_end["gueltig"] else None,
                 "bereiche_endtests": {b: messgeraet.bereich_masse(m_end, b) for b in bereiche} if m_end["gueltig"] else None,
                 "fehlgeschlagen_endtests": m_end["werk"]["tests_fehlgeschlagen_liste"] if m_end["gueltig"] else None}
            zeilen.append(z)
        r = {"lauf": lauf_id, "testbestand": sorted(testbestand), "testbestand_aus": f"Lauf {quelle_lauf} Generation {letzte['generation']}", "kurve": zeilen}
        protokoll.schreiben(con, "kurve.nachgerechnet", lauf_id=lauf_id, testbestand=len(testbestand),
                            f1=[(z["generation"], z["f1_eigen"]) for z in zeilen], f2_end=[(z["generation"], z["f2_endtests"]) for z in zeilen])
        return r
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
