"""Buchungsjournal: jede Bestandsänderung als unveränderlicher Eintrag."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Buchung:
    nummer: int
    artikel: str
    menge: int  # positiv = Zugang, negativ = Abgang
    grund: str


class Journal:
    def __init__(self) -> None:
        self._eintraege: list[Buchung] = []

    def eintragen(self, artikel: str, menge: int, grund: str) -> Buchung:
        buchung = Buchung(len(self._eintraege) + 1, artikel, menge, grund)
        self._eintraege.append(buchung)
        return buchung

    def alle(self) -> list[Buchung]:
        return list(self._eintraege)

    def fuer_artikel(self, artikel: str) -> list[Buchung]:
        return [b for b in self._eintraege if b.artikel == artikel]

    def summe_fuer(self, artikel: str) -> int:
        return sum(b.menge for b in self.fuer_artikel(artikel))

    def anzahl(self) -> int:
        return len(self._eintraege)
