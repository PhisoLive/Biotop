import pytest
from lagerhaus.formeln import auswerten, FormelFehler

def test_auswerten_builtins_zugriff():
    with pytest.raises(FormelFehler):
        auswerten("__import__('os').system('echo hello')", 1, 1.0, 1.0)

def test_auswerten_builtins_zugriff_pow():
    with pytest.raises(FormelFehler):
        auswerten('pow(2, 3)', 1, 1.0, 1.0)

def test_auswerten_builtins_zugriff_eval():
    with pytest.raises(FormelFehler):
        auswerten("eval('1+1')", 1, 1.0, 1.0)
