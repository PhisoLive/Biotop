from lagerhaus.preise.katalog import Artikel, Staffel, Katalog

def test_staffel_ab_menge_einschliesslich():
    artikel = Artikel(nummer='A1', name='Testartikel', grundpreis=10.0, staffeln=[Staffel(ab_menge=10, stueckpreis=8.0)])
    assert artikel.stueckpreis(10) == 8.0, 'Staffelpreis sollte bei genau ab_menge gelten'
