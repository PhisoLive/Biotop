import pytest
from lagerhaus.lager import Lager, NichtGenugBestand, Journal

def test_reservierung_einloesen_reduziert_reservierten_bestand_nicht_korrekt():
    lager = Lager()
    lager.zugang('A', 10)
    lager.reservieren('A', 5)
    assert lager.reserviert('A') == 5
    lager.reservierung_einloesen('A', 3)
    assert lager.reserviert('A') == 2

def test_reservierung_einloesen_mit_doppelter_reduzierung():
    lager = Lager()
    lager.zugang('Artikel1', 10)
    lager.reservieren('Artikel1', 5)
    assert lager.reserviert('Artikel1') == 5
    lager.reservierung_einloesen('Artikel1', 3)
    assert lager.reserviert('Artikel1') == 2
