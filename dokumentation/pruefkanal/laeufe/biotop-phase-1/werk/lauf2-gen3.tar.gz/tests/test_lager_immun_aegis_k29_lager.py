import pytest
from lagerhaus.lager import Lager, NichtGenugBestand, Journal

def test_reservierung_einloesen_reduziert_reservierung_nicht_korrekt():
    lager = Lager()
    lager.zugang('A', 10)
    lager.reservieren('A', 5)
    lager.reservierung_einloesen('A', 2)
    assert lager.reserviert('A') == 3, 'Reservierung sollte nach Einlösung korrekt reduziert werden'
