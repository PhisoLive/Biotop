from lagerhaus.preise.katalog import Artikel, Staffel, Katalog

def test_staffelpreis_genau_ab_menge():
    artikel = Artikel(nummer='A1', name='Testartikel', grundpreis=10.0, staffeln=[Staffel(ab_menge=10, stueckpreis=8.0)])
    katalog = Katalog()
    katalog.aufnehmen(artikel)
    assert katalog.preis_fuer('A1', 10) == 80.0
