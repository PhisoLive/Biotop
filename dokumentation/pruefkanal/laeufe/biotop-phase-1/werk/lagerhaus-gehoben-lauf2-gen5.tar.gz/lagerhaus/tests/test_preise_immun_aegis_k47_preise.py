import pytest
from lagerhaus.preise.katalog import Artikel, Katalog, Staffel, UnbekannterArtikel

def test_stueckpreis_mit_nicht_int_menge():
    artikel = Artikel(nummer='A1', name='Testartikel', grundpreis=10.0)
    with pytest.raises(TypeError, match='Menge muss ein Integer sein'):
        artikel.stueckpreis(1.5)

def test_preis_fuer_mit_nicht_int_menge():
    katalog = Katalog()
    artikel = Artikel(nummer='A1', name='Testartikel', grundpreis=10.0)
    katalog.aufnehmen(artikel)
    with pytest.raises(TypeError, match='Menge muss ein Integer sein'):
        katalog.preis_fuer('A1', 1.5)
