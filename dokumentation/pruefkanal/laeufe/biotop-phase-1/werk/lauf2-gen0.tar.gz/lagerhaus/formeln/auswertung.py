"""Auswertung von Rabattformeln.

Vertrag (abgeleitet): `auswerten` liest nur die drei Variablen, hat keine
Nebenwirkungen und wirft `FormelFehler` bei ungültigen Formeln.
"""

from __future__ import annotations

import math

ERLAUBTE_NAMEN = {"menge", "preis", "summe", "min", "max", "abs", "round"}


class FormelFehler(ValueError):
    """Formel ist syntaktisch oder semantisch ungültig."""


def pruefen(formel: str) -> bool:
    """Grobe Vorprüfung: Formel nicht leer, nicht zu lang, nur bekannte Namen.

    Rückgabe True, wenn die Formel ausgewertet werden darf.
    """
    if not formel or not formel.strip():
        return False
    if len(formel) > 200:
        return False
    return True


def auswerten(formel: str, menge: int, preis: float, summe: float):
    """Wertet `formel` mit den Variablen menge, preis, summe aus.

    Beispiele:
        auswerten("summe * 0.05", 3, 10.0, 30.0) -> 1.5
        auswerten("menge >= 10", 3, 10.0, 30.0) -> False
    """
    if not pruefen(formel):
        raise FormelFehler(f"ungültige Formel: {formel!r}")
    umgebung = {
        "menge": int(menge),
        "preis": float(preis),
        "summe": float(summe),
        "min": min,
        "max": max,
        "abs": abs,
        "round": round,
    }
    try:
        ergebnis = eval(formel, {"__builtins__": __builtins__}, umgebung)
    except FormelFehler:
        raise
    except Exception as exc:  # noqa: BLE001
        raise FormelFehler(f"Formel konnte nicht ausgewertet werden: {exc}") from exc
    if isinstance(ergebnis, bool):
        return ergebnis
    if isinstance(ergebnis, (int, float)):
        if isinstance(ergebnis, float) and (math.isnan(ergebnis) or math.isinf(ergebnis)):
            raise FormelFehler("Formel liefert keinen endlichen Wert")
        return float(ergebnis)
    raise FormelFehler(f"Formel liefert unerlaubten Typ {type(ergebnis).__name__}")


def formel_beschreibung(formel: str) -> str:
    """Menschenlesbare Kurzbeschreibung für Berichte."""
    kurz = formel.strip()
    if len(kurz) > 40:
        kurz = kurz[:37] + "..."
    return f"Formel „{kurz}“"
