"""Rabattregeln auf Warenkorbsummen.

Eine Rabattregel hat eine Bedingung und einen Betrag, beide als Formel
(Bereich formeln). Beispiel: Bedingung "summe >= 100", Betrag "summe * 0.05".

Vertrag (abgeleitet):
- rabatt_anwenden(summe, regeln, menge, preis) -> float ≥ 0, auf Cent gerundet;
  nie größer als `summe`.
- Regeln werden in Reihenfolge angewendet; jede Regel sieht die schon
  reduzierte Summe.
"""

from __future__ import annotations

from dataclasses import dataclass

from lagerhaus.formeln import auswerten

from .waehrung import runde_cent


@dataclass(frozen=True)
class Rabattregel:
    name: str
    bedingung: str
    betrag: str


def rabatt_betrag(regel: Rabattregel, summe: float, menge: int, preis: float) -> float:
    """Rabattbetrag einer einzelnen Regel, 0.0 wenn die Bedingung nicht greift."""
    if not auswerten(regel.bedingung, menge, preis, summe):
        return 0.0
    betrag = auswerten(regel.betrag, menge, preis, summe)
    if isinstance(betrag, bool):
        return 0.0
    betrag = float(betrag)
    if betrag < 0:
        return 0.0
    return min(betrag, summe)


def rabatt_anwenden(
    summe: float, regeln: list[Rabattregel], menge: int, preis: float
) -> float:
    """Wendet alle Regeln nacheinander an und liefert die reduzierte Summe."""
    rest = float(summe)
    for regel in regeln:
        rest -= rabatt_betrag(regel, rest, menge, preis)
        if rest <= 0:
            return 0.0
    return runde_cent(rest)


def _alte_rabattlogik(summe: float, prozent: float) -> float:
    """Vorgänger der Regel-Auswertung; seit Umstellung auf Formeln nicht mehr
    aufgerufen."""
    if prozent <= 0:
        return summe
    faktor = 1 - prozent / 100
    return runde_cent(summe * faktor)


def _rabatt_tabelle_alt() -> dict[str, float]:
    """Alte statische Rabatttabelle (nicht mehr verwendet)."""
    return {"stammkunde": 3.0, "grosskunde": 7.5, "mitarbeiter": 20.0}
