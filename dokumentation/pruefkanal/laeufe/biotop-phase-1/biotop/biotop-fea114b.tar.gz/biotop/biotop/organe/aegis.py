"""Organ 3.7: Aegis — der Ankläger. Phase 1: Schritte 1 (Wirkungskreis),
4 (Angriff) und 5 (Ausführung in der Kammer). Schritte 2/3 (Verträge,
Verfassung) kommen in Phase 2.

Regeln, alle durch Messung:
- Ein Kandidat, der irgendwo im Wirkungskreis ein hartes Maß senkt, ist tot.
- Ein Kandidat, der kein Maß hebt, ist tot (schützt den sauberen Bereich).
- Tests, die ein Kandidat mitbringt, zählen nur, wenn sie am Ausgangszustand
  FEHLSCHLAGEN und am Kandidaten BESTEHEN (sonst wären sie kein Nachweis einer
  Verbesserung, sondern Zählerei). Tests, die am Kandidaten fehlschlagen,
  töten ihn.
- Ein Angriffstest gilt nur als bestätigter Fehler, wenn er mit AssertionError
  scheitert oder die Ausnahme im Werk (nicht im Test) entsteht. Ein Test, der
  an seinem eigenen Fehler stirbt (AttributeError im Test, falscher Import),
  ist ein fehlerhafter Angriff und zählt nicht.
- Jeder bestätigte Fehler geht ins Immunsystem (3.10). Offene Immuntests werden
  jedem späteren Kandidaten des Bereichs vorgelegt; besteht er sie, zählen
  sie als gestiegene Tests und wandern ins Werk.
"""

from __future__ import annotations

import ast
import re
import sqlite3
import xml.etree.ElementTree as ET
from pathlib import Path

from ..anbieter import AnbieterFehler, aufrufen
from ..kern import diffwerk, messgeraet, protokoll
from ..kern.datenbank import j, lj, transaktion
from . import kammer, landkarte

MODELL_ANGRIFF = ("openrouter", "google/gemini-2.5-flash")

ANGRIFF_SYSTEM = """Du bist der Ankläger. Dein einziger Auftrag: den Fehler, den Grenzfall, die Nebenwirkung in einem vorgeschlagenen Änderungssatz finden.
Du wirst nach Fehlern bewertet, die sich durch Ausführung BESTÄTIGEN lassen — nicht nach Bedenken. Ein Test, der an einem falschen Import oder falschen Methodennamen stirbt, zählt gegen dich.
Du bekommst den Quelltext des Bereichs (nach Anwendung des Diffs), den Diff selbst und die Verträge des Bereichs. Benutze NUR die Klassen, Funktionen und Signaturen, die im Quelltext stehen.
Liefere bis zu 3 pytest-Tests, die je einen konkreten Vertragsbruch oder Fehler NACHWEISEN (der Test schlägt mit AssertionError fehl, wenn der Fehler vorliegt, und besteht, wenn das Verhalten dem Vertrag entspricht).
Nur Tests gegen die dokumentierten Verträge und offensichtliche Fehler (Ausnahmen, falsche Zahlen, negative Bestände, Randwerte ±1). Keine Stilkritik, keine Tests über Sortierreihenfolgen, die kein Vertrag zusichert.
Wenn du nichts findest, antworte genau: KEIN ANGRIFF.

Antwortformat:
```python
# je Test eine Funktion test_..., Importe aus dem Werk-Paket
```
"""


# ---------------------------------------------------------------- Diff
def kandidat_dateien(werk: Path, diff: str) -> dict[str, str | None] | None:
    """Wendet den Diff (tolerant, deterministisch) an und liefert die geänderten
    Dateien (Pfad→Inhalt; None = gelöscht). None gesamt = nicht anwendbar."""
    try:
        out: dict[str, str | None] = {}
        for d in diffwerk.parsen(diff):
            f = werk / d.pfad
            out[d.pfad] = diffwerk.anwenden(f.read_text() if f.exists() else None, d)
        return out if out else None
    except Exception:  # noqa: BLE001
        return None


def diff_grund(werk: Path, diff: str) -> str:
    try:
        for d in diffwerk.parsen(diff):
            f = werk / d.pfad
            diffwerk.anwenden(f.read_text() if f.exists() else None, d)
        return ""
    except Exception as e:  # noqa: BLE001
        return str(e)[:300]


# ---------------------------------------------------------------- Testläufe

def _junit_aus_lauf(werk: Path, paket: str, dateien: dict[str, str], testdateien: list[str]) -> dict[str, dict]:
    skript = ("import subprocess,sys;subprocess.run([sys.executable,'-m','pytest','-q','-p','no:cacheprovider','--tb=short',"
              "'--junitxml=/tmp/j.xml',*sys.argv[1:]]);print('@@J@@'+open('/tmp/j.xml').read()+'@@E@@')")
    e = kammer.ausfuehren(werk, ["python", "_messgeraet/lauf.py", *testdateien], zeitlimit_s=90,
                          dateien={**dateien, "_messgeraet/lauf.py": skript})
    m = re.search(r"@@J@@(.*)@@E@@", e.stdout, re.S)
    out: dict[str, dict] = {}
    if not m:
        for t in testdateien:
            out[f"{t}::*"] = {"ok": False, "bestaetigt": False, "meldung": "Sammelfehler/Zeitlimit: " + (e.stderr or e.stdout)[-300:]}
        return out
    wurzel = ET.fromstring(m.group(1))
    for tc in wurzel.iter("testcase"):
        datei = (tc.get("classname") or "").replace(".", "/") + ".py"
        name = tc.get("name")
        f = tc.find("failure")
        er = tc.find("error")
        if f is None and er is None:
            out[f"{datei}::{name}"] = {"ok": True, "bestaetigt": False, "meldung": ""}
            continue
        knoten = f if f is not None else er
        msg = (knoten.get("message") or "")[:300]
        text = knoten.text or ""
        # Ort der Ausnahme: letzte Pfadzeile vor "E   "
        orte = re.findall(r"^([\w./-]+\.py):\d+: in ", text, re.M)
        im_werk = bool(orte) and orte[-1].startswith(paket + "/")
        bestaetigt = msg.startswith(("AssertionError", "assert", "Failed")) or im_werk
        out[f"{datei}::{name}"] = {"ok": False, "bestaetigt": bestaetigt, "meldung": msg, "ort": orte[-1] if orte else ""}
    # Sammelfehler (Importfehler der Datei): keine testcases → als fehlerhaft markieren
    for t in testdateien:
        if not any(k.startswith(t + "::") for k in out):
            out[f"{t}::*"] = {"ok": False, "bestaetigt": False, "meldung": "Sammelfehler (Import) in " + t}
    return out


def _nur_funktionen(code: str, behalten: set[str]) -> str | None:
    """Behält Importe/Modulcode und nur die Testfunktionen in `behalten`."""
    try:
        baum = ast.parse(code)
    except SyntaxError:
        return None
    koerper = [k for k in baum.body if not (isinstance(k, ast.FunctionDef) and k.name.startswith("test")) or k.name in behalten]
    if not any(isinstance(k, ast.FunctionDef) and k.name.startswith("test") for k in koerper):
        return None
    return ast.unparse(ast.Module(body=koerper, type_ignores=[])) + "\n"


# ---------------------------------------------------------------- Angriff
def _angriff(con, lauf_id, werk_id, paket, bereich, diff, dateien, werk) -> str | None:
    quelle = []
    for d in sorted((werk / paket / bereich).rglob("*.py")):
        rel = str(d.relative_to(werk))
        inhalt = dateien.get(rel, d.read_text())
        if inhalt is not None:
            quelle.append(f"### {rel}\n```python\n{inhalt}\n```")
    vertraege = "\n".join(f"- {z['text']} ({z['quelle']})" for z in con.execute(
        "SELECT text, quelle FROM vertraege WHERE werk_id=? AND bereich=? AND herkunft='docstring'", (werk_id, bereich)))
    try:
        a = aufrufen(con, lauf_id, *MODELL_ANGRIFF, ANGRIFF_SYSTEM,
                     f"BEREICH {bereich} (Paket {paket})\n\nVERTRÄGE:\n{vertraege or 'keine dokumentiert'}\n\nDIFF:\n```diff\n{diff}\n```\n\nQUELLTEXT NACH DIFF:\n" + "\n\n".join(quelle),
                     zweck=f"aegis.angriff.{bereich}", max_tokens=1800, temperatur=0.3)
    except AnbieterFehler as e:
        protokoll.schreiben(con, "aegis.fehler", lauf_id=lauf_id, fehler=str(e)[:300])
        return None
    if "KEIN ANGRIFF" in a.text[:200]:
        return None
    m = re.search(r"```python\s*\n(.*?)```", a.text, re.S)
    return m.group(1) if m else None


# ---------------------------------------------------------------- Anklage
def pruefen(con: sqlite3.Connection, lauf_id: int, werk_id: int, kandidat_id: int, werk: Path, paket: str,
            bereiche: list[str], bstrassen: list[tuple[str, str]], basis: dict, referenzlast: str | None) -> dict:
    """Vollständige Anklage eines Kandidaten. Rückgabe: Urteil mit Belegen; Status wird in der DB gesetzt."""
    k = con.execute("SELECT * FROM kandidaten WHERE id=?", (kandidat_id,)).fetchone()
    bereich = k["bereich"]
    urteil = {"kandidat": kandidat_id, "bereich": bereich, "status": "abgelehnt", "grund": "", "wirkungskreis": [],
              "immun": [], "tests_neu": [], "tests_verworfen": [], "immun_bestanden": []}

    def fertig(status, grund, masse=None, dateien_final=None):
        urteil["status"], urteil["grund"] = status, grund
        if masse is not None and dateien_final is not None:
            masse = {**masse, "_dateien": dateien_final}
        with transaktion(con):
            con.execute("UPDATE kandidaten SET status=?, grund=?, masse=?, wirkungskreis=? WHERE id=?",
                        (status, grund, j(masse) if masse else None, j(urteil["wirkungskreis"]), kandidat_id))
        protokoll.schreiben(con, "aegis.urteil", lauf_id=lauf_id, kandidat=kandidat_id, bereich=bereich, status=status,
                            grund=grund[:400], wirkungskreis=urteil["wirkungskreis"], immun=urteil["immun"],
                            tests_neu=urteil["tests_neu"], tests_verworfen=urteil["tests_verworfen"], immun_bestanden=urteil["immun_bestanden"],
                            angriff=urteil.get("angriff"))
        return urteil

    if k["status"] != "erzeugt":
        return fertig(k["status"], k["grund"] or "nicht geprüft")

    # Schritt 1: Wirkungskreis
    urteil["wirkungskreis"] = landkarte.wirkungskreis(bereich, bstrassen)

    dateien = kandidat_dateien(werk, k["diff"])
    if dateien is None:
        return fertig("abgelehnt", "Diff nicht anwendbar: " + (diff_grund(werk, k["diff"]) or "kein Inhalt"))
    code = {p: (i if i is not None else "") for p, i in dateien.items() if not p.startswith("tests/")}
    tests_kandidat = {p: i for p, i in dateien.items() if p.startswith("tests/") and i is not None}
    if not code and not tests_kandidat:
        return fertig("abgelehnt", "Diff ändert nichts")

    # Offene Immuntests des Bereichs (vom Ankläger früher gefunden)
    immun_offen = {f"tests/test_{bereich}_immun_{z['name']}.py": (z["name"], z["code"]) for z in con.execute(
        "SELECT name, code FROM immunsystem WHERE werk_id=? AND bereich=? AND status IN ('gefunden','offen')", (werk_id, bereich))}

    # Neue Tests: am Ausgangszustand müssen sie FEHLSCHLAGEN, sonst zählen sie nicht
    tests_gueltig: dict[str, str] = {}
    if tests_kandidat:
        an_basis = _junit_aus_lauf(werk, paket, tests_kandidat, list(tests_kandidat))
        for p, inhalt in tests_kandidat.items():
            faellt = {n.split("::")[1] for n, r in an_basis.items() if n.startswith(p + "::") and not r["ok"] and r["bestaetigt"]}
            besteht = {n.split("::")[1] for n, r in an_basis.items() if n.startswith(p + "::") and r["ok"]}
            urteil["tests_verworfen"] += [f"{p}::{n} (besteht schon am Ausgangszustand)" for n in sorted(besteht)]
            urteil["tests_verworfen"] += [f"{p}::{n.split('::')[1]} (fehlerhafter Test: {r['meldung'][:80]})" for n, r in an_basis.items()
                                          if n.startswith(p + "::") and not r["ok"] and not r["bestaetigt"]]
            gefiltert = _nur_funktionen(inhalt, faellt) if faellt else None
            if gefiltert:
                tests_gueltig[p] = gefiltert
                urteil["tests_neu"] += [f"{p}::{n}" for n in sorted(faellt)]

    # Schritt 5a: Messung mit Kandidat + gültigen neuen Tests
    dateien_mess = {**code, **tests_gueltig}
    mess = messgeraet.messen(werk, bereiche, paket, referenzlast, dateien=dateien_mess)
    if not mess["gueltig"]:
        return fertig("abgelehnt", f"Kammer: {mess['grund']} (rc={mess.get('rc')})", mess)
    if not mess["werk"]["baut"]:
        return fertig("abgelehnt", "baut nicht: " + mess["werk"]["bau_fehler"][-300:], mess)

    # Offene Immuntests am Kandidaten: bestandene wandern mit (zählen als gestiegene Tests)
    if immun_offen:
        r = _junit_aus_lauf(werk, paket, {**code, **{p: c for p, (_, c) in immun_offen.items()}}, list(immun_offen))
        for p, (name, c) in immun_offen.items():
            ok = {n.split("::")[1] for n, x in r.items() if n.startswith(p + "::") and x["ok"]}
            if ok:
                g = _nur_funktionen(c, ok)
                if g:
                    dateien_mess[p] = g
                    urteil["immun_bestanden"].append(name)
        if urteil["immun_bestanden"]:
            mess = messgeraet.messen(werk, bereiche, paket, referenzlast, dateien=dateien_mess)
            if not mess["gueltig"]:
                return fertig("abgelehnt", f"Kammer (2): {mess['grund']}", mess)

    # Schritt 4: Angriff — Tests gegen den Kandidaten, gemessen an Kandidat und Ausgangszustand
    angriff = _angriff(con, lauf_id, werk_id, paket, bereich, k["diff"], dateien, werk)
    angriff_ergebnis = None
    if angriff:
        ad = f"tests/test_{bereich}_aegis_k{kandidat_id}.py"
        r_k = _junit_aus_lauf(werk, paket, {**code, ad: angriff}, [ad])
        r_b = _junit_aus_lauf(werk, paket, {ad: angriff}, [ad])
        best_k = {n.split("::")[1] for n, x in r_k.items() if not x["ok"] and x["bestaetigt"]}
        best_b = {n.split("::")[1] for n, x in r_b.items() if not x["ok"] and x["bestaetigt"]}
        ok_k = {n.split("::")[1] for n, x in r_k.items() if x["ok"]}
        fehlerhaft = {n.split("::")[1] for n, x in r_k.items() if not x["ok"] and not x["bestaetigt"]}
        angriff_ergebnis = {"bestaetigt_kandidat": sorted(best_k), "bestaetigt_basis": sorted(best_b), "fehlerhaft": sorted(fehlerhaft),
                            "gesamt": len([n for n in r_k if not n.endswith("::*")])}
        # Jeder durch Ausführung bestätigte Fehler — am Kandidaten oder am Ausgangszustand — wird zum Test (Satz 7).
        gefunden = (best_k | best_b) - fehlerhaft
        if gefunden:
            name = f"aegis_k{kandidat_id}_{bereich}"
            code_immun = _nur_funktionen(angriff, gefunden)
            if code_immun:
                with transaktion(con):
                    con.execute("INSERT OR IGNORE INTO immunsystem(werk_id, lauf_id, bereich, name, code, ursprung, status, erstellt_am, generation) VALUES (?,?,?,?,?,?,?,?,?)",
                                (werk_id, lauf_id, bereich, name, code_immun,
                                 f"Ankläger, Kandidat {kandidat_id}: bestätigt am Kandidaten {sorted(best_k)}, am Ausgangszustand {sorted(best_b)}",
                                 "gefunden", protokoll.jetzt(), k["generation"]))
                urteil["immun"].append(name)
                protokoll.schreiben(con, "immun.gefunden", lauf_id=lauf_id, kandidat=kandidat_id, bereich=bereich, name=name,
                                    bestaetigt_kandidat=sorted(best_k), bestaetigt_basis=sorted(best_b), fehlerhaft=sorted(fehlerhaft))
        neu_eingefuehrt = best_k - best_b
        if neu_eingefuehrt:
            urteil["angriff"] = angriff_ergebnis
            return fertig("abgelehnt", f"Ankläger: Kandidat führt Fehler ein — {sorted(neu_eingefuehrt)} (bestätigt am Kandidaten, nicht am Ausgangszustand)", mess)
        # Fehler am Ausgangszustand, den der Kandidat behebt (fällt an Basis, besteht am Kandidaten):
        # der Test wandert in den Dateisatz des Kandidaten und zählt als gestiegener Test.
        behoben = best_b & ok_k
        if behoben:
            g = _nur_funktionen(angriff, behoben)
            if g:
                dateien_mess[f"tests/test_{bereich}_immun_aegis_k{kandidat_id}_{bereich}.py"] = g
                urteil["immun_bestanden"].append(f"aegis_k{kandidat_id}_{bereich}")
                urteil["tests_neu"] += [f"aegis::{n}" for n in sorted(behoben)]
                mess = messgeraet.messen(werk, bereiche, paket, referenzlast, dateien=dateien_mess)
                if not mess["gueltig"]:
                    return fertig("abgelehnt", f"Kammer (3): {mess['grund']}", mess)
    urteil["angriff"] = angriff_ergebnis

    # Pareto über Wirkungskreis (alle Maße) + übrige Bereiche (Tests) + Werk (Zyklen)
    gesunken, gestiegen = [], []
    for b in bereiche:
        v = messgeraet.vergleichen(messgeraet.bereich_masse(basis, b), messgeraet.bereich_masse(mess, b))
        if b in urteil["wirkungskreis"]:
            gesunken += [f"{b}.{x}" for x in v["gesunken"]]
            gestiegen += [f"{b}.{x}" for x in v["gestiegen"]]
        else:
            gesunken += [f"{b}.{x}" for x in v["gesunken"] if not x.startswith("laufzeit")]
    vw = messgeraet.vergleichen({"zyklen": basis["werk"]["zyklen"]}, {"zyklen": mess["werk"]["zyklen"]})
    gesunken += [f"werk.{x}" for x in vw["gesunken"]]
    urteil["gesunken"], urteil["gestiegen"] = gesunken, gestiegen
    if gesunken:
        return fertig("abgelehnt", "hartes Maß gesunken: " + "; ".join(gesunken), mess, dateien_mess)
    if not gestiegen:
        hinweis = f"; verworfene Tests: {len(urteil['tests_verworfen'])}" if urteil["tests_verworfen"] else ""
        return fertig("abgelehnt", "kein hartes Maß gestiegen (Maße unverändert in " + ", ".join(urteil["wirkungskreis"]) + ")" + hinweis, mess, dateien_mess)
    return fertig("ueberlebt", "gestiegen: " + "; ".join(gestiegen), mess, dateien_mess)
