"""Organ 3.6: Genesis — der Schwarm. Phase 1: eine Nische („Der Sichere“),
zwei Anbieter (Hersteller) über OpenRouter.

Ausgang: Kandidaten als Änderungssätze (unified diff), nie ganze Dateien;
jeder mit Begründung und der Angabe, welche Verträge er berührt.
Der Schwarm sieht nur die Landkarten-Sicht + die Quelldateien seines
Bereichs + die Liste der gescheiterten Wege (Projektgedächtnis).
"""

from __future__ import annotations

import re
import sqlite3
from pathlib import Path

from ..anbieter import AnbieterFehler, aufrufen
from ..kern import protokoll
from ..kern.datenbank import j, lj
from . import landkarte

NISCHEN = {
    "sicher": {
        "temperatur": 0.2,
        "auftrag": "Du bist „Der Sichere“: Beseitige Fehler, Sicherheitslücken, tote Stellen und Vertragsverletzungen; "
                   "härte Verträge; wage nichts Neues; verändere keine öffentliche Signatur.",
        "modelle": [("openrouter", "openai/gpt-4.1-mini"), ("openrouter", "google/gemini-2.5-flash")],
    },
}

SYSTEM = """Du bist ein Mitglied eines Schwarms, das ein Software-Werk in kleinen, messbaren Schritten hebt.
Du bekommst: die Landkarte des Werks, den Quelltext EINES Bereichs, die harten Maße, die Verträge, und die Liste bereits gescheiterter Wege.
Du lieferst GENAU EINEN Vorschlag als unified diff (git-Format, Pfade relativ zur Werkwurzel, mit a/ und b/ Präfix), der nur Dateien deines Bereichs ändert.
Ein Diff besteht aus kleinen Hunks mit 2–3 Kontextzeilen; ersetze NIE eine ganze Datei (das wird als Neuschreibung abgelehnt).

So wird gemessen (nichts anderes zählt):
- tests_bestanden steigt NUR durch Tests, die am jetzigen Stand FEHLSCHLAGEN und mit deiner Änderung BESTEHEN. Ein Test, der schon jetzt besteht, wird verworfen. Behebst du einen Fehler oder Vertragsbruch, MUSST du deshalb einen solchen Test mitliefern, in einer NEUEN Datei tests/test_<bereich>_<thema>.py (vorhandene Tests niemals ändern). Ein Test, der mit deiner Änderung fehlschlägt, tötet den Vorschlag.
- sicherheit_punkte sinkt nur, wenn bandit den Befund nicht mehr meldet (bandit meldet eval/exec IMMER, auch mit leeren builtins — ein eval-Befund verschwindet nur, wenn eval verschwindet, z. B. durch einen ast-basierten Auswerter).
- tote_funktionen sinkt, wenn vulture eine unbenutzte Funktion nicht mehr findet.
- laufzeit_ms sinkt bei messbar (>15 %) schnellerem Code auf der Referenzlast.
- groesste_funktion darf nicht um mehr als 25 % wachsen; alle anderen Maße dürfen nicht sinken — auch nicht in Nachbarbereichen.
Wenn du im Bereich nichts findest, was ein Maß messbar hebt, antworte mit genau: KEIN VORSCHLAG — und einem Satz Begründung. Das ist eine gute Antwort; ein erfundener Vorschlag nicht.

Antwortformat (strikt):
BEGRÜNDUNG: <2–4 Sätze: was, warum, welches Maß steigt>
VERTRÄGE: <welche Verträge berührt werden, oder „keine“>
DIFF:
```diff
<unified diff>
```
"""


def _quelltext(werk: Path, paket: str, bereich: str) -> str:
    teile = []
    for d in sorted((werk / paket / bereich).rglob("*.py")):
        rel = d.relative_to(werk)
        teile.append(f"### {rel}\n```python\n{d.read_text()}\n```")
    tests = werk / "tests" / f"test_{bereich}.py"
    if tests.exists():
        teile.append(f"### {tests.relative_to(werk)} (nur lesen)\n```python\n{tests.read_text()}\n```")
    return "\n\n".join(teile)


def _parsen(text: str) -> dict | None:
    if "KEIN VORSCHLAG" in text[:400]:
        return None
    m = re.search(r"```diff\s*\n(.*?)```", text, re.S)
    if not m:
        m = re.search(r"(^diff --git .*|^--- a/.*)", text, re.S | re.M)
        diff = m.group(1) if m else ""
    else:
        diff = m.group(1)
    if not diff.strip() or "+++ " not in diff:
        return None
    beg = re.search(r"BEGRÜNDUNG:\s*(.+?)(?:\nVERTRÄGE:|\nDIFF:|$)", text, re.S)
    vt = re.search(r"VERTRÄGE:\s*(.+?)(?:\nDIFF:|$)", text, re.S)
    return {"diff": diff.strip() + "\n", "begruendung": (beg.group(1).strip() if beg else "")[:1000],
            "vertraege": (vt.group(1).strip() if vt else "")[:500]}


def dateien_im_diff(diff: str) -> list[str]:
    return sorted(set(re.findall(r"^\+\+\+ b/(\S+)", diff, re.M)) | set(re.findall(r"^diff --git a/(\S+) b/", diff, re.M)))


def gescheiterte_wege(con: sqlite3.Connection, lauf_id: int, bereich: str) -> list[str]:
    out = []
    for z in con.execute("SELECT generation, begruendung, grund FROM kandidaten WHERE lauf_id=? AND bereich=? AND status='abgelehnt' AND grund NOT LIKE 'Diff nicht anwendbar%' ORDER BY id DESC LIMIT 12",
                         (lauf_id, bereich)):
        out.append(f"Gen {z['generation']}: {z['begruendung'][:200]} → abgelehnt: {z['grund'][:200]}")
    return out


def erzeugen(con: sqlite3.Connection, lauf_id: int, werk_id: int, generation: int, werk: Path, paket: str,
             bereich: str, masse: dict, nische: str = "sicher") -> list[int]:
    """Erzeugt Kandidaten für einen Bereich (ein Aufruf je Modell der Nische).
    Rückgabe: Kandidaten-IDs (auch „kein Vorschlag“ wird als Kandidat mit Status 'leer' geführt)."""
    n = NISCHEN[nische]
    sicht = landkarte.sicht(con, werk_id, paket, bereich)
    quelle = _quelltext(werk, paket, bereich)
    wege = gescheiterte_wege(con, lauf_id, bereich)
    nutzer = (f"{n['auftrag']}\n\nLANDKARTE:\n{sicht}\n\nHARTE MASSE DES BEREICHS {bereich} (aktuell): {j(masse)}\n"
              f"Richtung: tests_bestanden ↑, tests_fehlgeschlagen ↓, sicherheit_punkte ↓ (bandit), tote_funktionen ↓ (vulture), laufzeit_ms ↓ (Referenzlast), groesste_funktion ↓\n\n"
              f"BEREITS GESCHEITERTE WEGE (nicht wiederholen):\n" + ("\n".join(wege) if wege else "keine") +
              f"\n\nQUELLTEXT DES BEREICHS {bereich}:\n{quelle}")
    ids = []
    for anbieter, modell in n["modelle"]:
        try:
            a = aufrufen(con, lauf_id, anbieter, modell, SYSTEM, nutzer, zweck=f"schwarm.{nische}.{bereich}.gen{generation}",
                         max_tokens=3500, temperatur=n["temperatur"])
        except AnbieterFehler as e:
            protokoll.schreiben(con, "schwarm.fehler", lauf_id=lauf_id, bereich=bereich, modell=modell, fehler=str(e)[:300])
            continue
        k = _parsen(a.text)
        hersteller = modell.split("/")[0]
        if k is None:
            status, diff, beg, vt = "leer", "", a.text.strip()[:400], ""
        else:
            status, diff, beg, vt = "erzeugt", k["diff"], k["begruendung"], k["vertraege"]
            fremd = [f for f in dateien_im_diff(diff) if not (f.startswith(f"{paket}/{bereich}/") or f.startswith(f"tests/test_{bereich}_"))]
            if fremd:
                status, beg = "abgelehnt", beg
                grund = f"Diff berührt fremde Dateien: {fremd}"
            else:
                grund = ""
        cur = con.execute(
            "INSERT INTO kandidaten(lauf_id, generation, bereich, nische, anbieter, modell, diff, begruendung, status, grund, erstellt_am) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (lauf_id, generation, bereich, nische, f"{anbieter}/{hersteller}", modell, diff, beg, status,
             grund if status == "abgelehnt" else ("kein Vorschlag" if status == "leer" else ""), protokoll.jetzt()))
        ids.append(cur.lastrowid)
        protokoll.schreiben(con, "schwarm.kandidat", lauf_id=lauf_id, generation=generation, bereich=bereich, nische=nische,
                            modell=modell, kandidat=cur.lastrowid, status=status, dateien=dateien_im_diff(diff), vertraege=vt[:200])
    return ids
