"""Befehlszeile des Biotops (Phase 1: einzige Oberfläche).

  biotop lauf anlegen --budget 30
  biotop einlegen <lauf> <name> <quelle>
  biotop kartieren <lauf>
  biotop mass <lauf> --bestaetigt-von Philipp
  biotop generation <lauf>
  biotop freigabe <lauf> <nummer> frei|ablehnen --grund "..." --von Philipp
  biotop lazarus liste|rueckkehr <lauf> [nummer] [--ziel PFAD]
  biotop kasse <lauf>
  biotop protokoll [--ab N] [--art X]
  biotop benutzer <name>            (Kennwort über Umgebungsvariable BIOTOP_KENNWORT)
"""

from __future__ import annotations

import argparse
import json
import os
import sys

from . import lauf as L
from .kern import anmeldung, kasse, protokoll
from .kern.datenbank import verbinden
from .organe import lazarus


def _p(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=1, default=str))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="biotop")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("lauf"); s.add_argument("aktion", choices=["anlegen"]); s.add_argument("--budget", type=float, required=True)
    s = sub.add_parser("einlegen"); s.add_argument("lauf", type=int); s.add_argument("name"); s.add_argument("quelle")
    s = sub.add_parser("kartieren"); s.add_argument("lauf", type=int)
    s = sub.add_parser("mass"); s.add_argument("lauf", type=int); s.add_argument("--bestaetigt-von", required=True)
    s = sub.add_parser("generation"); s.add_argument("lauf", type=int)
    s = sub.add_parser("freigabe"); s.add_argument("lauf", type=int); s.add_argument("nummer", type=int)
    s.add_argument("entscheidung", choices=["frei", "ablehnen"]); s.add_argument("--grund", default=""); s.add_argument("--von", required=True)
    s = sub.add_parser("lazarus"); s.add_argument("aktion", choices=["liste", "rueckkehr"]); s.add_argument("lauf", type=int)
    s.add_argument("nummer", type=int, nargs="?"); s.add_argument("--ziel")
    s = sub.add_parser("kasse"); s.add_argument("lauf", type=int, nargs="?")
    s = sub.add_parser("protokoll"); s.add_argument("--ab", type=int, default=0); s.add_argument("--art"); s.add_argument("--limit", type=int, default=200)
    s = sub.add_parser("protokoll-pruefen")
    s = sub.add_parser("benutzer"); s.add_argument("name")
    a = ap.parse_args(argv)
    con = verbinden()
    try:
        if a.cmd == "lauf":
            _p({"lauf": L.anlegen(con, a.budget), "budget_eur": a.budget})
        elif a.cmd == "einlegen":
            _p(L.einlegen(con, a.lauf, a.name, a.quelle))
        elif a.cmd == "kartieren":
            _p(L.kartieren(con, a.lauf))
        elif a.cmd == "mass":
            r = L.mass_einfrieren(con, a.lauf, a.bestaetigt_von)
            _p({"mass": r["mass"], "kernmass": r["messung"]["kernmass"], "bereiche": {b: {k: v for k, v in m.items() if not isinstance(v, (list, dict))} for b, m in r["messung"]["bereiche"].items()}, "schnappschuss": r["schnappschuss"]})
        elif a.cmd == "generation":
            r = L.generation(con, a.lauf)
            m = r.get("messung")
            _p({"nummer": r["nummer"], "status": r["status"], "grund": r["grund"], "kandidaten": r["kandidaten"],
                "kernmass": m["kernmass"] if m else None, "schnappschuss": r.get("schnappschuss"), "kasse": kasse.stand(con, a.lauf)})
        elif a.cmd == "freigabe":
            _p(L.freigabe(con, a.lauf, a.nummer, a.entscheidung, a.grund, a.von))
        elif a.cmd == "lazarus":
            if a.aktion == "liste":
                _p(lazarus.liste(con, a.lauf))
            else:
                from pathlib import Path
                werk = L._werk(con, L._lauf(con, a.lauf)["werk_id"])
                _p(lazarus.rueckkehr(con, a.lauf, a.nummer, Path(werk["pfad"]), Path(a.ziel) if a.ziel else None))
        elif a.cmd == "kasse":
            if a.lauf:
                _p(kasse.stand(con, a.lauf))
            print(kasse.bericht_md(con, a.lauf))
        elif a.cmd == "protokoll":
            for z in protokoll.lesen(con, a.ab, a.art, a.limit):
                print(f"#{z['nr']} {z['zeit']} {z['art']} {z['inhalt']}")
        elif a.cmd == "protokoll-pruefen":
            ok, n = protokoll.pruefen(con)
            _p({"kette_in_ordnung": ok, "geprueft": n})
        elif a.cmd == "benutzer":
            anmeldung.benutzer_anlegen(con, a.name, os.environ.get("BIOTOP_KENNWORT", ""))
            _p({"benutzer": a.name, "angelegt": True})
        return 0
    except (L.LaufFehler, kasse.BudgetErschoepft) as e:
        print(f"ABBRUCH: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
