# Referenzlast für das Werk „lagerhaus" — Teil des Messgeräts (Kern).
# Je Bereich eine Funktion last_<bereich>(), die eine feste Arbeit ausführt.
# Wird in der Kammer ausgeführt; Ergebnis ist die Laufzeit in ms (min aus 3).

import sys
sys.path.insert(0, "/werk")


def last_formeln():
    from lagerhaus.formeln import auswerten
    for i in range(3000):
        auswerten("min(summe * 0.05, 20) + max(menge, 3)", i % 50, 9.99, float(i))


def last_preise():
    from lagerhaus.preise import Artikel, Katalog, Rabattregel, Staffel, rabatt_anwenden
    k = Katalog()
    for i in range(200):
        k.aufnehmen(Artikel(f"A{i}", "x", 1.0 + i, [Staffel(10, 0.9), Staffel(100, 0.8)]))
    regeln = [Rabattregel("a", "summe >= 100", "summe * 0.05"), Rabattregel("b", "menge >= 50", "10")]
    for i in range(2000):
        s = k.preis_fuer(f"A{i % 200}", 1 + i % 150)
        rabatt_anwenden(s, regeln, 1 + i % 150, s)


def last_lager():
    from lagerhaus.lager import Lager
    l = Lager()
    for i in range(1500):
        l.zugang(f"A{i % 20}", 3)
        if i % 3 == 0:
            l.entnehmen(f"A{i % 20}", 1)
        l.verfuegbar(f"A{i % 20}")
    l.inventur()


def last_bericht():
    from lagerhaus.bericht import textbericht, bewegungsbericht
    from lagerhaus.lager import Lager
    from lagerhaus.preise import Artikel, Katalog
    k = Katalog(); l = Lager()
    for i in range(30):
        k.aufnehmen(Artikel(f"A{i}", "x", 1.5))
        l.zugang(f"A{i}", 10 + i)
    for _ in range(60):
        textbericht(l, k)
        bewegungsbericht(l.journal)
