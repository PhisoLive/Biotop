"""HTTP-Dienst des Biotops (nur lesend in Phase 1, Bindung an 127.0.0.1).

Anmeldezwang fest verdrahtet: JEDE Route außer POST /anmelden verlangt
`Authorization: Bearer <token>`; ohne gültigen Token → 401. Es gibt keinen
Schalter, der das abstellt.

Routen:
  POST /anmelden                      {name, kennwort} → {token}
  GET  /laeufe                        alle Läufe
  GET  /laeufe/<id>                   Lauf mit Maß und Kasse
  GET  /laeufe/<id>/generationen      Generationen mit Maßen
  GET  /laeufe/<id>/kandidaten        Kandidaten
  GET  /laeufe/<id>/kasse             Kassenstand
  GET  /laeufe/<id>/lazarus           Schnappschüsse
  GET  /werke                         Werke
  GET  /werke/<id>/landkarte          Landkarte (Stufen 0–3, Straßen, Verträge)
  GET  /protokoll                     Protokoll (letzte 200)
"""

from __future__ import annotations

import json
import re
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

from .kern import anmeldung, kasse, protokoll
from .kern.datenbank import lj, verbinden

ROUTEN = [
    ("POST", r"^/anmelden$"),
    ("GET", r"^/laeufe$"),
    ("GET", r"^/laeufe/(\d+)$"),
    ("GET", r"^/laeufe/(\d+)/generationen$"),
    ("GET", r"^/laeufe/(\d+)/kandidaten$"),
    ("GET", r"^/laeufe/(\d+)/kasse$"),
    ("GET", r"^/laeufe/(\d+)/lazarus$"),
    ("GET", r"^/werke$"),
    ("GET", r"^/werke/(\d+)/landkarte$"),
    ("GET", r"^/protokoll$"),
]


def _rows(con, q, p=()):
    return [dict(z) for z in con.execute(q, p)]


class Handler(BaseHTTPRequestHandler):
    con = None

    def _senden(self, code: int, obj):
        body = json.dumps(obj, ensure_ascii=False, default=str).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):  # kein Zugriffsprotokoll auf stderr
        pass

    def _benutzer(self) -> str | None:
        h = self.headers.get("Authorization", "")
        if not h.startswith("Bearer "):
            return None
        return anmeldung.pruefen(self.con, h[7:].strip())

    def do_POST(self):
        if self.path != "/anmelden":
            if not self._benutzer():
                return self._senden(401, {"fehler": "Anmeldung erforderlich"})
            return self._senden(404, {"fehler": "unbekannt"})
        n = int(self.headers.get("Content-Length", "0"))
        try:
            d = json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            return self._senden(400, {"fehler": "kein JSON"})
        token = anmeldung.anmelden(self.con, str(d.get("name", "")), str(d.get("kennwort", "")))
        if not token:
            return self._senden(401, {"fehler": "Anmeldung fehlgeschlagen"})
        return self._senden(200, {"token": token})

    def do_GET(self):
        # Anmeldezwang VOR jeder Routenauflösung — auch unbekannte Pfade antworten 401 ohne Token.
        if not self._benutzer():
            return self._senden(401, {"fehler": "Anmeldung erforderlich"})
        con = self.con
        pfad = self.path.split("?")[0]
        m = re.match(r"^/laeufe$", pfad)
        if m:
            return self._senden(200, _rows(con, "SELECT id, werk_id, budget_eur, status, begonnen_am, beendet_am, grund FROM laeufe"))
        m = re.match(r"^/laeufe/(\d+)$", pfad)
        if m:
            z = con.execute("SELECT * FROM laeufe WHERE id=?", (m.group(1),)).fetchone()
            if not z:
                return self._senden(404, {"fehler": "Lauf unbekannt"})
            d = dict(z); d["mass"] = lj(d["mass"]); d["kasse"] = kasse.stand(con, int(m.group(1)))
            return self._senden(200, d)
        m = re.match(r"^/laeufe/(\d+)/generationen$", pfad)
        if m:
            out = []
            for z in _rows(con, "SELECT nummer, status, grund, tag, pruefsumme, erstellt_am, freigabe_am, freigabe_grund, masse FROM generationen WHERE lauf_id=? ORDER BY nummer", (m.group(1),)):
                mm = lj(z.pop("masse"))
                z["kernmass"] = mm["kernmass"] if mm else None
                z["bereiche"] = {b: {k: v for k, v in bm.items() if not isinstance(v, (list, dict))} for b, bm in mm["bereiche"].items()} if mm else None
                out.append(z)
            return self._senden(200, out)
        m = re.match(r"^/laeufe/(\d+)/kandidaten$", pfad)
        if m:
            return self._senden(200, _rows(con, "SELECT id, generation, bereich, nische, anbieter, modell, status, grund, begruendung, wirkungskreis, erstellt_am FROM kandidaten WHERE lauf_id=? ORDER BY id", (m.group(1),)))
        m = re.match(r"^/laeufe/(\d+)/kasse$", pfad)
        if m:
            return self._senden(200, {"stand": kasse.stand(con, int(m.group(1))), "aufrufe": _rows(con, "SELECT * FROM kasse WHERE lauf_id=? ORDER BY id", (m.group(1),))})
        m = re.match(r"^/laeufe/(\d+)/lazarus$", pfad)
        if m:
            return self._senden(200, _rows(con, "SELECT generation, tag, pruefsumme, archiv, erstellt_am FROM lazarus WHERE lauf_id=? ORDER BY generation", (m.group(1),)))
        if pfad == "/werke":
            return self._senden(200, _rows(con, "SELECT id, name, pfad, quelle, aufgenommen_am, sprache, status FROM werke"))
        m = re.match(r"^/werke/(\d+)/landkarte$", pfad)
        if m:
            wid = m.group(1)
            return self._senden(200, {
                "stufen": [{**z, "inhalt": lj(z["inhalt"])} for z in _rows(con, "SELECT stufe, schluessel, inhalt, pruefsumme, herkunft FROM landkarte WHERE werk_id=? ORDER BY stufe, schluessel", (wid,))],
                "strassen": _rows(con, "SELECT von, nach, art FROM strassen WHERE werk_id=? ORDER BY von, nach", (wid,)),
                "vertraege": _rows(con, "SELECT bereich, text, herkunft, quelle FROM vertraege WHERE werk_id=? ORDER BY bereich, id", (wid,)),
            })
        if pfad == "/protokoll":
            return self._senden(200, protokoll.lesen(con, 0, None, 200))
        return self._senden(404, {"fehler": "unbekannt"})


def main(port: int = 8642):
    Handler.con = verbinden()
    srv = HTTPServer(("127.0.0.1", port), Handler)
    print(f"Biotop-Dienst auf 127.0.0.1:{port} — {len(ROUTEN)} Routen, Anmeldezwang aktiv", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 8642)
