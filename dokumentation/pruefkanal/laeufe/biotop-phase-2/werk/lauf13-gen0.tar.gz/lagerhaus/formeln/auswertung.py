"""Auswertung von Rabattformeln.

Vertrag (abgeleitet): `auswerten` liest nur die drei Variablen, hat keine
Nebenwirkungen und wirft `FormelFehler` bei ungültigen Formeln.
"""

from __future__ import annotations

import ast
import math

ERLAUBTE_NAMEN = {"menge", "preis", "summe", "min", "max", "abs", "round"}
ERLAUBTE_FUNCS = {"min", "max", "abs", "round"}


class FormelFehler(ValueError):
    """Formel ist syntaktisch oder semantisch ungültig."""


def pruefen(formel: str) -> bool:
    """Grobe Vorprüfung: Formel nicht leer, nicht zu lang, nur bekannte Namen.

    Rückgabe True, wenn die Formel ausgewertet werden darf.
    """
    if not formel or not formel.strip():
        return False
    if len(formel) > 200:
        return False
    return True


class _SichererAuswerter(ast.NodeVisitor):
    def __init__(self, umgebung: dict):
        self.umgebung = umgebung
        self.ergebnis = None

    def visit(self, node):
        method = "visit_" + node.__class__.__name__
        visitor = getattr(self, method, self.generic_visit)
        return visitor(node)

    def visit_Expression(self, node: ast.Expression):
        return self.visit(node.body)

    def visit_BinOp(self, node: ast.BinOp):
        left = self.visit(node.left)
        right = self.visit(node.right)
        op = node.op
        if isinstance(op, ast.Add):
            return left + right
        elif isinstance(op, ast.Sub):
            return left - right
        elif isinstance(op, ast.Mult):
            return left * right
        elif isinstance(op, ast.Div):
            if right == 0:
                raise FormelFehler("Division durch Null")
            return left / right
        elif isinstance(op, ast.FloorDiv):
            if right == 0:
                raise FormelFehler("Division durch Null")
            return left // right
        elif isinstance(op, ast.Mod):
            if right == 0:
                raise FormelFehler("Modulo durch Null")
            return left % right
        else:
            raise FormelFehler(f"Nicht erlaubter Operator {op.__class__.__name__}")

    def visit_UnaryOp(self, node: ast.UnaryOp):
        operand = self.visit(node.operand)
        op = node.op
        if isinstance(op, ast.UAdd):
            return +operand
        elif isinstance(op, ast.USub):
            return -operand
        elif isinstance(op, ast.Not):
            return not operand
        else:
            raise FormelFehler(f"Nicht erlaubter Operator {op.__class__.__name__}")

    def visit_BoolOp(self, node: ast.BoolOp):
        if isinstance(node.op, ast.And):
            for value in node.values:
                if not self.visit(value):
                    return False
            return True
        elif isinstance(node.op, ast.Or):
            for value in node.values:
                if self.visit(value):
                    return True
            return False
        else:
            raise FormelFehler(f"Nicht erlaubter Bool-Operator {node.op.__class__.__name__}")

    def visit_Compare(self, node: ast.Compare):
        left = self.visit(node.left)
        for op, comparator in zip(node.ops, node.comparators):
            right = self.visit(comparator)
            if isinstance(op, ast.Eq):
                if not (left == right):
                    return False
            elif isinstance(op, ast.NotEq):
                if not (left != right):
                    return False
            elif isinstance(op, ast.Lt):
                if not (left < right):
                    return False
            elif isinstance(op, ast.LtE):
                if not (left <= right):
                    return False
            elif isinstance(op, ast.Gt):
                if not (left > right):
                    return False
            elif isinstance(op, ast.GtE):
                if not (left >= right):
                    return False
            else:
                raise FormelFehler(f"Nicht erlaubter Vergleichsoperator {op.__class__.__name__}")
            left = right
        return True

    def visit_Call(self, node: ast.Call):
        if not isinstance(node.func, ast.Name):
            raise FormelFehler("Nur direkte Funktionsnamen erlaubt")
        func_name = node.func.id
        if func_name not in ERLAUBTE_FUNCS:
            raise FormelFehler(f"Nicht erlaubte Funktion {func_name}")
        func = self.umgebung.get(func_name)
        args = [self.visit(arg) for arg in node.args]
        if node.keywords:
            raise FormelFehler("Keine Schlüsselwortargumente erlaubt")
        try:
            return func(*args)
        except Exception as exc:
            raise FormelFehler(f"Fehler bei Funktionsaufruf {func_name}: {exc}") from exc

    def visit_Name(self, node: ast.Name):
        if node.id not in ERLAUBTE_NAMEN:
            raise FormelFehler(f"Unbekannter Name {node.id}")
        if node.id not in self.umgebung:
            raise FormelFehler(f"Name {node.id} nicht definiert")
        return self.umgebung[node.id]

    def visit_Constant(self, node: ast.Constant):
        if isinstance(node.value, (int, float, bool)):
            return node.value
        raise FormelFehler(f"Nicht erlaubter Konstante-Typ {type(node.value).__name__}")

    # Für Python <3.8 Kompatibilität
    def visit_Num(self, node: ast.Num):
        return node.n

    def visit_NameConstant(self, node: ast.NameConstant):
        if isinstance(node.value, bool):
            return node.value
        raise FormelFehler(f"Nicht erlaubter Konstanten-Typ {type(node.value).__name__}")

    def generic_visit(self, node):
        raise FormelFehler(f"Nicht erlaubter Ausdruck {node.__class__.__name__}")


def auswerten(formel: str, menge: int, preis: float, summe: float):
    """Wertet `formel` mit den Variablen menge, preis, summe aus.

    Beispiele:
        auswerten("summe * 0.05", 3, 10.0, 30.0) -> 1.5
        auswerten("menge >= 10", 3, 10.0, 30.0) -> False
    """
    if not pruefen(formel):
        raise FormelFehler(f"ungültige Formel: {formel!r}")
    umgebung = {
        "menge": int(menge),
        "preis": float(preis),
        "summe": float(summe),
        "min": min,
        "max": max,
        "abs": abs,
        "round": round,
    }
    try:
        baum = ast.parse(formel, mode="eval")
        auswerter = _SichererAuswerter(umgebung)
        ergebnis = auswerter.visit(baum)
    except FormelFehler:
        raise
    except Exception as exc:
        raise FormelFehler(f"Formel konnte nicht ausgewertet werden: {exc}") from exc
    if isinstance(ergebnis, bool):
        return ergebnis
    if isinstance(ergebnis, (int, float)):
        if isinstance(ergebnis, float) and (math.isnan(ergebnis) or math.isinf(ergebnis)):
            raise FormelFehler("Formel liefert keinen endlichen Wert")
        return float(ergebnis)
    raise FormelFehler(f"Formel liefert unerlaubten Typ {type(ergebnis).__name__}")


def formel_beschreibung(formel: str) -> str:
    """Menschenlesbare Kurzbeschreibung für Berichte."""
    kurz = formel.strip()
    if len(kurz) > 40:
        kurz = kurz[:37] + "..."
    return f"Formel „{kurz}“"
