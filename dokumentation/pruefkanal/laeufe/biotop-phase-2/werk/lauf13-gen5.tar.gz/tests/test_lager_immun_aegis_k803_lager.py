from lagerhaus.lager import Lager, NichtGenugBestand
import pytest

def test_reservierung_einloesen_ignoriert_anderteils_reservierungen():
    lager = Lager()
    lager.zugang('A', 10)
    lager.reservieren('A', 10)
    lager2 = Lager()
    lager2.zugang('B', 10)
    lager2.reservieren('B', 10)
    with pytest.raises(NichtGenugBestand):
        lager2.reservierung_einloesen('B', 5)
