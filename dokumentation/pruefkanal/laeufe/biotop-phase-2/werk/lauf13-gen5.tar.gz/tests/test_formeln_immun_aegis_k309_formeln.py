import pytest
from lagerhaus.formeln import FormelFehler, auswerten

def test_lambda_funktion_injection():
    """Angriff: Lambda-Funktion zur Code-Ausführung.
    
    Lambda ist nicht in erlaubte_knoten und muss abgewiesen werden.
    """
    formel = "(lambda: __import__('os').system('echo pwned'))()"
    with pytest.raises(FormelFehler):
        auswerten(formel, 10, 5.0, 50.0)
