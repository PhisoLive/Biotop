import pytest

from lagerhaus.preise import (
    Artikel,
    Katalog,
    Rabattregel,
    Staffel,
    UnbekannterArtikel,
    rabatt_anwenden,
    rabatt_betrag,
    runde_cent,
    umrechnen,
)


@pytest.fixture
def katalog():
    k = Katalog()
    k.aufnehmen(Artikel("A1", "Schraube", 0.10, [Staffel(100, 0.08), Staffel(1000, 0.05)]))
    k.aufnehmen(Artikel("B2", "Mutter", 0.20))
    return k


# ----- Währung ---------------------------------------------------------

def test_runde_cent_kaufmaennisch():
    assert runde_cent(1.005) == 1.01
    assert runde_cent(2.675) == 2.68
    assert runde_cent(0.1 + 0.2) == 0.30


def test_umrechnen_gleiche_waehrung():
    assert umrechnen(12.345, "EUR", "EUR") == 12.35


def test_umrechnen_eur_usd():
    assert umrechnen(100.0, "EUR", "USD") == 108.0


def test_umrechnen_unbekannter_kurs():
    with pytest.raises(ValueError):
        umrechnen(1.0, "EUR", "JPY")


# ----- Katalog ---------------------------------------------------------

def test_katalog_aufnehmen_holen(katalog):
    assert katalog.anzahl() == 2
    assert katalog.holen("A1").name == "Schraube"
    assert katalog.enthaelt("B2")
    assert not katalog.enthaelt("Z9")


def test_katalog_unbekannt(katalog):
    with pytest.raises(UnbekannterArtikel):
        katalog.holen("Z9")


def test_katalog_entfernen(katalog):
    katalog.entfernen("B2")
    assert katalog.anzahl() == 1
    katalog.entfernen("nicht-da")  # still erlaubt


def test_negativer_grundpreis_abgelehnt():
    with pytest.raises(ValueError):
        Katalog().aufnehmen(Artikel("X", "x", -1.0))


def test_grundpreis_ohne_staffel(katalog):
    assert katalog.preis_fuer("B2", 7) == 1.40


def test_staffel_deutlich_ueber_grenze(katalog):
    assert katalog.preis_fuer("A1", 150) == 12.00
    assert katalog.preis_fuer("A1", 2000) == 100.00


def test_staffel_unter_grenze(katalog):
    assert katalog.preis_fuer("A1", 99) == pytest.approx(9.90)


def test_menge_null_abgelehnt(katalog):
    with pytest.raises(ValueError):
        katalog.preis_fuer("A1", 0)


def test_alle_sortiert(katalog):
    assert [a.nummer for a in katalog.alle()] == ["A1", "B2"]


# ----- Rabatt ----------------------------------------------------------

def test_rabatt_greift_nicht():
    regel = Rabattregel("ab100", "summe >= 100", "summe * 0.05")
    assert rabatt_betrag(regel, 50.0, 1, 50.0) == 0.0


def test_rabatt_greift():
    regel = Rabattregel("ab100", "summe >= 100", "summe * 0.05")
    assert rabatt_betrag(regel, 200.0, 1, 200.0) == pytest.approx(10.0)


def test_rabatt_nie_ueber_summe():
    regel = Rabattregel("gross", "summe > 0", "summe * 3")
    assert rabatt_betrag(regel, 10.0, 1, 10.0) == 10.0


def test_rabatt_negativ_wird_null():
    regel = Rabattregel("neg", "summe > 0", "0 - 5")
    assert rabatt_betrag(regel, 10.0, 1, 10.0) == 0.0


def test_rabatt_anwenden_reihenfolge():
    regeln = [
        Rabattregel("a", "summe >= 100", "10"),
        Rabattregel("b", "summe >= 100", "summe * 0.1"),
    ]
    # 100 - 10 = 90; zweite Regel greift nicht mehr (90 < 100)
    assert rabatt_anwenden(100.0, regeln, 1, 100.0) == 90.0


def test_rabatt_anwenden_nie_negativ():
    regeln = [Rabattregel("alles", "summe > 0", "summe"), Rabattregel("mehr", "1 == 1", "5")]
    assert rabatt_anwenden(10.0, regeln, 1, 10.0) == 0.0
