import pytest
from lagerhaus.lager.bestand import Lager, NichtGenugBestand
from lagerhaus.lager.journal import Journal

def test_reservierung_einloesen_reduziert_verfuegbaren_bestand_nicht_korrekt():
    journal = Journal()
    lager = Lager(journal)
    lager.zugang('A', 10)
    lager.reservieren('A', 5)
    assert lager.verfuegbar('A') == 5
    lager.reservierung_einloesen('A', 3)
    assert lager.verfuegbar('A') == 5
