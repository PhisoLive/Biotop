from lagerhaus.preise.katalog import Artikel, Staffel

def test_staffel_genau_ab_menge():
    """
    Staffeln gelten ab `ab_menge` einschließlich: bei ab_menge=10 zahlt
    eine Bestellung von genau 10 Stück den Staffelpreis.
    """
    artikel = Artikel(nummer='A1', name='Testartikel', grundpreis=10.0)
    artikel.staffeln.append(Staffel(ab_menge=10, stueckpreis=8.0))
    artikel.staffeln.append(Staffel(ab_menge=20, stueckpreis=7.0))
    assert artikel.stueckpreis(10) == 8.0
