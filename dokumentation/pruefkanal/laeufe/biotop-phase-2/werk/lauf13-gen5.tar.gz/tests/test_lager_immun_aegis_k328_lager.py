from lagerhaus.lager.bestand import Lager, NichtGenugBestand
from lagerhaus.lager.journal import Journal

def test_reservierung_einloesen_bucht_trotz_unterdeckung_wenn_reserviert():
    lager = Lager()
    lager.zugang('A', 10)
    lager.reservieren('A', 5)
    lager.entnehmen('A', 3)
    try:
        lager.reservierung_einloesen('A', 4)
        assert False, 'NichtGenugBestand sollte geworfen werden, da nicht genug verfügbar ist.'
    except NichtGenugBestand:
        pass
    assert lager.bestand('A') == 7
    assert lager.reserviert('A') == 5

def test_reservierung_einloesen_bucht_teilweise_trotz_nichtgenugbestand():
    lager = Lager()
    lager.zugang('A', 10)
    lager.reservieren('A', 10)
    lager.journal.eintragen('A', -5, 'Fehlerhafte Buchung')
    try:
        lager.reservierung_einloesen('A', 7)
        assert False, 'NichtGenugBestand sollte geworfen werden, da nicht genug verfügbar ist.'
    except NichtGenugBestand:
        pass
    assert lager.bestand('A') == 5
    assert lager.reserviert('A') == 10
