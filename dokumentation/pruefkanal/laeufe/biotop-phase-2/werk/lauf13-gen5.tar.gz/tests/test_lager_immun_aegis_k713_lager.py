from lagerhaus.lager import Lager, Journal

def test_artikel_methode_mit_externem_journal():
    journal = Journal()
    journal.eintragen('A', 10, 'Init')
    lager = Lager(journal)
    assert lager.artikel() == ['A']
