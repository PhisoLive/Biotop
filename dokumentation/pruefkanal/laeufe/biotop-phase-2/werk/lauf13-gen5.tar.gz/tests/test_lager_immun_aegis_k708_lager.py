import pytest
from lagerhaus.lager import Lager, Journal, NichtGenugBestand

def test_externes_journal_befuellt_cache_nicht():
    journal = Journal()
    journal.eintragen('A', 10, 'Init')
    lager = Lager(journal)
    assert lager.bestand('A') == 10
    journal.eintragen('A', 5, 'Externer Zugang')
    assert lager.bestand('A') == 15
