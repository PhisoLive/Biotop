from lagerhaus.preise.katalog import Artikel, Staffel

def test_staffelpreis_bei_exakter_menge_wird_nicht_angewendet():
    artikel = Artikel(nummer='A1', name='Testartikel', grundpreis=10.0, staffeln=[Staffel(ab_menge=10, stueckpreis=8.0)])
    assert artikel.stueckpreis(10) == 8.0

def test_mehrere_staffeln_falsche_reihenfolge_anwendung():
    artikel = Artikel(nummer='A1', name='Testartikel', grundpreis=10.0, staffeln=[Staffel(ab_menge=10, stueckpreis=8.0), Staffel(ab_menge=20, stueckpreis=7.0)])
    assert artikel.stueckpreis(15) == 8.0
    assert artikel.stueckpreis(20) == 7.0
