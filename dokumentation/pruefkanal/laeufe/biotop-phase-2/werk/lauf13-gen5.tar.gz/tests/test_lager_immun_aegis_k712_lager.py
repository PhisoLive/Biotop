from lagerhaus.lager import Lager, Journal, NichtGenugBestand
import pytest

def test_externes_journal_wird_ignoriert():
    journal = Journal()
    journal.eintragen('A', 100, 'Start')
    lager = Lager(journal)
    assert lager.bestand('A') == 100
