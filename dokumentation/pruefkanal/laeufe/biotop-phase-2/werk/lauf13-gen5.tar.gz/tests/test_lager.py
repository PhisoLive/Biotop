import pytest

from lagerhaus.lager import Journal, Lager, NichtGenugBestand


@pytest.fixture
def lager():
    l = Lager()
    l.zugang("A1", 100)
    l.zugang("B2", 10)
    return l


def test_zugang_und_bestand(lager):
    assert lager.bestand("A1") == 100
    assert lager.bestand("B2") == 10
    assert lager.bestand("nix") == 0


def test_zugang_muss_positiv_sein(lager):
    with pytest.raises(ValueError):
        lager.zugang("A1", 0)


def test_entnehmen(lager):
    assert lager.entnehmen("A1", 30) == 70
    assert lager.bestand("A1") == 70


def test_entnehmen_zu_viel_bucht_nichts(lager):
    with pytest.raises(NichtGenugBestand):
        lager.entnehmen("B2", 11)
    assert lager.bestand("B2") == 10
    assert lager.journal.anzahl() == 2


def test_entnehmen_genau_alles(lager):
    assert lager.entnehmen("B2", 10) == 0
    assert "B2" not in lager.artikel()


def test_reservieren_senkt_verfuegbar(lager):
    lager.reservieren("A1", 40)
    assert lager.bestand("A1") == 100
    assert lager.verfuegbar("A1") == 60


def test_reservierung_blockiert_entnahme(lager):
    lager.reservieren("A1", 90)
    with pytest.raises(NichtGenugBestand):
        lager.entnehmen("A1", 20)


def test_reservierung_zu_viel(lager):
    with pytest.raises(NichtGenugBestand):
        lager.reservieren("B2", 11)


def test_freigeben(lager):
    lager.reservieren("A1", 40)
    assert lager.freigeben("A1", 15) == 25
    assert lager.verfuegbar("A1") == 75
    with pytest.raises(ValueError):
        lager.freigeben("A1", 100)


def test_reservierung_einloesen_senkt_bestand(lager):
    lager.reservieren("A1", 40)
    lager.reservierung_einloesen("A1", 40)
    assert lager.bestand("A1") == 60


def test_journal_fortlaufend(lager):
    lager.entnehmen("A1", 1)
    nummern = [b.nummer for b in lager.journal.alle()]
    assert nummern == [1, 2, 3]
    assert lager.journal.summe_fuer("A1") == 99


def test_inventur_und_gesamt(lager):
    assert lager.inventur() == {"A1": 100, "B2": 10}
    assert lager.gesamtmenge() == 110


def test_journal_alleine():
    j = Journal()
    j.eintragen("X", 5, "test")
    j.eintragen("X", -2, "test")
    assert j.summe_fuer("X") == 3
    assert len(j.fuer_artikel("X")) == 2
    assert j.fuer_artikel("Y") == []


def test_lager_mit_grossem_journal():
    l = Lager()
    for i in range(300):
        l.zugang("A1", 1)
    assert l.bestand("A1") == 300
