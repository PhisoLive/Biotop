import pytest
from lagerhaus.lager.bestand import Lager, NichtGenugBestand
from lagerhaus.lager.journal import Journal

def test_reservierung_einloesen_doppelte_buchung_bei_nicht_genug_bestand():
    """
    Testet, ob bei einem NichtGenugBestand-Fehler in reservierung_einloesen
    trotzdem eine Buchung im Journal landet.
    """
    lager = Lager()
    lager.zugang('A', 10)
    lager.reservieren('A', 5)
    with pytest.raises(NichtGenugBestand):
        lager.reservierung_einloesen('A', 6)
    assert lager.journal.summe_fuer('A') == 10
    assert lager.reserviert('A') == 5

def test_reservierung_einloesen_verfuegbar_wird_nicht_aktualisiert_vor_pruefung():
    """
    Testet, ob die `verfuegbar`-Prüfung den aktuellen Wert verwendet
    und nicht einen veralteten, wenn zwischenzeitlich entnommen wurde.
    """
    lager = Lager()
    lager.zugang('A', 10)
    lager.reservieren('A', 5)
    lager.entnehmen('A', 3)
    with pytest.raises(NichtGenugBestand):
        lager.reservierung_einloesen('A', 3)
    assert lager.bestand('A') == 7
    assert lager.reserviert('A') == 5

def test_reservierung_einloesen_reservierung_nicht_vollstaendig_eingeloest_bei_nicht_genug_bestand():
    """
    Testet, ob die Reservierung bei einem NichtGenugBestand-Fehler
    nicht teilweise eingelöst wird.
    """
    lager = Lager()
    lager.zugang('A', 10)
    lager.reservieren('A', 5)
    lager.entnehmen('A', 3)
    with pytest.raises(NichtGenugBestand):
        lager.reservierung_einloesen('A', 3)
    assert lager.reserviert('A') == 5

def test_reservierung_einloesen_negativer_bestand_durch_einloesung_wenn_reserviert_groesser_als_bestand():
    """
    Testet, ob ein negativer Bestand entstehen kann, wenn die Anzahl der
    einzulösenden Artikel zwar kleiner oder gleich der Reservierung ist,
    aber größer als der tatsächliche Bestand.
    """
    lager = Lager()
    lager.zugang('A', 5)
    lager.reservieren('A', 5)
    lager.journal.eintragen('A', -3, 'Fehlerhafte Entnahme')
    with pytest.raises(NichtGenugBestand):
        lager.reservierung_einloesen('A', 4)
    assert lager.bestand('A') == 2
    assert lager.reserviert('A') == 5
