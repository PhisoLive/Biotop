import pytest
from lagerhaus.preise import Artikel, Katalog


def test_katalog_alle_sortierung_erzwingen():
    k = Katalog()
    # Artikel in umgekehrter alphabetischer Reihenfolge einfügen,
    # damit ein unsortiertes dict (oder unsortierte Rückgabe) auffällt.
    k.aufnehmen(Artikel("Z9", "Zahn", 1.0))
    k.aufnehmen(Artikel("A1", "Anker", 1.0))

    nummern = [a.nummer for a in k.alle()]
    assert nummern == ["A1", "Z9"]
