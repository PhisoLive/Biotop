import pytest
from lagerhaus.preise.katalog import Artikel, Staffel, Katalog, UnbekannterArtikel

def test_stueckpreis_negativer_grundpreis_nach_initialisierung():
    artikel = Artikel(nummer='A1', name='Testartikel', grundpreis=-10.0)
    with pytest.raises(ValueError, match='Grundpreis darf nicht negativ sein'):
        artikel.stueckpreis(1)

def test_stueckpreis_negativer_staffelpreis_nach_initialisierung():
    artikel = Artikel(nummer='A2', name='Testartikel', grundpreis=10.0, staffeln=[Staffel(ab_menge=5, stueckpreis=-5.0)])
    with pytest.raises(ValueError, match='Staffelpreis darf nicht negativ sein'):
        artikel.stueckpreis(5)

def test_preis_fuer_negativer_grundpreis_umgeht_katalog_aufnehmen():
    katalog = Katalog()
    artikel_mit_negativ_grundpreis = Artikel(nummer='A3', name='Negativpreis', grundpreis=-10.0)
    katalog._artikel['A3'] = artikel_mit_negativ_grundpreis
    with pytest.raises(ValueError, match='Grundpreis darf nicht negativ sein'):
        katalog.preis_fuer('A3', 1)

def test_preis_fuer_negativer_staffelpreis_umgeht_katalog_aufnehmen():
    katalog = Katalog()
    artikel_mit_negativ_staffel = Artikel(nummer='A4', name='Negativstaffel', grundpreis=10.0, staffeln=[Staffel(ab_menge=5, stueckpreis=-5.0)])
    katalog._artikel['A4'] = artikel_mit_negativ_staffel
    with pytest.raises(ValueError, match='Staffelpreis darf nicht negativ sein'):
        katalog.preis_fuer('A4', 5)
