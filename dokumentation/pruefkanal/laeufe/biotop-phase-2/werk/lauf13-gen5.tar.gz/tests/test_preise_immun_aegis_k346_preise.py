import pytest
from lagerhaus.preise.katalog import Artikel, Katalog, Staffel

def test_staffel_mit_negativem_stueckpreis_wird_nicht_aufgenommen():
    katalog = Katalog()
    artikel = Artikel(nummer='A1', name='Testartikel', grundpreis=10.0, staffeln=[Staffel(ab_menge=10, stueckpreis=-5.0)])
    with pytest.raises(ValueError, match='Staffelpreis darf nicht negativ sein'):
        katalog.aufnehmen(artikel)

def test_staffel_mit_negativem_stueckpreis_nach_grundpreis_pruefung():
    katalog = Katalog()
    artikel = Artikel(nummer='A1', name='Testartikel', grundpreis=10.0, staffeln=[Staffel(ab_menge=1, stueckpreis=5.0), Staffel(ab_menge=10, stueckpreis=-5.0)])
    with pytest.raises(ValueError, match='Staffelpreis darf nicht negativ sein'):
        katalog.aufnehmen(artikel)

def test_staffel_mit_negativem_stueckpreis_und_mehreren_staffeln():
    katalog = Katalog()
    artikel = Artikel(nummer='A1', name='Testartikel', grundpreis=10.0, staffeln=[Staffel(ab_menge=1, stueckpreis=5.0), Staffel(ab_menge=5, stueckpreis=4.0), Staffel(ab_menge=10, stueckpreis=-3.0)])
    with pytest.raises(ValueError, match='Staffelpreis darf nicht negativ sein'):
        katalog.aufnehmen(artikel)
