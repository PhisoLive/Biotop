import pytest

from lagerhaus.bericht import bewegungsbericht, lagerwert, textbericht
from lagerhaus.lager import Lager
from lagerhaus.preise import Artikel, Katalog


@pytest.fixture
def welt():
    k = Katalog()
    k.aufnehmen(Artikel("A1", "Schraube", 0.10))
    k.aufnehmen(Artikel("B2", "Mutter", 0.20))
    l = Lager()
    l.zugang("A1", 100)
    l.zugang("B2", 10)
    l.zugang("C3", 5)  # nicht im Katalog
    l.entnehmen("A1", 20)
    return k, l


def test_lagerwert_gesamt(welt):
    k, l = welt
    w = lagerwert(l, k)
    assert w.je_artikel == {"A1": 8.0, "B2": 2.0, "C3": 0.0}
    assert w.gesamt == 10.0
    assert w.fehlende == ["C3"]


def test_lagerwert_leer():
    w = lagerwert(Lager(), Katalog())
    assert w.gesamt == 0.0
    assert w.je_artikel == {}
    assert w.fehlende == []


def test_lagerwert_veraendert_nichts(welt):
    k, l = welt
    vorher = l.journal.anzahl()
    lagerwert(l, k)
    assert l.journal.anzahl() == vorher


def test_bewegungsbericht(welt):
    _, l = welt
    assert bewegungsbericht(l.journal) == {"A1": (100, 20), "B2": (10, 0), "C3": (5, 0)}


def test_bewegungsbericht_leer():
    assert bewegungsbericht(Lager().journal) == {}


def test_textbericht_zeilen(welt):
    k, l = welt
    text = textbericht(l, k)
    zeilen = text.splitlines()
    assert zeilen[0].startswith("Artikel")
    assert "A1 | 80 | 100 | 20 | 8.00" in zeilen
    assert "Summe | 95 | | | 10.00" in zeilen
    assert zeilen[-1] == "Ohne Katalogeintrag: C3"


def test_textbericht_ohne_fehlende():
    k = Katalog()
    k.aufnehmen(Artikel("A1", "Schraube", 1.0))
    l = Lager()
    l.zugang("A1", 3)
    text = textbericht(l, k)
    assert "Ohne Katalogeintrag" not in text
    assert text.splitlines()[-1] == "Summe | 3 | | | 3.00"
