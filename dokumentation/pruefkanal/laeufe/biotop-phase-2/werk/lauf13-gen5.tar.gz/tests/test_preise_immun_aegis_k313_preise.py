from lagerhaus.preise.katalog import Artikel, Staffel

def test_staffelpreis_genau_ab_menge():
    """
    Staffelpreise gelten ab der eingetragenen Mindestmenge (einschließlich).
    Der Diff ändert `menge > staffel.ab_menge` zu `menge >= staffel.ab_menge`.
    Dieser Test prüft, ob der Staffelpreis angewendet wird, wenn die Menge
    genau der `ab_menge` entspricht.
    """
    artikel = Artikel(nummer='A1', name='Testartikel', grundpreis=10.0, staffeln=[Staffel(ab_menge=10, stueckpreis=8.0)])
    assert artikel.stueckpreis(10) == 8.0, 'Staffelpreis sollte bei genau ab_menge gelten'
