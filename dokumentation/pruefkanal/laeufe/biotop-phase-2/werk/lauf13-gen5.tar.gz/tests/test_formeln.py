import pytest

from lagerhaus.formeln import FormelFehler, auswerten, pruefen
from lagerhaus.formeln.auswertung import formel_beschreibung


def test_einfache_rechnung():
    assert auswerten("summe * 0.05", 3, 10.0, 30.0) == pytest.approx(1.5)


def test_vergleich_liefert_bool():
    assert auswerten("menge >= 10", 3, 10.0, 30.0) is False
    assert auswerten("menge >= 10", 10, 10.0, 100.0) is True


def test_min_max_erlaubt():
    assert auswerten("min(summe, 20)", 5, 10.0, 50.0) == 20.0
    assert auswerten("max(menge, 7)", 5, 10.0, 50.0) == 7.0


def test_verkettung_and_or():
    assert auswerten("menge > 2 and preis < 20", 3, 10.0, 30.0) is True
    assert auswerten("menge > 5 or preis > 5", 3, 10.0, 30.0) is True


def test_leere_formel_ungueltig():
    assert pruefen("") is False
    assert pruefen("   ") is False
    with pytest.raises(FormelFehler):
        auswerten("", 1, 1.0, 1.0)


def test_zu_lange_formel_ungueltig():
    assert pruefen("1+" * 101 + "1") is False


def test_syntaxfehler_wird_formelfehler():
    with pytest.raises(FormelFehler):
        auswerten("summe *", 1, 1.0, 1.0)


def test_unbekannter_name_wird_formelfehler():
    with pytest.raises(FormelFehler):
        auswerten("rabatt * 2", 1, 1.0, 1.0)


def test_division_durch_null_wird_formelfehler():
    with pytest.raises(FormelFehler):
        auswerten("summe / 0", 1, 1.0, 1.0)


def test_beschreibung_kuerzt():
    assert formel_beschreibung("summe * 0.05") == "Formel „summe * 0.05“"
    lang = formel_beschreibung("a" * 60)
    assert lang.endswith("...“")
    assert len(lang) < 60
