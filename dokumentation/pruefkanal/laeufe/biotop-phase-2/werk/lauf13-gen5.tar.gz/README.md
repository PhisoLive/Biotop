# lagerhaus

Kleines Warenwirtschaftswerk mit vier Bereichen:

- `lagerhaus/formeln` — Auswertung von Rabattformeln
- `lagerhaus/preise` — Katalog, Staffelpreise, Rabatte, Währung (nutzt formeln)
- `lagerhaus/lager` — Bestände, Reservierungen, Buchungsjournal
- `lagerhaus/bericht` — Auswertungen über Lager und Preise (nutzt lager, preise)

Tests: `python -m pytest`
