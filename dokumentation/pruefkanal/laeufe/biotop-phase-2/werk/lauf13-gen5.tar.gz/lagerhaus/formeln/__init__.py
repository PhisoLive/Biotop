"""Bereich formeln — Auswertung einfacher Rabattformeln.

Eine Formel ist ein Ausdruck über den Variablen `menge`, `preis` und
`summe`, z. B. "summe * 0.05" oder "menge > 10 and preis * 0.1".
Erlaubt sind Zahlen, die drei Variablen, + - * / Vergleiche, `and`, `or`,
`not` sowie `min(...)` und `max(...)`.

Vertrag (abgeleitet, siehe Landkarte):
- auswerten(formel, menge, preis, summe) -> float | bool
- Eine Formel mit unbekannten Namen führt zu FormelFehler.
- Die Auswertung hat keine Nebenwirkungen.
"""

from .auswertung import FormelFehler, auswerten, pruefen

__all__ = ["FormelFehler", "auswerten", "pruefen"]
