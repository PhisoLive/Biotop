"""Bereich preise — Artikelkatalog, Staffelpreise, Rabatte, Währung.

Vertrag (abgeleitet):
- Katalog.preis_fuer(artikel_nr, menge) -> float, auf Cent gerundet, nie negativ.
- Staffelpreise gelten ab der eingetragenen Mindestmenge (einschließlich).
- rabatt_anwenden(...) -> float, auf Cent gerundet, nie negativ.
"""

from .katalog import Artikel, Katalog, Staffel, UnbekannterArtikel
from .rabatt import Rabattregel, rabatt_anwenden, rabatt_betrag
from .waehrung import runde_cent, umrechnen

__all__ = [
    "Artikel",
    "Katalog",
    "Staffel",
    "UnbekannterArtikel",
    "Rabattregel",
    "rabatt_anwenden",
    "rabatt_betrag",
    "runde_cent",
    "umrechnen",
]
