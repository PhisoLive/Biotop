"""Rabattregeln auf Warenkorbsummen.

Eine Rabattregel hat eine Bedingung und einen Betrag, beide als Formel
(Bereich formeln). Beispiel: Bedingung "summe >= 100", Betrag "summe * 0.05".

Vertrag (abgeleitet):
- rabatt_anwenden(summe, regeln, menge, preis) -> float ≥ 0, auf Cent gerundet;
  nie größer als `summe`.
- Regeln werden in Reihenfolge angewendet; jede Regel sieht die schon
  reduzierte Summe.
"""

from __future__ import annotations

from dataclasses import dataclass

from lagerhaus.formeln import auswerten

from .waehrung import runde_cent


@dataclass(frozen=True)
class Rabattregel:
    name: str
    bedingung: str
    betrag: str


def rabatt_betrag(regel: Rabattregel, summe: float, menge: int, preis: float) -> float:
    """Rabattbetrag einer einzelnen Regel, 0.0 wenn die Bedingung nicht greift."""
    if not auswerten(regel.bedingung, menge, preis, summe):
        return 0.0
    betrag = auswerten(regel.betrag, menge, preis, summe)
    if isinstance(betrag, bool):
        return 0.0
    betrag = float(betrag)
    if betrag < 0:
        return 0.0
    return min(betrag, summe)


def rabatt_anwenden(
    summe: float, regeln: list[Rabattregel], menge: int, preis: float
) -> float:
    """Wendet alle Regeln nacheinander an und liefert die reduzierte Summe."""
    rest = float(summe)
    for regel in regeln:
        rest -= rabatt_betrag(regel, rest, menge, preis)
        if rest <= 0:
            return 0.0
    return runde_cent(rest)
