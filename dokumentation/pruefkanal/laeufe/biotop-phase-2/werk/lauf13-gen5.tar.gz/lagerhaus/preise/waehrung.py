"""Währungsrundung und Umrechnung."""

from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal

KURSE = {
    ("EUR", "EUR"): 1.0,
    ("EUR", "USD"): 1.08,
    ("USD", "EUR"): 1 / 1.08,
    ("EUR", "CHF"): 0.96,
    ("CHF", "EUR"): 1 / 0.96,
}


def runde_cent(betrag: float) -> float:
    """Kaufmännische Rundung auf zwei Nachkommastellen."""
    d = Decimal(str(betrag)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return float(d)


def umrechnen(betrag: float, von: str, nach: str) -> float:
    """Rechnet `betrag` von Währung `von` nach `nach` um, gerundet auf Cent."""
    if von == nach:
        return runde_cent(betrag)
    kurs = KURSE.get((von, nach))
    if kurs is None:
        raise ValueError(f"kein Kurs für {von}->{nach}")
    return runde_cent(betrag * kurs)
