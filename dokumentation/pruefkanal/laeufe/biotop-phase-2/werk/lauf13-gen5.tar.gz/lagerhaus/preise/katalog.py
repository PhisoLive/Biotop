"""Artikelkatalog mit Staffelpreisen.

Vertrag (abgeleitet):
- Staffeln gelten ab `ab_menge` einschließlich: bei ab_menge=10 zahlt
  eine Bestellung von genau 10 Stück den Staffelpreis.
- preis_fuer liefert den Gesamtpreis (Stückpreis × Menge), auf Cent gerundet.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .waehrung import runde_cent


class UnbekannterArtikel(KeyError):
    """Artikelnummer ist im Katalog nicht vorhanden."""


@dataclass(frozen=True)
class Staffel:
    ab_menge: int
    stueckpreis: float


@dataclass
class Artikel:
    nummer: str
    name: str
    grundpreis: float
    staffeln: list[Staffel] = field(default_factory=list)
    waehrung: str = "EUR"

    def __post_init__(self) -> None:
        self.staffeln.sort(key=lambda s: s.ab_menge)

    def stueckpreis(self, menge: int) -> float:
        """Stückpreis für `menge` unter Berücksichtigung der Staffeln."""
        if menge <= 0:
            raise ValueError("Menge muss positiv sein")
        preis = self.grundpreis
        if preis < 0:
            raise ValueError("Grundpreis darf nicht negativ sein")
        for staffel in self.staffeln:
            if staffel.stueckpreis < 0:
                raise ValueError("Staffelpreis darf nicht negativ sein")
            if menge >= staffel.ab_menge:
                preis = staffel.stueckpreis
        return preis


class Katalog:
    def __init__(self) -> None:
        self._artikel: dict[str, Artikel] = {}

    def aufnehmen(self, artikel: Artikel) -> None:
        if artikel.grundpreis < 0:
            raise ValueError("Grundpreis darf nicht negativ sein")
        for staffel in artikel.staffeln:
            if staffel.stueckpreis < 0:
                raise ValueError("Staffelpreis darf nicht negativ sein")
        self._artikel[artikel.nummer] = artikel

    def entfernen(self, nummer: str) -> None:
        self._artikel.pop(nummer, None)

    def holen(self, nummer: str) -> Artikel:
        try:
            return self._artikel[nummer]
        except KeyError as exc:
            raise UnbekannterArtikel(nummer) from exc

    def enthaelt(self, nummer: str) -> bool:
        return nummer in self._artikel

    def alle(self) -> list[Artikel]:
        return sorted(self._artikel.values(), key=lambda a: a.nummer)

    def preis_fuer(self, nummer: str, menge: int) -> float:
        artikel = self.holen(nummer)
        return runde_cent(artikel.stueckpreis(menge) * menge)

    def anzahl(self) -> int:
        return len(self._artikel)
