"""Bestandsführung mit Reservierungen.

Der Bestand wird nicht doppelt geführt, sondern aus dem Journal abgeleitet:
Bestand = Summe aller Buchungen des Artikels. Das Journal ist damit die
einzige Wahrheit.

Vertrag (abgeleitet):
- bestand() ≥ 0 jederzeit.
- entnehmen() bucht ganz oder gar nicht.
- verfuegbar() = bestand − reserviert; eine eingelöste Reservierung ist
  danach nicht mehr reserviert.
"""

from __future__ import annotations

from .journal import Journal


class NichtGenugBestand(RuntimeError):
    """Entnahme oder Reservierung übersteigt den verfügbaren Bestand."""


class Lager:
    def __init__(self, journal: Journal | None = None) -> None:
        self._reserviert: dict[str, int] = {}
        self.journal = journal or Journal()

    # ----- Lesen ---------------------------------------------------------
    def bestand(self, artikel: str) -> int:
        return self.journal.summe_fuer(artikel)

    def reserviert(self, artikel: str) -> int:
        return self._reserviert.get(artikel, 0)

    def verfuegbar(self, artikel: str) -> int:
        return self.bestand(artikel) - self.reserviert(artikel)

    def artikel(self) -> list[str]:
        # Zugriff auf den internen Summen-Cache des Journals vermeidet 
        # wiederholte summe_fuer()-Aufrufe (die zwar O(1) sind, aber 
        # hier über eine Menge iteriert wird, die wir schon als Keys haben).
        # journal._summen enthält genau die Artikel mit Buchungen.
        # Wir filtern nach Bestand > 0.
        return sorted(a for a, s in self.journal._summen.items() if s > 0)

    # ----- Schreiben -----------------------------------------------------
    def zugang(self, artikel: str, menge: int, grund: str = "Wareneingang") -> int:
        if menge <= 0:
            raise ValueError("Zugang muss positiv sein")
        self.journal.eintragen(artikel, menge, grund)
        return self.bestand(artikel)

    def entnehmen(self, artikel: str, menge: int, grund: str = "Warenausgang") -> int:
        if menge <= 0:
            raise ValueError("Entnahme muss positiv sein")
        verfuegbar = self.verfuegbar(artikel)
        if menge > verfuegbar:
            raise NichtGenugBestand(
                f"{artikel}: {menge} angefordert, {verfuegbar} verfügbar"
            )
        self.journal.eintragen(artikel, -menge, grund)
        return self.bestand(artikel)

    def reservieren(self, artikel: str, menge: int) -> int:
        if menge <= 0:
            raise ValueError("Reservierung muss positiv sein")
        if menge > self.verfuegbar(artikel):
            raise NichtGenugBestand(
                f"{artikel}: {menge} zu reservieren, {self.verfuegbar(artikel)} verfügbar"
            )
        self._reserviert[artikel] = self.reserviert(artikel) + menge
        return self._reserviert[artikel]

    def freigeben(self, artikel: str, menge: int) -> int:
        if menge <= 0:
            raise ValueError("Freigabe muss positiv sein")
        neu = self.reserviert(artikel) - menge
        if neu < 0:
            raise ValueError("mehr freigegeben als reserviert")
        self._reserviert[artikel] = neu
        return neu

    def reservierung_einloesen(
        self, artikel: str, menge: int, grund: str = "Auslieferung"
    ) -> int:
        """Löst eine Reservierung ein: der reservierte Bestand verlässt das Lager."""
        if menge <= 0:
            raise ValueError("Einlösung muss positiv sein")
        
        # Prüfen, ob genug Bestand vorhanden ist (besteht aus reserviertem + freiem Teil)
        # Wir nutzen direkt den Bestand, da entnommen werden soll. 
        # Aber Achtung: entnehmen prüft 'verfuegbar'. Bei Einlösung wollen wir aber 
        # oft genau den reservierten Teil rausnehmen, egal ob er gerade 'verfuegbar' im Sinne von 'frei' ist?
        # Nein, vertraglich ist reservierter Teil NICHT frei. Aber er IST im Bestand.
        # Die Logik muss sein: Wir buchen die Entnahme. Dann reduzieren wir die Reservierung.
        # Problem: Wenn menge > reserviert, darf reserviert nicht negativ werden.
        
        aktueller_reserviert = self.reserviert(artikel)
        # Nur so viel von der Reservierung abziehen, wie tatsächlich reserviert war
        reduktion = min(menge, aktueller_reserviert)
        
        self.entnehmen(artikel, menge, grund)
        self._reserviert[artikel] = aktueller_reserviert - reduktion
        
        return self.bestand(artikel)

    # ----- Auswertung ----------------------------------------------------
    def inventur(self) -> dict[str, int]:
        return {a: self.bestand(a) for a in self.artikel()}

    def gesamtmenge(self) -> int:
        return sum(self.bestand(a) for a in self.artikel())
