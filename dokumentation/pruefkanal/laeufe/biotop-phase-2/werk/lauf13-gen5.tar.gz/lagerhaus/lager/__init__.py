"""Bereich lager — Bestände, Buchungen, Reservierungen.

Vertrag (abgeleitet):
- Lager.bestand(artikel_nr) -> int ≥ 0.
- Lager.entnehmen(artikel_nr, menge) senkt den Bestand nie unter 0; bei
  Unterdeckung wird NichtGenugBestand geworfen und nichts gebucht.
- Jede Buchung landet im Journal (unveränderlich, fortlaufend).
"""

from .bestand import Lager, NichtGenugBestand
from .journal import Buchung, Journal

__all__ = ["Lager", "NichtGenugBestand", "Buchung", "Journal"]
