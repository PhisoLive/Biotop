"""Buchungsjournal: jede Bestandsänderung als unveränderlicher Eintrag."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Buchung:
    nummer: int
    artikel: str
    menge: int  # positiv = Zugang, negativ = Abgang
    grund: str


class Journal:
    def __init__(self) -> None:
        self._eintraege: list[Buchung] = []
        self._summen: dict[str, int] = {}
        self._artikel_eintraege: dict[str, list[Buchung]] = {}

    def eintragen(self, artikel: str, menge: int, grund: str) -> Buchung:
        buchung = Buchung(len(self._eintraege) + 1, artikel, menge, grund)
        self._eintraege.append(buchung)
        self._summen[artikel] = self._summen.get(artikel, 0) + menge
        if artikel not in self._artikel_eintraege:
            self._artikel_eintraege[artikel] = []
        self._artikel_eintraege[artikel].append(buchung)
        return buchung

    def alle(self) -> list[Buchung]:
        return list(self._eintraege)

    def fuer_artikel(self, artikel: str) -> list[Buchung]:
        return list(self._artikel_eintraege.get(artikel, []))

    def summe_fuer(self, artikel: str) -> int:
        return self._summen.get(artikel, 0)

    def anzahl(self) -> int:
        return len(self._eintraege)
