"""Bereich bericht — Auswertungen über Lager und Preise.

Dieser Bereich verändert nichts; er liest Lager, Journal und Katalog und
erzeugt Zahlen und Textzeilen.

Vertrag (abgeleitet):
- lagerwert(lager, katalog) -> float ≥ 0, auf Cent gerundet; Artikel ohne
  Katalogeintrag werden mit 0 bewertet und in `fehlende` gemeldet.
- bewegungsbericht(journal) -> je Artikel (zugang, abgang), beide ≥ 0.
- Alle Funktionen sind frei von Nebenwirkungen.
"""

from .auswertung import Lagerwert, bewegungsbericht, lagerwert, textbericht

__all__ = ["Lagerwert", "bewegungsbericht", "lagerwert", "textbericht"]
