"""lagerhaus — kleines Warenwirtschaftswerk mit vier Bereichen.

Bereiche und Straßen (wer importiert wen):
- formeln   : keine Abhängigkeiten
- preise    : -> formeln (Rabattregeln werten Formeln aus)
- lager     : keine Abhängigkeiten
- bericht   : -> lager, -> preise
"""

__version__ = "1.0.0"
