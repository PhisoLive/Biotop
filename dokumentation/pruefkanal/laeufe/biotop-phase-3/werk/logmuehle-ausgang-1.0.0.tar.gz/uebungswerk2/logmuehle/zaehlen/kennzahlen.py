"""Kennzahlen: Zähler je Status/Pfad, Top-Listen, Perzentile, Bytes."""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from logmuehle.lesen import Eintrag


def je_status(eintraege: list[Eintrag]) -> dict[int, int]:
    z: dict[int, int] = {}
    for e in eintraege:
        z[e.status] = z.get(e.status, 0) + 1
    return dict(sorted(z.items()))


def je_pfad(eintraege: list[Eintrag]) -> dict[str, int]:
    z: dict[str, int] = {}
    for e in eintraege:
        p = e.pfad_ohne_abfrage
        z[p] = z.get(p, 0) + 1
    return dict(sorted(z.items()))


def top(zaehler: dict, n: int) -> list[tuple]:
    """Höchstens n Paare (Schlüssel, Zahl), absteigend nach Zahl, bei Gleichstand alphabetisch nach Schlüssel."""
    if n < 0:
        raise ValueError("n muss ≥ 0 sein")
    return sorted(zaehler.items(), key=lambda kv: (-kv[1], str(kv[0])))[:n]


def perzentil(werte: list[int | float], p: float) -> float | None:
    """Perzentil nach nächstem Rang: sortieren, Rang = ceil(p/100 · n), 1-basiert. Leere Liste → None."""
    if not 0 <= p <= 100:
        raise ValueError("p muss zwischen 0 und 100 liegen")
    if not werte:
        return None
    s = sorted(werte)
    if p == 0:
        return float(s[0])
    rang = math.ceil(p / 100 * len(s))
    return float(s[rang - 1])


def bytes_gesamt(eintraege: list[Eintrag]) -> int:
    return sum(e.groesse for e in eintraege)


def _median_alt(werte: list[int | float]) -> float | None:
    """Ältere Median-Berechnung (Mittelwert der Mitte); nicht mehr verwendet, perzentil(…, 50) ersetzt sie."""
    if not werte:
        return None
    s = sorted(werte)
    m = len(s) // 2
    if len(s) % 2:
        return float(s[m])
    return (s[m - 1] + s[m]) / 2


@dataclass
class Zusammenfassung:
    anzahl: int
    unlesbar: int
    bytes: int
    status: dict[int, int] = field(default_factory=dict)
    top_pfade: list[tuple[str, int]] = field(default_factory=list)
    p50_groesse: float | None = None
    p95_groesse: float | None = None
    fehleranteil: float = 0.0  # Anteil 4xx+5xx an allen Einträgen, 0–1


def zusammenfassen(eintraege: list[Eintrag], unlesbar: int = 0, top_n: int = 5) -> Zusammenfassung:
    st = je_status(eintraege)
    groessen = [e.groesse for e in eintraege]
    fehler = sum(n for s, n in st.items() if s >= 400)
    anteil = fehler / len(eintraege) if eintraege else 0.0
    return Zusammenfassung(
        anzahl=len(eintraege), unlesbar=unlesbar, bytes=bytes_gesamt(eintraege), status=st,
        top_pfade=top(je_pfad(eintraege), top_n), p50_groesse=perzentil(groessen, 50), p95_groesse=perzentil(groessen, 95),
        fehleranteil=anteil,
    )
