"""Externe Filter: ein Befehl bekommt die Pfade zeilenweise auf stdin und gibt die zu behaltenden zurück.

Damit lässt sich ein beliebiges Werkzeug (grep, awk, eigenes Skript) als Filter einhängen:
    logmuehle ... --extern "grep -v /static/"
"""

from __future__ import annotations

import subprocess

from logmuehle.lesen import Eintrag


def extern_filtern(eintraege: list[Eintrag], befehl: str, zeitlimit_s: int = 30) -> list[Eintrag]:
    """Führt `befehl` als Shell-Filter über die Pfade aus; behält die Einträge, deren Pfad zurückkommt."""
    if not befehl.strip():
        return list(eintraege)
    eingabe = "\n".join(e.pfad for e in eintraege) + "\n"
    p = subprocess.run(befehl, shell=True, input=eingabe, capture_output=True, text=True, timeout=zeitlimit_s)
    if p.returncode not in (0, 1):
        raise RuntimeError(f"externer Filter scheiterte ({p.returncode}): {p.stderr[:200]}")
    behalten = set(p.stdout.splitlines())
    return [e for e in eintraege if e.pfad in behalten]
