"""Auswahlfilter über Einträge."""

from __future__ import annotations

import fnmatch
from datetime import datetime, timezone

from logmuehle.lesen import Eintrag


class FilterFehler(ValueError):
    """Ungültige Filterangabe."""


def _utc(t: datetime) -> datetime:
    if t.tzinfo is None:
        return t.replace(tzinfo=timezone.utc)
    return t.astimezone(timezone.utc)


def nach_zeit(eintraege: list[Eintrag], von: datetime | None, bis: datetime | None) -> list[Eintrag]:
    """Einträge im Zeitfenster [von, bis], beide Enden einschließlich; None = offen."""
    if von is not None and bis is not None and _utc(von) > _utc(bis):
        raise FilterFehler("von liegt nach bis")
    v = _utc(von) if von is not None else None
    b = _utc(bis) if bis is not None else None
    out = []
    for e in eintraege:
        if v is not None and e.zeit < v:
            continue
        if b is not None and e.zeit >= b:
            continue
        out.append(e)
    return out


def status_passt(status: int, angabe: str | int) -> bool:
    """404 oder '404' oder '4xx' (Klasse)."""
    s = str(angabe).strip().lower()
    if len(s) == 3 and s[0].isdigit() and s[1:] == "xx":
        return status // 100 == int(s[0])
    if s.isdigit() and len(s) == 3:
        return status == int(s)
    raise FilterFehler(f"ungültige Statusangabe: {angabe!r}")


def nach_status(eintraege: list[Eintrag], angaben: list[str | int]) -> list[Eintrag]:
    """Einträge, deren Status zu mindestens einer Angabe passt; leere Angabenliste = alle."""
    if not angaben:
        return list(eintraege)
    for a in angaben:
        status_passt(200, a)  # validiert die Angabe
    return [e for e in eintraege if any(status_passt(e.status, a) for a in angaben)]


def nach_pfad(eintraege: list[Eintrag], muster: str) -> list[Eintrag]:
    """Glob-Muster auf dem Pfad ohne Abfrageteil; '*' = alle."""
    if not muster:
        raise FilterFehler("leeres Pfadmuster")
    return [e for e in eintraege if fnmatch.fnmatchcase(e.pfad_ohne_abfrage, muster)]
