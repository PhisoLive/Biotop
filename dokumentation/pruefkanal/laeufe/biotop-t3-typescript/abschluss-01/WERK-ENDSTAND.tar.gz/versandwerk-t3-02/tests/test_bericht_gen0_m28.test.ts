import { test, expect } from 'vitest';
import { kuerzen } from '../src/bericht/tabelle.js';

test('kuerzen behaelt genau breite Zeichen ohne Kuerzung', () => {
  expect(kuerzen('abcd', 4)).toBe('abcd');
});

test('kuerzen kuerzt mit Auslassungszeichen auf breite Zeichen', () => {
  expect(kuerzen('abcdef', 4)).toBe('abc…');
});

test('kuerzen bei Breite 1 ergibt nur Auslassungszeichen', () => {
  expect(kuerzen('abc', 1)).toBe('…');
});
