import { test, expect } from 'vitest';
import { filtern } from '../src/eingang/register.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(kennung: string, gewicht: number): Sendung {
  return { kennung, gewicht, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } };
}

test('filtern ohne minimum behaelt sendungen ab gewicht 0', () => {
  const daten = [sendung('AA', 0), sendung('BB', 500)];
  expect(filtern(daten, {}).map(s => s.kennung)).toEqual(['AA', 'BB']);
});

test('filtern ohne minimum behaelt leichteste sendung', () => {
  const daten = [sendung('AA', 0)];
  expect(filtern(daten, { maximum: 1000 }).map(s => s.kennung)).toEqual(['AA']);
});

test('filtern ohne minimum behaelt sendung mit gewicht 0', () => {
  expect(filtern([sendung('AA', 0)], { zone: 'nah' })).toHaveLength(1);
});
