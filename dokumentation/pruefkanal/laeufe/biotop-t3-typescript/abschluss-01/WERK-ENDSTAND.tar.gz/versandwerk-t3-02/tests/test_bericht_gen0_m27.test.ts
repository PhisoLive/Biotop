import { test, expect } from 'vitest';
import { kuerzen } from '../src/bericht/tabelle.js';

test('kuerzen kuerzt auf breite mit Auslassungszeichen', () => {
  expect(kuerzen('abcdef', 4)).toBe('abc…');
});

test('kuerzen laesst kurzen Text unveraendert', () => {
  expect(kuerzen('abc', 4)).toBe('abc');
});

test('kuerzen bei Breite 1 ergibt nur Auslassungszeichen', () => {
  expect(kuerzen('abc', 1)).toBe('…');
});
