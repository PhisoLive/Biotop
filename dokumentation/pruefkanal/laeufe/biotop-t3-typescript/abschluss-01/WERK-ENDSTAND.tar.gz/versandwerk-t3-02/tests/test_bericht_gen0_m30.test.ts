import { test, expect } from 'vitest';
import { tabellenbreiten } from '../src/bericht/tabelle.js';

test('tabellenbreiten nutzt 0 als Startwert', () => {
  expect(tabellenbreiten([['']])).toEqual([0]);
});

test('tabellenbreiten behält echte Feldbreiten', () => {
  expect(tabellenbreiten([['a', 'bbbb'], ['ccc', 'dd']])).toEqual([3, 4]);
});

test('tabellenbreiten leer ergibt leeres Array', () => {
  expect(tabellenbreiten([])).toEqual([]);
});
