import { test, expect } from 'vitest';
import { buendeln } from '../src/planung/plan.js';
import type { Sendung } from '../src/eingang/modell.js';

const sendung = (kennung: string, gewicht: number): Sendung => ({
  kennung,
  gewicht,
  zone: 'nah',
  prioritaet: 'normal',
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

test('test_planung_buendeln_exakt_limit_erlaubt', () => {
  const gruppen = buendeln([sendung('AA', 1000)], { gewicht: 1000, anzahl: 1 });
  expect(gruppen).toHaveLength(1);
  expect(gruppen[0]!.gewicht).toBe(1000);
});

test('test_planung_buendeln_ueber_limit_wirft', () => {
  expect(() => buendeln([sendung('AA', 1001)], { gewicht: 1000, anzahl: 1 })).toThrow('Kapazitaet');
});

test('test_planung_buendeln_mehrere_exakt_limit', () => {
  const gruppen = buendeln([sendung('AA', 1000), sendung('BB', 1000)], { gewicht: 1000, anzahl: 2 });
  expect(gruppen.map(g => g.sendungen.map(s => s.kennung))).toEqual([['AA'], ['BB']]);
});
