import { test, expect } from 'vitest';
import { kuerzen, ausrichten, tabelle } from '../src/bericht/tabelle.js';

test('kuerzen behaelt genau breite Zeichen ohne Kuerzung', () => {
  expect(kuerzen('abcd', 4)).toBe('abcd');
});

test('kuerzen kuerzt auf breite Zeichen inklusive Ellipse', () => {
  expect(kuerzen('abcdef', 4)).toBe('abc…');
});

test('tabelle richtet Felder auf Spaltenbreite aus', () => {
  expect(tabelle(['ID', 'Ort'], [['AA', 'nah'], ['BBBB', 'fern']])).toBe('ID   | Ort \n-----+-----\nAA   | nah \nBBBB | fern');
});
