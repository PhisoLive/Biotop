import { test, expect } from 'vitest';
import { kanten, volumen } from '../src/eingang/normalisieren.js';

test('kante akzeptiert die untere Grenze eins', () => {
  expect(kanten({ laenge: 1, breite: 1, hoehe: 1 })).toEqual({
    laenge: 1,
    breite: 1,
    hoehe: 1,
  });
});

test('volumen berechnet Kanten mit eins korrekt', () => {
  expect(volumen({ laenge: 1, breite: 2, hoehe: 3 })).toBe(6);
});
