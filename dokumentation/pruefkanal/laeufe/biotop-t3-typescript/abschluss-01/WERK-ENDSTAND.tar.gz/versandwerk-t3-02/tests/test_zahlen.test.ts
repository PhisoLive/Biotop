import { test, expect } from 'vitest';
import { endlich, ganz, nichtnegativ, bereich, begrenzen } from '../src/zahlen/pruefen.js';

test('test_zahlen_endliche_werte', () => {
  expect(endlich(-1.25)).toBe(-1.25);
  expect(endlich(0)).toBe(0);
  expect(() => endlich(NaN)).toThrow('endlich');
  expect(() => endlich(Infinity)).toThrow('endlich');
});

test('test_zahlen_ganze_cent', () => {
  expect(ganz(12)).toBe(12);
  expect(ganz(-2)).toBe(-2);
  expect(() => ganz(1.5)).toThrow('Ganzzahl');
  expect(() => ganz(Number.MAX_SAFE_INTEGER + 1)).toThrow('Ganzzahl');
});

test('test_zahlen_nichtnegative_menge', () => {
  expect(nichtnegativ(0)).toBe(0);
  expect(nichtnegativ(0.2)).toBe(0.2);
  expect(() => nichtnegativ(-1)).toThrow('negativ');
});

test('test_zahlen_inklusive_grenzen', () => {
  expect(bereich(1, 1, 3)).toBe(true);
  expect(bereich(3, 1, 3)).toBe(true);
  expect(bereich(0, 1, 3)).toBe(false);
  expect(bereich(4, 1, 3)).toBe(false);
  expect(() => bereich(2, 3, 1)).toThrow('Grenzen');
});

test('test_zahlen_begrenzen', () => {
  expect(begrenzen(-1, 0, 5)).toBe(0);
  expect(begrenzen(3, 0, 5)).toBe(3);
  expect(begrenzen(8, 0, 5)).toBe(5);
});

import { runden, cent, addieren, prozent, abziehen, multiplizieren, verteilen, euro, centLesen } from '../src/zahlen/geld.js';

test('test_zahlen_kaufmaennisch_runden', () => {
  expect(runden(2.5)).toBe(3);
  expect(runden(-2.5)).toBe(-3);
  expect(runden(2.49)).toBe(2);
  expect(runden(-0.1)).toBe(0);
  expect(() => runden(Infinity)).toThrow();
});
test('test_zahlen_cent_validieren', () => {
  expect(cent(125)).toBe(125);
  expect(() => cent(-1)).toThrow();
  expect(() => cent(1.1)).toThrow();
});
test('test_zahlen_geldsumme', () => {
  expect(addieren([125, 75, 1])).toBe(201);
  expect(addieren([])).toBe(0);
  expect(() => addieren([Number.MAX_SAFE_INTEGER, 1])).toThrow();
});
test('test_zahlen_prozent', () => {
  expect(prozent(105, 10)).toBe(11);
  expect(prozent(1000, 0)).toBe(0);
  expect(prozent(1000, 100)).toBe(1000);
  expect(() => prozent(100, 101)).toThrow();
});
test('test_zahlen_rabatt_abziehen', () => {
  expect(abziehen(100, 20)).toBe(80);
  expect(abziehen(100, 100)).toBe(0);
  expect(() => abziehen(100, 101)).toThrow();
});
test('test_zahlen_geld_multiplizieren', () => {
  expect(multiplizieren(125, 3)).toBe(375);
  expect(multiplizieren(125, 0)).toBe(0);
  expect(() => multiplizieren(125, 1.5)).toThrow();
});
test('test_zahlen_restcent_verteilung', () => {
  const gewichte = [1, 1, 1];
  expect(verteilen(10, gewichte)).toEqual([4, 3, 3]);
  expect(verteilen(100, [1, 2, 1])).toEqual([25, 50, 25]);
  expect(gewichte).toEqual([1, 1, 1]);
  expect(verteilen(0, [])).toEqual([]);
  expect(() => verteilen(1, [])).toThrow();
  expect(() => verteilen(1, [0, 0])).toThrow();
});
test('test_zahlen_euroformat', () => {
  expect(euro(0)).toBe('0,00');
  expect(euro(12345)).toBe('123,45');
  expect(euro(101)).toBe('1,01');
});
test('test_zahlen_cent_einlesen', () => {
  expect(centLesen('12,34')).toBe(1234);
  expect(centLesen('0,01')).toBe(1);
  expect(() => centLesen('1.00')).toThrow();
  expect(() => centLesen('-1,00')).toThrow();
  expect(() => centLesen('1,001')).toThrow();
});

import { summe, mittelwert, median, quantil, spannweite, histogramm, gewichteterMittelwert } from '../src/zahlen/statistik.js';

test('test_zahlen_summe', () => {
  expect(summe([2, -3, 4])).toBe(3);
  expect(summe([])).toBe(0);
  expect(() => summe([NaN])).toThrow();
});
test('test_zahlen_mittelwert', () => {
  expect(mittelwert([2, 4, 9])).toBe(5);
  expect(mittelwert([])).toBe(0);
});
test('test_zahlen_median', () => {
  const daten = [9, 1, 5, 3];
  expect(median(daten)).toBe(4);
  expect(median([7, 1, 4])).toBe(4);
  expect(daten).toEqual([9, 1, 5, 3]);
});
test('test_zahlen_quantil', () => {
  expect(quantil([0, 10, 20, 30], 0.25)).toBe(7.5);
  expect(quantil([0, 10], 0)).toBe(0);
  expect(quantil([0, 10], 1)).toBe(10);
  expect(quantil([], 0.5)).toBe(0);
  expect(() => quantil([1], 1.1)).toThrow();
});
test('test_zahlen_spannweite', () => {
  expect(spannweite([9, 1, -2])).toBe(11);
  expect(spannweite([])).toBe(0);
  expect(spannweite([3])).toBe(0);
});
test('test_zahlen_histogramm', () => {
  expect(histogramm([0, 1, 2, 3, 9], [1, 3])).toEqual([2, 2, 1]);
  expect(histogramm([], [1])).toEqual([0, 0]);
  expect(() => histogramm([1], [3, 2])).toThrow();
});
test('test_zahlen_gewichtetes_mittel', () => {
  expect(gewichteterMittelwert([10, 20], [1, 3])).toBe(17.5);
  expect(gewichteterMittelwert([], [])).toBe(0);
  expect(() => gewichteterMittelwert([1], [])).toThrow();
  expect(() => gewichteterMittelwert([1], [-1])).toThrow();
});

import { kumuliert, differenzen, gleitmittel, rangfolge, anteile, normalisieren, skaliert, monoton } from '../src/zahlen/reihen.js';

test('test_zahlen_kumulierte_reihe', () => { expect(kumuliert([2, -1, 4])).toEqual([2, 1, 5]); expect(kumuliert([])).toEqual([]); });
test('test_zahlen_differenzreihe', () => { expect(differenzen([2, 5, 4])).toEqual([3, -1]); expect(differenzen([2])).toEqual([]); });
test('test_zahlen_gleitmittel', () => {
  expect(gleitmittel([1, 3, 5, 7], 2)).toEqual([2, 4, 6]);
  expect(gleitmittel([1], 2)).toEqual([]);
  expect(() => gleitmittel([1], 0)).toThrow();
});
test('test_zahlen_stabile_rangfolge', () => { const a = [4, 1, 4, 2]; expect(rangfolge(a)).toEqual([1, 3, 0, 2]); expect(a).toEqual([4, 1, 4, 2]); });
test('test_zahlen_relative_anteile', () => { expect(anteile([1, 3])).toEqual([0.25, 0.75]); expect(anteile([0, 0])).toEqual([0, 0]); expect(() => anteile([-1, 2])).toThrow(); });
test('test_zahlen_normalisierte_reihe', () => { expect(normalisieren([2, 4, 6])).toEqual([0, 0.5, 1]); expect(normalisieren([3, 3])).toEqual([0, 0]); expect(normalisieren([])).toEqual([]); });
test('test_zahlen_skalierte_reihe', () => { expect(skaliert([1, -2, 3], 2)).toEqual([2, -4, 6]); expect(() => skaliert([1], Infinity)).toThrow(); });
test('test_zahlen_monotonie', () => { expect(monoton([1, 2, 2])).toBe(true); expect(monoton([1, 2, 2], true)).toBe(false); expect(monoton([2, 1])).toBe(false); expect(monoton([])).toBe(true); });
