import { test, expect } from 'vitest';
import { ersetzen } from '../src/eingang/register.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(kennung: string, gewicht = 500): Sendung {
  return { kennung, gewicht, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } };
}

test('ersetzen tauscht nur die passende Kennung', () => {
  const daten = [sendung('AA'), sendung('BB')];
  const neu = sendung('AA', 900);
  const ergebnis = ersetzen(daten, neu);
  expect(ergebnis.map(s => s.kennung)).toEqual(['AA', 'BB']);
  expect(ergebnis[0]?.gewicht).toBe(900);
  expect(ergebnis[1]?.gewicht).toBe(500);
});

test('ersetzen laesst andere Sendungen unveraendert', () => {
  const daten = [sendung('AA'), sendung('BB'), sendung('CC')];
  const ergebnis = ersetzen(daten, sendung('BB', 750));
  expect(ergebnis[0]?.gewicht).toBe(500);
  expect(ergebnis[1]?.gewicht).toBe(750);
  expect(ergebnis[2]?.gewicht).toBe(500);
});

test('ersetzen wirft bei unbekannter Kennung', () => {
  expect(() => ersetzen([sendung('AA')], sendung('ZZ'))).toThrow('Unbekannte');
});
