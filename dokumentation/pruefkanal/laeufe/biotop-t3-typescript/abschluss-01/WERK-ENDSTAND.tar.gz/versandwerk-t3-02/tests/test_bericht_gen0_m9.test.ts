import { test, expect } from 'vitest';
import { grammtext } from '../src/bericht/formate.js';

test('grammtext trennt Kilogramm bei 1000 Gramm', () => {
  expect(grammtext(1000)).toBe('1,000 kg');
});

test('grammtext zeigt Rest unter einem Kilogramm', () => {
  expect(grammtext(999)).toBe('0,999 kg');
});

test('grammtext formatiert knapp über der Kilogrammgrenze', () => {
  expect(grammtext(1001)).toBe('1,001 kg');
});
