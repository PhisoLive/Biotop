import { test, expect } from 'vitest';
import { sortieren } from '../src/eingang/stapel.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(kennung: string): Sendung {
  return { kennung, gewicht: 500, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } };
}

test('sortieren ordnet aufsteigend nach Kennung', () => {
  const ergebnis = sortieren([sendung('CC'), sendung('AA'), sendung('BB')]);
  expect(ergebnis.map(s => s.kennung)).toEqual(['AA', 'BB', 'CC']);
});

test('sortieren vergleicht benachbarte Kennungen korrekt', () => {
  const ergebnis = sortieren([sendung('BB'), sendung('AA')]);
  expect(ergebnis[0]?.kennung).toBe('AA');
  expect(ergebnis[1]?.kennung).toBe('BB');
});

test('sortieren laesst Reihenfolge bei gleicher Kennung unveraendert', () => {
  const a = sendung('AA');
  const b = sendung('AA');
  const ergebnis = sortieren([a, b]);
  expect(ergebnis[0]).toBe(a);
  expect(ergebnis[1]).toBe(b);
});
