import { test, expect } from 'vitest';
import { zusammenfassen } from '../src/bericht/zusammenfassung.js';
import type { Plan } from '../src/planung/modell.js';

function planMitAnzahl(anzahl: number, gesamt: number): Plan {
  return {
    anzahl,
    gewicht: 0,
    buendel: [],
    positionen: [],
    gesamt,
    rabatt: 0,
    vorRabatt: 0,
  } as unknown as Plan;
}

test('zusammenfassen berechnet Durchschnitt bei nichtleerem Plan', () => {
  expect(zusammenfassen(planMitAnzahl(2, 1130)).durchschnitt).toBe(565);
});

test('zusammenfassen liefert Durchschnitt 0 bei leerem Plan', () => {
  expect(zusammenfassen(planMitAnzahl(0, 0)).durchschnitt).toBe(0);
});

test('zusammenfassen ignoriert gesamt bei leerem Plan', () => {
  expect(zusammenfassen(planMitAnzahl(0, 500)).durchschnitt).toBe(0);
});
