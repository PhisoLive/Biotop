import { test, expect } from 'vitest';
import { gewichtsbericht } from '../src/bericht/zusammenfassung.js';
import type { Plan } from '../src/planung/modell.js';

function leererPlan(): Plan {
  return {
    anzahl: 0,
    gewicht: 0,
    buendel: [],
    positionen: [],
    gesamt: 0,
    rabatt: 0,
    vorRabatt: 0,
  } as unknown as Plan;
}

test('gewichtsbericht leerer Plan minimum ist 0', () => {
  expect(gewichtsbericht(leererPlan()).minimum).toBe(0);
});

test('gewichtsbericht leerer Plan maximum ist 0', () => {
  expect(gewichtsbericht(leererPlan()).maximum).toBe(0);
});

test('gewichtsbericht leerer Plan gesamtstruktur', () => {
  expect(gewichtsbericht(leererPlan())).toEqual({ minimum: 0, maximum: 0, median: 0, mittel: 0, klassen: [0, 0, 0, 0] });
});
