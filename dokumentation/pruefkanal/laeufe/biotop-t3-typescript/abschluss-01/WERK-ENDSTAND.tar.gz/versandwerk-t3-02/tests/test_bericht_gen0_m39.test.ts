import { test, expect } from 'vitest';
import { gewichtsbericht } from '../src/bericht/zusammenfassung.js';
import type { Plan } from '../src/planung/modell.js';

function planMitGewichten(gewichte: number[]): Plan {
  return {
    anzahl: gewichte.length,
    gewicht: gewichte.reduce((a, b) => a + b, 0),
    buendel: [],
    positionen: gewichte.map((g, i) => ({
      sendung: {
        kennung: `K${i}`,
        zone: 'nah',
        gewicht: g,
        prioritaet: 'normal',
        zerbrechlich: false,
        kanten: { laenge: 1, breite: 1, hoehe: 1 },
      },
      buendel: 1,
      angebot: { gesamt: 0 },
    })),
    gesamt: 0,
    rabatt: 0,
    vorRabatt: 0,
  } as unknown as Plan;
}

test('gewichtsbericht minimum bei nichtleerem Plan', () => {
  expect(gewichtsbericht(planMitGewichten([500, 1000])).minimum).toBe(500);
});

test('gewichtsbericht maximum bei nichtleerem Plan', () => {
  expect(gewichtsbericht(planMitGewichten([500, 1000])).maximum).toBe(1000);
});

test('gewichtsbericht minimum bei leerem Plan', () => {
  expect(gewichtsbericht(planMitGewichten([])).minimum).toBe(0);
});
