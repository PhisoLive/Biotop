import { test, expect } from 'vitest';
import { planen } from '../src/planung/plan.js';
import { zonenbericht } from '../src/bericht/zusammenfassung.js';
import type { Sendung } from '../src/eingang/modell.js';

const daten: Sendung[] = [
  { kennung: 'AA', gewicht: 500, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } },
  { kennung: 'BB', gewicht: 1000, zone: 'fern', prioritaet: 'eilig', zerbrechlich: true, kanten: { laenge: 200, breite: 100, hoehe: 50 } },
];
const limit = { gewicht: 2000, anzahl: 5 };

test('zonenbericht zaehlt Positionen je Zone korrekt', () => {
  const bericht = zonenbericht(planen(daten, limit));
  expect(bericht[0]).toEqual({ zone: 'nah', anzahl: 1, gramm: 500, cent: 285 });
  expect(bericht[1]).toEqual({ zone: 'fern', anzahl: 1, gramm: 1000, cent: 845 });
});

test('zonenbericht summiert Gewicht und Cent je Zone', () => {
  const bericht = zonenbericht(planen(daten, limit));
  expect(bericht.map(z => z.gramm)).toEqual([500, 1000, 0]);
  expect(bericht.map(z => z.cent)).toEqual([285, 845, 0]);
});

test('zonenbericht leere Zone bleibt bei null', () => {
  const bericht = zonenbericht(planen(daten, limit));
  expect(bericht[2]).toEqual({ zone: 'insel', anzahl: 0, gramm: 0, cent: 0 });
});
