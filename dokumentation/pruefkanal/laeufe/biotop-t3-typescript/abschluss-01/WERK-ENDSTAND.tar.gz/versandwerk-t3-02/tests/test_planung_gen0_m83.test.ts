import { test, expect } from 'vitest';
import { auslastung } from '../src/planung/analyse.js';
import { planen } from '../src/planung/plan.js';

const sendung = (kennung: string, gewicht: number) => ({
  kennung,
  gewicht,
  zone: 'nah' as const,
  prioritaet: 'normal' as const,
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

test('test_analyse_auslastung_gewicht_prozent', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })[0]!.gewichtProzent).toBe(50);
});

test('test_analyse_auslastung_anzahl_prozent', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })[0]!.anzahlProzent).toBe(50);
});

test('test_analyse_auslastung_rest', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  const a = auslastung(plan, { gewicht: 1000, anzahl: 2 })[0]!;
  expect(a.restGewicht).toBe(500);
  expect(a.restAnzahl).toBe(1);
});
