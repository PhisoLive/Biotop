import { test, expect } from 'vitest';
import { kennung, zone, prioritaet, kanten, gewicht, kopieren, volumen, laengsteKante, gurtmass, volumengewicht } from '../src/eingang/normalisieren.js';
import type { Sendung } from '../src/eingang/modell.js';

export function muster(kennung = 'AB', gewicht = 500): Sendung {
  return { kennung, gewicht, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } };
}

test('test_eingang_kennung_kanonisch', () => {
  expect(kennung(' ab-12 ')).toBe('AB-12');
  expect(() => kennung('1ABC')).toThrow();
  expect(() => kennung('A')).toThrow();
  expect(() => kennung('A'.repeat(17))).toThrow();
  expect(() => kennung(42)).toThrow();
});
test('test_eingang_zonen', () => {
  expect(zone(' NAH ')).toBe('nah');
  expect(zone('Fern')).toBe('fern');
  expect(zone('insel')).toBe('insel');
  expect(() => zone('west')).toThrow();
});
test('test_eingang_prioritaet', () => {
  expect(prioritaet(' EILIG ')).toBe('eilig');
  expect(prioritaet('normal')).toBe('normal');
  expect(() => prioritaet('spaeter')).toThrow();
});
test('test_eingang_kanten_validieren', () => {
  expect(kanten({ laenge: 1, breite: 1200, hoehe: 42 })).toEqual({ laenge: 1, breite: 1200, hoehe: 42 });
  expect(() => kanten({ laenge: 0, breite: 1, hoehe: 1 })).toThrow();
  expect(() => kanten({ laenge: 1201, breite: 1, hoehe: 1 })).toThrow();
  expect(() => kanten(null)).toThrow();
});
test('test_eingang_gewicht_grenzen', () => {
  expect(gewicht(0)).toBe(0);
  expect(gewicht(30000)).toBe(30000);
  expect(() => gewicht(30001)).toThrow();
  expect(() => gewicht(-1)).toThrow();
  expect(() => gewicht('100')).toThrow();
});
test('test_eingang_tiefe_kopie', () => {
  const original = muster();
  const neu = kopieren(original);
  neu.kanten.laenge = 300;
  expect(original.kanten.laenge).toBe(200);
  expect(neu.kennung).toBe('AB');
});
test('test_eingang_volumen', () => {
  expect(volumen(muster().kanten)).toBe(1000000);
});
test('test_eingang_laengste_kante', () => {
  expect(laengsteKante({ laenge: 5, breite: 7, hoehe: 6 })).toBe(7);
});
test('test_eingang_gurtmass', () => {
  expect(gurtmass({ laenge: 200, breite: 100, hoehe: 50 })).toBe(500);
});
test('test_eingang_volumengewicht', () => {
  expect(volumengewicht({ laenge: 200, breite: 100, hoehe: 50 })).toBe(200);
  expect(volumengewicht({ laenge: 1, breite: 1, hoehe: 1 })).toBe(1);
});

import { pruefen, verlangen } from '../src/eingang/pruefer.js';

test('test_eingang_gueltige_sendung', () => {
  const roh = { ...muster(), kennung: ' xy ', zone: ' FERN ' };
  expect(pruefen(roh)).toEqual({ gueltig: true, sendung: { ...muster('XY'), zone: 'fern' }, befunde: [] });
  expect(roh.kennung).toBe(' xy ');
});
test('test_eingang_mehrere_fehler_sammeln', () => {
  const ergebnis = pruefen({ ...muster(), kennung: '', gewicht: -1, zerbrechlich: 1 });
  expect(ergebnis.gueltig).toBe(false);
  expect(ergebnis.sendung).toBe(null);
  expect(ergebnis.befunde.map(b => b.feld)).toEqual(['kennung', 'gewicht', 'zerbrechlich']);
  expect(ergebnis.befunde.map(b => b.code)).toEqual(['ungueltig', 'ungueltig', 'ungueltig']);
});
test('test_eingang_objekt_erforderlich', () => {
  expect(pruefen(null).befunde[0]?.code).toBe('objekt');
  expect(pruefen([]).gueltig).toBe(false);
  expect(pruefen('abc').gueltig).toBe(false);
});
test('test_eingang_streng_verlangen', () => {
  expect(verlangen(muster())).toEqual(muster());
  expect(() => verlangen({})).toThrow('kennung');
});

import { stapelPruefen, sortieren, nachZone, statistik, priorisieren, teilen, auswaehlen } from '../src/eingang/stapel.js';

test('test_eingang_stapel_bilanz', () => {
  const ergebnis = stapelPruefen([muster(), null, muster('CD')]);
  expect(ergebnis.gesamt).toBe(3);
  expect(ergebnis.sendungen.map(s => s.kennung)).toEqual(['AB', 'CD']);
  expect(ergebnis.abgelehnt.map(a => a.position)).toEqual([1]);
});
test('test_eingang_stapel_doppelt', () => {
  const ergebnis = stapelPruefen([muster(), muster(' ab ')]);
  expect(ergebnis.sendungen).toHaveLength(1);
  expect(ergebnis.abgelehnt[0]?.befunde[0]?.code).toBe('doppelt');
});
test('test_eingang_sortierausgabe', () => {
  expect(sortieren([muster('CC'), muster('AA'), muster('BB')]).map(s => s.kennung)).toEqual(['AA', 'BB', 'CC']);
});
test('test_eingang_zonengruppen', () => {
  const gruppen = nachZone([muster(), { ...muster('CD'), zone: 'fern' }]);
  expect(gruppen.nah.map(s => s.kennung)).toEqual(['AB']);
  expect(gruppen.fern.map(s => s.kennung)).toEqual(['CD']);
  expect(gruppen.insel).toEqual([]);
});
test('test_eingang_statistik', () => {
  expect(statistik([muster(), { ...muster('CD', 750), prioritaet: 'eilig', zerbrechlich: true }])).toEqual({ anzahl: 2, gewicht: 1250, eilig: 1, zerbrechlich: 1, zonen: { nah: 2, fern: 0, insel: 0 } });
  expect(statistik([]).gewicht).toBe(0);
});
test('test_eingang_stabile_prioritaet', () => {
  const daten = [muster('AA'), { ...muster('BB'), prioritaet: 'eilig' as const }, { ...muster('CC'), prioritaet: 'eilig' as const }];
  expect(priorisieren(daten).map(s => s.kennung)).toEqual(['BB', 'CC', 'AA']);
  expect(daten[0]?.kennung).toBe('AA');
});
test('test_eingang_stapel_teilen', () => {
  expect(teilen([muster('AA'), muster('BB'), muster('CC')], 2).map(g => g.length)).toEqual([2, 1]);
  expect(teilen([], 2)).toEqual([]);
  expect(() => teilen([], 0)).toThrow();
});
test('test_eingang_auswahl', () => {
  expect(auswaehlen([muster('AA'), muster('BB')], ['BB']).map(s => s.kennung)).toEqual(['BB']);
  expect(() => auswaehlen([muster()], ['ZZ'])).toThrow('Unbekannte');
});

import { zeileLesen, zeileSchreiben, listeLesen, listeSchreiben, kennungsfolge } from '../src/eingang/zeilen.js';

test('test_eingang_zeile_lesen', () => {
  expect(zeileLesen(' ab ;nah;500;200;100;50;normal;nein')).toEqual(muster());
  expect(zeileLesen('BB;fern;0;1;1;1;eilig;ja').zerbrechlich).toBe(true);
});
test('test_eingang_zeile_feldzahl', () => {
  expect(() => zeileLesen('AB;nah;500')).toThrow('8 Felder');
  expect(() => zeileLesen('AB;nah;5e2;200;100;50;normal;nein')).toThrow('Dezimal');
  expect(() => zeileLesen('AB;nah;500;200;100;50;normal;vielleicht')).toThrow('ja oder nein');
});
test('test_eingang_zeile_schreiben', () => {
  expect(zeileSchreiben(muster())).toBe('AB;nah;500;200;100;50;normal;nein');
});
test('test_eingang_liste_lesen', () => {
  const result = listeLesen('AB;nah;500;200;100;50;normal;nein\nkaputt\nBB;fern;0;1;1;1;eilig;ja\n');
  expect(result.gesamt).toBe(3);
  expect(result.sendungen.map(s => s.kennung)).toEqual(['AB', 'BB']);
  expect(result.abgelehnt[0]?.position).toBe(1);
});
test('test_eingang_liste_duplikat', () => {
  const zeile = 'AB;nah;500;200;100;50;normal;nein';
  expect(listeLesen(zeile + '\n' + zeile).abgelehnt[0]?.befunde[0]?.code).toBe('doppelt');
});
test('test_eingang_liste_schreiben', () => {
  expect(listeSchreiben([muster()])).toBe('AB;nah;500;200;100;50;normal;nein\n');
  expect(listeSchreiben([])).toBe('');
  expect(listeLesen('').gesamt).toBe(0);
});
test('test_eingang_kennungsfolge', () => {
  expect(kennungsfolge('ab', 8, 3)).toEqual(['AB0008', 'AB0009', 'AB0010']);
  expect(kennungsfolge('AB', 0, 0)).toEqual([]);
  expect(() => kennungsfolge('AB', -1, 1)).toThrow();
});

import { registrieren, suchen, ersetzen, filtern, unterschied, kennungenPruefen } from '../src/eingang/register.js';

test('test_eingang_register', () => {
  const daten = [muster('AA'), muster('BB')];
  const register = registrieren(daten);
  expect([...register.keys()]).toEqual(['AA', 'BB']);
  register.get('AA')!.kanten.laenge = 300;
  expect(daten[0]?.kanten.laenge).toBe(200);
  expect(() => registrieren([muster(), muster()])).toThrow('Doppelte');
});
test('test_eingang_register_suchen', () => {
  const register = registrieren([muster()]);
  expect(suchen(register, ' ab ')).toEqual(muster());
  expect(suchen(register, 'ZZ')).toBe(null);
});
test('test_eingang_ersetzen', () => {
  const daten = [muster('AA'), muster('BB')];
  expect(ersetzen(daten, muster('AA', 700)).map(s => s.gewicht)).toEqual([700, 500]);
  expect(daten[0]?.gewicht).toBe(500);
  expect(() => ersetzen(daten, muster('ZZ'))).toThrow('Unbekannte');
});
test('test_eingang_filter_grenzen', () => {
  const daten = [muster('AA', 100), muster('BB', 200), muster('CC', 300)];
  expect(filtern(daten, { minimum: 200, maximum: 300 }).map(s => s.kennung)).toEqual(['BB', 'CC']);
  expect(filtern(daten, { zone: 'fern' })).toEqual([]);
  expect(() => filtern(daten, { minimum: 300, maximum: 200 })).toThrow();
});
test('test_eingang_filter_prioritaet', () => {
  const daten = [muster('AA'), { ...muster('BB'), prioritaet: 'eilig' as const }];
  expect(filtern(daten, { eilig: true }).map(s => s.kennung)).toEqual(['BB']);
  expect(filtern(daten, { eilig: false }).map(s => s.kennung)).toEqual(['AA']);
});
test('test_eingang_register_unterschied', () => {
  expect(unterschied([muster('AA'), muster('BB')], [muster('BB'), muster('CC')])).toEqual({ hinzu: ['CC'], weg: ['AA'], gleich: ['BB'] });
});
test('test_eingang_kennungen_pruefen', () => {
  expect(kennungenPruefen([' ab ', 'CD', 'AB', 'ab'])).toEqual({ normal: ['AB', 'CD'], doppelt: ['AB'] });
});
