import { test, expect } from 'vitest';
import { auslastung } from '../src/planung/analyse.js';
import { planen } from '../src/planung/plan.js';

const sendung = (kennung: string, gewicht: number) => ({
  kennung,
  gewicht,
  zone: 'nah' as const,
  prioritaet: 'normal' as const,
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

test('test_analyse_auslastung_restgewicht', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })).toEqual([
    { nummer: 1, gewichtProzent: 50, anzahlProzent: 50, restGewicht: 500, restAnzahl: 1 },
  ]);
});

test('test_analyse_auslastung_restgewicht_klein', () => {
  const plan = planen([sendung('AA', 300)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })[0]!.restGewicht).toBe(700);
});

test('test_analyse_auslastung_restanzahl', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })[0]!.restAnzahl).toBe(1);
});
