import { test, expect } from 'vitest';
import { statistik } from '../src/eingang/stapel.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(gewicht: number): Sendung {
  return { kennung: 'AB', gewicht, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 1, breite: 1, hoehe: 1 } };
}

test('test_eingang_statistik_endlichkeit verfassung Satz 3', () => {
  expect(() => statistik([sendung(Number.NaN)])).toThrow('Gewicht ungueltig');
});

test('test_eingang_statistik_endlichkeit_unendlich verfassung Satz 3', () => {
  expect(() => statistik([sendung(Number.POSITIVE_INFINITY)])).toThrow('Gewicht ungueltig');
});

test('test_eingang_statistik_endlichkeit_bruch verfassung Satz 3', () => {
  expect(() => statistik([sendung(1.5)])).toThrow('Gewicht ungueltig');
});
