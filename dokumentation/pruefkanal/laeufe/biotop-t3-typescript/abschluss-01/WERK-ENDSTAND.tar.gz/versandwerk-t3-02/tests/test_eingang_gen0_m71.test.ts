import { test, expect } from 'vitest';
import { zeileLesen, zeileSchreiben } from '../src/eingang/zeilen.js';

test('test_zeilen_ja_zerbrechlich', () => {
  expect(zeileLesen('BB;fern;0;1;1;1;eilig;ja').zerbrechlich).toBe(true);
});

test('test_zeilen_ja_nein_rundreise', () => {
  const sendung = zeileLesen('AB;nah;500;200;100;50;normal;ja');
  expect(zeileSchreiben(sendung)).toBe('AB;nah;500;200;100;50;normal;ja');
});

test('test_zeilen_nein_bleibt_false', () => {
  expect(zeileLesen('AB;nah;500;200;100;50;normal;nein').zerbrechlich).toBe(false);
});
