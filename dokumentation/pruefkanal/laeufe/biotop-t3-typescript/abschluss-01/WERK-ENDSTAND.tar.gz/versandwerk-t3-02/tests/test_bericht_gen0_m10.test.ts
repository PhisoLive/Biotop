import { test, expect } from 'vitest';
import { grammtext } from '../src/bericht/formate.js';

test('grammtext trennt Kilogramm bei 1000 Gramm', () => {
  expect(grammtext(1000)).toBe('1,000 kg');
});

test('grammtext zeigt Rest unter einem Kilogramm', () => {
  expect(grammtext(999)).toBe('0,999 kg');
});

test('grammtext formatiert mehrere Kilogramm', () => {
  expect(grammtext(1999)).toBe('1,999 kg');
});
