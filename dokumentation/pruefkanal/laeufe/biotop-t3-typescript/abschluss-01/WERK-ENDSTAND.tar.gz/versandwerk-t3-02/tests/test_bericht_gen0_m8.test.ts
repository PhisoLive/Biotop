import { test, expect } from 'vitest';
import { grammtext } from '../src/bericht/formate.js';

test('grammtext trennt Kilogramm und Restgramm', () => {
  expect(grammtext(1234)).toBe('1,234 kg');
  expect(grammtext(999)).toBe('0,999 kg');
  expect(grammtext(1000)).toBe('1,000 kg');
});
