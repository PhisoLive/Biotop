import { test, expect } from 'vitest';

// Ursache A und Beobachtung B bleiben in EINEM Realm; kein Mock, kein Workerwechsel.
test('test_bericht_keine_geteilte_veraenderung verfassung Satz 4', async () => {
  const prototypen = [Object.prototype, Array.prototype, Function.prototype,
    String.prototype, Number.prototype, Boolean.prototype, Date.prototype,
    RegExp.prototype, Map.prototype, Set.prototype, Promise.prototype, Error.prototype];
  const vorher = prototypen.map(p => Object.getOwnPropertyDescriptors(p));
  const { planen } = await import('../src/planung/plan.js');
  const { zusammenfassen } = await import('../src/bericht/zusammenfassung.js');
  const { textbericht } = await import('../src/bericht/formate.js');
  const standard = Object.freeze({ gewicht: 10000, anzahl: 20 });
  const daten = [{ kennung: 'P1', gewicht: 500, zone: 'nah', prioritaet: 'normal',
    zerbrechlich: false, kanten: { laenge: 100, breite: 100, hoehe: 100 } }];
  const standardVorher = { ...standard };
  const plan = planen(daten, standard);
  expect(plan.anzahl).toBe(1);
  expect(zusammenfassen(plan)).toBeDefined();
  expect(textbericht(plan)).toContain('Gesamt: 2,85 EUR');
  expect(standard).toEqual(standardVorher);
  for (let i = 0; i < prototypen.length; i++) {
    const p = prototypen[i];
    if (p === undefined) throw new Error('Pruefpopulation unvollstaendig');
    const alte = vorher[i];
    if (alte === undefined) throw new Error('Pruefpopulation unvollstaendig');
    const aktuelle = Object.getOwnPropertyDescriptors(p);
    const schluessel = Reflect.ownKeys(alte);
    expect(Reflect.ownKeys(aktuelle), 'Prototypschluessel unveraendert').toEqual(schluessel);
    for (const key of schluessel) {
      const alt = Reflect.get(alte, key) as PropertyDescriptor;
      const neu = Reflect.get(aktuelle, key) as PropertyDescriptor;
      for (const feld of ['value', 'get', 'set', 'writable', 'enumerable', 'configurable'] as const) {
        expect(Object.is(alt[feld], neu[feld]), `${i}:${String(key)}:${feld} unveraendert`).toBe(true);
      }
    }
  }
});
