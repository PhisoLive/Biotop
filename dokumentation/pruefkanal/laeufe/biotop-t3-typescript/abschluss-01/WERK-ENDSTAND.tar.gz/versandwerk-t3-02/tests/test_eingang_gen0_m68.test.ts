import { test, expect } from 'vitest';
import { statistik } from '../src/eingang/stapel.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(kennung: string, gewicht: number): Sendung {
  return { kennung, gewicht, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } };
}

test('statistik summiert Gewicht korrekt', () => {
  expect(statistik([sendung('AA', 500), sendung('BB', 750)]).gewicht).toBe(1250);
});

test('statistik leere Liste hat Gewicht null', () => {
  expect(statistik([]).gewicht).toBe(0);
});

test('statistik zaehlt Sendungen', () => {
  expect(statistik([sendung('AA', 100)]).anzahl).toBe(1);
});
