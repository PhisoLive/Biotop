import { test, expect } from 'vitest';
import type { Sendung } from '../src/eingang/modell.js';
import { filtern } from '../src/eingang/register.js';

function sendung(kennung: string, gewicht: number): Sendung {
  return { kennung, gewicht, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } };
}

test('filtern ohne minimum behaelt gewicht 0', () => {
  expect(filtern([sendung('AA', 0)], {}).map(s => s.kennung)).toEqual(['AA']);
});

test('filtern mit explizitem minimum 0 behaelt gewicht 0', () => {
  expect(filtern([sendung('AA', 0)], { minimum: 0 }).map(s => s.kennung)).toEqual(['AA']);
});
