import { test, expect } from 'vitest';
import { zeileLesen } from '../src/eingang/zeilen.js';

test('zeileLesen akzeptiert genau 8 Felder', () => {
  const sendung = zeileLesen('AB;nah;500;200;100;50;normal;nein');
  expect(sendung.kennung).toBe('AB');
  expect(sendung.zerbrechlich).toBe(false);
});

test('zeileLesen lehnt 7 Felder ab', () => {
  expect(() => zeileLesen('AB;nah;500;200;100;50;normal')).toThrow('8 Felder');
});

test('zeileLesen lehnt 9 Felder ab', () => {
  expect(() => zeileLesen('AB;nah;500;200;100;50;normal;nein;extra')).toThrow('8 Felder');
});
