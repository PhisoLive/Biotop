import { test, expect } from 'vitest';
import { filtern } from '../src/eingang/register.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(kennung: string, gewicht: number): Sendung {
  return { kennung, gewicht, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 10, breite: 10, hoehe: 10 } };
}

test('filtern akzeptiert gleiche Grenzen', () => {
  const daten = [sendung('AA', 500), sendung('BB', 600)];
  expect(filtern(daten, { minimum: 500, maximum: 500 }).map(s => s.kennung)).toEqual(['AA']);
});

test('filtern wirft bei vertauschten Grenzen', () => {
  expect(() => filtern([], { minimum: 600, maximum: 500 })).toThrow(RangeError);
});

test('filtern filtert nach Gewichtsgrenzen', () => {
  const daten = [sendung('AA', 100), sendung('BB', 500), sendung('CC', 1000)];
  expect(filtern(daten, { minimum: 200, maximum: 800 }).map(s => s.kennung)).toEqual(['BB']);
});
