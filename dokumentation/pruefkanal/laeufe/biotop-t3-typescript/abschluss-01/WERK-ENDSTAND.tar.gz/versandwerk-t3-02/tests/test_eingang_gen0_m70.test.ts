import { test, expect } from 'vitest';
import { statistik } from '../src/eingang/stapel.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(kennung: string, prioritaet: 'normal' | 'eilig'): Sendung {
  return { kennung, gewicht: 100, zone: 'nah', prioritaet, zerbrechlich: false, kanten: { laenge: 10, breite: 10, hoehe: 10 } };
}

test('statistik zaehlt eilige Sendungen korrekt', () => {
  const ergebnis = statistik([sendung('AA', 'eilig'), sendung('BB', 'normal'), sendung('CC', 'eilig')]);
  expect(ergebnis.eilig).toBe(2);
});

test('statistik ohne eilige Sendungen ergibt null', () => {
  const ergebnis = statistik([sendung('AA', 'normal')]);
  expect(ergebnis.eilig).toBe(0);
});

test('statistik leere Liste ergibt null eilige', () => {
  const ergebnis = statistik([]);
  expect(ergebnis.eilig).toBe(0);
});
