# Fachliche Grenzverträge

## zahlen → tarife
- Alle Zahlen müssen endlich sein. Geld ist eine sichere ganze Zahl in Cent; nichtnegative Geldwerte werden ausdrücklich geprüft.
- Kaufmännisches Runden erfolgt bei halben Werten vom Nullpunkt weg. Prozentwerte liegen einschließlich zwischen 0 und 100.
- Restcent werden nach größtem Rest verteilt; Gleichstand geht an den kleineren ursprünglichen Index. Die Summe bleibt erhalten.
- Bereichsgrenzen und Kapazitätsgrenzen sind einschließlich, sofern nicht ausdrücklich anders angegeben.

## eingang → planung
- Sendungen besitzen eine eindeutige Kennung, eine Zone `nah`, `fern` oder `insel`, ein Gewicht in Gramm, drei Kanten in Millimeter, die Priorität `normal` oder `eilig` und eine Zerbrechlichkeitsangabe.
- Gewicht: 0 bis 30000 Gramm einschließlich; Kanten: 1 bis 1200 Millimeter einschließlich. Kennungen werden getrimmt und großgeschrieben; sie bestehen aus 2 bis 16 ASCII-Buchstaben, Ziffern oder Bindestrichen und beginnen mit einem Buchstaben.
- Alle öffentlichen Funktionen verändern weder Eingabeobjekte noch Eingabearrays. Sortierte Ausgaben sind neue Arrays. Bei gleicher Priorität bleibt die ursprüngliche Reihenfolge erhalten.
- Kein Bereich verändert Object.prototype, andere eingebaute Prototypen oder gemeinsam genutzte Standardwerte, auch nicht innerhalb desselben Bereichs oder vorübergehend (Verfassung Revision 02, Satz 4).
- Doppelte Kennungen sind ein expliziter Fehler. Keine Sendung wird still verworfen.

## tarife → planung
- `skalar(gewichtGramm: number): number` liefert nichtnegative sichere ganze Cent. Gewicht ist endlich, 0 bis 30000 Gramm einschließlich.
- Grundtarif: 250 Cent plus 35 Cent für jedes angefangene 500-Gramm-Stück. Null Gramm kosten 250 Cent.
- Zonenaufschlag: nah 0, fern 150, insel 400 Cent. Eilig kostet 250 Cent extra; zerbrechlich 125 Cent. Ab längster Kante über 600 mm kommen 300 Cent dazu.
- Mengenrabatt: ab 10 Sendungen einschließlich 10 Prozent; darunter kein Rabatt. Verfassung Revision 02, Satz 3: Rabatt und weitere Prozentsätze werden ohne Zwischenrundung in die exakte Endpreisrechnung einbezogen. Erst der nichtnegative Endpreis jeder Sendung wird einmal auf den nächsten Cent gerundet, exakt halbe Cent aufwärts. Sammelsummen addieren die bereits abgerechneten Sendungen, ohne weitere Rundung. Kein negativer Preis oder negativer Rabatt. Ein eigenständig aufgerufener Prozent-Helfer mit ganzzahligem Ergebnis darf nicht zur Zwischenrundung dieses Endpreispfads verwendet werden.
- `endpreis(basisCent, steuersatz, rabattsatz=0)` führt beide Prozentsätze als exakte Dezimalbrüche in derselben Rechnung zusammen; eine hintereinandergeschaltete Abrechnung bereits gerundeter Preise ist keine gleichwertige mehrstufige Tarifrechnung.
- Begrenzte Tarifsprache: nichtnegative Dezimalzahlen, die Variablen `gewicht` und `grund`, Operatoren `+ - * /` sowie Klammern. Normale Rechenrangfolge; höchstens 160 Zeichen; Eingaben sind Daten und keine Programme. Division durch null, negatives oder nicht endliches Ergebnis und unbekannte Bezeichner werden ausdrücklich abgewiesen.
- Die Planung ruft `skalar` für jede Sendung zur Kostenbildung auf. Bündelung ändert die Einzeltarife nicht.

## planung → bericht
- Bündel enthalten nur eine Zone und eine Priorität. Maximalgewicht und Maximalanzahl sind einschließlich. First-fit in Eingangsreihenfolge; keine Neusortierung über Prioritäten hinweg ohne expliziten Auftrag.
- Jede Sendung erscheint genau einmal. Eine Sendung über der Bündelkapazität führt zum Fehler, nicht zum Verlust.
- Berichte übernehmen die Preise aus dem Plan unverändert. Sie berechnen keine Tarife nach.
- Leere Eingaben liefern leere Gruppen und Nullsummen; Mittelwerte leerer Listen sind null. Statistikquantile interpolieren linear.
- Text- und CSV-Formate sind localeunabhängig. CSV nutzt Semikolon und verdoppelt Anführungszeichen in zitierten Feldern; Zeilen enden mit LF.
