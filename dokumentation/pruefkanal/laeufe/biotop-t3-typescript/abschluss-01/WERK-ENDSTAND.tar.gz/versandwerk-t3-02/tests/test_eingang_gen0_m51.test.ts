import { test, expect } from 'vitest';
import { filtern } from '../src/eingang/register.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(kennung: string, gewicht: number): Sendung {
  return { kennung, gewicht, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 100, breite: 100, hoehe: 100 } };
}

test('filtern obere Standardgrenze exklusiv 30001', () => {
  const daten = [sendung('AA', 29999), sendung('BB', 30000), sendung('CC', 30001)];
  expect(filtern(daten, {}).map(s => s.kennung)).toEqual(['AA', 'BB']);
});

test('filtern explizite Obergrenze 30000 grenzt 30001 aus', () => {
  const daten = [sendung('AA', 30000), sendung('BB', 30001)];
  expect(filtern(daten, { maximum: 30000 }).map(s => s.kennung)).toEqual(['AA']);
});

test('filtern Standardbereich enthaelt 30000', () => {
  const daten = [sendung('AA', 30000)];
  expect(filtern(daten, {}).map(s => s.kennung)).toEqual(['AA']);
});
