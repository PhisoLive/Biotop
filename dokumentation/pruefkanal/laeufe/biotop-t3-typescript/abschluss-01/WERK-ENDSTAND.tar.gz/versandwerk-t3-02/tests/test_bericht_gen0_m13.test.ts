import { test, expect } from 'vitest';
import { grammtext, etiketten } from '../src/bericht/formate.js';

test('grammtext nutzt 1000 Gramm pro Kilogramm', () => {
  expect(grammtext(999)).toBe('0,999 kg');
  expect(grammtext(1000)).toBe('1,000 kg');
  expect(grammtext(1999)).toBe('1,999 kg');
});

test('etiketten formatiert Gewicht an der Kilogrammgrenze', () => {
  const plan = {
    anzahl: 1,
    gewicht: 1000,
    buendel: [1],
    gesamt: 0,
    rabatt: 0,
    vorRabatt: 0,
    positionen: [
      {
        sendung: {
          kennung: 'AA',
          zone: 'nah',
          gewicht: 1000,
          prioritaet: 'normal',
          zerbrechlich: false,
          kanten: { laenge: 1, breite: 1, hoehe: 1 },
        },
        buendel: 1,
        angebot: { gesamt: 0 },
      },
    ],
  };
  expect(etiketten(plan as never)).toEqual(['AA | NAH | B1 | 1,000 kg']);
});
