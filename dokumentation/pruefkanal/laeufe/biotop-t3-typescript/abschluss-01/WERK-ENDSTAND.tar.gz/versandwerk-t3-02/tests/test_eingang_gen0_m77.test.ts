import { test, expect } from 'vitest';
import { zeileLesen, zeileSchreiben, listeLesen } from '../src/eingang/zeilen.js';

test('zeileLesen akzeptiert genau 8 Felder', () => {
  const sendung = zeileLesen('AB;nah;500;200;100;50;normal;nein');
  expect(sendung.kennung).toBe('AB');
  expect(sendung.gewicht).toBe(500);
  expect(sendung.zerbrechlich).toBe(false);
});

test('zeileLesen lehnt falsche Feldzahl ab', () => {
  expect(() => zeileLesen('AB;nah;500')).toThrow('8 Felder');
});

test('listeLesen zaehlt abgelehnte Zeilen', () => {
  const ergebnis = listeLesen('AB;nah;500;200;100;50;normal;nein\nkaputt\n');
  expect(ergebnis.gesamt).toBe(2);
  expect(ergebnis.sendungen).toHaveLength(1);
  expect(ergebnis.abgelehnt).toHaveLength(1);
});
