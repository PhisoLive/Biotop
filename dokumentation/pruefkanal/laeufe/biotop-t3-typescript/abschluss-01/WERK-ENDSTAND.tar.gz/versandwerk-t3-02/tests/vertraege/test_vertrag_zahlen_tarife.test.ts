import { test, expect } from 'vitest';
import { prozent, abziehen, cent } from '../../src/zahlen/geld.js';
import { skalar, mengenpreis } from '../../src/tarife/preise.js';

test('test_vertrag_zahlen_tarife_ganze_cent', () => {
  expect(cent(skalar(501))).toBe(320);
  expect(cent(mengenpreis(105, 11))).toBe(95);
});
test('test_vertrag_zahlen_tarife_rundung', () => {
  expect(prozent(105, 10)).toBe(11);
  expect(abziehen(105, 11)).toBe(94);
});
test('test_vertrag_zahlen_tarife_gewichtsgrenze', () => {
  expect(skalar(30000)).toBe(2350);
  expect(() => skalar(30001)).toThrow();
});
