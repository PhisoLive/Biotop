import { test, expect } from 'vitest';
import { zusammenfassen } from '../src/bericht/zusammenfassung.js';
import type { Plan } from '../src/planung/modell.js';

function leererPlan(): Plan {
  return {
    anzahl: 0,
    gewicht: 0,
    buendel: [],
    positionen: [],
    gesamt: 0,
    rabatt: 0,
    vorRabatt: 0,
  } as unknown as Plan;
}

test('zusammenfassen leerer Plan hat Durchschnitt 0', () => {
  expect(zusammenfassen(leererPlan()).durchschnitt).toBe(0);
});

test('zusammenfassen berechnet Durchschnitt bei vorhandenen Sendungen', () => {
  const plan = { ...leererPlan(), anzahl: 2, gesamt: 1130 } as unknown as Plan;
  expect(zusammenfassen(plan).durchschnitt).toBe(565);
});

test('zusammenfassen Durchschnitt ist gerundet', () => {
  const plan = { ...leererPlan(), anzahl: 3, gesamt: 1000 } as unknown as Plan;
  expect(zusammenfassen(plan).durchschnitt).toBe(333);
});
