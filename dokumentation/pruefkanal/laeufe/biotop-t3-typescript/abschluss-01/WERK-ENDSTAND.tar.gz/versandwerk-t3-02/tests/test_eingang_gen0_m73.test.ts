import { test, expect } from 'vitest';
import { zeileLesen, zeileSchreiben } from '../src/eingang/zeilen.js';

test('test_zeilen_ja_ist_zerbrechlich', () => {
  expect(zeileLesen('AB;nah;500;200;100;50;normal;ja').zerbrechlich).toBe(true);
});

test('test_zeilen_nein_ist_nicht_zerbrechlich', () => {
  expect(zeileLesen('AB;nah;500;200;100;50;normal;nein').zerbrechlich).toBe(false);
});

test('test_zeilen_schreiben_nein', () => {
  expect(zeileSchreiben({ kennung: 'AB', zone: 'nah', gewicht: 500, prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } })).toBe('AB;nah;500;200;100;50;normal;nein');
});
