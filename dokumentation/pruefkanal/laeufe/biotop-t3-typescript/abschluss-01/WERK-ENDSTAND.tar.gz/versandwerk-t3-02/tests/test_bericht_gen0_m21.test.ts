import { test, expect } from 'vitest';
import { kuerzen, ausrichten, seiten } from '../src/bericht/tabelle.js';

test('kuerzen bei Breite 0 liefert leeren String', () => {
  expect(kuerzen('abc', 0)).toBe('');
});

test('kuerzen bei Breite 1 liefert nur die Ellipse', () => {
  expect(kuerzen('abc', 1)).toBe('…');
});

test('ausrichten mit Breite 0 liefert leeren String', () => {
  expect(ausrichten('abc', 0)).toBe('');
});
