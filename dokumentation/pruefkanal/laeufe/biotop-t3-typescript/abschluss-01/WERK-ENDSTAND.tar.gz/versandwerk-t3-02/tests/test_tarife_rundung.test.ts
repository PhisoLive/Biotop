import { test, expect } from 'vitest';
import { mengenpreis, endpreis } from '../src/tarife/preise.js';
import { planen } from '../src/planung/plan.js';

// Verfassung Revision 02, Satz 3: Richtung UND Stelle, kein gerundeter Rabatt.
test('test_tarife_rundung_unter_halb verfassung Satz 3', () => {
  expect(mengenpreis(104, 11)).toBe(94); // exakt 93,6
});
test('test_tarife_rundung_genau_halb verfassung Satz 3', () => {
  expect(mengenpreis(105, 11)).toBe(95); // exakt 94,5, nicht 105 - round(10,5)
});
test('test_tarife_rundung_ueber_halb verfassung Satz 3', () => {
  expect(mengenpreis(106, 11)).toBe(95); // exakt 95,4
  expect(mengenpreis(103, 11)).toBe(93); // exakt 92,7
});
test('test_tarife_rundung_exakte_grosse_cent verfassung Satz 3', () => {
  expect(mengenpreis(9007199254740991, 11)).toBe(8106479329266892);
});
test('test_tarife_rundung_dezimaltarif verfassung Satz 3', () => {
  expect(endpreis(100, 0.5)).toBe(101);
  expect(endpreis(100, 0.499)).toBe(100);
  expect(endpreis(100, 0.501)).toBe(101);
  expect(endpreis(100, 0.000001)).toBe(100);
});
test('test_tarife_rundung_mehrstufig_ohne_zwischenrundung verfassung Satz 3', () => {
  const rechnen = endpreis as (basis: number, steuer: number, rabatt: number) => number;
  // 105 * 0,9 * 1,1 = 103,95 => 104; Zwischenrundung 94,5=>95 gäbe 105.
  expect(rechnen(105, 10, 10)).toBe(104);
  expect(rechnen(100, 5, 10)).toBe(95);
});
test('test_tarife_rundung_summe_der_sendungen verfassung Satz 3', () => {
  const sendungen = Array.from({ length: 11 }, (_, i) => ({
    kennung: 'P' + String(i), gewicht: 500, zone: 'nah', prioritaet: 'normal',
    zerbrechlich: false, kanten: { laenge: 100, breite: 100, hoehe: 100 },
  }));
  const plan = planen(sendungen, { gewicht: 10000, anzahl: 20 });
  expect(plan.positionen.map(p => p.angebot.gesamt)).toEqual(Array(11).fill(257));
  expect(plan.gesamt).toBe(2827);
  expect(plan.rabatt).toBe(308);
});
