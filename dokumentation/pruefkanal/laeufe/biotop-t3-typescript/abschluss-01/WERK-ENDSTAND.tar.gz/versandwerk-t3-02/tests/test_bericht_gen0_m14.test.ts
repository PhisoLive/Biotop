import { test, expect } from 'vitest';
import { grammtext } from '../src/bericht/formate.js';

test('grammtext trennt Kilogramm und Restgramm', () => {
  expect(grammtext(1234)).toBe('1,234 kg');
});

test('grammtext gibt Rest mit führenden Nullen aus', () => {
  expect(grammtext(1005)).toBe('1,005 kg');
});

test('grammtext behandelt Werte unter einem Kilogramm', () => {
  expect(grammtext(999)).toBe('0,999 kg');
});
