import { test, expect } from 'vitest';
import { auslastung } from '../src/planung/analyse.js';
import { planen } from '../src/planung/plan.js';

const sendung = (kennung: string, gewicht: number) => ({
  kennung,
  gewicht,
  zone: 'nah' as const,
  prioritaet: 'normal' as const,
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

test('auslastung gewichtProzent ist Anteil am Limit', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })[0]!.gewichtProzent).toBe(50);
});

test('auslastung restGewicht ist Differenz zum Limit', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })[0]!.restGewicht).toBe(500);
});

test('auslastung anzahlProzent ist Anteil am Limit', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })[0]!.anzahlProzent).toBe(50);
});
