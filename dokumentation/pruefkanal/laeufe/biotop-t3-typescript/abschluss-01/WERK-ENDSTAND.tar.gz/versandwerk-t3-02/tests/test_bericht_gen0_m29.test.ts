import { test, expect } from 'vitest';
import { ausrichten } from '../src/bericht/tabelle.js';

test('ausrichten richtung links ist Standard', () => {
  expect(ausrichten('AB', 4)).toBe('AB  ');
});

test('ausrichten richtung rechts fuellt links auf', () => {
  expect(ausrichten('AB', 4, 'rechts')).toBe('  AB');
});

test('ausrichten richtung links fuellt rechts auf', () => {
  expect(ausrichten('AB', 4, 'links')).toBe('AB  ');
});
