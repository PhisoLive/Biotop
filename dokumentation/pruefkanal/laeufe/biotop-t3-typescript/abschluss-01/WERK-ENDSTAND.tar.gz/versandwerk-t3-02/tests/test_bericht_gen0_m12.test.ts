import { test, expect } from 'vitest';
import { grammtext } from '../src/bericht/formate.js';

test('grammtext trennt Kilogramm und Rest bei 1000', () => {
  expect(grammtext(1000)).toBe('1,000 kg');
});

test('grammtext zeigt Rest bei 1001 als 001', () => {
  expect(grammtext(1001)).toBe('1,001 kg');
});

test('grammtext zeigt Rest bei 2000 als 000', () => {
  expect(grammtext(2000)).toBe('2,000 kg');
});
