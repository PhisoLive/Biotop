import { test, expect } from 'vitest';
import { skalar, zonenaufschlag, zuschlaege, mengenpreis, angebot, versicherung, endpreis } from '../src/tarife/preise.js';
import type { Sendung } from '../src/eingang/modell.js';
const sendung: Sendung = { kennung: 'AA', zone: 'nah', gewicht: 500, kanten: { laenge: 200, breite: 100, hoehe: 50 }, prioritaet: 'normal', zerbrechlich: false };

test('test_tarife_skalar_null', () => { expect(skalar(0)).toBe(250); });
test('test_tarife_skalar_erste_stufe', () => { expect(skalar(1)).toBe(285); expect(skalar(500)).toBe(285); });
test('test_tarife_skalar_naechste_stufe', () => { expect(skalar(501)).toBe(320); expect(skalar(1000)).toBe(320); });
test('test_tarife_skalar_maximum', () => { expect(skalar(30000)).toBe(2350); expect(() => skalar(30001)).toThrow(); });
test('test_tarife_skalar_ungueltig', () => { expect(() => skalar(-1)).toThrow(); expect(() => skalar(NaN)).toThrow(); });
test('test_tarife_zone_nah', () => { expect(zonenaufschlag('nah')).toBe(0); });
test('test_tarife_zone_fern', () => { expect(zonenaufschlag('fern')).toBe(150); });
test('test_tarife_zone_insel', () => { expect(zonenaufschlag('insel')).toBe(400); });
test('test_tarife_zuschlag_normal', () => { expect(zuschlaege(sendung)).toBe(0); });
test('test_tarife_zuschlag_eilig', () => { expect(zuschlaege({ ...sendung, prioritaet: 'eilig' })).toBe(250); });
test('test_tarife_zuschlag_zerbrechlich', () => { expect(zuschlaege({ ...sendung, zerbrechlich: true })).toBe(125); });
test('test_tarife_zuschlag_sperrgut', () => {
  expect(zuschlaege({ ...sendung, kanten: { laenge: 600, breite: 1, hoehe: 1 } })).toBe(0);
  expect(zuschlaege({ ...sendung, kanten: { laenge: 601, breite: 1, hoehe: 1 } })).toBe(300);
});
test('test_tarife_menge_unterhalb', () => { expect(mengenpreis(1000, 9)).toBe(1000); expect(mengenpreis(0, 1)).toBe(0); });
test('test_tarife_menge_oberhalb', () => { expect(mengenpreis(1000, 11)).toBe(900); expect(mengenpreis(105, 20)).toBe(95); });
test('test_tarife_menge_ungueltig', () => { expect(() => mengenpreis(100, -1)).toThrow(); expect(() => mengenpreis(100, 1.5)).toThrow(); });
test('test_tarife_angebot_zeilen', () => {
  const preis = angebot({ ...sendung, zone: 'fern', zerbrechlich: true }, 11);
  expect(preis).toEqual({ kennung: 'AA', zeilen: [{ art: 'grund', cent: 285 }, { art: 'zone', cent: 150 }, { art: 'extras', cent: 125 }], vorRabatt: 560, rabatt: 56, gesamt: 504 });
});
test('test_tarife_angebot_grundvorgabe', () => { expect(angebot(sendung, 1, 100).gesamt).toBe(100); });
test('test_tarife_versicherung', () => { expect(versicherung(0)).toBe(0); expect(versicherung(10000)).toBe(100); expect(versicherung(10001)).toBe(200); });
test('test_tarife_endpreis', () => { expect(endpreis(1000, 19)).toBe(1190); expect(endpreis(105, 10)).toBe(116); });

import { ausdruck } from '../src/tarife/ausdruck.js';

test('test_tarife_ausdruck_konstante', () => { expect(ausdruck('12.5', { gewicht: 1, grund: 2 })).toBe(12.5); });
test('test_tarife_ausdruck_rangfolge', () => { expect(ausdruck('grund + gewicht * 2', { gewicht: 30, grund: 250 })).toBe(310); });
test('test_tarife_ausdruck_klammer', () => { expect(ausdruck('(grund + gewicht) * 2', { gewicht: 30, grund: 250 })).toBe(560); });
test('test_tarife_ausdruck_subtraktion', () => { expect(ausdruck('10 - 3 - 2', { gewicht: 0, grund: 0 })).toBe(5); });
test('test_tarife_ausdruck_division', () => { expect(ausdruck('20 / 2 / 5', { gewicht: 0, grund: 0 })).toBe(2); });
test('test_tarife_ausdruck_null', () => { expect(ausdruck('0', { gewicht: 0, grund: 0 })).toBe(0); expect(() => ausdruck('1/0', { gewicht: 0, grund: 0 })).toThrow(); });
test('test_tarife_ausdruck_unbekannt', () => { expect(() => ausdruck('unbekannt + 1', { gewicht: 0, grund: 0 })).toThrow(); });
test('test_tarife_ausdruck_negativ', () => { expect(() => ausdruck('1-2', { gewicht: 0, grund: 0 })).toThrow(); });
test('test_tarife_ausdruck_leer_lang', () => { expect(() => ausdruck('', { gewicht: 0, grund: 0 })).toThrow(); expect(() => ausdruck('1'.repeat(161), { gewicht: 0, grund: 0 })).toThrow(); });
test('test_tarife_ausdruck_fehlerhafte_syntax', () => { expect(() => ausdruck('(2+1', { gewicht: 0, grund: 0 })).toThrow(); expect(() => ausdruck('1 2', { gewicht: 0, grund: 0 })).toThrow(); });

import { staffelpreis, interpolieren, angeboteVergleichen, rabattVerteilen, kostengrenze } from '../src/tarife/staffeln.js';
const stufen = [{ bis: 500, cent: 200 }, { bis: 1000, cent: 300 }, { bis: 2000, cent: 500 }];

test('test_tarife_staffel_grenzen', () => {
  expect(staffelpreis(0, stufen)).toBe(200);
  expect(staffelpreis(500, stufen)).toBe(200);
  expect(staffelpreis(501, stufen)).toBe(300);
  expect(staffelpreis(2000, stufen)).toBe(500);
  expect(() => staffelpreis(2001, stufen)).toThrow();
});
test('test_tarife_staffel_validierung', () => {
  expect(() => staffelpreis(1, [])).toThrow();
  expect(() => staffelpreis(1, [{ bis: 2, cent: 3 }, { bis: 1, cent: 4 }])).toThrow();
});
test('test_tarife_interpolation', () => {
  expect(interpolieren(750, stufen)).toBe(250);
  expect(interpolieren(1500, stufen)).toBe(400);
  expect(interpolieren(0, stufen)).toBe(200);
  expect(interpolieren(2000, stufen)).toBe(500);
});
test('test_tarife_angebotsvergleich', () => {
  expect(angeboteVergleichen([angebot(sendung, 1, 100), angebot(sendung, 1, 300)])).toEqual({ billigste: 100, teuerste: 300, differenz: 200, durchschnitt: 200 });
  expect(angeboteVergleichen([])).toEqual({ billigste: 0, teuerste: 0, differenz: 0, durchschnitt: 0 });
});
test('test_tarife_rabatt_verteilung', () => {
  const preise = [angebot(sendung, 1, 100), angebot({ ...sendung, kennung: 'BB' }, 1, 300)];
  const neu = rabattVerteilen(preise, 100);
  expect(neu.map(a => a.gesamt)).toEqual([75, 225]);
  expect(neu.map(a => a.rabatt)).toEqual([25, 75]);
  expect(preise.map(a => a.gesamt)).toEqual([100, 300]);
  expect(() => rabattVerteilen(preise, 401)).toThrow();
});
test('test_tarife_kostengrenze', () => {
  const preise = [angebot(sendung, 1, 100), angebot({ ...sendung, kennung: 'BB' }, 1, 200)];
  expect(kostengrenze(preise, 300)).toEqual(['AA', 'BB']);
  expect(kostengrenze(preise, 299)).toEqual(['AA']);
  expect(kostengrenze(preise, 0)).toEqual([]);
});

import { abrechnungsgewicht, verpackung, rueckweg, servicepreis, budgetRest, angebotsspanne } from '../src/tarife/optionen.js';

test('test_tarife_abrechnungsgewicht_real', () => { expect(abrechnungsgewicht(sendung)).toBe(500); });
test('test_tarife_abrechnungsgewicht_volumen', () => { expect(abrechnungsgewicht({ ...sendung, kanten: { laenge: 500, breite: 400, hoehe: 300 } })).toBe(12000); });
test('test_tarife_verpackung_klein', () => { expect(verpackung(sendung)).toEqual({ art: 'klein', cent: 75, gramm: 50 }); });
test('test_tarife_verpackung_mittel', () => { expect(verpackung({ ...sendung, kanten: { laenge: 400, breite: 200, hoehe: 100 } })).toEqual({ art: 'mittel', cent: 150, gramm: 100 }); });
test('test_tarife_verpackung_gross', () => { expect(verpackung({ ...sendung, kanten: { laenge: 700, breite: 200, hoehe: 100 } })).toEqual({ art: 'gross', cent: 250, gramm: 200 }); });
test('test_tarife_verpackung_schutz', () => { expect(verpackung({ ...sendung, zerbrechlich: true })).toEqual({ art: 'klein+schutz', cent: 155, gramm: 80 }); });
test('test_tarife_rueckweg', () => { expect(rueckweg(1000, false)).toBe(1000); expect(rueckweg(1000, true)).toBe(600); expect(rueckweg(101, true)).toBe(61); });
test('test_tarife_servicepreise', () => { expect(servicepreis('beleg', 2)).toBe(100); expect(servicepreis('termin', 2)).toBe(600); expect(servicepreis('pruefung', 2)).toBe(350); expect(servicepreis('beleg', 0)).toBe(0); });
test('test_tarife_budgetrest', () => { expect(budgetRest(1000, [200, 300])).toBe(500); expect(() => budgetRest(100, [101])).toThrow(); });
test('test_tarife_angebotsspanne', () => { expect(angebotsspanne(500, 501)).toEqual({ minimum: 285, maximum: 320, differenz: 35 }); expect(() => angebotsspanne(501, 500)).toThrow(); });
