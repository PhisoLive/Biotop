import { test, expect } from 'vitest';
import { filtern } from '../src/eingang/register.js';
import type { Sendung } from '../src/eingang/modell.js';

function muster(kennung: string, gewicht: number): Sendung {
  return {
    kennung,
    gewicht,
    zone: 'nah',
    prioritaet: 'normal',
    zerbrechlich: false,
    kanten: { laenge: 200, breite: 100, hoehe: 50 },
  };
}

test('filtern verwendet standardmaessig die obere Gewichtsgrenze', () => {
  const daten = [muster('LEICHT', 500), muster('SCHWER', 30000)];

  expect(filtern(daten, {}).map(s => s.kennung)).toEqual(['LEICHT', 'SCHWER']);
});

test('filtern schliesst Sendungen oberhalb der expliziten Grenze aus', () => {
  const daten = [muster('PASSEND', 1000), muster('ZU_SCHWER', 1001)];

  expect(filtern(daten, { maximum: 1000 }).map(s => s.kennung)).toEqual(['PASSEND']);
});
