import { test, expect } from 'vitest';
import { zeileLesen, listeLesen } from '../src/eingang/zeilen.js';

test('zeileLesen akzeptiert genau 8 Felder', () => {
  const sendung = zeileLesen('AB;nah;500;200;100;50;normal;nein');
  expect(sendung.kennung).toBe('AB');
  expect(sendung.gewicht).toBe(500);
});

test('zeileLesen lehnt 9 Felder ab', () => {
  expect(() => zeileLesen('AB;nah;500;200;100;50;normal;nein;extra')).toThrow('8 Felder');
});

test('listeLesen zaehlt 9-Feld-Zeile als abgelehnt', () => {
  const ergebnis = listeLesen('AB;nah;500;200;100;50;normal;nein;extra');
  expect(ergebnis.sendungen).toHaveLength(0);
  expect(ergebnis.abgelehnt).toHaveLength(1);
});
