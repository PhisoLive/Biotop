import { test, expect } from 'vitest';
import { kuerzen } from '../src/bericht/tabelle.js';

test('kuerzen behaelt den Anfang des Textes', () => {
  expect(kuerzen('abcdef', 4)).toBe('abc…');
});

test('kuerzen ohne Kuerzung gibt Text unveraendert zurueck', () => {
  expect(kuerzen('abc', 4)).toBe('abc');
});

test('kuerzen bei Breite eins ergibt nur die Auslassung', () => {
  expect(kuerzen('abc', 1)).toBe('…');
});
