import { test, expect } from 'vitest';
import { grammtext } from '../src/bericht/formate.js';

test('grammtext fuellt Rest auf drei Stellen auf', () => {
  expect(grammtext(5)).toBe('0,005 kg');
  expect(grammtext(1005)).toBe('1,005 kg');
});
