import { test, expect } from 'vitest';
import { ausdruck } from '../src/tarife/ausdruck.js';

test('test_ausdruck fuehrt keinen globalen Nebeneffekt aus verfassung Satz 2', () => {
  (globalThis as any).__marker__ = 'unversehrt';
  const kontext = { gewicht: 1, grund: 1 };
  try {
    ausdruck('(globalThis.__marker__="veraendert")', kontext);
  } catch {
    // Fehler ist erwartet, da kein gueltiger numerischer Ausdruck
  }
  expect((globalThis as any).__marker__).toBe('unversehrt');
  delete (globalThis as any).__marker__;
});
