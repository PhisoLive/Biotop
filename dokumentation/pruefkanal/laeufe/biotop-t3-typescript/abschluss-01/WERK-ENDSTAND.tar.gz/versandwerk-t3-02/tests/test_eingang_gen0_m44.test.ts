import { test, expect } from 'vitest';
import { pruefen, verlangen } from '../src/eingang/pruefer.js';

test('test_eingang_pruefen_array_abgelehnt', () => {
  const ergebnis = pruefen([]);
  expect(ergebnis.gueltig).toBe(false);
  expect(ergebnis.sendung).toBe(null);
  expect(ergebnis.befunde[0]?.code).toBe('objekt');
});

test('test_eingang_pruefen_string_abgelehnt', () => {
  const ergebnis = pruefen('abc');
  expect(ergebnis.gueltig).toBe(false);
  expect(ergebnis.befunde[0]?.code).toBe('objekt');
});

test('test_eingang_pruefen_null_abgelehnt', () => {
  const ergebnis = pruefen(null);
  expect(ergebnis.gueltig).toBe(false);
  expect(ergebnis.befunde[0]?.code).toBe('objekt');
});
