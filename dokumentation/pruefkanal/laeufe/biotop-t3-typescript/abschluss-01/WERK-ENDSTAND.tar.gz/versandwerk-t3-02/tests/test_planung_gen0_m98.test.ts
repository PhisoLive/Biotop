import { test, expect } from 'vitest';
import { buendeln, planen } from '../src/planung/plan.js';
import type { Sendung } from '../src/eingang/modell.js';

const sendung = (kennung: string, gewicht: number): Sendung => ({
  kennung,
  gewicht,
  zone: 'nah',
  prioritaet: 'normal',
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

const limit = { gewicht: 1000, anzahl: 2 };

test('test_planung_buendel_nummern_fortlaufend', () => {
  const gruppen = buendeln([sendung('AA', 700), sendung('BB', 500), sendung('CC', 300)], limit);
  expect(gruppen.map(g => g.nummer)).toEqual([1, 2]);
});

test('test_planung_plan_buendelnummern', () => {
  const plan = planen([sendung('AA', 700), sendung('BB', 500), sendung('CC', 300)], limit);
  expect(plan.positionen.map(p => p.buendel)).toEqual([1, 2, 1]);
});

test('test_planung_analyse_auslastung_nummer', () => {
  const plan = planen([sendung('AA', 500)], limit);
  expect(plan.buendel[0]!.nummer).toBe(1);
});
