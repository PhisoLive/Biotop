import { test, expect } from 'vitest';
import { auslastung } from '../src/planung/analyse.js';
import { planen } from '../src/planung/plan.js';
import type { Sendung } from '../src/eingang/modell.js';

const sendung = (kennung: string, gewicht: number): Sendung => ({
  kennung,
  gewicht,
  zone: 'nah',
  prioritaet: 'normal',
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

test('test_analyse_auslastung_prozente', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })).toEqual([
    { nummer: 1, gewichtProzent: 50, anzahlProzent: 50, restGewicht: 500, restAnzahl: 1 },
  ]);
});

test('test_analyse_auslastung_anzahlprozent_skaliert', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 4 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 4 })[0]!.anzahlProzent).toBe(25);
});

test('test_analyse_auslastung_restwerte', () => {
  const plan = planen([sendung('AA', 300)], { gewicht: 1000, anzahl: 3 });
  const [zeile] = auslastung(plan, { gewicht: 1000, anzahl: 3 });
  expect(zeile!.restGewicht).toBe(700);
  expect(zeile!.restAnzahl).toBe(2);
});
