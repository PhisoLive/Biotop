import { test, expect } from 'vitest';
import { grammtext } from '../src/bericht/formate.js';

test('grammtext polstert Rest auf drei Stellen', () => {
  expect(grammtext(5)).toBe('0,005 kg');
});

test('grammtext gibt bei 1000 drei Nachkommastellen aus', () => {
  expect(grammtext(1000)).toBe('1,000 kg');
});

test('grammtext formatiert 1234 korrekt', () => {
  expect(grammtext(1234)).toBe('1,234 kg');
});
