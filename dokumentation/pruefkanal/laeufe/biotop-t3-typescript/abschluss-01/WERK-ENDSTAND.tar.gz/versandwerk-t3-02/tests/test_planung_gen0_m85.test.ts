import { test, expect } from 'vitest';
import { auslastung } from '../src/planung/analyse.js';
import { planen } from '../src/planung/plan.js';

const sendung = (kennung: string, gewicht: number) => ({
  kennung,
  gewicht,
  zone: 'nah' as const,
  prioritaet: 'normal' as const,
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

test('auslastung_gewicht_prozent_bei_halber_kapazitaet', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })[0]!.gewichtProzent).toBe(50);
});

test('auslastung_gewicht_prozent_bei_voller_kapazitaet', () => {
  const plan = planen([sendung('AA', 1000)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })[0]!.gewichtProzent).toBe(100);
});

test('auslastung_gewicht_prozent_bei_viertel_kapazitaet', () => {
  const plan = planen([sendung('AA', 250)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })[0]!.gewichtProzent).toBe(25);
});
