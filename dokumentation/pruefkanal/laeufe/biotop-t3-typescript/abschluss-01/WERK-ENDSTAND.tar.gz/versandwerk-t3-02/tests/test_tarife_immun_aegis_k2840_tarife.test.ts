import { test, expect } from 'vitest';
import { ausdruck } from '../src/tarife/ausdruck.js';

test('test_ausdruck Function und eval werden nicht zur Auswertung genutzt verfassung Satz 2', () => {
  const marker = { getroffen: false };
  (globalThis as unknown as Record<string, unknown>).__ausdruck_marker__ = marker;
  const boese = '(globalThis.__ausdruck_marker__.getroffen=true)+gewicht';
  expect(() => ausdruck(boese, { gewicht: 100, grund: 50 })).toThrow();
  expect(marker.getroffen).toBe(false);
  delete (globalThis as unknown as Record<string, unknown>).__ausdruck_marker__;
});
