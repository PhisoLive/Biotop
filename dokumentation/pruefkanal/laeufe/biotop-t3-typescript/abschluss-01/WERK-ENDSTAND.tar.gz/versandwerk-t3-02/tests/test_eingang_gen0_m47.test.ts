import { test, expect } from 'vitest';
import { registrieren, suchen, ersetzen, filtern, unterschied, kennungenPruefen } from '../src/eingang/register.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(kennung: string, gewicht = 500, zone: 'nah' | 'fern' | 'insel' = 'nah', prioritaet: 'normal' | 'eilig' = 'normal'): Sendung {
  return { kennung, gewicht, zone, prioritaet, zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } };
}

test('register_ersetzen_bekannte_kennung', () => {
  const daten = [sendung('AA'), sendung('BB')];
  const neu = sendung('AA', 900);
  const ergebnis = ersetzen(daten, neu);
  expect(ergebnis.map(s => s.kennung)).toEqual(['AA', 'BB']);
  expect(ergebnis[0]?.gewicht).toBe(900);
  expect(ergebnis[1]?.gewicht).toBe(500);
});

test('register_ersetzen_unbekannte_kennung', () => {
  const daten = [sendung('AA'), sendung('BB')];
  expect(() => ersetzen(daten, sendung('ZZ'))).toThrow(RangeError);
});

test('register_ersetzen_kopie', () => {
  const daten = [sendung('AA')];
  const neu = sendung('AA', 700);
  const ergebnis = ersetzen(daten, neu);
  ergebnis[0]!.kanten.laenge = 999;
  expect(neu.kanten.laenge).toBe(200);
});
