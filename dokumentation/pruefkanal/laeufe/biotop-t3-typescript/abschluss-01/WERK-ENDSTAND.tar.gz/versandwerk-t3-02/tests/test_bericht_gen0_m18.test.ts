import { test, expect } from 'vitest';
import { prozenttext } from '../src/bericht/formate.js';

test('prozenttext rundet auf Zehntelprozent', () => {
  expect(prozenttext(12.35)).toBe('12,4 %');
  expect(prozenttext(0)).toBe('0,0 %');
});

test('prozenttext bei 100 Prozent', () => {
  expect(prozenttext(100)).toBe('100,0 %');
});
