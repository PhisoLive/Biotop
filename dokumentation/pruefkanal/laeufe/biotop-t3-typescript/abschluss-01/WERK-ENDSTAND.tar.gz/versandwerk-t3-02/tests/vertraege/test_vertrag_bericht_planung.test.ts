import { test, expect } from 'vitest';
import { planen } from '../../src/planung/plan.js';
import { textbericht } from '../../src/bericht/formate.js';
import { zusammenfassen } from '../../src/bericht/zusammenfassung.js';

test('test_vertrag_bericht_planung_kein_nachtarifieren', () => {
  const plan = planen([], { gewicht: 1000, anzahl: 2 });
  plan.gesamt = 1234;
  expect(zusammenfassen(plan).cent).toBe(1234);
  expect(textbericht(plan)).toContain('12,34 EUR');
});
test('test_vertrag_bericht_planung_unveraendert', () => {
  const plan = planen([], { gewicht: 1000, anzahl: 2 });
  const vorher = JSON.stringify(plan);
  textbericht(plan);
  zusammenfassen(plan);
  expect(JSON.stringify(plan)).toBe(vorher);
});
