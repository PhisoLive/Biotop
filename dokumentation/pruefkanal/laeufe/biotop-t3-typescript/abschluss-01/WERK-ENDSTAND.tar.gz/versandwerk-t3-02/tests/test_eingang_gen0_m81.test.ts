import { test, expect } from 'vitest';
import { zeileLesen, zeileSchreiben } from '../src/eingang/zeilen.js';

test('test_zeile_lesen_zone_aus_feld2', () => {
  const sendung = zeileLesen('AB;fern;500;200;100;50;normal;nein');
  expect(sendung.zone).toBe('fern');
});

test('test_zeile_lesen_zone_und_kennung_getrennt', () => {
  const sendung = zeileLesen('AB;nah;500;200;100;50;normal;nein');
  expect(sendung.kennung).toBe('AB');
  expect(sendung.zone).toBe('nah');
});

test('test_zeile_schreiben_rundlauf_zone', () => {
  const sendung = zeileLesen('AB;fern;500;200;100;50;normal;nein');
  expect(zeileSchreiben(sendung)).toBe('AB;fern;500;200;100;50;normal;nein');
});
