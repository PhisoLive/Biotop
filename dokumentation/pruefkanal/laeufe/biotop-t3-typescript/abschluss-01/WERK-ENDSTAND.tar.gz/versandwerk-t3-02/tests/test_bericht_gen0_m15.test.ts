import { test, expect } from 'vitest';
import { grammtext } from '../src/bericht/formate.js';

test('grammtext formatiert Rest mit drei Stellen', () => {
  expect(grammtext(1234)).toBe('1,234 kg');
});

test('grammtext formatiert kleine Werte mit fuehrenden Nullen', () => {
  expect(grammtext(5)).toBe('0,005 kg');
});

test('grammtext formatiert exakte Kilogrammwerte', () => {
  expect(grammtext(2000)).toBe('2,000 kg');
});
