import { test, expect } from 'vitest';
import { buendeln, planen } from '../src/planung/plan.js';
import type { Sendung } from '../src/eingang/modell.js';

const sendung = (kennung: string, gewicht: number): Sendung => ({
  kennung,
  gewicht,
  zone: 'nah',
  prioritaet: 'normal',
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

test('test_planung_buendel_gewicht_startwert', () => {
  const gruppen = buendeln([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  expect(gruppen[0]!.gewicht).toBe(500);
});

test('test_planung_plan_gewicht_und_buendel', () => {
  const plan = planen([sendung('AA', 500), sendung('BB', 500)], { gewicht: 1000, anzahl: 2 });
  expect(plan.buendel[0]!.gewicht).toBe(1000);
  expect(plan.gewicht).toBe(1000);
});

test('test_planung_buendel_gewicht_mehrere', () => {
  const gruppen = buendeln([sendung('AA', 300), sendung('BB', 300)], { gewicht: 1000, anzahl: 2 });
  expect(gruppen[0]!.gewicht).toBe(600);
});
