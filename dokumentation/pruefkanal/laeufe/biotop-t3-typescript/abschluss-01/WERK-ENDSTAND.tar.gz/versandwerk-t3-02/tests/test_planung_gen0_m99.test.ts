import { test, expect } from 'vitest';
import { buendeln } from '../src/planung/plan.js';
import type { Sendung } from '../src/eingang/modell.js';

const sendung = (kennung: string, gewicht: number): Sendung => ({
  kennung,
  gewicht,
  zone: 'nah',
  prioritaet: 'normal',
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

test('test_planung_buendel_nummern_fortlaufend', () => {
  const gruppen = buendeln([sendung('AA', 500), sendung('BB', 500), sendung('CC', 500)], { gewicht: 1000, anzahl: 2 });
  expect(gruppen.map(g => g.nummer)).toEqual([1, 2]);
});

test('test_planung_buendel_nummern_drei_gruppen', () => {
  const gruppen = buendeln(
    [sendung('AA', 500), { ...sendung('BB', 500), zone: 'fern' }, { ...sendung('CC', 500), prioritaet: 'eilig' }],
    { gewicht: 1000, anzahl: 2 },
  );
  expect(gruppen.map(g => g.nummer)).toEqual([1, 2, 3]);
});

test('test_planung_buendel_nummern_erste_gruppe', () => {
  const gruppen = buendeln([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  expect(gruppen[0]!.nummer).toBe(1);
});
