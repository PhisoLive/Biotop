import { test, expect } from 'vitest';
import { zeileLesen, zeileSchreiben, listeLesen } from '../src/eingang/zeilen.js';
import type { Sendung } from '../src/eingang/modell.js';

function muster(kennung = 'AB', gewicht = 500): Sendung {
  return { kennung, gewicht, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } };
}

test('zeileLesen akzeptiert genau acht Felder', () => {
  expect(zeileLesen('AB;nah;500;200;100;50;normal;nein')).toEqual(muster());
});

test('zeileLesen lehnt zu wenige Felder ab', () => {
  expect(() => zeileLesen('AB;nah;500')).toThrow('Genau 8 Felder erwartet');
});

test('listeLesen zaehlt abgelehnte Zeilen mit falscher Feldzahl', () => {
  const ergebnis = listeLesen('AB;nah;500');
  expect(ergebnis.abgelehnt).toHaveLength(1);
  expect(ergebnis.sendungen).toHaveLength(0);
});
