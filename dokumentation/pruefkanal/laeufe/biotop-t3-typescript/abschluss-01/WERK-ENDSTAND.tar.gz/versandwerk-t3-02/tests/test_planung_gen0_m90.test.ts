import { test, expect } from 'vitest';
import { auslastung } from '../src/planung/analyse.js';
import { planen } from '../src/planung/plan.js';

const sendung = (kennung: string, gewicht: number) => ({
  kennung,
  gewicht,
  zone: 'nah' as const,
  prioritaet: 'normal' as const,
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

test('test_analyse_auslastung_anzahl_prozent', () => {
  const plan = planen([sendung('AA', 500), sendung('BB', 500)], { gewicht: 1000, anzahl: 4 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 4 })).toEqual([
    { nummer: 1, gewichtProzent: 100, anzahlProzent: 50, restGewicht: 0, restAnzahl: 2 },
  ]);
});

test('test_analyse_auslastung_gewicht_prozent', () => {
  const plan = planen([sendung('AA', 250)], { gewicht: 1000, anzahl: 2 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 2 })[0]!.gewichtProzent).toBe(25);
});

test('test_analyse_auslastung_restwerte', () => {
  const plan = planen([sendung('AA', 300)], { gewicht: 1000, anzahl: 3 });
  expect(auslastung(plan, { gewicht: 1000, anzahl: 3 })[0]!.restGewicht).toBe(700);
  expect(auslastung(plan, { gewicht: 1000, anzahl: 3 })[0]!.restAnzahl).toBe(2);
});
