import { test, expect } from 'vitest';
import { gewichtsbericht } from '../src/bericht/zusammenfassung.js';
import type { Plan } from '../src/planung/modell.js';

function planMitGewichten(gewichte: number[]): Plan {
  return {
    anzahl: gewichte.length,
    gewicht: gewichte.reduce((a, b) => a + b, 0),
    buendel: [],
    gesamt: 0,
    rabatt: 0,
    vorRabatt: 0,
    positionen: gewichte.map((g, i) => ({
      sendung: {
        kennung: `K${i}`,
        zone: 'nah',
        gewicht: g,
        prioritaet: 'normal',
        zerbrechlich: false,
        kanten: { laenge: 1, breite: 1, hoehe: 1 },
      },
      buendel: 1,
      angebot: { gesamt: 0 },
    })),
  } as unknown as Plan;
}

test('gewichtsbericht minimum bei genau einem Gewicht', () => {
  expect(gewichtsbericht(planMitGewichten([700])).minimum).toBe(700);
});

test('gewichtsbericht minimum bei mehreren Gewichten', () => {
  expect(gewichtsbericht(planMitGewichten([900, 300, 600])).minimum).toBe(300);
});

test('gewichtsbericht maximum bleibt korrekt', () => {
  expect(gewichtsbericht(planMitGewichten([900, 300, 600])).maximum).toBe(900);
});
