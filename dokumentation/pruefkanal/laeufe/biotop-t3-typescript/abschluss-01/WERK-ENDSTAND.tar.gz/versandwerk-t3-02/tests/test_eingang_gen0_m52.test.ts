import { test, expect } from 'vitest';
import { filtern } from '../src/eingang/register.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(kennung: string, gewicht: number): Sendung {
  return { kennung, gewicht, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } };
}

test('test_filtern_standard_maximum_30000', () => {
  const daten = [sendung('AA', 30000)];
  expect(filtern(daten, {}).map(s => s.kennung)).toEqual(['AA']);
});

test('test_filtern_maximum_grenze_inklusive', () => {
  const daten = [sendung('AA', 29999), sendung('BB', 30000)];
  expect(filtern(daten, { maximum: 30000 }).map(s => s.kennung)).toEqual(['AA', 'BB']);
});

test('test_filtern_maximum_explizit_29999', () => {
  const daten = [sendung('AA', 29999), sendung('BB', 30000)];
  expect(filtern(daten, { maximum: 29999 }).map(s => s.kennung)).toEqual(['AA']);
});
