import { test, expect } from 'vitest';
import { prioritaetsbericht } from '../src/bericht/zusammenfassung.js';
import type { Plan } from '../src/planung/modell.js';

function planMitPrioritaeten(): Plan {
  return {
    anzahl: 2,
    gewicht: 1500,
    buendel: [],
    gesamt: 1130,
    rabatt: 0,
    vorRabatt: 1130,
    positionen: [
      {
        sendung: {
          kennung: 'AA',
          zone: 'nah',
          gewicht: 500,
          prioritaet: 'normal',
          zerbrechlich: false,
          kanten: { laenge: 1, breite: 1, hoehe: 1 },
        },
        buendel: 1,
        angebot: { gesamt: 285 },
      },
      {
        sendung: {
          kennung: 'BB',
          zone: 'fern',
          gewicht: 1000,
          prioritaet: 'eilig',
          zerbrechlich: true,
          kanten: { laenge: 1, breite: 1, hoehe: 1 },
        },
        buendel: 2,
        angebot: { gesamt: 845 },
      },
    ],
  } as unknown as Plan;
}

test('prioritaetsbericht zaehlt normale Sendungen', () => {
  const zeilen = prioritaetsbericht(planMitPrioritaeten());
  expect(zeilen[0]).toEqual({ prioritaet: 'normal', anzahl: 1, cent: 285 });
});

test('prioritaetsbericht zaehlt eilige Sendungen', () => {
  const zeilen = prioritaetsbericht(planMitPrioritaeten());
  expect(zeilen[1]).toEqual({ prioritaet: 'eilig', anzahl: 1, cent: 845 });
});

test('prioritaetsbericht summiert Cent je Prioritaet', () => {
  const zeilen = prioritaetsbericht(planMitPrioritaeten());
  expect(zeilen.map(z => z.cent)).toEqual([285, 845]);
});
