import { test, expect } from 'vitest';
import { zeileLesen } from '../src/eingang/zeilen.js';

test('test_zeilen_ja_erlaubt', () => {
  expect(zeileLesen('AB;nah;500;200;100;50;normal;ja').zerbrechlich).toBe(true);
});

test('test_zeilen_nein_erlaubt', () => {
  expect(zeileLesen('AB;nah;500;200;100;50;normal;nein').zerbrechlich).toBe(false);
});

test('test_zeilen_ungueltig_wirft', () => {
  expect(() => zeileLesen('AB;nah;500;200;100;50;normal;vielleicht')).toThrow('ja oder nein');
});
