import { test, expect } from 'vitest';
import { zusammenfassen } from '../src/bericht/zusammenfassung.js';
import type { Plan } from '../src/planung/modell.js';

function planMitAnzahl(anzahl: number, gesamt: number): Plan {
  return {
    anzahl,
    gewicht: 0,
    buendel: [],
    positionen: [],
    gesamt,
    rabatt: 0,
    vorRabatt: 0,
  } as unknown as Plan;
}

test('zusammenfassen berechnet Durchschnitt bei einer Sendung', () => {
  expect(zusammenfassen(planMitAnzahl(1, 500)).durchschnitt).toBe(500);
});

test('zusammenfassen berechnet Durchschnitt bei mehreren Sendungen', () => {
  expect(zusammenfassen(planMitAnzahl(2, 1130)).durchschnitt).toBe(565);
});

test('zusammenfassen liefert Durchschnitt 0 ohne Sendungen', () => {
  expect(zusammenfassen(planMitAnzahl(0, 0)).durchschnitt).toBe(0);
});
