import { test, expect } from 'vitest';
import { pruefen, verlangen } from '../src/eingang/pruefer.js';

test('pruefen akzeptiert gueltiges objekt', () => {
  const ergebnis = pruefen({
    kennung: 'AB',
    zone: 'nah',
    gewicht: 500,
    kanten: { laenge: 200, breite: 100, hoehe: 50 },
    prioritaet: 'normal',
    zerbrechlich: false,
  });
  expect(ergebnis.gueltig).toBe(true);
  expect(ergebnis.sendung).not.toBe(null);
});

test('pruefen lehnt array ab', () => {
  const ergebnis = pruefen([]);
  expect(ergebnis.gueltig).toBe(false);
  expect(ergebnis.befunde[0]?.code).toBe('objekt');
});

test('verlangen wirft bei ungueltigem objekt', () => {
  expect(() => verlangen({})).toThrow();
});
