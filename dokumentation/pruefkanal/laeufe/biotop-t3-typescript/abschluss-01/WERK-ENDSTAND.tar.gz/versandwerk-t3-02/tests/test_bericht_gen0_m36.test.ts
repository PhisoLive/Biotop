import { test, expect } from 'vitest';
import { planen } from '../src/planung/plan.js';
import { zusammenfassen } from '../src/bericht/zusammenfassung.js';
import type { Sendung } from '../src/eingang/modell.js';

const daten: Sendung[] = [
  { kennung: 'AA', gewicht: 500, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } },
  { kennung: 'BB', gewicht: 1000, zone: 'fern', prioritaet: 'eilig', zerbrechlich: true, kanten: { laenge: 200, breite: 100, hoehe: 50 } },
];
const limit = { gewicht: 2000, anzahl: 5 };

test('durchschnitt teilt gesamt durch anzahl', () => {
  const bericht = zusammenfassen(planen(daten, limit));
  expect(bericht.anzahl).toBe(2);
  expect(bericht.cent).toBe(1130);
  expect(bericht.durchschnitt).toBe(565);
});

test('durchschnitt bei leerem plan ist null', () => {
  expect(zusammenfassen(planen([], limit)).durchschnitt).toBe(0);
});

test('durchschnitt ist nicht das produkt aus gesamt und anzahl', () => {
  const bericht = zusammenfassen(planen(daten, limit));
  expect(bericht.durchschnitt).not.toBe(2260);
});
