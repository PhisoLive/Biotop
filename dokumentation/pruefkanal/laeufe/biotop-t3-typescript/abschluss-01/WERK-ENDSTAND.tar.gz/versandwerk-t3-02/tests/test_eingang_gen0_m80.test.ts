import { test, expect } from 'vitest';
import { zeileLesen, zeileSchreiben } from '../src/eingang/zeilen.js';

test('test_zeilen_zone_aus_feld_2', () => {
  const sendung = zeileLesen('AB;fern;500;200;100;50;normal;nein');
  expect(sendung.zone).toBe('fern');
});

test('test_zeilen_runde_reise', () => {
  const text = 'AB;fern;500;200;100;50;normal;nein';
  expect(zeileSchreiben(zeileLesen(text))).toBe(text);
});
