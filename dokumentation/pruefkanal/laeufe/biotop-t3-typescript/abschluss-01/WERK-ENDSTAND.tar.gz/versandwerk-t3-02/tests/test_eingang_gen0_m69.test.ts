import { test, expect } from 'vitest';
import { statistik } from '../src/eingang/stapel.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(kennung: string, prioritaet: 'normal' | 'eilig'): Sendung {
  return {
    kennung,
    gewicht: 500,
    zone: 'nah',
    prioritaet,
    zerbrechlich: false,
    kanten: { laenge: 200, breite: 100, hoehe: 50 },
  };
}

test('statistik zaehlt eilige Sendungen korrekt', () => {
  const ergebnis = statistik([sendung('AA', 'eilig'), sendung('BB', 'normal')]);
  expect(ergebnis.eilig).toBe(1);
});

test('statistik ohne eilige Sendungen', () => {
  const ergebnis = statistik([sendung('AA', 'normal'), sendung('BB', 'normal')]);
  expect(ergebnis.eilig).toBe(0);
});

test('statistik leere Liste hat keine eiligen', () => {
  expect(statistik([]).eilig).toBe(0);
});
