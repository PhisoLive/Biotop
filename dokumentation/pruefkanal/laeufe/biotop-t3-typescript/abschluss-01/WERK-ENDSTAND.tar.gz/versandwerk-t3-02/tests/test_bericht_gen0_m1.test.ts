import { test, expect } from 'vitest';
import { kostenstruktur } from '../src/bericht/abstimmung.js';
import type { Plan } from '../src/planung/modell.js';

function leererPlan(): Plan {
  return {
    anzahl: 0,
    gewicht: 0,
    buendel: [],
    positionen: [],
    gesamt: 0,
    rabatt: 0,
    vorRabatt: 0,
  } as unknown as Plan;
}

test('kostenstruktur startet grund bei 0', () => {
  expect(kostenstruktur(leererPlan()).grund).toBe(0);
});

test('kostenstruktur ohne Positionen hat nur Nullwerte', () => {
  expect(kostenstruktur(leererPlan())).toEqual({ grund: 0, zone: 0, extras: 0, rabatt: 0, gesamt: 0 });
});
