import { test, expect } from 'vitest';
import { auslastung } from '../src/planung/analyse.js';
import { planen } from '../src/planung/plan.js';

const sendung = (kennung: string, gewicht: number) => ({
  kennung,
  gewicht,
  zone: 'nah' as const,
  prioritaet: 'normal' as const,
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

test('test_analyse_auslastung_anzahl_prozent', () => {
  const plan = planen([sendung('AA', 500), sendung('BB', 500)], { gewicht: 1000, anzahl: 2 });
  const werte = auslastung(plan, { gewicht: 1000, anzahl: 2 });
  expect(werte[0]!.anzahlProzent).toBe(100);
});

test('test_analyse_auslastung_anzahl_prozent_teil', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 4 });
  const werte = auslastung(plan, { gewicht: 1000, anzahl: 4 });
  expect(werte[0]!.anzahlProzent).toBe(25);
});

test('test_analyse_auslastung_gewicht_prozent', () => {
  const plan = planen([sendung('AA', 500)], { gewicht: 1000, anzahl: 2 });
  const werte = auslastung(plan, { gewicht: 1000, anzahl: 2 });
  expect(werte[0]!.gewichtProzent).toBe(50);
});
