import { test, expect } from 'vitest';
import { filtern } from '../src/eingang/register.js';
import type { Sendung } from '../src/eingang/modell.js';

function s(kennung: string, zone: Sendung['zone'], eilig: boolean): Sendung {
  return { kennung, gewicht: 500, zone, prioritaet: eilig ? 'eilig' : 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } };
}

test('filtern_zone_ungueltig_wirft', () => {
  const daten = [s('AA', 'nah', false)];
  expect(() => filtern(daten, { zone: 'west' as Sendung['zone'] })).toThrow();
});

test('filtern_zone_gueltig_kein_wurf', () => {
  const daten = [s('AA', 'nah', false)];
  expect(filtern(daten, { zone: 'nah' })).toHaveLength(1);
});

test('filtern_ohne_zone_kein_wurf', () => {
  const daten = [s('AA', 'nah', false)];
  expect(filtern(daten, {})).toHaveLength(1);
});
