import { test, expect } from 'vitest';
import { verlangen } from '../../src/eingang/pruefer.js';
import { planen } from '../../src/planung/plan.js';
const roh = { kennung: ' aa ', gewicht: 1000, zone: ' NAH ', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 1, breite: 1, hoehe: 1 } };

test('test_vertrag_eingang_planung_normalisierung', () => {
  const plan = planen([verlangen(roh)], { gewicht: 1000, anzahl: 1 });
  expect(plan.positionen[0]?.sendung.kennung).toBe('AA');
  expect(plan.buendel[0]?.gewicht).toBe(1000);
  expect(roh.kennung).toBe(' aa ');
});
test('test_vertrag_eingang_planung_einmaligkeit', () => {
  expect(() => planen([roh, roh], { gewicht: 2000, anzahl: 2 })).toThrow('Doppelte');
});
