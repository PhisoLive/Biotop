import { test, expect } from 'vitest';
import { buendeln } from '../src/planung/plan.js';
import type { Sendung } from '../src/eingang/modell.js';

const sendung = (kennung: string, gewicht: number): Sendung => ({
  kennung,
  gewicht,
  zone: 'nah',
  prioritaet: 'normal',
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

test('test_planung_buendel_nummern_starten_bei_eins', () => {
  const gruppen = buendeln([sendung('AA', 500), sendung('BB', 500), sendung('CC', 500)], { gewicht: 1000, anzahl: 2 });
  expect(gruppen.map(g => g.nummer)).toEqual([1, 2]);
});

test('test_planung_buendel_nummern_fortlaufend', () => {
  const gruppen = buendeln(
    [sendung('AA', 500), sendung('BB', 500), sendung('CC', 500), sendung('DD', 500), sendung('EE', 500)],
    { gewicht: 1000, anzahl: 2 },
  );
  expect(gruppen.map(g => g.nummer)).toEqual([1, 2, 3]);
});

test('test_planung_buendel_nummern_positiv', () => {
  const gruppen = buendeln([sendung('AA', 500), sendung('BB', 500)], { gewicht: 1000, anzahl: 2 });
  expect(gruppen[0]!.nummer).toBeGreaterThan(0);
});
