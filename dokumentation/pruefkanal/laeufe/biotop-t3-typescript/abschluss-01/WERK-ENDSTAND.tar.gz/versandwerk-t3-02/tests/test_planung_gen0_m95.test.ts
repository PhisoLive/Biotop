import { test, expect } from 'vitest';
import { buendeln, planen } from '../src/planung/plan.js';
import type { Sendung } from '../src/eingang/modell.js';

const limit = { gewicht: 1000, anzahl: 2 };
const s = (kennung: string, gewicht: number): Sendung => ({
  kennung,
  gewicht,
  zone: 'nah',
  prioritaet: 'normal',
  zerbrechlich: false,
  kanten: { laenge: 200, breite: 100, hoehe: 50 },
});

test('test_planung_buendel_gewicht_startwert', () => {
  const gruppen = buendeln([s('AA', 500)], limit);
  expect(gruppen[0]!.gewicht).toBe(500);
});

test('test_planung_buendel_gewicht_summe', () => {
  const gruppen = buendeln([s('AA', 300), s('BB', 400)], limit);
  expect(gruppen[0]!.gewicht).toBe(700);
});

test('test_planung_plan_gewicht_aus_buendeln', () => {
  const plan = planen([s('AA', 500), s('BB', 500)], limit);
  expect(plan.buendel[0]!.gewicht).toBe(1000);
});
