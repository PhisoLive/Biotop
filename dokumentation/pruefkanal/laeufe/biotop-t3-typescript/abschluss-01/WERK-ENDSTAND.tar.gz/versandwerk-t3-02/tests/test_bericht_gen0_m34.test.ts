import { test, expect } from 'vitest';
import { zusammenfassen } from '../src/bericht/zusammenfassung.js';
import type { Plan } from '../src/planung/modell.js';

function leererPlan(): Plan {
  return {
    anzahl: 0,
    gewicht: 0,
    buendel: [],
    positionen: [],
    gesamt: 0,
    rabatt: 0,
    vorRabatt: 0,
  } as unknown as Plan;
}

test('zusammenfassen leerer Plan hat Durchschnitt 0', () => {
  expect(zusammenfassen(leererPlan()).durchschnitt).toBe(0);
});

test('zusammenfassen leerer Plan liefert alle Nullwerte', () => {
  expect(zusammenfassen(leererPlan())).toEqual({
    anzahl: 0,
    buendel: 0,
    gramm: 0,
    cent: 0,
    rabatt: 0,
    durchschnitt: 0,
  });
});

test('zusammenfassen Durchschnitt bei anzahl 0 bleibt 0', () => {
  const plan = leererPlan();
  plan.gesamt = 500;
  expect(zusammenfassen(plan).durchschnitt).toBe(0);
});
