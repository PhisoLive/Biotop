import { test, expect } from 'vitest';
import { kuerzen } from '../src/bericht/tabelle.js';

test('kuerzen bei Breite 0 liefert leeren String', () => {
  expect(kuerzen('abc', 0)).toBe('');
});

test('kuerzen bei Breite groesser als Text liefert Text unveraendert', () => {
  expect(kuerzen('abc', 4)).toBe('abc');
});

test('kuerzen bei Breite 1 liefert nur Auslassungszeichen', () => {
  expect(kuerzen('abc', 1)).toBe('…');
});
