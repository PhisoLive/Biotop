import { test, expect } from 'vitest';
import { kuerzen } from '../src/bericht/tabelle.js';

test('kuerzen behaelt den Anfang des Textes', () => {
  expect(kuerzen('abcdef', 4)).toBe('abc…');
});

test('kuerzen gibt kurze Texte unveraendert zurueck', () => {
  expect(kuerzen('abc', 4)).toBe('abc');
});

test('kuerzen mit Breite eins ergibt nur die Ellipse', () => {
  expect(kuerzen('abc', 1)).toBe('…');
});
