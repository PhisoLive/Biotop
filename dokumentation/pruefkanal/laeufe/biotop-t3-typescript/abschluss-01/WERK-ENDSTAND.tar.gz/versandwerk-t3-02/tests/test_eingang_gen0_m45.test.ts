import { test, expect } from 'vitest';
import { pruefen } from '../src/eingang/pruefer.js';

test('test_eingang_pruefen_gueltig', () => {
  const ergebnis = pruefen({
    kennung: 'AB',
    zone: 'nah',
    gewicht: 500,
    kanten: { laenge: 200, breite: 100, hoehe: 50 },
    prioritaet: 'normal',
    zerbrechlich: false,
  });
  expect(ergebnis.gueltig).toBe(true);
  expect(ergebnis.sendung?.kennung).toBe('AB');
});

test('test_eingang_pruefen_null_abgelehnt', () => {
  const ergebnis = pruefen(null);
  expect(ergebnis.gueltig).toBe(false);
  expect(ergebnis.befunde[0]?.code).toBe('objekt');
});

test('test_eingang_pruefen_string_abgelehnt', () => {
  const ergebnis = pruefen('abc');
  expect(ergebnis.gueltig).toBe(false);
  expect(ergebnis.befunde[0]?.code).toBe('objekt');
});
