import { test, expect } from 'vitest';
import { eindeutig, kapazitaet, passt, vollstaendig } from '../src/planung/pruefen.js';
import type { Sendung } from '../src/eingang/modell.js';
import type { Buendel } from '../src/planung/modell.js';
const muster = (kennung = 'AA', gewicht = 500): Sendung => ({ kennung, gewicht, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } });
const buendel = (): Buendel => ({ nummer: 1, zone: 'nah', prioritaet: 'normal', sendungen: [muster()], gewicht: 500 });

test('test_planung_eindeutige_kennungen', () => {
  expect(eindeutig([muster('AA'), muster('BB')])).toBeUndefined();
  expect(eindeutig([])).toBeUndefined();
  expect(() => eindeutig([muster('AA'), muster('AA')])).toThrow('Doppelte');
});
test('test_planung_kapazitaet', () => {
  expect(kapazitaet({ gewicht: 1000, anzahl: 2 })).toEqual({ gewicht: 1000, anzahl: 2 });
  expect(() => kapazitaet({ gewicht: 0, anzahl: 2 })).toThrow();
  expect(() => kapazitaet({ gewicht: 1000, anzahl: 1.5 })).toThrow();
});
test('test_planung_passt_inklusive', () => {
  expect(passt(buendel(), muster('BB'), { gewicht: 1000, anzahl: 2 })).toBe(true);
  expect(passt(buendel(), muster('BB', 501), { gewicht: 1000, anzahl: 2 })).toBe(false);
  expect(passt(buendel(), muster('BB'), { gewicht: 2000, anzahl: 1 })).toBe(false);
});
test('test_planung_passt_gruppen', () => {
  expect(passt(buendel(), { ...muster('BB'), zone: 'fern' }, { gewicht: 1000, anzahl: 2 })).toBe(false);
  expect(passt(buendel(), { ...muster('BB'), prioritaet: 'eilig' }, { gewicht: 1000, anzahl: 2 })).toBe(false);
});
test('test_planung_vollstaendigkeit', () => {
  expect(vollstaendig([muster()], [buendel()])).toBe(true);
  expect(vollstaendig([muster(), muster('BB')], [buendel()])).toBe(false);
  expect(vollstaendig([muster()], [buendel(), buendel()])).toBe(false);
});

import { buendeln, planen, neuPlanen, entfernen } from '../src/planung/plan.js';
const limit = { gewicht: 1000, anzahl: 2 };

test('test_planung_buendel_kapazitaet', () => {
  const gruppen = buendeln([muster('AA'), muster('BB'), muster('CC')], limit);
  expect(gruppen.map(g => g.sendungen.map(s => s.kennung))).toEqual([['AA', 'BB'], ['CC']]);
  expect(gruppen.map(g => g.gewicht)).toEqual([1000, 500]);
  expect(gruppen.map(g => g.nummer)).toEqual([1, 2]);
});
test('test_planung_buendel_first_fit', () => {
  expect(buendeln([muster('AA', 700), muster('BB', 500), muster('CC', 300)], limit).map(g => g.sendungen.map(s => s.kennung))).toEqual([['AA', 'CC'], ['BB']]);
});
test('test_planung_buendel_zonen', () => {
  expect(buendeln([muster('AA'), { ...muster('BB'), zone: 'fern' }, { ...muster('CC'), prioritaet: 'eilig' }], limit)).toHaveLength(3);
});
test('test_planung_uebergewicht_kein_verlust', () => { expect(() => buendeln([muster('AA', 1001)], limit)).toThrow('Kapazitaet'); });
test('test_planung_plan_feste_kosten', () => {
  const plan = planen([muster('AA'), { ...muster('BB', 501), zone: 'fern' }], limit);
  expect(plan.anzahl).toBe(2);
  expect(plan.gewicht).toBe(1001);
  expect(plan.gesamt).toBe(755);
  expect(plan.vorRabatt).toBe(755);
  expect(plan.rabatt).toBe(0);
  expect(plan.positionen.map(p => p.angebot.gesamt)).toEqual([285, 470]);
});
test('test_planung_leer', () => { expect(planen([], limit)).toEqual({ buendel: [], positionen: [], anzahl: 0, gewicht: 0, vorRabatt: 0, rabatt: 0, gesamt: 0 }); });
test('test_planung_prueft_eingang', () => { expect(() => planen([{}], limit)).toThrow('kennung'); expect(() => planen([muster(), muster()], limit)).toThrow('Doppelte'); });
test('test_planung_kopiert_eingang', () => {
  const daten = [muster()];
  const plan = planen(daten, limit);
  plan.positionen[0]!.sendung.kanten.laenge = 300;
  expect(daten[0]?.kanten.laenge).toBe(200);
});
test('test_planung_neuplanen', () => {
  const original = planen([muster('AA'), muster('BB')], limit);
  const neu = neuPlanen(original, { gewicht: 500, anzahl: 1 });
  expect(neu.buendel).toHaveLength(2);
  expect(neu.gesamt).toBe(570);
  expect(original.buendel).toHaveLength(1);
});
test('test_planung_entfernen', () => {
  const original = planen([muster('AA'), muster('BB')], limit);
  expect(entfernen(original, ['AA'], limit).positionen.map(p => p.sendung.kennung)).toEqual(['BB']);
  expect(() => entfernen(original, ['ZZ'], limit)).toThrow('Unbekannte');
  expect(original.anzahl).toBe(2);
});

import { auslastung, vergleichen, abgleichen, reihenfolge, schwerste, kostenJeBuendel } from '../src/planung/analyse.js';

test('test_planung_auslastung', () => {
  const plan = planen([muster()], limit);
  expect(auslastung(plan, limit)).toEqual([{ nummer: 1, gewichtProzent: 50, anzahlProzent: 50, restGewicht: 500, restAnzahl: 1 }]);
});
test('test_planung_vergleich', () => {
  expect(vergleichen(planen([], limit), planen([muster()], limit))).toEqual({ anzahlDifferenz: 1, buendelDifferenz: 1, kostenDifferenz: 285, gewichtDifferenz: 500 });
});
test('test_planung_abgleich_sauber', () => { expect(abgleichen(planen([muster()], limit))).toEqual([]); });
test('test_planung_abgleich_fehler', () => {
  const plan = planen([muster()], limit);
  plan.gesamt = 1;
  plan.gewicht = 1;
  plan.anzahl = 2;
  expect(abgleichen(plan)).toEqual(['anzahl', 'gewicht', 'gesamt']);
});
test('test_planung_reihenfolge', () => {
  expect(reihenfolge(planen([muster('AA', 700), muster('BB', 500), muster('CC', 300)], limit))).toEqual(['AA', 'CC', 'BB']);
});
test('test_planung_schwerste', () => {
  const plan = planen([muster('AA', 300), muster('BB', 500), muster('CC', 500)], limit);
  expect(schwerste(plan, 2)).toEqual(['BB', 'CC']);
  expect(schwerste(plan, 0)).toEqual([]);
  expect(() => schwerste(plan, -1)).toThrow();
});
test('test_planung_buendelkosten', () => {
  const plan = planen([muster('AA'), muster('BB'), muster('CC')], limit);
  expect(kostenJeBuendel(plan)).toEqual([{ nummer: 1, cent: 570 }, { nummer: 2, cent: 285 }]);
});

import { ergaenzen, zonenplan, zusammenlegen, umleiten, kapazitaetenVergleichen, kleinsteKapazitaet } from '../src/planung/szenarien.js';

test('test_planung_ergaenzen', () => {
  const original = planen([muster('AA')], limit);
  expect(ergaenzen(original, [muster('BB')], limit).gesamt).toBe(570);
  expect(original.anzahl).toBe(1);
  expect(() => ergaenzen(original, [muster('AA')], limit)).toThrow('Doppelte');
});
test('test_planung_zonenplan', () => {
  const plan = planen([muster('AA'), { ...muster('BB'), zone: 'insel' }], limit);
  expect(zonenplan(plan, 'insel', limit).gesamt).toBe(685);
  expect(zonenplan(plan, 'fern', limit).anzahl).toBe(0);
});
test('test_planung_zusammenlegen', () => {
  const result = zusammenlegen([planen([muster('AA')], limit), planen([muster('BB')], limit)], limit);
  expect(result.buendel).toHaveLength(1);
  expect(result.gesamt).toBe(570);
});
test('test_planung_umleiten', () => {
  const original = planen([muster('AA'), muster('BB')], limit);
  const neu = umleiten(original, ['AA'], 'fern', limit);
  expect(neu.gesamt).toBe(720);
  expect(neu.buendel).toHaveLength(2);
  expect(original.gesamt).toBe(570);
  expect(() => umleiten(original, ['ZZ'], 'fern', limit)).toThrow('Unbekannte');
});
test('test_planung_kapazitaetsvergleich', () => {
  expect(kapazitaetenVergleichen([muster('AA'), muster('BB')], [{ gewicht: 500, anzahl: 1 }, limit])).toEqual([
    { limit: { gewicht: 500, anzahl: 1 }, buendel: 2, cent: 570 },
    { limit, buendel: 1, cent: 570 },
  ]);
});
test('test_planung_kleinste_kapazitaet', () => {
  const sendungen = [muster('AA'), muster('BB')];
  expect(kleinsteKapazitaet(sendungen, [{ gewicht: 2000, anzahl: 3 }, limit, { gewicht: 500, anzahl: 1 }], 1)).toEqual(limit);
  expect(kleinsteKapazitaet(sendungen, [{ gewicht: 500, anzahl: 1 }], 1)).toBe(null);
  expect(() => kleinsteKapazitaet(sendungen, [], 0)).toThrow();
});
