import { test, expect } from 'vitest';
import { filtern } from '../src/eingang/register.js';
import type { Sendung } from '../src/eingang/modell.js';

function muster(kennung: string, zone: Sendung['zone']): Sendung {
  return {
    kennung,
    gewicht: 500,
    zone,
    prioritaet: 'normal',
    zerbrechlich: false,
    kanten: { laenge: 200, breite: 100, hoehe: 50 },
  };
}

test('filtern ohne Zonenvorgabe liefert alle Zonen', () => {
  const sendungen = [muster('AA', 'nah'), muster('BB', 'fern')];

  expect(filtern(sendungen, {})).toEqual(sendungen);
});

test('filtern mit Zonenvorgabe beschränkt auf diese Zone', () => {
  expect(filtern([muster('AA', 'nah'), muster('BB', 'fern')], { zone: 'nah' }))
    .toEqual([muster('AA', 'nah')]);
});
