import { test, expect } from 'vitest';
import { planen } from '../../src/planung/plan.js';
const roh = { kennung: 'AA', gewicht: 501, zone: 'fern', prioritaet: 'eilig', zerbrechlich: true, kanten: { laenge: 601, breite: 1, hoehe: 1 } };

test('test_vertrag_planung_tarife_feste_kosten', () => {
  const plan = planen([roh], { gewicht: 1000, anzahl: 2 });
  expect(plan.gesamt).toBe(1145);
  expect(plan.positionen[0]?.angebot.zeilen).toEqual([{ art: 'grund', cent: 320 }, { art: 'zone', cent: 150 }, { art: 'extras', cent: 675 }]);
});
test('test_vertrag_planung_tarife_mengenbilanz', () => {
  const daten = Array.from({ length: 11 }, (_, i) => ({ ...roh, kennung: 'P' + i, gewicht: 0, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 1, breite: 1, hoehe: 1 } }));
  const plan = planen(daten, { gewicht: 1000, anzahl: 20 });
  expect(plan.vorRabatt).toBe(2750);
  expect(plan.rabatt).toBe(275);
  expect(plan.gesamt).toBe(2475);
});
