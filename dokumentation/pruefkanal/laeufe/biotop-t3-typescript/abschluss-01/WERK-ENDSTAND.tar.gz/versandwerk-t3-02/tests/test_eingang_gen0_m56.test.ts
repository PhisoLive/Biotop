import { test, expect } from 'vitest';
import { filtern } from '../src/eingang/register.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(kennung: string, zone: Sendung['zone']): Sendung {
  return { kennung, gewicht: 500, zone, prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } };
}

test('filtern_ohne_zone_behaelt_alle_zonen', () => {
  const daten = [sendung('AA', 'nah'), sendung('BB', 'fern'), sendung('CC', 'insel')];
  expect(filtern(daten, {}).map(s => s.kennung)).toEqual(['AA', 'BB', 'CC']);
});

test('filtern_mit_zone_waehlt_nur_diese_zone', () => {
  const daten = [sendung('AA', 'nah'), sendung('BB', 'fern')];
  expect(filtern(daten, { zone: 'nah' }).map(s => s.kennung)).toEqual(['AA']);
});

test('filtern_grenzen_werden_geprueft', () => {
  const daten = [sendung('AA', 'nah')];
  expect(() => filtern(daten, { minimum: 1000, maximum: 100 })).toThrow('Gewichtsgrenzen vertauscht');
});
