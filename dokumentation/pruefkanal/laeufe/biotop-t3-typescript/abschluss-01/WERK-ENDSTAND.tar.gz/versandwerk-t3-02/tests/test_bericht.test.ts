import { test, expect } from 'vitest';
import { planen } from '../src/planung/plan.js';
import { zusammenfassen, zonenbericht, prioritaetsbericht, gewichtsbericht, erstellen } from '../src/bericht/zusammenfassung.js';
import type { Sendung } from '../src/eingang/modell.js';
const daten: Sendung[] = [
  { kennung: 'AA', gewicht: 500, zone: 'nah', prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } },
  { kennung: 'BB', gewicht: 1000, zone: 'fern', prioritaet: 'eilig', zerbrechlich: true, kanten: { laenge: 200, breite: 100, hoehe: 50 } },
];
const limit = { gewicht: 2000, anzahl: 5 };

test('test_bericht_zusammenfassung', () => {
  expect(zusammenfassen(planen(daten, limit))).toEqual({ anzahl: 2, buendel: 2, gramm: 1500, cent: 1130, rabatt: 0, durchschnitt: 565 });
});
test('test_bericht_keine_neuberechnung', () => {
  const plan = planen(daten, limit);
  plan.gesamt = 777;
  expect(zusammenfassen(plan).cent).toBe(777);
});
test('test_bericht_leer', () => {
  expect(zusammenfassen(planen([], limit))).toEqual({ anzahl: 0, buendel: 0, gramm: 0, cent: 0, rabatt: 0, durchschnitt: 0 });
});
test('test_bericht_zonen', () => {
  expect(zonenbericht(planen(daten, limit))).toEqual([
    { zone: 'nah', anzahl: 1, gramm: 500, cent: 285 },
    { zone: 'fern', anzahl: 1, gramm: 1000, cent: 845 },
    { zone: 'insel', anzahl: 0, gramm: 0, cent: 0 },
  ]);
});
test('test_bericht_prioritaeten', () => {
  expect(prioritaetsbericht(planen(daten, limit))).toEqual([{ prioritaet: 'normal', anzahl: 1, cent: 285 }, { prioritaet: 'eilig', anzahl: 1, cent: 845 }]);
});
test('test_bericht_gewichte', () => {
  expect(gewichtsbericht(planen(daten, limit))).toEqual({ minimum: 500, maximum: 1000, median: 750, mittel: 750, klassen: [1, 1, 0, 0] });
  expect(gewichtsbericht(planen([], limit)).minimum).toBe(0);
});
test('test_bericht_erstellen_tragender_pfad', () => { expect(erstellen(daten, limit).cent).toBe(1130); });

import { grammtext, prozenttext, csvFeld, csvbericht, textbericht, jsonbericht, etiketten } from '../src/bericht/formate.js';

test('test_bericht_grammformat', () => {
  expect(grammtext(0)).toBe('0,000 kg');
  expect(grammtext(1234)).toBe('1,234 kg');
  expect(() => grammtext(-1)).toThrow();
});
test('test_bericht_prozentformat', () => {
  expect(prozenttext(12.35)).toBe('12,4 %');
  expect(prozenttext(0)).toBe('0,0 %');
});
test('test_bericht_csv_feld', () => {
  expect(csvFeld('abc')).toBe('abc');
  expect(csvFeld(42)).toBe('42');
  expect(csvFeld('a;b')).toBe('"a;b"');
  expect(csvFeld('a"b')).toBe('"a""b"');
  expect(csvFeld('a\nb')).toBe('"a\nb"');
});
test('test_bericht_csv_zeilen', () => {
  expect(csvbericht(planen(daten, limit))).toBe('kennung;zone;gramm;buendel;cent\nAA;nah;500;1;285\nBB;fern;1000;2;845\n'.replaceAll('\\n', '\n'));
});
test('test_bericht_text', () => {
  expect(textbericht(planen(daten, limit))).toBe('Sendungen: 2\nBuendel: 2\nGewicht: 1,500 kg\nGesamt: 11,30 EUR\nRabatt: 0,00 EUR'.replaceAll('\\n', '\n'));
});
test('test_bericht_jsonformat', () => {
  expect(JSON.parse(jsonbericht(planen(daten, limit)))).toEqual({ anzahl: 2, buendel: 2, gramm: 1500, cent: 1130, rabatt: 0, durchschnitt: 565 });
});
test('test_bericht_etiketten', () => {
  expect(etiketten(planen(daten, limit))).toEqual(['AA | NAH | B1 | 0,500 kg', 'BB | FERN | B2 | 1,000 kg']);
});

import { kuerzen, ausrichten, tabellenbreiten, tabelle, plantabelle, markdownTabelle, seiten } from '../src/bericht/tabelle.js';

test('test_bericht_kuerzen', () => {
  expect(kuerzen('abcdef', 4)).toBe('abc…');
  expect(kuerzen('abc', 4)).toBe('abc');
  expect(kuerzen('abc', 0)).toBe('');
  expect(kuerzen('abc', 1)).toBe('…');
});
test('test_bericht_ausrichtung', () => {
  expect(ausrichten('AB', 4)).toBe('AB  ');
  expect(ausrichten('AB', 4, 'rechts')).toBe('  AB');
  expect(() => ausrichten('AB', -1)).toThrow();
});
test('test_bericht_tabellenbreiten', () => { expect(tabellenbreiten([['a', 'bbbb'], ['ccc', 'dd']])).toEqual([3, 4]); expect(tabellenbreiten([])).toEqual([]); });
test('test_bericht_texttabelle', () => {
  expect(tabelle(['ID', 'Ort'], [['AA', 'nah'], ['BBBB', 'fern']])).toBe('ID   | Ort \n-----+-----\nAA   | nah \nBBBB | fern');
  expect(() => tabelle(['A'], [['a', 'b']])).toThrow('Spalten');
});
test('test_bericht_plantabelle', () => {
  const text = plantabelle(planen(daten, limit));
  expect(text).toContain('Kennung');
  expect(text).toContain('AA');
  expect(text).toContain('8,45');
});
test('test_bericht_markdown', () => {
  expect(markdownTabelle(planen(daten, limit))).toBe('| Kennung | Zone | Cent |\n| --- | --- | --- |\n| AA | nah | 285 |\n| BB | fern | 845 |');
});
test('test_bericht_seiten', () => {
  expect(seiten([1, 2, 3, 4, 5], 2)).toEqual([[1, 2], [3, 4], [5]]);
  expect(seiten([], 2)).toEqual([]);
  expect(() => seiten([1], 0)).toThrow();
});

import { kostenstruktur, positionsliste, buendelbericht, rabattquote, abweichungen, konsistenzbericht } from '../src/bericht/abstimmung.js';

test('test_bericht_kostenstruktur', () => {
  expect(kostenstruktur(planen(daten, limit))).toEqual({ grund: 605, zone: 150, extras: 375, rabatt: 0, gesamt: 1130 });
});
test('test_bericht_positionsliste', () => {
  expect(positionsliste(planen(daten, limit))).toEqual([{ kennung: 'AA', buendel: 1, gramm: 500, cent: 285, kumuliert: 285 }, { kennung: 'BB', buendel: 2, gramm: 1000, cent: 845, kumuliert: 1130 }]);
});
test('test_bericht_buendelbericht', () => {
  expect(buendelbericht(planen(daten, limit))).toEqual([{ nummer: 1, zone: 'nah', anzahl: 1, gramm: 500, cent: 285 }, { nummer: 2, zone: 'fern', anzahl: 1, gramm: 1000, cent: 845 }]);
});
test('test_bericht_rabattquote', () => {
  const plan = planen(daten, limit);
  plan.vorRabatt = 1000;
  plan.rabatt = 125;
  expect(rabattquote(plan)).toBe(12.5);
  expect(rabattquote(planen([], limit))).toBe(0);
});
test('test_bericht_abweichungen', () => {
  const alt = planen(daten, limit);
  const neu = planen([{ ...daten[0]!, zone: 'fern' }, { ...daten[1]!, kennung: 'CC' }], limit);
  expect(abweichungen(alt, neu)).toEqual([{ kennung: 'AA', art: 'geaendert', differenz: 150 }, { kennung: 'BB', art: 'entfernt', differenz: -845 }, { kennung: 'CC', art: 'neu', differenz: 845 }]);
  expect(abweichungen(alt, alt)).toEqual([]);
});
test('test_bericht_konsistenz', () => {
  expect(konsistenzbericht(planen(daten, limit))).toEqual({ gueltig: true, fehler: [] });
  const kaputt = planen(daten, limit);
  kaputt.gesamt = 1;
  expect(konsistenzbericht(kaputt)).toEqual({ gueltig: false, fehler: ['gesamt'] });
});
