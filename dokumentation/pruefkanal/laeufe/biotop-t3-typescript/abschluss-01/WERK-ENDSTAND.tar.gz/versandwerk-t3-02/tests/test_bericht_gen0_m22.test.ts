import { test, expect } from 'vitest';
import { kuerzen } from '../src/bericht/tabelle.js';

test('kuerzen gibt bei Breite 0 den leeren String zurueck', () => {
  expect(kuerzen('abc', 0)).toBe('');
});

test('kuerzen kuerzt bei Breite 1 auf das Ellipsenzeichen', () => {
  expect(kuerzen('abc', 1)).toBe('…');
});

test('kuerzen laesst Text innerhalb der Breite unveraendert', () => {
  expect(kuerzen('abc', 4)).toBe('abc');
});
