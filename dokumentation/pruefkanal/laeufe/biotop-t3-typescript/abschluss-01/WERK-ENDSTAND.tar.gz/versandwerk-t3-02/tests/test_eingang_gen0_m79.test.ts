import { test, expect } from 'vitest';
import { zeileLesen, zeileSchreiben, listeLesen, listeSchreiben, kennungsfolge } from '../src/eingang/zeilen.js';

test('test_eingang_zeile_lesen', () => {
  expect(zeileLesen(' ab ;nah;500;200;100;50;normal;nein')).toEqual({
    kennung: 'AB',
    zone: 'nah',
    gewicht: 500,
    kanten: { laenge: 200, breite: 100, hoehe: 50 },
    prioritaet: 'normal',
    zerbrechlich: false,
  });
  expect(zeileLesen('BB;fern;0;1;1;1;eilig;ja').zerbrechlich).toBe(true);
});

test('test_eingang_zeile_schreiben', () => {
  expect(zeileSchreiben({
    kennung: 'AB',
    zone: 'nah',
    gewicht: 500,
    kanten: { laenge: 200, breite: 100, hoehe: 50 },
    prioritaet: 'normal',
    zerbrechlich: false,
  })).toBe('AB;nah;500;200;100;50;normal;nein');
});

test('test_eingang_liste_lesen', () => {
  const result = listeLesen('AB;nah;500;200;100;50;normal;nein\nkaputt\nBB;fern;0;1;1;1;eilig;ja\n');
  expect(result.gesamt).toBe(3);
  expect(result.sendungen.map(s => s.kennung)).toEqual(['AB', 'BB']);
  expect(result.abgelehnt[0]?.position).toBe(1);
});
