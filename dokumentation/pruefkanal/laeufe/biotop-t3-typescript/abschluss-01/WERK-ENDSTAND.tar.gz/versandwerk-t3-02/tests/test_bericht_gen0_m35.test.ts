import { test, expect } from 'vitest';
import { zusammenfassen } from '../src/bericht/zusammenfassung.js';
import type { Plan } from '../src/planung/modell.js';

function leererPlan(): Plan {
  return {
    anzahl: 0,
    gewicht: 0,
    buendel: [],
    positionen: [],
    gesamt: 0,
    rabatt: 0,
    vorRabatt: 0,
  } as unknown as Plan;
}

test('zusammenfassen leerer Plan hat Durchschnitt 0', () => {
  expect(zusammenfassen(leererPlan()).durchschnitt).toBe(0);
});

test('zusammenfassen leerer Plan entspricht Nullbericht', () => {
  expect(zusammenfassen(leererPlan())).toEqual({
    anzahl: 0,
    buendel: 0,
    gramm: 0,
    cent: 0,
    rabatt: 0,
    durchschnitt: 0,
  });
});

test('zusammenfassen leerer Plan Durchschnitt nicht negativ', () => {
  expect(zusammenfassen(leererPlan()).durchschnitt).toBeGreaterThanOrEqual(0);
});
