import { test, expect } from 'vitest';
import { filtern } from '../src/eingang/register.js';
import type { Sendung } from '../src/eingang/modell.js';

function sendung(kennung: string, zone: Sendung['zone'] = 'nah'): Sendung {
  return { kennung, gewicht: 500, zone, prioritaet: 'normal', zerbrechlich: false, kanten: { laenge: 200, breite: 100, hoehe: 50 } };
}

test('filtern nach Zone behaelt nur passende Sendungen', () => {
  const daten = [sendung('AA', 'nah'), sendung('BB', 'fern'), sendung('CC', 'nah')];
  expect(filtern(daten, { zone: 'nah' }).map(s => s.kennung)).toEqual(['AA', 'CC']);
});

test('filtern ohne Zone behaelt alle Sendungen', () => {
  const daten = [sendung('AA', 'nah'), sendung('BB', 'fern'), sendung('CC', 'insel')];
  expect(filtern(daten, {}).map(s => s.kennung)).toEqual(['AA', 'BB', 'CC']);
});

test('filtern kombiniert Zone mit Gewichtsgrenzen', () => {
  const leicht = { ...sendung('AA', 'nah'), gewicht: 100 };
  const schwer = { ...sendung('BB', 'nah'), gewicht: 9000 };
  expect(filtern([leicht, schwer], { zone: 'nah', maximum: 5000 }).map(s => s.kennung)).toEqual(['AA']);
});
