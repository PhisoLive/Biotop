import { test, expect } from 'vitest';
import { zeileLesen } from '../src/eingang/zeilen.js';

test('zeileLesen liest Kennung aus dem ersten Feld', () => {
  const sendung = zeileLesen('AB;nah;500;200;100;50;normal;nein');
  expect(sendung.kennung).toBe('AB');
});

test('zeileLesen trennt Kennung und Zone korrekt', () => {
  const sendung = zeileLesen('AB;fern;500;200;100;50;normal;nein');
  expect(sendung.kennung).toBe('AB');
  expect(sendung.zone).toBe('fern');
});

test('zeileLesen erhaelt unterschiedliche Kennungen', () => {
  expect(zeileLesen('XY;nah;1;1;1;1;normal;nein').kennung).toBe('XY');
});
