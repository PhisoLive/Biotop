import { test, expect } from 'vitest';
import { kuerzen } from '../src/bericht/tabelle.js';

test('kuerzen behaelt Text exakt an der Breite', () => {
  expect(kuerzen('abc', 3)).toBe('abc');
});

test('kuerzen kuerzt Text knapp ueber der Breite', () => {
  expect(kuerzen('abcd', 3)).toBe('ab…');
});
