# versandwerk

Fiktives lokales Sendungsprüfwerk und künstlich präparierte Übungsfixture. Nicht für produktiven Versand oder andere Betriebszwecke geeignet. Die Präparation ist außerhalb des Werks dokumentiert; dieses Paket enthält keine Auflösung.

Fünf Bereiche: `eingang`, `tarife`, `planung`, `bericht`, `zahlen`. Alle Größen verwenden Gramm, Millimeter und ganze Cent. Es gibt keine Datei-, Netz- oder Prozessschnittstelle. Verarbeitung ist synchron und deterministisch.

Öffentliche Grenzverträge stehen in `tests/vertraege/VERTRAEGE.md`. Build und Test werden nur in der netzlosen TypeScript-Kammer ausgeführt; Werkzeuge TypeScript 5.7.3 und Vitest 2.1.8. `npm run build`, `npm run typecheck`, `npm test` sind die Paketbefehle innerhalb dieser Kammer.
