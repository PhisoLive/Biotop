import type { Sendung, Zone, Stapelergebnis, Eingangsstatistik } from './modell.js';
import { pruefen } from './pruefer.js';
import { kopieren } from './normalisieren.js';
import { ganz, nichtnegativ } from '../zahlen/pruefen.js';

export function stapelPruefen(roh: readonly unknown[]): Stapelergebnis {
  const ergebnis: Stapelergebnis = { sendungen: [], abgelehnt: [], gesamt: roh.length };
  const bekannt = new Set<string>();
  roh.forEach((wert, position) => {
    const pruefung = pruefen(wert);
    if (!pruefung.gueltig) {
      ergebnis.abgelehnt.push({ position, befunde: pruefung.befunde });
    } else if (bekannt.has(pruefung.sendung.kennung)) {
      ergebnis.abgelehnt.push({ position, befunde: [{ feld: 'kennung', code: 'doppelt', meldung: 'Kennung wiederholt' }] });
    } else {
      bekannt.add(pruefung.sendung.kennung);
      ergebnis.sendungen.push(pruefung.sendung);
    }
  });
  return ergebnis;
}

export function sortieren(sendungen: Sendung[]): Sendung[] {
  return sendungen.sort((a, b) => a.kennung < b.kennung ? -1 : a.kennung > b.kennung ? 1 : 0);
}

export function nachZone(sendungen: readonly Sendung[]): Record<Zone, Sendung[]> {
  const gruppen: Record<Zone, Sendung[]> = { nah: [], fern: [], insel: [] };
  for (const sendung of sendungen) {
    gruppen[sendung.zone].push(kopieren(sendung));
  }
  return gruppen;
}

export function statistik(sendungen: readonly Sendung[]): Eingangsstatistik {
  const ergebnis: Eingangsstatistik = {
    anzahl: sendungen.length,
    gewicht: 0,
    eilig: 0,
    zerbrechlich: 0,
    zonen: { nah: 0, fern: 0, insel: 0 },
  };
  for (const sendung of sendungen) {
    const gramm = sendung.gewicht;
    if (typeof gramm !== 'number' || !Number.isFinite(gramm) || !Number.isInteger(gramm)) {
      throw new TypeError(`Gewicht ungueltig: ${String(gramm)}`);
    }
    ergebnis.gewicht += nichtnegativ(gramm);
    ergebnis.eilig += sendung.prioritaet === 'eilig' ? 1 : 0;
    ergebnis.zerbrechlich += sendung.zerbrechlich ? 1 : 0;
    ergebnis.zonen[sendung.zone] += 1;
  }
  ganz(ergebnis.gewicht, 'Gesamtgewicht');
  return ergebnis;
}

export function priorisieren(sendungen: readonly Sendung[]): Sendung[] {
  const eilig = sendungen.filter(s => s.prioritaet === 'eilig');
  const normal = sendungen.filter(s => s.prioritaet === 'normal');
  return [...eilig, ...normal].map(kopieren);
}

export function teilen(sendungen: readonly Sendung[], groesse: number): Sendung[][] {
  ganz(groesse, 'Stapelgroesse');
  if (groesse < 1) throw new RangeError('Stapelgroesse muss positiv sein');
  const gruppen: Sendung[][] = [];
  for (let i = 0; i < sendungen.length; i += groesse) {
    gruppen.push(sendungen.slice(i, i + groesse).map(kopieren));
  }
  return gruppen;
}

export function auswaehlen(sendungen: readonly Sendung[], kennungen: readonly string[]): Sendung[] {
  const gesucht = new Set(kennungen);
  const vorhanden = new Set(sendungen.map(s => s.kennung));
  for (const id of gesucht) {
    if (!vorhanden.has(id)) throw new RangeError(`Unbekannte Kennung ${id}`);
  }
  return sendungen.filter(s => gesucht.has(s.kennung)).map(kopieren);
}
