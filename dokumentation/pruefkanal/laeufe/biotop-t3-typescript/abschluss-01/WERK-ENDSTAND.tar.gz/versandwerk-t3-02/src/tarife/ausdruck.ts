import type { Tarifkontext } from './modell.js';
import { nichtnegativ } from '../zahlen/pruefen.js';

const tokenCache = new Map<string, Token[]>();

type Token =
  | { art: 'zahl'; wert: number }
  | { art: 'var'; name: 'gewicht' | 'grund' }
  | { art: 'op'; symbol: '+' | '-' | '*' | '/' }
  | { art: 'klammer'; symbol: '(' | ')' };

function tokenisieren(text: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < text.length) {
    const c = text[i];
    if (c === ' ') {
      i++;
      continue;
    }
    if (/[0-9]/.test(c)) {
      let numStr = '';
      let punkte = 0;
      while (i < text.length && /[0-9.]/.test(text[i])) {
        if (text[i] === '.') {
          punkte++;
          if (punkte > 1) throw new SyntaxError('Ungültiges numerisches Literal');
        }
        numStr += text[i];
        i++;
      }
      // Check for trailing dot or invalid format like .5 or 5.
      if (numStr.startsWith('.') || numStr.endsWith('.')) {
         throw new SyntaxError('Ungültiges numerisches Literal');
      }
      const wert = Number(numStr);
      if (!Number.isFinite(wert)) throw new SyntaxError('Zahl nicht endlich');
      tokens.push({ art: 'zahl', wert });
      continue;
    }
    if (c === '+') { tokens.push({ art: 'op', symbol: '+' }); i++; continue; }
    if (c === '-') { tokens.push({ art: 'op', symbol: '-' }); i++; continue; }
    if (c === '*') { tokens.push({ art: 'op', symbol: '*' }); i++; continue; }
    if (c === '/') { tokens.push({ art: 'op', symbol: '/' }); i++; continue; }
    if (c === '(') { tokens.push({ art: 'klammer', symbol: '(' }); i++; continue; }
    if (c === ')') { tokens.push({ art: 'klammer', symbol: ')' }); i++; continue; }
    
    // Variable parsing
    if (/[a-zA-Z_]/.test(c)) {
      let varName = '';
      while (i < text.length && /[a-zA-Z0-9_]/.test(text[i])) {
        varName += text[i];
        i++;
      }
      if (varName === 'gewicht' || varName === 'grund') {
        tokens.push({ art: 'var', name: varName });
      } else {
        throw new SyntaxError(`Unbekannte Variable: ${varName}`);
      }
      continue;
    }
    
    throw new SyntaxError(`Unerwartetes Zeichen: ${c}`);
  }
  return tokens;
}

class Parser {
  private pos = 0;
  constructor(private tokens: Token[], private kontext: Tarifkontext) {}

  private peek(): Token | undefined { return this.tokens[this.pos]; }
  private consume(): Token { 
    const t = this.tokens[this.pos++]; 
    if (!t) throw new SyntaxError('Unerwartetes Ende'); 
    return t; 
  }

  parse(): number {
    const val = this.expr();
    if (this.pos < this.tokens.length) throw new SyntaxError('Resttokens nach Ausdruck');
    return val;
  }

  private expr(): number {
    let left = this.term();
    while (this.peek()?.art === 'op' && ['+', '-'].includes((this.peek() as any).symbol)) {
      const op = this.consume() as Extract<Token, { art: 'op' }>;
      const right = this.term();
      left = op.symbol === '+' ? left + right : left - right;
    }
    return left;
  }

  private term(): number {
    let left = this.factor();
    while (this.peek()?.art === 'op' && ['*', '/'].includes((this.peek() as any).symbol)) {
      const op = this.consume() as Extract<Token, { art: 'op' }>;
      const right = this.factor();
      if (op.symbol === '/') {
        if (right === 0) throw new RangeError('Division durch Null');
        left = left / right;
      } else {
        left = left * right;
      }
    }
    return left;
  }

  private factor(): number {
    const t = this.peek();
    if (!t) throw new SyntaxError('Erwartete Faktor');
    
    if (t.art === 'zahl') {
      this.consume();
      return t.wert;
    }
    
    if (t.art === 'var') {
      this.consume();
      return t.name === 'gewicht' ? this.kontext.gewicht : this.kontext.grund;
    }
    
    if (t.art === 'op' && t.symbol === '-') {
      this.consume();
      return -this.factor();
    }
    
    if (t.art === 'klammer' && t.symbol === '(') {
      this.consume();
      const val = this.expr();
      const close = this.peek();
      if (!close || close.art !== 'klammer' || close.symbol !== ')') {
        throw new SyntaxError('Klammer nicht geschlossen');
      }
      this.consume();
      return val;
    }
    
    throw new SyntaxError('Ungültiger Faktor');
  }
}

export function ausdruck(text: string, kontext: Tarifkontext): number {
  nichtnegativ(kontext.gewicht, 'Gewicht');
  nichtnegativ(kontext.grund, 'Grund');
  if (text.trim().length === 0 || text.length > 160) {
    throw new RangeError('Ausdruck muss 1..160 Zeichen enthalten');
  }
  
  try {
    let tokens = tokenCache.get(text);
    if (!tokens) {
      tokens = tokenisieren(text);
      // Cache nur wenn erfolgreich tokenisiert wurde, um fehlerhafte Zustände zu vermeiden
      tokenCache.set(text, tokens);
    }
    const parser = new Parser(tokens, kontext);
    const ergebnis = parser.parse();
    
    if (!Number.isFinite(ergebnis)) {
      throw new RangeError('Ergebnis nicht endlich');
    }
    
    return nichtnegativ(ergebnis, 'Ergebnis');
  } catch (e) {
    if (e instanceof SyntaxError || e instanceof RangeError || e instanceof TypeError) {
      throw e;
    }
    throw new Error('Fehler bei der Auswertung des Ausdrucks');
  }
}
