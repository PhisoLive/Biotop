import type { Sendung, Zone } from './modell.js';
import { kopieren, kennung, zone as zonePruefen } from './normalisieren.js';
import { verlangen } from './pruefer.js';
import { nichtnegativ } from '../zahlen/pruefen.js';

export interface Eingangsfilter {
  zone?: Zone;
  minimum?: number;
  maximum?: number;
  eilig?: boolean;
}

export interface Registerunterschied {
  hinzu: string[];
  weg: string[];
  gleich: string[];
}

export function registrieren(sendungen: readonly Sendung[]): ReadonlyMap<string, Sendung> {
  const register = new Map<string, Sendung>();
  for (const original of sendungen) {
    const sendung = verlangen(original);
    if (register.has(sendung.kennung)) throw new TypeError(`Doppelte Kennung ${sendung.kennung}`);
    register.set(sendung.kennung, sendung);
  }
  return register;
}

export function suchen(register: ReadonlyMap<string, Sendung>, id: string): Sendung | null {
  const gefunden = register.get(kennung(id));
  return gefunden ? kopieren(gefunden) : null;
}

export function ersetzen(sendungen: readonly Sendung[], neu: Sendung): Sendung[] {
  const geprueft = verlangen(neu);
  if (!sendungen.some(s => s.kennung === geprueft.kennung)) {
    throw new RangeError(`Unbekannte Kennung ${geprueft.kennung}`);
  }
  return sendungen.map(s => kopieren(s.kennung === geprueft.kennung ? geprueft : s));
}

export function filtern(sendungen: readonly Sendung[], filter: Eingangsfilter): Sendung[] {
  const minimum = nichtnegativ(filter.minimum ?? 0);
  const maximum = nichtnegativ(filter.maximum ?? 30000);
  if (minimum > maximum) throw new RangeError('Gewichtsgrenzen vertauscht');
  if (filter.zone !== undefined) zonePruefen(filter.zone);
  return sendungen.filter(sendung => {
    if (filter.zone !== undefined && sendung.zone !== filter.zone) return false;
    if (sendung.gewicht < minimum || sendung.gewicht > maximum) return false;
    if (filter.eilig !== undefined && (sendung.prioritaet === 'eilig') !== filter.eilig) return false;
    return true;
  }).map(kopieren);
}

export function unterschied(alt: readonly Sendung[], neu: readonly Sendung[]): Registerunterschied {
  const vorher = new Set(alt.map(s => s.kennung));
  const nachher = new Set(neu.map(s => s.kennung));
  return {
    hinzu: [...nachher].filter(id => !vorher.has(id)).sort(),
    weg: [...vorher].filter(id => !nachher.has(id)).sort(),
    gleich: [...vorher].filter(id => nachher.has(id)).sort(),
  };
}

export function kennungenPruefen(kennungen: readonly string[]): { normal: string[]; doppelt: string[] } {
  const bekannt = new Set<string>();
  const doppelt = new Set<string>();
  for (const roh of kennungen) {
    const id = kennung(roh);
    if (bekannt.has(id)) doppelt.add(id);
    bekannt.add(id);
  }
  return { normal: [...bekannt], doppelt: [...doppelt] };
}
