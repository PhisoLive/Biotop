export type Zone = 'nah' | 'fern' | 'insel';
export type Prioritaet = 'normal' | 'eilig';

export interface Kanten {
  laenge: number;
  breite: number;
  hoehe: number;
}

export interface Sendung {
  kennung: string;
  zone: Zone;
  gewicht: number;
  kanten: Kanten;
  prioritaet: Prioritaet;
  zerbrechlich: boolean;
}

export interface Befund {
  feld: string;
  code: string;
  meldung: string;
}

export type Pruefergebnis =
  | { gueltig: true; sendung: Sendung; befunde: [] }
  | { gueltig: false; sendung: null; befunde: Befund[] };

export interface Stapelergebnis {
  sendungen: Sendung[];
  abgelehnt: { position: number; befunde: Befund[] }[];
  gesamt: number;
}

export interface Eingangsstatistik {
  anzahl: number;
  gewicht: number;
  eilig: number;
  zerbrechlich: number;
  zonen: Record<Zone, number>;
}
