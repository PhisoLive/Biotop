import type { Kanten, Zone, Prioritaet, Sendung } from './modell.js';
import { ganz, bereich } from '../zahlen/pruefen.js';

function text(wert: unknown, name: string): string {
  if (typeof wert !== 'string') {
    throw new TypeError(`${name} muss Text sein`);
  }
  return wert.trim();
}

export function kennung(wert: unknown): string {
  const normal = text(wert, 'Kennung').toUpperCase();
  if (!/^[A-Z][A-Z0-9-]{1,15}$/.test(normal)) {
    throw new TypeError('Kennung ungueltig');
  }
  return normal;
}

export function zone(wert: unknown): Zone {
  const normal = text(wert, 'Zone').toLowerCase();
  if (normal !== 'nah' && normal !== 'fern' && normal !== 'insel') {
    throw new TypeError('Zone unbekannt');
  }
  return normal;
}

export function prioritaet(wert: unknown): Prioritaet {
  const normal = text(wert, 'Prioritaet').toLowerCase();
  if (normal !== 'normal' && normal !== 'eilig') {
    throw new TypeError('Prioritaet unbekannt');
  }
  return normal;
}

function kante(wert: unknown): number {
  if (typeof wert !== 'number' || !bereich(wert, 1, 1200)) {
    throw new RangeError('Kante ausserhalb 1..1200');
  }
  return ganz(wert, 'Kante');
}

export function kanten(wert: unknown): Kanten {
  if (!wert || typeof wert !== 'object' || Array.isArray(wert)) {
    throw new TypeError('Kanten muessen ein Objekt sein');
  }
  const daten = wert as Record<string, unknown>;
  return {
    laenge: kante(daten.laenge),
    breite: kante(daten.breite),
    hoehe: kante(daten.hoehe),
  };
}

export function gewicht(wert: unknown): number {
  if (typeof wert !== 'number' || !bereich(wert, 0, 30000)) {
    throw new RangeError('Gewicht ausserhalb 0..30000');
  }
  return ganz(wert, 'Gewicht');
}

export function kopieren(sendung: Sendung): Sendung {
  return { ...sendung, kanten: { ...sendung.kanten } };
}

export function volumen(masse: Kanten): number {
  const geprueft = kanten(masse);
  return geprueft.laenge * geprueft.breite * geprueft.hoehe;
}

export function laengsteKante(masse: Kanten): number {
  const geprueft = kanten(masse);
  return Math.max(geprueft.laenge, geprueft.breite, geprueft.hoehe);
}

export function gurtmass(masse: Kanten): number {
  const geprueft = kanten(masse);
  const summe = geprueft.laenge + geprueft.breite + geprueft.hoehe;
  return 2 * summe - laengsteKante(geprueft);
}

export function volumengewicht(masse: Kanten): number {
  return Math.ceil(volumen(masse) / 5000);
}
