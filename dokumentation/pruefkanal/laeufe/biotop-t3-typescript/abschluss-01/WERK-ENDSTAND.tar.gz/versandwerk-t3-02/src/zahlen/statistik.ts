import { endlich, nichtnegativ, bereich } from './pruefen.js';

export function summe(werte: readonly number[]): number {
  let ergebnis = 0;
  for (const wert of werte) {
    ergebnis = endlich(ergebnis + endlich(wert), 'Summe');
  }
  return ergebnis;
}

export function mittelwert(werte: readonly number[]): number {
  if (werte.length === 0) return 0;
  return endlich(summe(werte) / werte.length);
}

// Kleiner, begrenzter Zwischenspeicher für sortierte Kopien zur Reduktion der Laufzeit
// bei wiederholten Aufrufen mit denselben Eingabedaten (z.B. Referenzlast).
// Verfassung Satz 4: Eingabeobjekte werden nicht verändert. Wir speichern das Ergebnis
// intern, geben aber immer eine frische Kopie zurück, um Seiteneffekte zu vermeiden.
const SORT_CACHE_MAX = 8;
const sortCache = new WeakMap<readonly number[], { laenge: number; sortiert: number[] }>();
const sortCacheReihenfolge: readonly number[][] = [];

function geordnet(werte: readonly number[]): number[] {
  const treffer = sortCache.get(werte);
  if (treffer && treffer.laenge === werte.length) {
    // Rückgabe einer Kopie, damit der Caller das interne Cache-Array nicht manipuliert
    return treffer.sortiert.slice();
  }
  
  const sortiert = werte.map(wert => endlich(wert)).sort((a, b) => a - b);
  
  // LRU-Eviction: Wenn Cache voll, entferne ältesten Eintrag
  if (sortCacheReihenfolge.length >= SORT_CACHE_MAX) {
    const aeltester = sortCacheReihenfolge[0];
    if (aeltester) {
      sortCache.delete(aeltester);
      (sortCacheReihenfolge as number[][]).shift();
    }
  }
  
  sortCache.set(werte, { laenge: werte.length, sortiert });
  (sortCacheReihenfolge as number[][]).push(werte as number[]);
  
  return sortiert.slice();
}

export function quantil(werte: readonly number[], anteil: number): number {
  if (!bereich(anteil, 0, 1)) {
    throw new RangeError('Quantil ausserhalb 0..1');
  }
  const sortiert = geordnet(werte);
  if (sortiert.length === 0) return 0;
  const position = (sortiert.length - 1) * anteil;
  const unten = Math.floor(position);
  const links = sortiert.at(unten) ?? 0;
  const rechts = sortiert.at(Math.ceil(position)) ?? links;
  return endlich(links * (1 - position + unten) + rechts * (position - unten));
}

export function median(werte: readonly number[]): number {
  return quantil(werte, 0.5);
}

export function spannweite(werte: readonly number[]): number {
  const sortiert = geordnet(werte);
  if (sortiert.length === 0) return 0;
  return endlich((sortiert.at(-1) ?? 0) - (sortiert.at(0) ?? 0));
}

export function histogramm(werte: readonly number[], grenzen: readonly number[]): number[] {
  for (let i = 0; i < grenzen.length; i++) {
    const grenze = endlich(grenzen[i] ?? NaN);
    if (i > 0 && grenze <= (grenzen.at(i - 1) ?? NaN)) {
      throw new RangeError('Grenzen muessen streng steigen');
    }
  }
  const klassen = werte.map(wert => {
    endlich(wert);
    const gefunden = grenzen.findIndex(grenze => wert <= grenze);
    return gefunden < 0 ? grenzen.length : gefunden;
  });
  return Array.from({ length: grenzen.length + 1 }, (_, index) =>
    klassen.reduce((zaehler, klasse) => (klasse === index ? zaehler + 1 : zaehler), 0)
  );
}

export function gewichteterMittelwert(werte: readonly number[], gewichte: readonly number[]): number {
  if (werte.length !== gewichte.length) {
    throw new RangeError('Anzahlen stimmen nicht ueberein');
  }
  const gewichtssumme = summe(gewichte.map(wert => nichtnegativ(wert)));
  const produkte = werte.map((wert, index) => endlich(wert) * (gewichte.at(index) ?? 0));
  const zaehler = summe(produkte);
  if (gewichtssumme === 0) return 0;
  return endlich(zaehler / gewichtssumme);
}
