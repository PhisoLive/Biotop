import type { Plan } from '../planung/modell.js';
import { abgleichen, kostenJeBuendel } from '../planung/analyse.js';
import { addieren } from '../zahlen/geld.js';
import { kumuliert } from '../zahlen/reihen.js';

export interface Kostenstruktur {
  grund: number;
  zone: number;
  extras: number;
  rabatt: number;
  gesamt: number;
}

export interface Positionszeile {
  kennung: string;
  buendel: number;
  gramm: number;
  cent: number;
  kumuliert: number;
}

export interface Buendelzeile {
  nummer: number;
  zone: string;
  anzahl: number;
  gramm: number;
  cent: number;
}

export interface Abweichung {
  kennung: string;
  art: string;
  differenz: number;
}

export function kostenstruktur(plan: Plan): Kostenstruktur {
  const ergebnis: Kostenstruktur = { grund: 0, zone: 0, extras: 0, rabatt: plan.rabatt, gesamt: plan.gesamt };
  for (const position of plan.positionen) {
    for (const zeile of position.angebot.zeilen) {
      if (zeile.art === 'grund' || zeile.art === 'zone' || zeile.art === 'extras') {
        ergebnis[zeile.art] = addieren([ergebnis[zeile.art], zeile.cent]);
      }
    }
  }
  return ergebnis;
}

export function positionsliste(plan: Plan): Positionszeile[] {
  const laufend = kumuliert(plan.positionen.map(p => p.angebot.gesamt));
  return plan.positionen.map((position, index) => ({
    kennung: position.sendung.kennung,
    buendel: position.buendel,
    gramm: position.sendung.gewicht,
    cent: position.angebot.gesamt,
    kumuliert: laufend[index] ?? 0,
  }));
}

export function buendelbericht(plan: Plan): Buendelzeile[] {
  const kosten = new Map(kostenJeBuendel(plan).map(k => [k.nummer, k.cent]));
  return plan.buendel.map(gruppe => ({
    nummer: gruppe.nummer,
    zone: gruppe.zone,
    anzahl: gruppe.sendungen.length,
    gramm: gruppe.gewicht,
    cent: kosten.get(gruppe.nummer) ?? 0,
  }));
}

export function rabattquote(plan: Plan): number {
  if (plan.vorRabatt === 0) return 0;
  return plan.rabatt / plan.vorRabatt * 100;
}

export function abweichungen(alt: Plan, neu: Plan): Abweichung[] {
  const vorher = new Map(alt.positionen.map(p => [p.sendung.kennung, p.angebot.gesamt]));
  const nachher = new Map(neu.positionen.map(p => [p.sendung.kennung, p.angebot.gesamt]));
  const kennungen = [...new Set([...vorher.keys(), ...nachher.keys()])].sort();
  const ergebnis: Abweichung[] = [];
  for (const kennung of kennungen) {
    const links = vorher.get(kennung);
    const rechts = nachher.get(kennung);
    if (links === rechts) continue;
    ergebnis.push({
      kennung,
      art: links === undefined ? 'neu' : rechts === undefined ? 'entfernt' : 'geaendert',
      differenz: (rechts ?? 0) - (links ?? 0),
    });
  }
  return ergebnis;
}

export function konsistenzbericht(plan: Plan): { gueltig: boolean; fehler: string[] } {
  const fehler = abgleichen(plan);
  return { gueltig: fehler.length === 0, fehler };
}
