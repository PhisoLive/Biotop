import type { Plan } from '../planung/modell.js';
import { euro, runden } from '../zahlen/geld.js';
import { ganz, nichtnegativ } from '../zahlen/pruefen.js';
import { zusammenfassen } from './zusammenfassung.js';

export function grammtext(gramm: number): string {
  ganz(gramm, 'Gramm');
  nichtnegativ(gramm, 'Gramm');
  const kilo = Math.floor(gramm / 1000);
  const rest = String(gramm % 1000).padStart(3, '0');
  return `${kilo},${rest} kg`;
}

export function prozenttext(wert: number): string {
  nichtnegativ(wert, 'Prozent');
  const zehntel = runden(wert * 10);
  return `${Math.floor(zehntel / 10)},${zehntel % 10} %`;
}

export function csvFeld(wert: string | number): string {
  const text = String(wert);
  if (/[;"\n\r]/.test(text)) {
    return `"${text.replaceAll('"', '""')}"`;
  }
  return text;
}

export function csvbericht(plan: Plan): string {
  const zeilen = ['kennung;zone;gramm;buendel;cent'];
  for (const position of plan.positionen) {
    const felder = [
      position.sendung.kennung,
      position.sendung.zone,
      position.sendung.gewicht,
      position.buendel,
      position.angebot.gesamt,
    ];
    zeilen.push(felder.map(csvFeld).join(';'));
  }
  return zeilen.join('\n') + '\n';
}

export function textbericht(plan: Plan): string {
  return [
    `Sendungen: ${plan.anzahl}`,
    `Buendel: ${plan.buendel.length}`,
    `Gewicht: ${grammtext(plan.gewicht)}`,
    `Gesamt: ${euro(plan.gesamt)} EUR`,
    `Rabatt: ${euro(plan.rabatt)} EUR`,
  ].join('\n');
}

export function jsonbericht(plan: Plan): string {
  return JSON.stringify(zusammenfassen(plan));
}

export function etiketten(plan: Plan): string[] {
  return plan.positionen.map(position => [
    position.sendung.kennung,
    position.sendung.zone.toUpperCase(),
    `B${position.buendel}`,
    grammtext(position.sendung.gewicht),
  ].join(' | '));
}
