import { endlich, ganz, nichtnegativ, bereich } from './pruefen.js';

export function runden(wert: number): number {
  endlich(wert);
  const gerundet = Math.sign(wert) * Math.floor(Math.abs(wert) + 0.5);
  ganz(gerundet);
  return gerundet === 0 ? 0 : gerundet;
}

export function cent(wert: number): number {
  ganz(wert, 'Cent');
  return nichtnegativ(wert, 'Cent');
}

export function addieren(werte: readonly number[]): number {
  let summe = 0;
  for (const wert of werte) {
    summe = ganz(summe + cent(wert), 'Summe');
  }
  return summe;
}

export function prozent(basis: number, satz: number): number {
  cent(basis);
  if (!bereich(satz, 0, 100)) {
    throw new RangeError('Prozentsatz ausserhalb 0..100');
  }
  return cent(runden(basis * (satz / 100)));
}

export function abziehen(basis: number, rabatt: number): number {
  cent(basis);
  cent(rabatt);
  if (rabatt > basis) {
    throw new RangeError('Rabatt uebersteigt Basis');
  }
  return basis - rabatt;
}

export function multiplizieren(basis: number, anzahl: number): number {
  cent(basis);
  ganz(anzahl, 'Anzahl');
  nichtnegativ(anzahl, 'Anzahl');
  return cent(basis * anzahl);
}

function anteile(betrag: number, gewichte: readonly number[]): number[] {
  const gesamt = gewichte.reduce((summe, wert) => summe + nichtnegativ(wert), 0);
  endlich(gesamt, 'Gewichtssumme');
  if (gesamt === 0) {
    if (betrag === 0) return gewichte.map(() => 0);
    throw new RangeError('Verteilung ohne Gewicht');
  }
  return gewichte.map(wert => betrag * (wert / gesamt));
}

export function verteilen(betrag: number, gewichte: readonly number[]): number[] {
  cent(betrag);
  const exakt = anteile(betrag, gewichte);
  const basis = exakt.map(Math.floor);
  const rest = betrag - addieren(basis);
  const reihenfolge = exakt.map((wert, index) => ({ index, rest: wert - Math.floor(wert) }));
  reihenfolge.sort((a, b) => b.rest - a.rest || a.index - b.index);
  const beguenstigt = reihenfolge.slice(0, rest).map(position => position.index);
  if (beguenstigt.length !== rest) {
    throw new RangeError('Verteilung nicht darstellbar');
  }
  return basis.map((wert, index) =>
    wert + beguenstigt.reduce((zaehler, treffer) => (treffer === index ? zaehler + 1 : zaehler), 0)
  );
}

export function euro(betrag: number): string {
  cent(betrag);
  const ganzteil = Math.floor(betrag / 100);
  const rest = String(betrag % 100).padStart(2, '0');
  return `${ganzteil},${rest}`;
}

export function centLesen(text: string): number {
  if (!/^(0|[1-9][0-9]*),[0-9]{2}$/.test(text)) {
    throw new TypeError('Geldformat ungueltig');
  }
  const [ganzteil, rest] = text.split(',');
  return cent(Number(ganzteil) * 100 + Number(rest));
}
