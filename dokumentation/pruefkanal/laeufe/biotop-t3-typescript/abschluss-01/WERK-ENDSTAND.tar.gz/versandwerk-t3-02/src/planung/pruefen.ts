import type { Sendung } from '../eingang/modell.js';
import type { Kapazitaet, Buendel } from './modell.js';
import { ganz } from '../zahlen/pruefen.js';

export function eindeutig(sendungen: readonly Sendung[]): void {
  const gesehen = new Set<string>();
  for (const sendung of sendungen) {
    if (gesehen.has(sendung.kennung)) {
      throw new TypeError(`Doppelte Kennung ${sendung.kennung}`);
    }
    gesehen.add(sendung.kennung);
  }
}

export function kapazitaet(wert: Kapazitaet): Kapazitaet {
  ganz(wert.gewicht, 'Gewichtskapazitaet');
  ganz(wert.anzahl, 'Anzahlkapazitaet');
  if (wert.gewicht < 1 || wert.anzahl < 1) {
    throw new RangeError('Kapazitaeten muessen positiv sein');
  }
  return { gewicht: wert.gewicht, anzahl: wert.anzahl };
}

export function passt(buendel: Buendel, sendung: Sendung, limit: Kapazitaet): boolean {
  kapazitaet(limit);
  if (buendel.zone !== sendung.zone) return false;
  if (buendel.prioritaet !== sendung.prioritaet) return false;
  if (buendel.sendungen.length + 1 > limit.anzahl) return false;
  return buendel.gewicht + sendung.gewicht <= limit.gewicht;
}

export function vollstaendig(sendungen: readonly Sendung[], buendel: readonly Buendel[]): boolean {
  const erwartet = new Map<string, number>();
  for (const sendung of sendungen) {
    erwartet.set(sendung.kennung, (erwartet.get(sendung.kennung) ?? 0) + 1);
  }
  for (const gruppe of buendel) {
    for (const sendung of gruppe.sendungen) {
      const rest = erwartet.get(sendung.kennung) ?? 0;
      if (rest === 0) return false;
      erwartet.set(sendung.kennung, rest - 1);
    }
  }
  return [...erwartet.values()].every(anzahl => anzahl === 0);
}
