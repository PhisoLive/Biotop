import type { Befund, Pruefergebnis, Sendung } from './modell.js';
import { kennung, zone, prioritaet, kanten, gewicht } from './normalisieren.js';

function schalter(wert: unknown): boolean {
  if (typeof wert !== 'boolean') {
    throw new TypeError('Zerbrechlich muss boolean sein');
  }
  return wert;
}

function feld<T>(name: string, wert: unknown, pruefer: (wert: unknown) => T, befunde: Befund[]): T | undefined {
  try {
    return pruefer(wert);
  } catch (fehler) {
    const meldung = fehler instanceof Error ? fehler.message : 'Ungueltiges Feld';
    befunde.push({ feld: name, code: 'ungueltig', meldung });
    return undefined;
  }
}

export function pruefen(roh: unknown): Pruefergebnis {
  if (!roh || typeof roh !== 'object' || Array.isArray(roh)) {
    return {
      gueltig: false,
      sendung: null,
      befunde: [{ feld: '$', code: 'objekt', meldung: 'Sendung muss Objekt sein' }],
    };
  }
  const daten = roh as Record<string, unknown>;
  const befunde: Befund[] = [];
  const id = feld('kennung', daten.kennung, kennung, befunde);
  const ort = feld('zone', daten.zone, zone, befunde);
  const gramm = feld('gewicht', daten.gewicht, gewicht, befunde);
  const masse = feld('kanten', daten.kanten, kanten, befunde);
  const rang = feld('prioritaet', daten.prioritaet, prioritaet, befunde);
  const vorsicht = feld('zerbrechlich', daten.zerbrechlich, schalter, befunde);
  if (id === undefined || ort === undefined || gramm === undefined || masse === undefined || rang === undefined || vorsicht === undefined) {
    return { gueltig: false, sendung: null, befunde };
  }
  const sendung: Sendung = {
    kennung: id,
    zone: ort,
    gewicht: gramm,
    kanten: masse,
    prioritaet: rang,
    zerbrechlich: vorsicht,
  };
  return { gueltig: true, sendung, befunde: [] };
}

export function verlangen(roh: unknown): Sendung {
  const ergebnis = pruefen(roh);
  if (!ergebnis.gueltig) {
    throw new TypeError(ergebnis.befunde.map(b => `${b.feld}: ${b.meldung}`).join('; '));
  }
  return ergebnis.sendung;
}
