import type { Sendung, Stapelergebnis } from './modell.js';
import { verlangen } from './pruefer.js';
import { kennung } from './normalisieren.js';
import { ganz, nichtnegativ } from '../zahlen/pruefen.js';

function dezimal(text: string): number {
  if (!/^[0-9]+$/.test(text.trim())) {
    throw new TypeError('Dezimalzahl ohne Vorzeichen erwartet');
  }
  return ganz(Number(text), 'Zahl');
}

function jaNein(text: string): boolean {
  const wert = text.trim().toLowerCase();
  if (wert === 'ja') return true;
  if (wert === 'nein') return false;
  throw new TypeError('ja oder nein erwartet');
}

export function zeileLesen(text: string): Sendung {
  const felder = text.split(';');
  if (felder.length !== 8) throw new TypeError('Genau 8 Felder erwartet');
  return verlangen({
    kennung: felder[0],
    zone: felder[1],
    gewicht: dezimal(felder[2] ?? ''),
    kanten: {
      laenge: dezimal(felder[3] ?? ''),
      breite: dezimal(felder[4] ?? ''),
      hoehe: dezimal(felder[5] ?? ''),
    },
    prioritaet: felder[6],
    zerbrechlich: jaNein(felder[7] ?? ''),
  });
}

export function zeileSchreiben(sendung: Sendung): string {
  const geprueft = verlangen(sendung);
  return [
    geprueft.kennung,
    geprueft.zone,
    geprueft.gewicht,
    geprueft.kanten.laenge,
    geprueft.kanten.breite,
    geprueft.kanten.hoehe,
    geprueft.prioritaet,
    geprueft.zerbrechlich ? 'ja' : 'nein',
  ].join(';');
}

export function listeLesen(text: string): Stapelergebnis {
  const zeilen = text === '' ? [] : text.replace(/\r\n/g, '\n').replace(/\n$/, '').split('\n');
  const ergebnis: Stapelergebnis = { gesamt: zeilen.length, sendungen: [], abgelehnt: [] };
  const gesehen = new Set<string>();
  zeilen.forEach((zeile, position) => {
    try {
      const sendung = zeileLesen(zeile);
      if (gesehen.has(sendung.kennung)) {
        ergebnis.abgelehnt.push({ position, befunde: [{ feld: 'kennung', code: 'doppelt', meldung: 'Kennung wiederholt' }] });
      } else {
        gesehen.add(sendung.kennung);
        ergebnis.sendungen.push(sendung);
      }
    } catch (fehler) {
      const meldung = fehler instanceof Error ? fehler.message : 'Ungueltige Zeile';
      ergebnis.abgelehnt.push({ position, befunde: [{ feld: '$', code: 'zeile', meldung }] });
    }
  });
  return ergebnis;
}

export function listeSchreiben(sendungen: readonly Sendung[]): string {
  if (sendungen.length === 0) return '';
  return sendungen.map(zeileSchreiben).join('\n') + '\n';
}

export function kennungsfolge(prefix: string, start: number, anzahl: number): string[] {
  ganz(start, 'Start');
  ganz(anzahl, 'Anzahl');
  nichtnegativ(start);
  nichtnegativ(anzahl);
  if (anzahl > 10000) throw new RangeError('Hoechstens 10000 Kennungen');
  const ergebnis: string[] = [];
  for (let i = 0; i < anzahl; i++) {
    ergebnis.push(kennung(prefix + String(ganz(start + i)).padStart(4, '0')));
  }
  return ergebnis;
}
