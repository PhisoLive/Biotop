import type { Plan } from '../planung/modell.js';
import { ganz, nichtnegativ } from '../zahlen/pruefen.js';
import { euro } from '../zahlen/geld.js';

function breitePruefen(breite: number): void {
  ganz(breite, 'Breite');
  nichtnegativ(breite, 'Breite');
}

export function kuerzen(text: string, breite: number): string {
  breitePruefen(breite);
  if (breite === 0) return '';
  if (text.length <= breite) return text;
  return text.slice(0, breite - 1) + '…';
}

export function ausrichten(text: string, breite: number, richtung: 'links' | 'rechts' = 'links'): string {
  breitePruefen(breite);
  const gekuerzt = kuerzen(text, breite);
  return richtung === 'rechts' ? gekuerzt.padStart(breite) : gekuerzt.padEnd(breite);
}

export function tabellenbreiten(zeilen: readonly (readonly string[])[]): number[] {
  const breiten: number[] = [];
  for (const zeile of zeilen) {
    zeile.forEach((feld, index) => {
      breiten[index] = Math.max(breiten[index] ?? 0, feld.length);
    });
  }
  return breiten;
}

export function tabelle(kopf: readonly string[], zeilen: readonly (readonly string[])[]): string {
  if (zeilen.some(zeile => zeile.length !== kopf.length)) {
    throw new RangeError('Spaltenzahl stimmt nicht');
  }
  const breiten = tabellenbreiten([kopf, ...zeilen]);
  const format = (zeile: readonly string[]) => zeile.map((feld, i) => ausrichten(feld, breiten[i] ?? 0)).join(' | ');
  const trenner = breiten.map(breite => '-'.repeat(breite)).join('-+-');
  return [format(kopf), trenner, ...zeilen.map(format)].join('\n');
}

export function plantabelle(plan: Plan): string {
  const zeilen = plan.positionen.map(position => [
    position.sendung.kennung,
    position.sendung.zone,
    String(position.sendung.gewicht),
    euro(position.angebot.gesamt),
  ]);
  return tabelle(['Kennung', 'Zone', 'Gramm', 'EUR'], zeilen);
}

function markdownFeld(text: string): string {
  return text.replaceAll('|', '\\|').replaceAll('\n', ' ');
}

export function markdownTabelle(plan: Plan): string {
  const zeilen = ['| Kennung | Zone | Cent |', '| --- | --- | --- |'];
  for (const position of plan.positionen) {
    const felder = [position.sendung.kennung, position.sendung.zone, String(position.angebot.gesamt)];
    zeilen.push('| ' + felder.map(markdownFeld).join(' | ') + ' |');
  }
  return zeilen.join('\n');
}

export function seiten<T>(zeilen: readonly T[], groesse: number): T[][] {
  ganz(groesse, 'Seitengroesse');
  if (groesse < 1) throw new RangeError('Seitengroesse muss positiv sein');
  const ergebnis: T[][] = [];
  for (let i = 0; i < zeilen.length; i += groesse) {
    ergebnis.push(zeilen.slice(i, i + groesse));
  }
  return ergebnis;
}
