import type { Zone } from '../eingang/modell.js';

export interface Preiszeile {
  art: string;
  cent: number;
}

export interface Angebot {
  kennung: string;
  zeilen: Preiszeile[];
  vorRabatt: number;
  rabatt: number;
  gesamt: number;
}

export interface Tarifkontext {
  gewicht: number;
  grund: number;
}

export interface Gewichtsstufe {
  bis: number;
  cent: number;
}

export interface Zonenpreis {
  zone: Zone;
  cent: number;
}

export interface Vergleich {
  billigste: number;
  teuerste: number;
  differenz: number;
  durchschnitt: number;
}
