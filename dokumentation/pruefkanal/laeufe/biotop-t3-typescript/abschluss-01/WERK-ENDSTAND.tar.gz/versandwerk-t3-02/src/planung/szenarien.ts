import type { Plan, Kapazitaet } from './modell.js';
import type { Sendung, Zone } from '../eingang/modell.js';
import { planen } from './plan.js';
import { kapazitaet } from './pruefen.js';
import { kopieren, zone as zonePruefen } from '../eingang/normalisieren.js';
import { ganz } from '../zahlen/pruefen.js';

export interface Kapazitaetsvergleich {
  limit: Kapazitaet;
  buendel: number;
  cent: number;
}

export function ergaenzen(plan: Plan, neu: readonly unknown[], limit: Kapazitaet): Plan {
  const vorhanden = plan.positionen.map(p => p.sendung);
  return planen([...vorhanden, ...neu], limit);
}

export function zonenplan(plan: Plan, zone: Zone, limit: Kapazitaet): Plan {
  zonePruefen(zone);
  const sendungen = plan.positionen.filter(p => p.sendung.zone === zone).map(p => p.sendung);
  return planen(sendungen, limit);
}

export function zusammenlegen(plaene: readonly Plan[], limit: Kapazitaet): Plan {
  const sendungen = plaene.flatMap(plan => plan.positionen.map(p => p.sendung));
  return planen(sendungen, limit);
}

export function umleiten(plan: Plan, kennungen: readonly string[], zone: Zone, limit: Kapazitaet): Plan {
  const ziel = zonePruefen(zone);
  const gesucht = new Set(kennungen);
  const vorhanden = new Set(plan.positionen.map(p => p.sendung.kennung));
  for (const id of gesucht) {
    if (!vorhanden.has(id)) throw new RangeError(`Unbekannte Kennung ${id}`);
  }
  const sendungen = plan.positionen.map(p => {
    const sendung = kopieren(p.sendung);
    if (gesucht.has(sendung.kennung)) sendung.zone = ziel;
    return sendung;
  });
  return planen(sendungen, limit);
}

export function kapazitaetenVergleichen(sendungen: readonly Sendung[], grenzen: readonly Kapazitaet[]): Kapazitaetsvergleich[] {
  return grenzen.map(grenze => {
    const limit = kapazitaet(grenze);
    const plan = planen(sendungen, limit);
    return { limit, buendel: plan.buendel.length, cent: plan.gesamt };
  });
}

export function kleinsteKapazitaet(sendungen: readonly Sendung[], grenzen: readonly Kapazitaet[], hoechstens: number): Kapazitaet | null {
  ganz(hoechstens, 'Buendelgrenze');
  if (hoechstens < 1) throw new RangeError('Buendelgrenze muss positiv sein');
  const sortiert = grenzen.map(kapazitaet).sort((a, b) => a.gewicht - b.gewicht || a.anzahl - b.anzahl);
  for (const limit of sortiert) {
    if (sendungen.some(sendung => sendung.gewicht > limit.gewicht)) continue;
    if (planen(sendungen, limit).buendel.length <= hoechstens) return limit;
  }
  return null;
}
