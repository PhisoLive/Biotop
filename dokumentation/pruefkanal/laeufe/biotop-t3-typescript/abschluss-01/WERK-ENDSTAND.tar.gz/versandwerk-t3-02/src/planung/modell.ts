import type { Prioritaet, Sendung, Zone } from '../eingang/modell.js';
import type { Angebot } from '../tarife/modell.js';

export interface Kapazitaet {
  gewicht: number;
  anzahl: number;
}

export interface Buendel {
  nummer: number;
  zone: Zone;
  prioritaet: Prioritaet;
  sendungen: Sendung[];
  gewicht: number;
}

export interface Planposition {
  sendung: Sendung;
  angebot: Angebot;
  buendel: number;
}

export interface Plan {
  buendel: Buendel[];
  positionen: Planposition[];
  anzahl: number;
  gewicht: number;
  vorRabatt: number;
  rabatt: number;
  gesamt: number;
}

export interface Auslastung {
  nummer: number;
  gewichtProzent: number;
  anzahlProzent: number;
  restGewicht: number;
  restAnzahl: number;
}

export interface Planvergleich {
  anzahlDifferenz: number;
  buendelDifferenz: number;
  kostenDifferenz: number;
  gewichtDifferenz: number;
}
