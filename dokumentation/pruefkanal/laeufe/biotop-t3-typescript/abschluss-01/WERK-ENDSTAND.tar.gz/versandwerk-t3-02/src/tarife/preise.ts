import type { Sendung, Zone } from '../eingang/modell.js';
import type { Angebot, Preiszeile } from './modell.js';
import { ganz, nichtnegativ, bereich } from '../zahlen/pruefen.js';
import { cent, addieren } from '../zahlen/geld.js';
import { laengsteKante } from '../eingang/normalisieren.js';

export function skalar(gewicht: number): number {
  ganz(gewicht, 'Gewicht');
  if (!bereich(gewicht, 0, 30000)) {
    throw new RangeError('Gewicht ausserhalb 0..30000');
  }
  return 250 + Math.ceil(gewicht / 500) * 35;
}

export function zonenaufschlag(zone: Zone): number {
  switch (zone) {
    case 'nah': return 0;
    case 'fern': return 150;
    case 'insel': return 400;
    default: throw new TypeError('Zone unbekannt');
  }
}

export function zuschlaege(sendung: Sendung): number {
  let betrag = 0;
  if (sendung.prioritaet === 'eilig') betrag += 250;
  if (sendung.zerbrechlich) betrag += 125;
  if (laengsteKante(sendung.kanten) > 600) betrag += 300;
  return betrag;
}

export function mengenpreis(basis: number, anzahl: number): number {
  cent(basis);
  ganz(anzahl, 'Anzahl');
  nichtnegativ(anzahl, 'Anzahl');
  return endpreis(basis, 0, anzahl > 10 ? 10 : 0);
}

export function angebot(sendung: Sendung, anzahl = 1, grundpreis?: number): Angebot {
  const grund = grundpreis === undefined ? skalar(sendung.gewicht) : cent(grundpreis);
  const zeilen: Preiszeile[] = [
    { art: 'grund', cent: grund },
    { art: 'zone', cent: zonenaufschlag(sendung.zone) },
    { art: 'extras', cent: zuschlaege(sendung) },
  ];
  const vorRabatt = addieren(zeilen.map(zeile => zeile.cent));
  const gesamt = mengenpreis(vorRabatt, anzahl);
  return {
    kennung: sendung.kennung,
    zeilen,
    vorRabatt,
    rabatt: vorRabatt - gesamt,
    gesamt,
  };
}

export function versicherung(wert: number): number {
  cent(wert);
  return cent(Math.ceil(wert / 10000) * 100);
}

function dezimalbruch(satz: number): [bigint, bigint] {
  if (!bereich(satz, 0, 100)) {
    throw new RangeError('Prozentsatz ausserhalb 0..100');
  }
  const [mantisse = '', exponent = '0'] = String(satz).toLowerCase().split('e');
  const [ganzteil = '', nachkomma = ''] = mantisse.split('.');
  const stellen = nachkomma.length - Number(exponent);
  const zaehler = BigInt(ganzteil + nachkomma);
  return stellen >= 0
    ? [zaehler, 10n ** BigInt(stellen)]
    : [zaehler * 10n ** BigInt(-stellen), 1n];
}

function endcent(zaehler: bigint, nenner: bigint): number {
  if (zaehler < 0n || nenner <= 0n) throw new RangeError('Preisbruch ungueltig');
  const ganzteil = zaehler / nenner;
  const rest = zaehler % nenner;
  const ergebnis = ganzteil + (rest * 2n >= nenner ? 1n : 0n);
  if (ergebnis > BigInt(Number.MAX_SAFE_INTEGER)) {
    throw new RangeError('Endpreis ausserhalb sicherer Cent');
  }
  return cent(Number(ergebnis));
}

export function endpreis(netto: number, steuersatz: number, rabattsatz = 0): number {
  cent(netto);
  const [steuer, steuerbasis] = dezimalbruch(steuersatz);
  const [rabatt, rabattbasis] = dezimalbruch(rabattsatz);
  const zaehler = BigInt(netto) * (100n * rabattbasis - rabatt)
    * (100n * steuerbasis + steuer);
  const nenner = 100n * rabattbasis * 100n * steuerbasis;
  return endcent(zaehler, nenner);
}
