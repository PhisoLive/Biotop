export function endlich(wert: number, name = 'Wert'): number {
  if (!Number.isFinite(wert)) {
    throw new RangeError(`${name} muss endlich sein`);
  }
  return wert;
}

export function ganz(wert: number, name = 'Wert'): number {
  endlich(wert, name);
  if (!Number.isSafeInteger(wert)) {
    throw new RangeError(`${name} muss eine sichere Ganzzahl sein`);
  }
  return wert;
}

export function nichtnegativ(wert: number, name = 'Wert'): number {
  endlich(wert, name);
  if (wert < 0) {
    throw new RangeError(`${name} darf nicht negativ sein`);
  }
  return wert;
}

function grenzen(unten: number, oben: number): void {
  endlich(unten, 'Untergrenze');
  endlich(oben, 'Obergrenze');
  if (unten > oben) {
    throw new RangeError('Grenzen sind vertauscht');
  }
}

export function bereich(wert: number, unten: number, oben: number): boolean {
  endlich(wert);
  grenzen(unten, oben);
  return wert >= unten && wert <= oben;
}

export function begrenzen(wert: number, unten: number, oben: number): number {
  endlich(wert);
  grenzen(unten, oben);
  return Math.min(oben, Math.max(unten, wert));
}
