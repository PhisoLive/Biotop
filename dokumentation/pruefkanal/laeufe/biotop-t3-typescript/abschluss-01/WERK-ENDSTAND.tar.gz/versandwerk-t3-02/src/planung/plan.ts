import type { Sendung } from '../eingang/modell.js';
import type { Kapazitaet, Buendel, Plan, Planposition } from './modell.js';
import { verlangen } from '../eingang/pruefer.js';
import { kopieren } from '../eingang/normalisieren.js';
import { skalar, angebot } from '../tarife/preise.js';
import { addieren } from '../zahlen/geld.js';
import { summe } from '../zahlen/statistik.js';
import { eindeutig, kapazitaet, passt, vollstaendig } from './pruefen.js';

function neuesBuendel(sendung: Sendung, nummer: number): Buendel {
  return {
    nummer,
    zone: sendung.zone,
    prioritaet: sendung.prioritaet,
    sendungen: [],
    gewicht: 0,
  };
}

export function buendeln(sendungen: readonly Sendung[], limit: Kapazitaet): Buendel[] {
  kapazitaet(limit);
  eindeutig(sendungen);
  const gruppen: Buendel[] = [];
  for (const original of sendungen) {
    const sendung = verlangen(original);
    if (sendung.gewicht > limit.gewicht) {
      throw new RangeError(`Kapazitaet fuer ${sendung.kennung} unzureichend`);
    }
    let gruppe = gruppen.find(b => passt(b, sendung, limit));
    if (!gruppe) {
      gruppe = neuesBuendel(sendung, gruppen.length + 1);
      gruppen.push(gruppe);
    }
    gruppe.sendungen.push(sendung);
    gruppe.gewicht += sendung.gewicht;
  }
  if (!vollstaendig(sendungen, gruppen)) throw new Error('Plan ist unvollstaendig');
  return gruppen;
}

function zuordnung(gruppen: readonly Buendel[]): Map<string, number> {
  const nummern = new Map<string, number>();
  for (const gruppe of gruppen) {
    for (const sendung of gruppe.sendungen) {
      nummern.set(sendung.kennung, gruppe.nummer);
    }
  }
  return nummern;
}

function positionen(sendungen: readonly Sendung[], gruppen: readonly Buendel[]): Planposition[] {
  const nummern = zuordnung(gruppen);
  return sendungen.map(sendung => {
    const grund = skalar(sendung.gewicht);
    const nummer = nummern.get(sendung.kennung);
    if (nummer === undefined) throw new Error('Sendung ohne Buendel');
    return {
      sendung: kopieren(sendung),
      angebot: angebot(sendung, sendungen.length, grund),
      buendel: nummer,
    };
  });
}

export function planen(roh: readonly unknown[], limit: Kapazitaet): Plan {
  const sendungen = roh.map(verlangen);
  const buendel = buendeln(sendungen, limit);
  const zeilen = positionen(sendungen, buendel);
  return {
    buendel,
    positionen: zeilen,
    anzahl: zeilen.length,
    gewicht: summe(sendungen.map(s => s.gewicht)),
    vorRabatt: addieren(zeilen.map(p => p.angebot.vorRabatt)),
    rabatt: addieren(zeilen.map(p => p.angebot.rabatt)),
    gesamt: addieren(zeilen.map(p => p.angebot.gesamt)),
  };
}

export function neuPlanen(plan: Plan, limit: Kapazitaet): Plan {
  return planen(plan.positionen.map(p => p.sendung), limit);
}

export function entfernen(plan: Plan, kennungen: readonly string[], limit: Kapazitaet): Plan {
  const entfernt = new Set(kennungen);
  const vorhanden = new Set(plan.positionen.map(p => p.sendung.kennung));
  for (const id of entfernt) {
    if (!vorhanden.has(id)) throw new RangeError(`Unbekannte Kennung ${id}`);
  }
  const rest = plan.positionen.filter(p => !entfernt.has(p.sendung.kennung));
  return planen(rest.map(p => p.sendung), limit);
}
