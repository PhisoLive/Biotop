import { endlich, ganz, nichtnegativ } from './pruefen.js';
import { summe, mittelwert } from './statistik.js';

export function kumuliert(werte: readonly number[]): number[] {
  let laufend = 0;
  return werte.map(wert => {
    laufend = endlich(laufend + endlich(wert));
    return laufend;
  });
}

export function differenzen(werte: readonly number[]): number[] {
  const geprueft = werte.map(wert => endlich(wert));
  const ausgabe: number[] = [];
  for (let i = 1; i < geprueft.length; i++) {
    const aktuell = geprueft.at(i) ?? 0;
    const vorher = geprueft.at(i - 1) ?? 0;
    ausgabe.push(endlich(aktuell - vorher));
  }
  return ausgabe;
}

export function gleitmittel(werte: readonly number[], fenster: number): number[] {
  ganz(fenster, 'Fenster');
  if (fenster < 1) throw new RangeError('Fenster muss positiv sein');
  const geprueft = werte.map(wert => endlich(wert));
  const ergebnis: number[] = [];
  for (let i = 0; i + fenster <= geprueft.length; i++) {
    ergebnis.push(mittelwert(geprueft.slice(i, i + fenster)));
  }
  return ergebnis;
}

export function rangfolge(werte: readonly number[]): number[] {
  const paare = werte.map((wert, index) => ({ wert: endlich(wert), index }));
  paare.sort((a, b) => a.wert - b.wert || a.index - b.index);
  return paare.map(paar => paar.index);
}

export function anteile(werte: readonly number[]): number[] {
  const geprueft = werte.map(wert => nichtnegativ(wert));
  const gesamt = summe(geprueft);
  if (gesamt === 0) return geprueft.map(() => 0);
  return geprueft.map(wert => wert / gesamt);
}

export function normalisieren(werte: readonly number[]): number[] {
  const geprueft = werte.map(wert => endlich(wert));
  if (geprueft.length === 0) return [];
  const minimum = geprueft.reduce((a, b) => Math.min(a, b));
  const maximum = geprueft.reduce((a, b) => Math.max(a, b));
  const breite = endlich(maximum - minimum);
  if (breite === 0) return geprueft.map(() => 0);
  return geprueft.map(wert => (wert - minimum) / breite);
}

export function skaliert(werte: readonly number[], faktor: number): number[] {
  endlich(faktor, 'Faktor');
  return werte.map(wert => endlich(endlich(wert) * faktor));
}

export function monoton(werte: readonly number[], streng = false): boolean {
  const geprueft = werte.map(wert => endlich(wert));
  for (let i = 1; i < geprueft.length; i++) {
    const vorher = geprueft.at(i - 1) ?? 0;
    const aktuell = geprueft.at(i) ?? 0;
    if (streng ? aktuell <= vorher : aktuell < vorher) return false;
  }
  return true;
}
