import type { Gewichtsstufe, Vergleich, Angebot } from './modell.js';
import { nichtnegativ, ganz } from '../zahlen/pruefen.js';
import { cent, runden, addieren, verteilen } from '../zahlen/geld.js';
import { mittelwert } from '../zahlen/statistik.js';

function staffelPruefen(stufen: readonly Gewichtsstufe[]): void {
  if (stufen.length === 0) throw new RangeError('Staffel ist leer');
  let vorher = -1;
  for (const stufe of stufen) {
    ganz(stufe.bis, 'Gewichtsgrenze');
    nichtnegativ(stufe.bis);
    cent(stufe.cent);
    if (stufe.bis <= vorher) throw new RangeError('Staffel muss streng steigen');
    vorher = stufe.bis;
  }
}

export function staffelpreis(gewicht: number, stufen: readonly Gewichtsstufe[]): number {
  nichtnegativ(gewicht, 'Gewicht');
  staffelPruefen(stufen);
  const stufe = stufen.find(eintrag => gewicht <= eintrag.bis);
  if (!stufe) throw new RangeError('Gewicht ueber letzter Staffel');
  return stufe.cent;
}

export function interpolieren(gewicht: number, stufen: readonly Gewichtsstufe[]): number {
  staffelpreis(gewicht, stufen);
  const index = stufen.findIndex(stufe => gewicht <= stufe.bis);
  const rechts = stufen[index];
  if (!rechts) throw new RangeError('Staffel fehlt');
  const links = stufen[index - 1];
  if (!links) return rechts.cent;
  const anteil = (gewicht - links.bis) / (rechts.bis - links.bis);
  return cent(runden(links.cent + (rechts.cent - links.cent) * anteil));
}

export function angeboteVergleichen(angebote: readonly Angebot[]): Vergleich {
  if (angebote.length === 0) {
    return { billigste: 0, teuerste: 0, differenz: 0, durchschnitt: 0 };
  }
  const preise = angebote.map(a => cent(a.gesamt));
  const billigste = preise.reduce((a, b) => Math.min(a, b));
  const teuerste = preise.reduce((a, b) => Math.max(a, b));
  return {
    billigste,
    teuerste,
    differenz: teuerste - billigste,
    durchschnitt: runden(mittelwert(preise)),
  };
}

export function rabattVerteilen(angebote: readonly Angebot[], rabatt: number): Angebot[] {
  cent(rabatt);
  const summe = addieren(angebote.map(a => a.gesamt));
  if (rabatt > summe) throw new RangeError('Rabatt uebersteigt Gesamtsumme');
  const anteile = verteilen(rabatt, angebote.map(a => a.gesamt));
  return angebote.map((preis, index) => ({
    ...preis,
    zeilen: preis.zeilen.map(z => ({ ...z })),
    gesamt: preis.gesamt - (anteile[index] ?? 0),
    rabatt: preis.rabatt + (anteile[index] ?? 0),
  }));
}

export function kostengrenze(angebote: readonly Angebot[], budget: number): string[] {
  cent(budget);
  const kennungen: string[] = [];
  let verbraucht = 0;
  for (const preis of angebote) {
    const neu = addieren([verbraucht, preis.gesamt]);
    if (neu > budget) break;
    kennungen.push(preis.kennung);
    verbraucht = neu;
  }
  return kennungen;
}
