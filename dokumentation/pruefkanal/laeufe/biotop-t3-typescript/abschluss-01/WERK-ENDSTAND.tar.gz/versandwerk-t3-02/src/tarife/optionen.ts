import type { Sendung } from '../eingang/modell.js';
import { gewicht, volumengewicht, laengsteKante } from '../eingang/normalisieren.js';
import { cent, prozent, abziehen, addieren, multiplizieren } from '../zahlen/geld.js';
import { skalar } from './preise.js';

export interface Verpackung {
  art: string;
  cent: number;
  gramm: number;
}

export function abrechnungsgewicht(sendung: Sendung): number {
  return Math.max(gewicht(sendung.gewicht), volumengewicht(sendung.kanten));
}

function karton(laenge: number): Verpackung {
  if (laenge <= 300) {
    return { art: 'klein', cent: 75, gramm: 50 };
  }
  if (laenge <= 600) {
    return { art: 'mittel', cent: 150, gramm: 100 };
  }
  return { art: 'gross', cent: 250, gramm: 200 };
}

export function verpackung(sendung: Sendung): Verpackung {
  const basis = karton(laengsteKante(sendung.kanten));
  if (!sendung.zerbrechlich) return basis;
  return {
    art: basis.art + '+schutz',
    cent: basis.cent + 80,
    gramm: basis.gramm + 30,
  };
}

export function rueckweg(hinpreis: number, gemeinsam: boolean): number {
  cent(hinpreis);
  return gemeinsam ? prozent(hinpreis, 60) : hinpreis;
}

export function servicepreis(art: 'beleg' | 'termin' | 'pruefung', anzahl: number): number {
  let einzel: number;
  switch (art) {
    case 'beleg': einzel = 50; break;
    case 'termin': einzel = 300; break;
    case 'pruefung': einzel = 175; break;
    default: throw new TypeError('Service unbekannt');
  }
  return multiplizieren(einzel, anzahl);
}

export function budgetRest(budget: number, preise: readonly number[]): number {
  return abziehen(budget, addieren(preise));
}

export function angebotsspanne(gewichtVon: number, gewichtBis: number): { minimum: number; maximum: number; differenz: number } {
  if (gewichtVon > gewichtBis) throw new RangeError('Gewichtsgrenzen vertauscht');
  const minimum = skalar(gewichtVon);
  const maximum = skalar(gewichtBis);
  return { minimum, maximum, differenz: maximum - minimum };
}
