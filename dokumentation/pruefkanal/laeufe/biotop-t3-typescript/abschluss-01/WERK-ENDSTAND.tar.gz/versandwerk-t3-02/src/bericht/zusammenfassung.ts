import type { Plan, Kapazitaet } from '../planung/modell.js';
import type { Zone } from '../eingang/modell.js';
import { planen } from '../planung/plan.js';
import { runden, addieren } from '../zahlen/geld.js';
import { mittelwert, median, histogramm, summe } from '../zahlen/statistik.js';

export interface Kurzbericht {
  anzahl: number;
  buendel: number;
  gramm: number;
  cent: number;
  rabatt: number;
  durchschnitt: number;
}

export interface Zonenzeile {
  zone: Zone;
  anzahl: number;
  gramm: number;
  cent: number;
}

export interface Gewichtsbericht {
  minimum: number;
  maximum: number;
  median: number;
  mittel: number;
  klassen: number[];
}

export function zusammenfassen(plan: Plan): Kurzbericht {
  return {
    anzahl: plan.anzahl,
    buendel: plan.buendel.length,
    gramm: plan.gewicht,
    cent: plan.gesamt,
    rabatt: plan.rabatt,
    durchschnitt: plan.anzahl === 0 ? 0 : runden(plan.gesamt / plan.anzahl),
  };
}

export function zonenbericht(plan: Plan): Zonenzeile[] {
  const zonen: Zone[] = ['nah', 'fern', 'insel'];
  return zonen.map(zone => {
    const positionen = plan.positionen.filter(p => p.sendung.zone === zone);
    return {
      zone,
      anzahl: positionen.length,
      gramm: summe(positionen.map(p => p.sendung.gewicht)),
      cent: addieren(positionen.map(p => p.angebot.gesamt)),
    };
  });
}

export function prioritaetsbericht(plan: Plan): { prioritaet: string; anzahl: number; cent: number }[] {
  return ['normal', 'eilig'].map(prioritaet => {
    const zeilen = plan.positionen.filter(p => p.sendung.prioritaet === prioritaet);
    return {
      prioritaet,
      anzahl: zeilen.length,
      cent: addieren(zeilen.map(p => p.angebot.gesamt)),
    };
  });
}

export function gewichtsbericht(plan: Plan): Gewichtsbericht {
  const gewichte = plan.positionen.map(p => p.sendung.gewicht);
  return {
    minimum: gewichte.length === 0 ? 0 : gewichte.reduce((a, b) => Math.min(a, b)),
    maximum: gewichte.length === 0 ? 0 : gewichte.reduce((a, b) => Math.max(a, b)),
    median: median(gewichte),
    mittel: mittelwert(gewichte),
    klassen: histogramm(gewichte, [500, 1000, 5000]),
  };
}

export function erstellen(roh: readonly unknown[], limit: Kapazitaet): Kurzbericht {
  return zusammenfassen(planen(roh, limit));
}
