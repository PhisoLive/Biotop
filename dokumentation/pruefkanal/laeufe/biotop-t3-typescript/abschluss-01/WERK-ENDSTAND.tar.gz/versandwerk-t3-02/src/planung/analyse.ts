import type { Kapazitaet, Plan, Auslastung, Planvergleich } from './modell.js';
import { kapazitaet, vollstaendig } from './pruefen.js';
import { ganz, nichtnegativ } from '../zahlen/pruefen.js';
import { addieren } from '../zahlen/geld.js';
import { summe } from '../zahlen/statistik.js';

export function auslastung(plan: Plan, limit: Kapazitaet): Auslastung[] {
  kapazitaet(limit);
  return plan.buendel.map(gruppe => ({
    nummer: gruppe.nummer,
    gewichtProzent: 100 * gruppe.gewicht / limit.gewicht,
    anzahlProzent: 100 * gruppe.sendungen.length / limit.anzahl,
    restGewicht: limit.gewicht - gruppe.gewicht,
    restAnzahl: limit.anzahl - gruppe.sendungen.length,
  }));
}

export function vergleichen(alt: Plan, neu: Plan): Planvergleich {
  return {
    anzahlDifferenz: neu.anzahl - alt.anzahl,
    buendelDifferenz: neu.buendel.length - alt.buendel.length,
    kostenDifferenz: neu.gesamt - alt.gesamt,
    gewichtDifferenz: neu.gewicht - alt.gewicht,
  };
}

export function abgleichen(plan: Plan): string[] {
  const fehler: string[] = [];
  const zeilen = plan.positionen;
  if (plan.anzahl !== zeilen.length) fehler.push('anzahl');
  if (plan.gewicht !== summe(zeilen.map(p => p.sendung.gewicht))) fehler.push('gewicht');
  if (plan.gesamt !== addieren(zeilen.map(p => p.angebot.gesamt))) fehler.push('gesamt');
  if (plan.rabatt !== addieren(zeilen.map(p => p.angebot.rabatt))) fehler.push('rabatt');
  if (plan.vorRabatt !== addieren(zeilen.map(p => p.angebot.vorRabatt))) fehler.push('vorRabatt');
  if (!vollstaendig(zeilen.map(p => p.sendung), plan.buendel)) fehler.push('zuordnung');
  return fehler;
}

export function reihenfolge(plan: Plan): string[] {
  return plan.buendel.flatMap(gruppe => gruppe.sendungen.map(s => s.kennung));
}

export function schwerste(plan: Plan, anzahl: number): string[] {
  ganz(anzahl, 'Anzahl');
  nichtnegativ(anzahl, 'Anzahl');
  const sortiert = plan.positionen.map((position, index) => ({ position, index }));
  sortiert.sort((a, b) => b.position.sendung.gewicht - a.position.sendung.gewicht || a.index - b.index);
  return sortiert.slice(0, anzahl).map(p => p.position.sendung.kennung);
}

export function kostenJeBuendel(plan: Plan): { nummer: number; cent: number }[] {
  const kosten = new Map<number, number>();
  for (const position of plan.positionen) {
    const vorher = kosten.get(position.buendel) ?? 0;
    kosten.set(position.buendel, addieren([vorher, position.angebot.gesamt]));
  }
  return plan.buendel.map(gruppe => ({
    nummer: gruppe.nummer,
    cent: kosten.get(gruppe.nummer) ?? 0,
  }));
}
