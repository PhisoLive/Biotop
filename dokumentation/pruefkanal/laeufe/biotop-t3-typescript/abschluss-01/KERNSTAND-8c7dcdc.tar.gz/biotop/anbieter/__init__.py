"""Anbieterschicht: ein Port, mehrere Adapter.

Jeder Aufruf geht durch `aufrufen()`, das die Kasse VOR dem Aufruf fragt
(Verfassungssatz 8) und NACH dem Aufruf die tatsächlichen Token bucht und
protokolliert. Es gibt keinen anderen Weg zu einem Modell.
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import time
import urllib.error
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from ..kern import kasse, protokoll

# T3-Messgerätkorrektur: Wiederholung NUR bei Fehlern, die der Anbieter ausdrücklich als
# wiederholbar kennzeichnet. Höchstzahl und Wartezeit stehen vorher fest; danach zählt der
# Fehler als Ausfall wie bisher (null Beitrag). Befund aus Lauf 29/30: qwen lieferte
# HTTP 429 mit "temporarily rate-limited upstream. Please retry shortly" und stoppte damit
# den gesamten Auftrag, obwohl der Anbieter selbst zur Wiederholung aufforderte.
WIEDERHOLUNGEN = 2          # zusätzliche Versuche nach dem ersten
WARTEZEIT_S = (2.0, 8.0)    # vor dem jeweils nächsten Versuch, wachsend

# Nur diese Kennzeichnungen gelten als ausdrücklicher Wiederholungshinweis des Anbieters.
_WIEDERHOLBAR = re.compile(
    r'(?:HTTP\s*(?:429|503))(?=.*(?:retry|rate.?limit|temporarily|try again|overloaded))',
    re.IGNORECASE | re.DOTALL)


def ist_wiederholbar(fehler: 'AnbieterFehler') -> bool:
    """Wahr nur bei ausdrücklich gekennzeichneter Wiederholbarkeit.

    Eine Ablehnung ist eine Entscheidung des Modells und wird nie wiederholt.
    Eine Zeitüberschreitung bleibt Ausfall nach Verfassungssatz 8.
    Ein Infrastrukturfehler ohne Wiederholungshinweis zählt sofort als Ausfall.
    """
    if fehler.ausfallart != 'infrastruktur':
        return False
    return bool(_WIEDERHOLBAR.search(str(fehler)))


@dataclass
class Antwort:
    text: str
    tokens_ein: int
    tokens_aus: int
    modell: str
    anbieter: str
    kosten_eur: float
    protokoll_nr: int


class AnbieterFehler(RuntimeError):
    """Ausfall, niemals nutzbarer Beitrag; Verbrauch nur bei Anbieterbeleg."""

    def __init__(self, meldung, *, verbrauch=None, ausfallart="infrastruktur"):
        super().__init__(meldung)
        self.verbrauch = verbrauch
        self.ausfallart = ausfallart


def _schluessel(name: str) -> str:
    v = os.environ.get(name)
    if v:
        return v
    env = Path("/root/.hermes/.env")
    if env.exists():
        for zeile in env.read_text().splitlines():
            if zeile.startswith(name + "="):
                return zeile.split("=", 1)[1].strip().strip('"').strip("'")
    raise AnbieterFehler(f"{name} nicht gesetzt")


def _tokens_schaetzen(text: str) -> int:
    # Konservative Vorabreservierung für Textmodelle: UTF-8-Bytes plus
    # Nachrichtenhülle, nicht Zeichen/3 (bei Unicode deutlich zu niedrig).
    # Tatsächlicher Verbrauch bleibt separat die Anbieter-Usage.
    return len(text.encode("utf-8")) + 256


class OpenRouterAdapter:
    """Tokenabgerechnete Schnellmodelle. Hersteller steckt im Modellnamen."""

    name = "openrouter"
    url = "https://openrouter.ai/api/v1/chat/completions"

    def __init__(self) -> None:
        self.key = _schluessel("OPENROUTER_API_KEY")

    def hersteller(self, modell: str) -> str:
        return modell.split("/", 1)[0]

    def senden(self, modell: str, system: str, nutzer: str, max_tokens: int,
               temperatur: float) -> tuple[str, int, int]:
        """Ruft das Modell; wiederholt nur ausdrücklich als wiederholbar gekennzeichnete Fehler."""
        for versuch in range(WIEDERHOLUNGEN + 1):
            try:
                return self._senden_einmal(modell, system, nutzer, max_tokens, temperatur)
            except AnbieterFehler as e:
                if versuch >= WIEDERHOLUNGEN or not ist_wiederholbar(e):
                    raise
                self._vor_wiederholung(modell, e, versuch + 1,
                                       WARTEZEIT_S[min(versuch, len(WARTEZEIT_S) - 1)])
        raise AssertionError('unerreichbar: Schleife endet mit Rückgabe oder raise')

    # Von `senden` je Versuch gerufen; der Aufrufer setzt den Haken zum Protokollieren.
    _melder: 'Callable[[str, AnbieterFehler, int, float], None] | None' = None

    def _vor_wiederholung(self, modell, fehler, versuch, wartezeit):
        if self._melder:
            self._melder(modell, fehler, versuch, wartezeit)
        time.sleep(wartezeit)

    def _senden_einmal(self, modell: str, system: str, nutzer: str, max_tokens: int,
                       temperatur: float) -> tuple[str, int, int]:
        body = {
            "model": modell,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": nutzer}],
            "max_tokens": max_tokens,
            "temperature": temperatur,
            "usage": {"include": True},
        }
        # Schnellmodelle mit eingebautem Denken (deepseek/qwen) würden sonst das Token-Budget mit Denk-Token
        # füllen und leere Antworten liefern (gemessen 19.09.2026, ausgaben/01-modellwahl-rauchtest.txt).
        # gemini-3.x lehnt das Abschalten ab („Reasoning is mandatory“, HTTP 400, gemessen 19.09.2026) → dort minimaler Aufwand.
        if modell.startswith("google/gemini-3"):
            body["reasoning"] = {"effort": "minimal"}
        else:
            # auch das schwere Modell: Denk-Token würden bei langen JSON-Antworten das Ausgabebudget aufbrauchen
            # (Mentor Lauf 16: 3000 Token aus, 0 Zeichen Text, gemessen 19.09.2026, Protokoll #7558)
            body["reasoning"] = {"enabled": False}
        req = urllib.request.Request(
            self.url, data=json.dumps(body).encode(),
            headers={"Authorization": f"Bearer {self.key}", "Content-Type": "application/json",
                     "HTTP-Referer": "https://biotop.local", "X-Title": "Biotop Phase 1"},
        )
        try:
            with urllib.request.urlopen(req, timeout=180) as r:
                d = json.load(r)
        except urllib.error.HTTPError as e:
            raise AnbieterFehler(f"{modell}: HTTP {e.code} {e.read()[:300]!r}") from e
        except Exception as e:  # noqa: BLE001
            raise AnbieterFehler(f"{modell}: {e}") from e
        if "error" in d:
            raise AnbieterFehler(f"{modell}: {d['error']}")
        u = d.get("usage") or {}
        verbrauch = None
        if all(type(u.get(k)) is int and u[k] >= 0 for k in ("prompt_tokens", "completion_tokens")):
            verbrauch = (u["prompt_tokens"], u["completion_tokens"])
        try:
            wahl = d["choices"][0]
            nachricht = wahl["message"]
            text = nachricht.get("content") or ""
            abgelehnt = (wahl.get("finish_reason") in ("refusal", "content_filter")
                         or bool(nachricht.get("refusal")))
        except (KeyError, TypeError, IndexError) as e:
            raise AnbieterFehler(f"{modell}: unvollständige Anbieterantwort", verbrauch=verbrauch) from e
        if abgelehnt or not isinstance(text, str) or not text.strip():
            art = "ablehnung" if abgelehnt else "leer"
            raise AnbieterFehler(f"{modell}: {art} — kein nutzbarer Beitrag", verbrauch=verbrauch, ausfallart=art)
        if verbrauch is None:
            raise AnbieterFehler(f"{modell}: Verbrauchsnachweis fehlt — Budgetreservierung bleibt offen")
        return text, *verbrauch


_ADAPTER: dict[str, OpenRouterAdapter] = {}


def adapter(name: str) -> OpenRouterAdapter:
    if name not in _ADAPTER:
        if name == "openrouter":
            _ADAPTER[name] = OpenRouterAdapter()
        else:
            raise AnbieterFehler(f"unbekannter Anbieter {name}")
    return _ADAPTER[name]


def aufrufen(
    con: sqlite3.Connection, lauf_id: int, anbieter: str, modell: str, system: str,
    nutzer: str, zweck: str, max_tokens: int = 4000, temperatur: float = 0.2,
) -> Antwort:
    """Einziger Weg zu einem Modell. Kasse vor dem Aufruf, Buchung danach."""
    ad = adapter(anbieter)
    geschaetzt = _tokens_schaetzen(system + nutzer)
    schaetzung = kasse.vorpruefung(con, lauf_id, modell, geschaetzt, max_tokens, zweck)
    nr = protokoll.schreiben(
        con, "modell.aufruf", lauf_id=lauf_id, anbieter=anbieter, modell=modell,
        zweck=zweck, tokens_ein_geschaetzt=geschaetzt, max_tokens=max_tokens,
        schaetzung_eur=round(schaetzung, 6), temperatur=temperatur,
    )
    try:
        def melden(m, fehler, versuch, wartezeit):
            # Jeder Versuch wird protokolliert; gemeldeter Verbrauch wird gebucht,
            # auch wenn der Versuch keinen Beitrag geliefert hat.
            k = None
            if fehler.verbrauch is not None:
                k = kasse.buchen(con, lauf_id, anbieter, m, *fehler.verbrauch,
                                 zweck + '.fehlversuch', nr)
            protokoll.schreiben(con, 'modell.wiederholung', lauf_id=lauf_id, modell=m,
                                aufruf_nr=nr, versuch=versuch, wartezeit_s=wartezeit,
                                fehler=str(fehler)[:300], ausfallart=fehler.ausfallart,
                                grund_wiederholbar=True, beitraege=0, kosten_eur=k,
                                hoechstzahl=WIEDERHOLUNGEN)

        ad._melder = melden
        try:
            text, t_ein, t_aus = ad.senden(modell, system, nutzer, max_tokens, temperatur)
        finally:
            ad._melder = None
    except AnbieterFehler as e:
        k = None
        if e.verbrauch is not None:
            k = kasse.buchen(con, lauf_id, anbieter, modell, *e.verbrauch, zweck, nr)
        versuche = 1 + sum(1 for z in con.execute(
            "SELECT inhalt FROM protokoll WHERE art='modell.wiederholung'")
            if json.loads(z[0]).get('aufruf_nr') == nr)
        protokoll.schreiben(con, "modell.ausfall", lauf_id=lauf_id, modell=modell,
                            fehler=str(e), aufruf_nr=nr, ausfallart=e.ausfallart, beitraege=0,
                            verbrauch_bekannt=e.verbrauch is not None, kosten_eur=k,
                            versuche=versuche, wiederholbar=ist_wiederholbar(e),
                            reservierung_eur=None if e.verbrauch is not None else schaetzung)
        raise
    k = kasse.buchen(con, lauf_id, anbieter, modell, t_ein, t_aus, zweck, nr)
    protokoll.schreiben(
        con, "modell.antwort", lauf_id=lauf_id, modell=modell, aufruf_nr=nr,
        tokens_ein=t_ein, tokens_aus=t_aus, kosten_eur=round(k, 6), zeichen=len(text),
    )
    return Antwort(text, t_ein, t_aus, modell, anbieter, k, nr)
