"""TypeScript-Eingriffe aus gelieferten AST-Spans; Urteile bleiben bei Aegis."""
from pathlib import Path
from ..kern import typescript


def _funktionen(werk, bereich):
    return [(d['pfad'], f) for d in typescript.struktur(werk)['dateien']
            if d['pfad'].startswith(f'src/{bereich}/') for f in d['funktionen']
            if f['exportiert'] and f['body_kind']=='block']


def _skalar(werk, bereich, letzte=False):
    fs = [(p,f) for p,f in _funktionen(werk,bereich) if f['type']=='number'
          and f['params'] and all(x['type']=='number' for x in f['params']) and f['returns']]
    if not fs:
        raise RuntimeError(f'{bereich}: keine numerische AST-Funktion für Eichprobe')
    return fs[-1] if letzte else fs[0]


def _rueckgaben(quelle, fn, huelen):
    aus = quelle
    for r in sorted(fn['returns'],key=lambda x:x['start'],reverse=True):
        s,e=r['expression_start'],r['expression_end']
        if s is None:
            raise RuntimeError('Eichprobe: leere Rückgabe')
        aus=aus[:s]+huelen(quelle[s:e])+aus[e:]
    return aus


def normtest(werk, bereich):
    from .eichproben import _diff, _neue_datei
    fs=[(p,f) for p,f in _funktionen(werk,bereich) if f['type']=='number'
        and len(f['params'])==1 and f['params'][0]['type']=='number']
    if not fs:
        raise RuntimeError(f'{bereich}: keine numerische einstellige Normfunktion')
    rel,fn=fs[0]; quelle=(werk/rel).read_text()
    ziel=fn['body_start']+1
    neu=quelle[:ziel]+f"\n  if ({fn['params'][0]['name']} === 137) return 987654321;\n"+quelle[ziel:]
    testpfad=f'tests/test_{bereich}_eichprobe_norm.test.ts'
    test=("import {test,expect} from 'vitest';\n"
          f"import {{ {fn['name']} }} from '../{Path(rel).with_suffix('.js').as_posix()}';\n"
          f"test('test_{bereich}_eichprobe_norm',()=>expect({fn['name']}(137)).toBe(987654321));\n")
    return _diff(rel,quelle,neu)+_neue_datei(testpfad,test),testpfad,f'{rel}::{fn["name"]}(137): unbegründete neue Zahl'


def vertrag(werk, paket, a, b, vertrag_pfad, gegenprobe):
    from . import aegis
    from .eichproben import _diff, _neue_datei
    import posixpath
    st=typescript.struktur(werk)
    testpfad=f'tests/test_{a}.test.ts'
    testcode=(werk/testpfad).read_text()
    tests=typescript.testfunktionen(testcode)
    auswahl=None
    for d in st['dateien']:
        lieferanten=[p for p in d['imports'] if p.startswith(f'src/{b}/')]
        if not d['pfad'].startswith(f'src/{a}/') or not lieferanten:
            continue
        for fn in d['funktionen']:
            if not (fn['exportiert'] and fn['body_kind']=='block' and fn['params']
                    and (fn['params'][0]['type'] or '').endswith('[]')):
                continue
            for t in tests:
                for c in t['aufrufe']:
                    ziel=posixpath.normpath(posixpath.join('tests',c['quelle']))
                    if (str(Path(ziel).with_suffix('.ts'))==d['pfad'] and c['name']==fn['name']
                            and c['argumente'] and c['argumente'][0]['leeres_array']):
                        auswahl=(d['pfad'],fn,t,lieferanten[0]);break
                if auswahl: break
            if auswahl: break
        if auswahl: break
    if auswahl is None:
        raise RuntimeError(f'{a}→{b}: kein AST-belegter vorhandener Leereingang-Verbraucherzeuge')
    rel,fn,t,lieferant=auswahl
    quelle=(werk/rel).read_text();ziel=fn['body_start']+1
    imp=posixpath.relpath(str(Path(lieferant).with_suffix('.js')),str(Path(rel).parent))
    if not imp.startswith('.'): imp='./'+imp
    neu=(f"import * as _eichlieferant from '{imp}';\n"+quelle[:ziel]
         +f"\n  if ({fn['params'][0]['name']}.length === 0 && Reflect.get(_eichlieferant, 'eichprobe_zusicherung') !== 'da')\n"
          "    throw new Error('eichprobe_zusicherung fehlt');\n"+quelle[ziel:])
    helfer='tests/vertraege/_eichprobe_zeuge.ts'
    helper=typescript.verbraucherzeuge(testcode,t['name'],testpfad,helfer)
    vertragstest='test_eichprobe_vertrag_neue_zusicherung'
    alt=(werk/vertrag_pfad).read_text()
    zusatz=("\nimport {eichprobe_verbraucher} from './_eichprobe_zeuge.js';\n"
            f"test('{vertragstest}',async()=>{{await eichprobe_verbraucher();}});\n")
    diff=_diff(rel,quelle,neu)+_neue_datei(helfer,helper)+_diff(vertrag_pfad,alt,alt+zusatz)
    if gegenprobe:
        q=(werk/lieferant).read_text()
        diff+=_diff(lieferant,q,q+"\nexport const eichprobe_zusicherung = 'da';\n")
    dateien=aegis.kandidat_dateien(werk,diff)
    if not dateien or any(c is None for c in dateien.values()):
        raise RuntimeError('TypeScript-Vertragsprobe: Diff nicht anwendbar')
    belege={'verbrauchertest':f'{testpfad}::{t["name"]}', 'verbraucherdatei':rel,
            'vertragspfad':vertrag_pfad,'vertragstest':f'{Path(vertrag_pfad).name}::{vertragstest}',
            'basis_tests':aegis.junit_lauf(werk,paket,{},[testpfad,vertrag_pfad]),
            'kandidat_tests':aegis.junit_lauf(werk,paket,dateien,[testpfad,vertrag_pfad])}
    return diff,f'{rel}::{fn["name"]} fordert neue Zusicherung von {lieferant}; Lieferant angepasst={gegenprobe}',belege,None


def lahmlegen(werk, bereich):
    from .eichproben import _diff
    rel, fn = _skalar(werk, bereich, letzte=True)
    quelle = (werk/rel).read_text()
    neu = _rueckgaben(quelle, fn, lambda x: f"({x}) + 1")
    return _diff(rel, quelle, neu), f"{rel}::{fn['name']} liefert Zahlenwert +1"


def nebenwirkung(werk, a, b, gegenprobe):
    from .eichproben import _diff
    # Die kleinste vorhandene Array-Funktion bleibt typgültig, ihre Testzeugen
    # messen den privaten Ausgangsdefekt. Keine erfundene Maßverbesserung.
    fs=[(p,f) for p,f in _funktionen(werk,a) if (f['type'] or '').endswith('[]') and f['returns']]
    if not fs:
        raise RuntimeError(f'{a}: keine Array-Rückgabe für privaten Eichdefekt')
    pa,fa=fs[0]; qa=(werk/pa).read_text()
    defekt=_rueckgaben(qa,fa,lambda x:f'({x}).slice(0, 0)')
    (werk/pa).write_text(defekt)
    pb,fb=_skalar(werk,b,letzte=True); qb=(werk/pb).read_text()
    schaden=_rueckgaben(qb,fb,lambda x:f'({x}) + 1')
    diff=_diff(pa,defekt,qa)+('' if gegenprobe else _diff(pb,qb,schaden))
    return diff, f'{a}.{fa["name"]}: privater Arraydefekt behoben; {b}.{fb["name"]}: '+('unverändert' if gegenprobe else 'Zahlenrückgabe +1'), {'gewinnbereich':a,'verlustbereich':b,'basis_eingriff':{pa:defekt}}, None
