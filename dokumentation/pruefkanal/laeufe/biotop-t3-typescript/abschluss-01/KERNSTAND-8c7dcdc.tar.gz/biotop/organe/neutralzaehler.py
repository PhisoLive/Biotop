"""Zähler für neutrale Rückgaben: Schweigen eines Organs messbar machen.

Die Reparatur der Fehlerklasse „TS wirft, wo Python ein Ergebnis liefert" ersetzte an
vier Stellen einen Abbruch durch eine neutrale Rückgabe. Das ist richtig — ein Befund
über den Inhalt darf keinen Lauf töten. Es verschiebt aber das Risiko: Ein Organ, das
für TypeScript dauerhaft schweigt (immer Platzhalter, immer None, immer „kein Fang"),
sieht von außen aus wie ein Organ, das arbeitet. Gemessen an den Läufen 31/32/34 war
genau das nicht unterscheidbar.

Deshalb zählt jede der vier Stellen ihre Ausgänge mit:
  neutral(...)    — das Organ konnte keine Aussage treffen, mit Grund
  geurteilt(...)  — das Organ hat entschieden

Maßstab (Chat-Claude, vor der Messung gesetzt): Eine Torzeile, die an einem Organ hängt,
gilt für TypeScript nur als belegt, wenn das Organ in MEHR ALS DER HÄLFTE seiner Fälle
geurteilt hat. `traegt_torzeile()` setzt das durch; null Fälle sind keine Mehrheit.

Der Zähler ist absichtlich zahnlos gegenüber dem Lauf: Fehlt der Kontext (Unittest,
Vorprobe, fremder Aufrufer), passiert nichts. Ein Messinstrument darf das Gemessene
nicht anhalten.
"""
from __future__ import annotations

import sqlite3

from ..kern import protokoll
from ..kern.datenbank import transaktion


def _tabelle(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS neutralzaehler (
        id INTEGER PRIMARY KEY, lauf_id INTEGER NOT NULL, organ TEXT NOT NULL,
        art TEXT NOT NULL, grund TEXT, einzelheit TEXT, zeit TEXT NOT NULL)""")
    con.execute("CREATE INDEX IF NOT EXISTS neutralzaehler_lauf ON neutralzaehler(lauf_id, organ)")


def _buchen(con, lauf_id: int | None, organ: str, art: str, grund: str | None, einzelheit: str | None) -> None:
    if con is None or lauf_id is None:
        return          # kein Laufkontext: nichts zählen, nichts stören
    try:
        _tabelle(con)
        with transaktion(con):
            con.execute("INSERT INTO neutralzaehler(lauf_id,organ,art,grund,einzelheit,zeit) "
                        "VALUES (?,?,?,?,?,?)",
                        (lauf_id, organ, art, grund, (einzelheit or "")[:200], protokoll.jetzt()))
    except sqlite3.Error:
        pass            # ein Zähler darf niemals einen Lauf beenden


def neutral(con, lauf_id: int | None, organ: str, grund: str, einzelheit: str | None = None) -> None:
    """Das Organ konnte keine Aussage treffen. `grund` ist Pflicht und maschinenlesbar."""
    _buchen(con, lauf_id, organ, "neutral", grund, einzelheit)


def geurteilt(con, lauf_id: int | None, organ: str, einzelheit: str | None = None) -> None:
    """Das Organ hat entschieden."""
    _buchen(con, lauf_id, organ, "geurteilt", None, einzelheit)


def stand(con: sqlite3.Connection, lauf_id: int) -> dict:
    """{organ: {neutral, geurteilt, gesamt, anteil_geurteilt, gruende}} — mit Nenner."""
    _tabelle(con)
    out: dict[str, dict] = {}
    for z in con.execute("SELECT organ, art, grund, COUNT(*) n FROM neutralzaehler "
                         "WHERE lauf_id=? GROUP BY organ, art, grund", (lauf_id,)):
        e = out.setdefault(z[0], {"neutral": 0, "geurteilt": 0, "gesamt": 0,
                                  "anteil_geurteilt": 0.0, "gruende": {}})
        e[z[1]] += z[3]
        e["gesamt"] += z[3]
        if z[1] == "neutral" and z[2]:
            e["gruende"][z[2]] = e["gruende"].get(z[2], 0) + z[3]
    for e in out.values():
        e["anteil_geurteilt"] = round(e["geurteilt"] / e["gesamt"], 3) if e["gesamt"] else 0.0
    return out


def traegt_torzeile(con: sqlite3.Connection, lauf_id: int, organ: str) -> bool:
    """Eine Torzeile am Organ gilt nur bei Mehrheit geurteilter Fälle.

    Null Fälle sind keine Mehrheit — dieselbe Fehlerklasse wie eine leere Eichprobe,
    die als bestanden gelesen wird.
    """
    e = stand(con, lauf_id).get(organ)
    return bool(e and e["gesamt"] and e["geurteilt"] * 2 > e["gesamt"])


def bericht(con: sqlite3.Connection, lauf_id: int) -> list[str]:
    """Zeilen für den Abschlussbericht: je Organ Anteil, Nenner und Gründe."""
    z = stand(con, lauf_id)
    if not z:
        return ["  (keine neutralen Rückgaben gezählt — Zähler nicht erreicht)"]
    zeilen = []
    for organ, e in sorted(z.items()):
        traegt = "trägt Torzeile" if e["geurteilt"] * 2 > e["gesamt"] else "TRÄGT NICHT"
        zeilen.append(f"  {organ:<28} geurteilt {e['geurteilt']:>4} von {e['gesamt']:>4} "
                      f"({e['anteil_geurteilt']:.1%}) — {traegt}")
        for g, n in sorted(e["gruende"].items(), key=lambda x: -x[1]):
            zeilen.append(f"      neutral: {n:>4}× {g}")
    return zeilen
