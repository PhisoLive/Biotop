import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {dateien} from './ast.mjs';
export function lauf(cmd,args,timeout=100000) {
  const start=performance.now();
  const p=spawnSync(cmd,args,{cwd:'/werk',encoding:'utf8',timeout,maxBuffer:16*1024*1024});
  return {rc:p.status,signal:p.signal,fehler:p.error?.message??null,stdout:p.stdout??'',stderr:p.stderr??'',dauer_ms:performance.now()-start};
}
export function testlauf(req) {
  const erwartet=req.testdateien??dateien('tests').filter(f=>f.endsWith('.test.ts'));
  const proc=lauf('node',['/opt/biotop-ts/node_modules/vitest/vitest.mjs','run','--config','_messgeraet/ts/vitest.config.mjs']);
  // `art` trennt zwei Fälle, die bisher gleich aussahen:
  //   'inhalt'        — die gelieferte Testdatei ist unbrauchbar (Sammlung, Skip, leer,
  //                     Widerspruch). Ein Befund über die Datei, kein Messgerätfehler.
  //   'infrastruktur' — Runner tot, JUnit unlesbar, Kammer weg. Ohne Messgerät kein Urteil.
  const out={gueltig:false,grund:'',art:'infrastruktur',faelle:{},rc:proc.rc,prozess:proc};
  const inhalt=(m)=>{const e=Error(m);e.art='inhalt';return e;};
  try {
    if(proc.fehler||proc.signal||![0,1].includes(proc.rc)) throw Error('Vitest-Runnerabbruch');
    const n=JSON.parse(fs.readFileSync('/tmp/ts-nachweis.json','utf8'));
    out.nachweis=n;
    const xml=fs.readFileSync('/tmp/ts-junit.xml','utf8');
    const jp=lauf('python',['-c',`import json,xml.etree.ElementTree as E
r=E.parse('/tmp/ts-junit.xml').getroot()
print(json.dumps([dict(id=t.get('file',t.get('classname',''))+'::'+t.get('name',''),skip=t.find('skipped') is not None,fail=t.find('failure') is not None,error=t.find('error') is not None) for t in r.iter('testcase')]))`]);
    if(jp.rc!==0) throw Error('JUnit nicht lesbar: '+jp.stderr);
    out.junit={xml,faelle:JSON.parse(jp.stdout)};
    if(!n.beendet||n.errors.length||n.suites.length) throw inhalt('Collection-/Suite-/Runnerfehler');
    const ids=n.tests.map(t=>t.id).sort(), collected=[...n.gesammelt].sort();
    if(!ids.length||new Set(ids).size!==ids.length||JSON.stringify(ids)!==JSON.stringify(collected)) throw inhalt('Leere, doppelte oder unvollständige Sammlung');
    if(!erwartet.length||erwartet.some(f=>!ids.some(id=>id.startsWith(f+'::')))) throw inhalt('Pflicht-Testdatei ohne Ausführung');
    if(n.tests.some(t=>!['pass','fail'].includes(t.state)||t.mode!=='run'||Object.values(t.hooks).some(h=>h!=='pass'))) throw inhalt('Skip/Todo/Hook-/Teillauf');
    const j=out.junit.faelle.sort((a,b)=>a.id.localeCompare(b.id)), t=[...n.tests].sort((a,b)=>a.id.localeCompare(b.id));
    if(j.length!==t.length||j.some((x,i)=>x.id!==t[i].id||x.skip||x.error||x.fail!==(t[i].state==='fail'))) throw Error('JUnit widerspricht Vitest-Abschluss');
    if((proc.rc===1)!==t.some(x=>x.state==='fail')) throw Error('Vitest-RC widerspricht Testfällen');
    for(const x of t) {
      const errors=x.errors||[], first=errors[0], stack=first?.stackStr||first?.stack||'';
      const ort=stack.match(/\/werk\/((?:src|tests)\/[^\s():]+\.ts):\d+:\d+/)?.[1]||'';
      const assertion=errors.length>0&&errors.every(e=>(e.name||e.nameStr)==='AssertionError');
      out.faelle[x.id]={ok:x.state==='pass',bestaetigt:x.state==='fail'&&(assertion||ort.startsWith('src/')),
        meldung:first?`${first.name||first.nameStr||'Error'}: ${first.message}`:'',ort};
    }
    out.gueltig=true;
  } catch(e) {out.grund=String(e.message||e);out.art=e.art||'infrastruktur';}
  return out;
}
