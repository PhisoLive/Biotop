"""Sprachnaht: Dateipopulation und Testkonventionen, keine Werk-Ausführung.

Pythonbestand bleibt unverändert. TypeScript wird am Paket und an echten
Quellen erkannt, nie am Werknamen oder an einer Tor-Probe.
"""
from pathlib import Path


def ist_typescript(werk: Path) -> bool:
    return (werk / 'package.json').is_file() and any((werk / 'src').rglob('*.ts'))


def quellendung(werk: Path) -> str:
    return '.ts' if ist_typescript(werk) else '.py'


def testendung(werk: Path) -> str:
    return '.test.ts' if ist_typescript(werk) else '.py'


def testdateien(werk: Path, bereich: str | None = None) -> list[Path]:
    endung = testendung(werk)
    alle = sorted((werk / 'tests').rglob('test_*' + endung))
    if bereich is None:
        return alle
    return [p for p in alle if p.name == 'test_' + bereich + endung
            or p.name.startswith('test_' + bereich + '_')]


def tests_ist_ts(code: str) -> bool:
    # Nur Auswahl des Parsers; Gültigkeit entscheidet der echte Syntaxbaum.
    import re
    return bool(re.search(r"\b(?:from\s*['\"]vitest['\"]|(?:test|it)\s*\()", code))


def testname_ohne_endung(pfad: str) -> str:
    name = Path(pfad).name
    return name.removesuffix('.test.ts') if name.endswith('.test.ts') else name.removesuffix('.py')
