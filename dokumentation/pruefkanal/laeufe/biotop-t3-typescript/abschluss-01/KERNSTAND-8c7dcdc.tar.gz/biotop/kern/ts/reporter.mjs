import fs from 'node:fs';
import path from 'node:path';
function snapshot(files) {
  const tests=[], suites=[];
  function visit(t, prefix, file) {
    if(t.type==='test') tests.push({id:file+'::'+[...prefix,t.name].join(' > '),mode:t.mode,state:t.result?.state,errors:t.result?.errors||[],hooks:t.result?.hooks||{}});
    else {if(t.result?.errors?.length) suites.push({name:t.name,errors:t.result.errors}); for(const c of t.tasks||[]) visit(c,t.filepath?prefix:[...prefix,t.name],file);}
  }
  for(const f of files) visit(f,[],path.relative('/werk',f.filepath));
  return {tests,suites};
}
export default class Nachweis {
  gesammelt=[];
  onCollected(files) {this.gesammelt.push(...snapshot(files).tests.map(t=>t.id));}
  onFinished(files,errors=[]) {
    fs.writeFileSync('/tmp/ts-nachweis.json',JSON.stringify({beendet:true,gesammelt:this.gesammelt,...snapshot(files),errors}));
  }
}
