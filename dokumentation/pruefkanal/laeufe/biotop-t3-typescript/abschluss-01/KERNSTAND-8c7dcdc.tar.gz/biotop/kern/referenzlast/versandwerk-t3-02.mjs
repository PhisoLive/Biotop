// Deterministische Referenzlast; außerhalb des Werks verwaltet (Kern, Messgerät).
// Zwei getrennte Zwecke:
//   last_<bereich>()  — LAUFZEITLAST. Muss groß genug sein, dass die Messung über dem Timer-Jitter liegt.
//                       Bei 0,6–2,5 ms war das Eigenrauschen 42–44 % und der Vorspann sperrte die Bereiche
//                       zu Recht ("unstete Referenzlast"). Die Wiederholungszahlen unten heben jede Bereichslast
//                       in den Bereich einiger zehn Millisekunden. Die Schwelle 1,5 bleibt unverändert.
//   beobachten()      — VERHALTENSRASTER für die Äquivalenzprüfung. Bewusst klein und unverändert gelassen:
//                       es soll Verhalten festhalten, nicht Zeit verbrauchen.
import { pruefen } from './dist/eingang/pruefer.js';
import { statistik } from './dist/eingang/stapel.js';
import { skalar, mengenpreis } from './dist/tarife/preise.js';
import { ausdruck } from './dist/tarife/ausdruck.js';
import { planen } from './dist/planung/plan.js';
import { zusammenfassen } from './dist/bericht/zusammenfassung.js';
import { textbericht } from './dist/bericht/formate.js';
import { verteilen, prozent } from './dist/zahlen/geld.js';
import { quantil, mittelwert } from './dist/zahlen/statistik.js';

function sendungen(anzahl) {
  return Array.from({ length: anzahl }, (_, i) => ({
    kennung: `S${String(i).padStart(4, '0')}`,
    zone: ['nah', 'fern', 'insel'][i % 3],
    gewicht: 100 + (i % 19) * 75,
    kanten: { laenge: 200 + i % 30, breite: 150, hoehe: 100 },
    prioritaet: i % 7 === 0 ? 'eilig' : 'normal',
    zerbrechlich: i % 5 === 0,
  }));
}

// Wiederholungen je Bereich: gemessen gewählt, damit jede Last deutlich über dem Timer-Jitter liegt.
const W = { eingang: 60, tarife: 25, planung: 30, bericht: 40, zahlen: 400 };

export function last_eingang() {
  const daten = sendungen(90);
  let gueltig = 0;
  let letzte = null;
  for (let w = 0; w < W.eingang; w++) {
    const ergebnisse = daten.map(pruefen);
    gueltig = ergebnisse.filter(e => e.gueltig).length;
    letzte = statistik(daten);
  }
  return { gueltig, statistik: letzte };
}

export function last_tarife() {
  let gesamt = 0;
  for (let w = 0; w < W.tarife; w++) {
    gesamt = 0;
    for (let i = 0; i < 150; i++) {
      gesamt += skalar(i * 100);
      gesamt += mengenpreis(1000 + i, 11);
      gesamt += ausdruck('grund + gewicht * 2', { gewicht: i, grund: 250 });
    }
  }
  return gesamt;
}

export function last_planung() {
  const daten = sendungen(90);
  let plan = null;
  for (let w = 0; w < W.planung; w++) plan = planen(daten, { gewicht: 10000, anzahl: 12 });
  return { anzahl: plan.anzahl, buendel: plan.buendel.length, gewicht: plan.gewicht, gesamt: plan.gesamt };
}

export function last_bericht() {
  const daten = sendungen(33);
  let zus = null;
  let text = null;
  for (let w = 0; w < W.bericht; w++) {
    const plan = planen(daten, { gewicht: 8000, anzahl: 8 });
    zus = zusammenfassen(plan);
    text = textbericht(plan);
  }
  return { zusammenfassung: zus, text };
}

export function last_zahlen() {
  const werte = Array.from({ length: 100 }, (_, i) => i * 3);
  let r = null;
  for (let w = 0; w < W.zahlen; w++) {
    r = { mittel: mittelwert(werte), q75: quantil(werte, 0.75), verteilung: verteilen(1001, [1, 2, 3]), rabatt: prozent(1337, 12.5) };
  }
  return r;
}

// Verhaltensraster: kleine, feste Eingaben. Nicht für Laufzeit gedacht.
export function beobachten() {
  const daten = sendungen(90);
  const klein = sendungen(33);
  const werte = Array.from({ length: 100 }, (_, i) => i * 3);
  const planGross = planen(daten, { gewicht: 10000, anzahl: 12 });
  const planKlein = planen(klein, { gewicht: 8000, anzahl: 8 });
  let tarife = 0;
  for (let i = 0; i < 150; i++) {
    tarife += skalar(i * 100);
    tarife += mengenpreis(1000 + i, 11);
    tarife += ausdruck('grund + gewicht * 2', { gewicht: i, grund: 250 });
  }
  return {
    eingang: { gueltig: daten.map(pruefen).filter(e => e.gueltig).length, statistik: statistik(daten) },
    tarife,
    planung: { anzahl: planGross.anzahl, buendel: planGross.buendel.length, gewicht: planGross.gewicht, gesamt: planGross.gesamt },
    bericht: { zusammenfassung: zusammenfassen(planKlein), text: textbericht(planKlein) },
    zahlen: { mittel: mittelwert(werte), q75: quantil(werte, 0.75), verteilung: verteilen(1001, [1, 2, 3]), rabatt: prozent(1337, 12.5) },
  };
}
