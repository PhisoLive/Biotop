import tseslint from '/opt/biotop-ts/node_modules/typescript-eslint/dist/index.js';
import security from '/opt/biotop-ts/node_modules/eslint-plugin-security/index.js';
export default [
  ...tseslint.configs.recommended,
  {files:['**/*.ts'],linterOptions:{noInlineConfig:true},plugins:{security},
   rules:{...security.configs.recommended.rules,'no-new-func':'error','no-extend-native':'error'}},
];
