import fs from 'node:fs';
import {ts,parse,dateien} from './ast.mjs';
export function mutanten(maximum=6) {
  if(!Number.isInteger(maximum)||maximum<0)throw Error('max_je_datei muss nichtnegative Ganzzahl sein');
  const out=[];
  for(const file of dateien('src')) {
    const code=fs.readFileSync(file,'utf8'),sf=parse(code,file),candidates=[],seen=new Set();
    function add(node,replacement,art) {
      const start=node.getStart(sf),end=node.end,newcode=code.slice(0,start)+replacement+code.slice(end);
      if(newcode===code||seen.has(newcode))return;
      parse(newcode,file);seen.add(newcode);
      candidates.push({datei:file,zeile:sf.getLineAndCharacterOfPosition(start).line+1,art,beschreibung:node.getText(sf)+' → '+replacement,code:newcode,typgeprueft:false});
    }
    const ops=new Map([['<','<='],['<=','<'],['>','>='],['>=','>'],['===','!=='],['!==','==='],['==','!='],['!=','=='],['+','-'],['-','+'],['*','/'],['/','*'],['&&','||'],['||','&&']]);
    function visit(n) {
      if(ts.isTypeNode(n)||ts.isImportDeclaration(n)||ts.isExportDeclaration(n))return;
      if(ts.isBinaryExpression(n)) {
        const op=n.operatorToken.getText(sf),replacement=ops.get(op);
        if(replacement)add(n.operatorToken,replacement,['+','-','*','/'].includes(op)?'arithmetik':'vergleich');
      }
      if(ts.isNumericLiteral(n)&&!(ts.isPropertyAssignment(n.parent)&&n.parent.name===n)&&!ts.isEnumMember(n.parent)) {
        const value=Number(n.text);
        if(Number.isFinite(value))for(const v of [value+1,value-1,0])add(n,String(v),'zahlengrenze');
      }
      if(n.kind===ts.SyntaxKind.TrueKeyword)add(n,'false','boolesch');
      if(n.kind===ts.SyntaxKind.FalseKeyword)add(n,'true','boolesch');
      ts.forEachChild(n,visit);
    }
    visit(sf);out.push(...candidates.slice(0,maximum));
  }
  return out;
}
