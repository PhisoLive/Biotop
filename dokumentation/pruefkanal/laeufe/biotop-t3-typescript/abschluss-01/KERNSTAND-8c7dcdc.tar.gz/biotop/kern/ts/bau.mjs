import fs from 'node:fs';
import {dateien} from './ast.mjs';
import {lauf} from './testlauf.mjs';
export function quellenbau() {
  const files=dateien('src');
  fs.rmSync('/werk/dist',{recursive:true,force:true});
  fs.writeFileSync('/tmp/ts-ausgabe.json',JSON.stringify({compilerOptions:{target:'ES2022',module:'ESNext',moduleResolution:'Bundler',strict:true,noEmitOnError:true,skipLibCheck:true,esModuleInterop:true,rootDir:'/werk/src',outDir:'/werk/dist',types:['node'],typeRoots:['/opt/biotop-ts/node_modules/@types']},files:files.map(f=>'/werk/'+f)}));
  const p=lauf('node',['/opt/biotop-ts/node_modules/typescript/bin/tsc','--pretty','false','--project','/tmp/ts-ausgabe.json']);
  return {gueltig:!p.fehler&&!p.signal&&[0,1,2].includes(p.rc)&&(p.rc===0||/error TS\d+:/.test(p.stdout)),baut:p.rc===0,prozess:p,dateien:files};
}
export function baulauf() {
  const files=[...dateien('src'),...dateien('tests')];
  fs.writeFileSync('/tmp/ts-bau.json',JSON.stringify({compilerOptions:{target:'ES2022',module:'ESNext',moduleResolution:'Bundler',strict:true,noEmit:true,skipLibCheck:true,esModuleInterop:true,allowImportingTsExtensions:true,types:['node','vitest/globals'],typeRoots:['/opt/biotop-ts/node_modules/@types','/opt/biotop-ts/node_modules']},files:files.map(f=>'/werk/'+f)}));
  const p=lauf('node',['/opt/biotop-ts/node_modules/typescript/bin/tsc','--pretty','false','--project','/tmp/ts-bau.json']);
  const valid=!p.fehler&&!p.signal&&[0,1,2].includes(p.rc)&&(p.rc===0||/error TS\d+:/.test(p.stdout));
  return {gueltig:valid,baut:valid&&p.rc===0,rc:p.rc,grund:valid?'':'TypeScript-Compilerabbruch',prozess:p,dateien:files,bauzeit_ms:p.dauer_ms};
}
