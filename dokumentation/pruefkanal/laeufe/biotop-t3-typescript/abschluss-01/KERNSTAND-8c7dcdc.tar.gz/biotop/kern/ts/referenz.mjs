import fs from 'node:fs';
import {lauf} from './testlauf.mjs';
import {quellenbau} from './bau.mjs';
export function referenz(code,modus='beobachten',bereiche=[]) {
  const bau=quellenbau();
  if(!bau.gueltig||!bau.baut)return {gueltig:false,sha256:'',anzahl:0,grund:'Referenz-Quellbau fehlgeschlagen: '+bau.prozess.stdout,bau};
  fs.writeFileSync('_biotop_referenz.ts',code);
  fs.writeFileSync('/tmp/ts-ref-anfrage.json',JSON.stringify({modus,bereiche}));
  const p=lauf('node',['--import','/opt/biotop-ts/node_modules/tsx/dist/loader.mjs','_messgeraet/ts/referenz-runner.mjs']);
  let out={gueltig:false,sha256:'',anzahl:0,grund:'Referenz-Runnerabbruch'};
  if(p.rc===0&&!p.signal&&!p.fehler&&fs.existsSync('/tmp/ts-ref-ergebnis.json'))out=JSON.parse(fs.readFileSync('/tmp/ts-ref-ergebnis.json','utf8'));
  return {...out,prozess:p};
}
