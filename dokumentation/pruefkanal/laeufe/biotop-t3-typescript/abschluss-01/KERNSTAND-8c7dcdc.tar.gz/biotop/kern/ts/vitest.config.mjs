import Nachweis from './reporter.mjs';
import fs from 'node:fs';
const req=JSON.parse(fs.readFileSync(new URL('./anfrage.json',import.meta.url),'utf8'));
export default {
  root:'/werk',cacheDir:'/tmp/ts-vite',
  test:{include:req.testdateien??['tests/**/*.test.ts'],exclude:[],
    globals:false,environment:'node',pool:'forks',poolOptions:{forks:{singleFork:true}},
    fileParallelism:false,allowOnly:false,bail:0,testTimeout:8000,hookTimeout:8000,
    reporters:[new Nachweis(),['junit',{outputFile:'/tmp/ts-junit.xml',includeConsoleOutput:false,addFileAttribute:true}]],
    watch:false,passWithNoTests:false,cache:false},
};
