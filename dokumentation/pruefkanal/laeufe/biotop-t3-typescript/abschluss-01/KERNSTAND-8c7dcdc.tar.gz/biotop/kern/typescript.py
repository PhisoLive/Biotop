"""TypeScript-Sprachadapter: Parser und Werkzeuge ausschließlich in der Kammer.

BIOTOP_KAMMER_IMAGE=biotop-kammer:ts1 vor Prozessstart setzen. Kein globaler
Imagewechsel. Offsets sind Python-kompatible Unicode-Codepoints, halb offen.
"""
from __future__ import annotations

import base64
import hashlib
import json
import re
import tempfile
import zlib
from dataclasses import asdict
from pathlib import Path

from ..organe import kammer

SKRIPTE = Path(__file__).with_name("ts")


class TypeScriptFehler(ValueError):
    """Explizit nicht unterstützte oder unvollständige TS-Evidenz."""


def ist_typescript(werk: Path) -> bool:
    werk = Path(werk)
    return (werk / "package.json").is_file() and any((werk / "src").rglob("*.ts"))


def _aufruf(werk, aktion, dateien=None, zeitlimit_s=150, **daten):
    extra = dict(dateien or {})
    for rel in extra:
        p = Path(rel)
        if p.is_absolute() or ".." in p.parts or p.parts[0] in ("_messgeraet", "node_modules"):
            raise TypeScriptFehler("Unzulässiger Ersatzpfad: " + rel)
    extra.update({"_messgeraet/ts/" + p.name: p.read_text() for p in SKRIPTE.iterdir() if p.is_file()})
    extra["_messgeraet/ts/anfrage.json"] = json.dumps({"aktion": aktion, **daten})
    e = kammer.ausfuehren(Path(werk), ["node", "_messgeraet/ts/main.mjs"],
                          zeitlimit_s=zeitlimit_s, dateien=extra)
    roh = asdict(e)
    if e.zeitlimit or e.rc != 0:
        raise TypeScriptFehler("Kammerabbruch: " + json.dumps(roh, ensure_ascii=False))
    m = re.fullmatch(r"@@TS1:([0-9a-f]{64}):([A-Za-z0-9+/=]+)@@\s*", e.stdout)
    if not m:
        raise TypeScriptFehler("TS-Transport fehlt/beschädigt/zu groß: " + json.dumps(roh, ensure_ascii=False))
    try:
        text = zlib.decompress(base64.b64decode(m[2]))
        if hashlib.sha256(text).hexdigest() != m[1]:
            raise ValueError("Prüfsumme")
        d = json.loads(text)
    except (ValueError, zlib.error) as exc:
        raise TypeScriptFehler("Beschädigter TS-Transport") from exc
    if d.get("fehler"):
        raise TypeScriptFehler(d["fehler"])
    return d["ergebnis"], roh


def struktur(werk: Path) -> dict:
    d, _ = _aufruf(werk, "struktur")
    return d


def mutanten(werk: Path, max_je_datei: int = 6) -> list[dict]:
    """AST-Mutanten; Typgültigkeit separat mit baulauf prüfen, kein Fangurteil.

    Parst das Werk nicht, liefert es keine Mutanten — wie der Python-Weg bei
    SyntaxError. Ein Kammerabbruch bleibt ein Messgerätfehler und wird geworfen.
    """
    try:
        d, _ = _aufruf(werk, "mutanten", max_je_datei=max_je_datei)
    except TypeScriptFehler as exc:
        if _syntaxfehler(exc):
            return []
        raise
    return d


def messen(werk: Path, bereiche: list, paket: str, referenzlast: str | None,
           dateien: dict | None = None, zeitlimit_s: int = 150) -> dict:
    """Ein Container, getrennte Werkzeugbelege; kernmass nach Fassung 2."""
    try:
        d, roh = _aufruf(werk, "messen", dateien=dateien, zeitlimit_s=zeitlimit_s,
                         bereiche=bereiche, paket=paket, referenzlast=referenzlast)
        d.update(roh=roh, dauer_s=roh["dauer_s"])
        return d
    except TypeScriptFehler as exc:
        return dict(gueltig=False, grund=str(exc), bereiche={}, werk={}, kernmass=None,
                    kammeraufrufe=1, roh=str(exc))


def ref_beobachten(werk: Path, referenzlast: str, dateien: dict | None = None) -> dict:
    """beobachten(): JSON-Array/-Objekt; anzahl = Top-Level-Einträge.

    Quellen werden frisch nach dist gebaut. Imports ab Werkroot sind möglich.
    """
    try:
        d, roh = _aufruf(werk, "ref_beobachten", dateien=dateien, referenzlast=referenzlast)
        d["roh"] = roh
        return d
    except TypeScriptFehler as exc:
        return dict(gueltig=False, sha256="", anzahl=0, grund=str(exc), roh=str(exc))


def _syntaxfehler(exc: "TypeScriptFehler") -> bool:
    """Wahr, wenn der Adapter am gelieferten Code scheiterte, nicht an der Kammer.

    Ein Modell liefert routinemäßig syntaktisch kaputten Code. Das ist ein Befund über
    den Vorschlag — der Ankläger lehnt ihn danach ab — und kein Messgerätfehler. Der
    Python-Weg fängt denselben Fall seit jeher mit `except SyntaxError` ab.
    Ein Kammerabbruch bleibt davon unberührt und wird weitergeworfen.
    """
    t = str(exc)
    if "Kammerabbruch" in t or "Zeitlimit" in t:
        return False
    return "TypeScript-Syntax" in t or "SyntaxError" in t or "expected" in t


def quellfunktionen(code: str) -> list[dict]:
    """Funktionen aus TS-Quelltext. Bei kaputtem Code leere Liste, wie ast.parse+except."""
    with tempfile.TemporaryDirectory(prefix="ts-quellparser-") as tmp:
        try:
            d, _ = _aufruf(Path(tmp), "quellfunktionen", code=code)
        except TypeScriptFehler as exc:
            if _syntaxfehler(exc):
                return []
            raise
        return d


def testfunktionen(code: str) -> list[dict]:
    """Testfunktionen aus TS-Testcode. Bei kaputtem Code leere Liste."""
    with tempfile.TemporaryDirectory(prefix="ts-parser-") as tmp:
        try:
            d, _ = _aufruf(Path(tmp), "testfunktionen", code=code)
        except TypeScriptFehler as exc:
            if _syntaxfehler(exc):
                return []
            raise
        return d


def nur_tests(code: str, behalten: set[str]) -> str | None:
    """Gefilterter Testcode. Bei kaputtem Code None — nichts Brauchbares übrig."""
    with tempfile.TemporaryDirectory(prefix="ts-parser-") as tmp:
        try:
            d, _ = _aufruf(Path(tmp), "nur_tests", code=code, behalten=sorted(behalten))
        except TypeScriptFehler as exc:
            if _syntaxfehler(exc):
                return None
            raise
        return d


def verbraucherzeuge(code: str, name: str, von: str, nach: str) -> str:
    with tempfile.TemporaryDirectory(prefix='ts-zeuge-') as tmp:
        d, _ = _aufruf(Path(tmp), 'verbraucherzeuge', code=code, name=name, von=von, nach=nach)
        return d


def baulauf(werk: Path, dateien: dict | None = None) -> dict:
    try:
        d, roh = _aufruf(werk, "baulauf", dateien=dateien)
        d["roh"] = roh
        return d
    except TypeScriptFehler as exc:
        return dict(gueltig=False, baut=False, rc=None, grund=str(exc), roh=str(exc))


def testlauf(werk: Path, dateien: dict | None = None, testdateien: list | None = None) -> dict:
    try:
        d, roh = _aufruf(werk, "testlauf", dateien=dateien, testdateien=testdateien)
        d["roh"] = roh
        return d
    except TypeScriptFehler as exc:
        return dict(gueltig=False, grund=str(exc), art="infrastruktur", faelle={}, rc=None, roh=str(exc))
