import fs from 'node:fs';
import {createHash} from 'node:crypto';
const req=JSON.parse(fs.readFileSync('/tmp/ts-ref-anfrage.json','utf8'));
function kanonisch(x,seen=new Set()) {
  if(x===null||typeof x==='string'||typeof x==='boolean')return x;
  if(typeof x==='number'&&Number.isFinite(x))return x;
  if(typeof x!=='object'||seen.has(x)||(!Array.isArray(x)&&Object.getPrototypeOf(x)!==Object.prototype))throw Error('Nicht kanonisierbarer Beobachtungswert');
  seen.add(x);
  const out=Array.isArray(x)?Array.from(x,v=>kanonisch(v,seen)):Object.fromEntries(Object.keys(x).sort().map(k=>[k,kanonisch(x[k],seen)]));
  seen.delete(x);return out;
}
let out;
try {
  const ref=await import('file:///werk/_biotop_referenz.ts');
  if(req.modus==='beobachten') {
    if(typeof ref.beobachten!=='function')throw Error('Referenzlast muss beobachten() exportieren');
    const values=kanonisch(await ref.beobachten());
    if(values===null||typeof values!=='object'||!Object.keys(values).length)throw Error('beobachten() muss ein nichtleeres JSON-Array oder -Objekt liefern');
    out={gueltig:true,sha256:createHash('sha256').update(JSON.stringify(values)).digest('hex'),anzahl:Array.isArray(values)?values.length:Object.keys(values).length,grund:''};
  } else if(req.modus==='laufzeit') {
    const bereiche={};
    // Erst ALLE Bereiche aufwärmen, dann messen: der erste Aufruf einer Funktion trägt JIT-Übersetzung
    // und Erstallokation (gemessen: 0,98 ms gegen 0,12 ms beim dritten Aufruf). Diese Kosten gehören
    // nicht in die Laufzeit des Werks, sonst streut die Rauschmessung zwischen Durchläufen.
    const WARM=3, MESS=5;
    for(const b of req.bereiche) {
      const fn=ref['last_'+b];
      if(typeof fn!=='function')throw Error('Referenzlast muss last_'+b+'() exportieren');
      for(let i=0;i<WARM;i++)await fn();
    }
    if(typeof globalThis.gc==='function')globalThis.gc();
    for(const b of req.bereiche) {
      const fn=ref['last_'+b];
      const werte=[];
      for(let i=0;i<MESS;i++){const start=performance.now();await fn();const ms=performance.now()-start;if(!Number.isFinite(ms)||ms<=0)throw Error('Ungültige Laufzeit');werte.push(ms);}
      const sortiert=[...werte].sort((a,b)=>a-b);
      bereiche[b]={laufzeit_roh:werte,laufzeit_ms:sortiert[Math.floor(MESS/2)],
                   laufzeit_aufwaermung:WARM,laufzeit_messungen:MESS};
    }
    let aufrufe='';
    try{aufrufe=fs.existsSync('/tmp/ts-ref-zaehler.json')?fs.readFileSync('/tmp/ts-ref-zaehler.json','utf8'):'';}catch{aufrufe='';}
    out={gueltig:true,grund:'',bereiche,aufrufe};
  } else throw Error('Unbekannter Referenzmodus');
} catch(e) {out={gueltig:false,sha256:'',anzahl:0,grund:e.stack||String(e)};}
fs.writeFileSync('/tmp/ts-ref-ergebnis.json',JSON.stringify(out));
