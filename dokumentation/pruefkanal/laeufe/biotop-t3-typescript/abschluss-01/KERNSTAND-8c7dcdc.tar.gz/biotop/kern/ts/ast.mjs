import ts from '/opt/biotop-ts/node_modules/typescript/lib/typescript.js';
import fs from 'node:fs';
import path from 'node:path';
export { ts };
export function dateien(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, {withFileTypes:true}).flatMap(x => x.isDirectory() ? dateien(path.join(dir,x.name)) : x.isFile() && x.name.endsWith('.ts') && !x.name.endsWith('.d.ts') ? [path.join(dir,x.name)] : []).sort();
}
export function parse(code, name='eingabe.ts') {
  const sf=ts.createSourceFile(name, code, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  if(sf.parseDiagnostics.length) throw Error('TypeScript-Syntax: '+sf.parseDiagnostics.map(x=>ts.flattenDiagnosticMessageText(x.messageText,' ')).join('; '));
  return sf;
}
export function funktionen(sf) {
  // Path.read_text() benutzt universal newlines; Spans passen zu dessen Text.
  const out=[], cp=n=>[...sf.text.slice(0,n).replace(/\r\n?/g,'\n')].length;
  const span=n=>({start:cp(n.getStart(sf)),end:cp(n.end)});
  function visit(n) {
    if((ts.isFunctionDeclaration(n)||ts.isArrowFunction(n)||ts.isFunctionExpression(n)||ts.isMethodDeclaration(n)) && n.body) {
      let name=n.name?.getText(sf), whole=n;
      if(!name && ts.isVariableDeclaration(n.parent)) { name=n.parent.name.getText(sf); whole=n.parent; }
      if(!name) { ts.forEachChild(n, visit); return; }
      const returns=[];
      function ret(x) { if(x!==n.body && ts.isFunctionLike(x)) return; if(ts.isReturnStatement(x)) returns.push({...span(x),expression_start:x.expression ? cp(x.expression.getStart(sf)):null,expression_end:x.expression?cp(x.expression.end):null}); ts.forEachChild(x,ret); }
      ret(n.body);
      const docnode=ts.isVariableDeclaration(whole) ? whole.parent.parent : whole;
      const doc=(docnode.jsDoc||[]).map(d=>typeof d.comment==='string'?d.comment:'').join('\n');
      const ident=n.name ?? (ts.isVariableDeclaration(whole)?whole.name:null);
      const nameort=ident?sf.getLineAndCharacterOfPosition(ident.getStart(sf)):null;
      out.push({name,zeile:sf.getLineAndCharacterOfPosition(n.getStart(sf)).line+1,ende:sf.getLineAndCharacterOfPosition(n.end).line+1,
        signatur:sf.text.slice(whole.getStart(sf),n.body.getStart(sf)).trim(),zweck:doc,
        name_zeile:nameort?nameort.line+1:null,name_spalte:nameort?nameort.character+1:null,
        ...span(whole),body_start:cp(n.body.getStart(sf)),body_end:cp(n.body.end),body_kind:ts.isBlock(n.body)?'block':'expression',
        params:n.parameters.map(p=>({name:p.name.getText(sf),type:p.type?.getText(sf)??null,...span(p)})),type:n.type?.getText(sf)??null,returns,
        exportiert:!!docnode.modifiers?.some(m=>m.kind===ts.SyntaxKind.ExportKeyword)});
    }
    ts.forEachChild(n,visit);
  }
  visit(sf); return out;
}
export function struktur() {
  const files=dateien('src');
  if(!files.length) throw Error('Keine TypeScript-Quellen unter src');
  const known=new Set(files);
  const ds=files.map(p=>{
    const sf=parse(fs.readFileSync(p,'utf8'),p), imports=[];
    function visit(n) {
      let spec=(ts.isImportDeclaration(n)||ts.isExportDeclaration(n))?n.moduleSpecifier:null;
      if(ts.isCallExpression(n)&&n.expression.kind===ts.SyntaxKind.ImportKeyword) spec=n.arguments[0];
      if(spec && ts.isStringLiteralLike(spec) && spec.text.startsWith('.')) {
        const base=path.posix.normalize(path.posix.join(path.posix.dirname(p),spec.text));
        const targets=[base,base+'.ts',base+'/index.ts',base.replace(/\.js$/,'.ts')];
        const target=targets.find(x=>known.has(x));
        if(!target) throw Error('Nicht auflösbarer relativer Import '+p+': '+spec.text);
        imports.push(target);
      }
      ts.forEachChild(n,visit);
    }
    visit(sf);
    return {pfad:p,funktionen:funktionen(sf),imports:[...new Set(imports)].sort()};
  });
  if(ds.some(d=>d.pfad.split('/').length<3)) throw Error('Quellen müssen unter src/<bereich>/ liegen');
  return {bereiche:[...new Set(ds.map(d=>d.pfad.split('/')[1]))].sort(),dateien:ds,offset_unit:'unicode_codepoints'};
}
