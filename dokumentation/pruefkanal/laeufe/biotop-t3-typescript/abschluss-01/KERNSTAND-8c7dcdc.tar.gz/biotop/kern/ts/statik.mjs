import fs from 'node:fs';
import {lauf} from './testlauf.mjs';
// Unveränderliche Regelzuordnung: HIGH=10, MEDIUM=3, LOW=1; alle Pluginregeln.
export const SICHERHEIT={
 'security/detect-buffer-noassert':3,'security/detect-child-process':10,
 'security/detect-disable-mustache-escape':3,'security/detect-eval-with-expression':10,
 'security/detect-new-buffer':3,'security/detect-no-csrf-before-method-override':3,
 'security/detect-non-literal-fs-filename':3,'security/detect-non-literal-regexp':3,
 'security/detect-non-literal-require':10,'security/detect-object-injection':1,
 'security/detect-possible-timing-attacks':3,'security/detect-pseudoRandomBytes':3,
 'security/detect-unsafe-regex':3,'security/detect-bidi-characters':10,
 // TypeScript-Ergänzung vor dem ersten Lauf: Codeausführung HIGH, geteilte Native-Mutation MEDIUM.
 'no-new-func':10,'no-extend-native':3,
};
export function statik(struktur) {
 const files=struktur.dateien.map(f=>f.pfad);
 const eslint=lauf('node',['/opt/biotop-ts/node_modules/eslint/bin/eslint.js','--no-config-lookup','--no-ignore','--no-inline-config','--config','_messgeraet/ts/eslint.config.mjs','--format','json',...files]);
 const result={gueltig:false,grund:'',eslint,knip:null,sicherheit:[],tote:[],abdeckung:{}};
 try {
  if(eslint.fehler||eslint.signal||![0,1].includes(eslint.rc))throw Error('ESLint-Runnerabbruch');
  const reports=JSON.parse(eslint.stdout);
  if(!Array.isArray(reports)||JSON.stringify(reports.map(r=>r.filePath.replace('/werk/','')).sort())!==JSON.stringify([...files].sort())||reports.some(r=>r.fatalErrorCount))throw Error('ESLint-Dateiabdeckung fehlt/Parserabbruch');
  for(const r of reports)for(const m of r.messages)if(m.ruleId?.startsWith('security/') || m.ruleId in SICHERHEIT) {
   if(!(m.ruleId in SICHERHEIT))throw Error('Unbekannte Sicherheitsregel: '+m.ruleId);
   const punkte=SICHERHEIT[m.ruleId];
   result.sicherheit.push({test:m.ruleId,schwere:punkte===10?'HIGH':punkte===3?'MEDIUM':'LOW',punkte,datei:r.filePath.replace('/werk/',''),zeile:m.line,text:m.message});
  }
  result.abdeckung.eslint={beendet:true,dateien:files,regelgewichte:SICHERHEIT};
  const schema=JSON.parse(fs.readFileSync('/opt/biotop-ts/node_modules/knip/schema.json','utf8'));
  const plugins=Object.fromEntries(Object.keys(schema.definitions.plugins.properties).map(k=>[k,false]));
  const config={...plugins,entry:['tests/**/*.test.ts'],project:['src/**/*.ts','tests/**/*.test.ts'],ignoreExportsUsedInFile:true,includeEntryExports:false};
  fs.writeFileSync('_messgeraet/ts/knip.json',JSON.stringify(config));
  const knip=lauf('node',['/opt/biotop-ts/node_modules/knip/bin/knip.js','--no-gitignore','--tsConfig','/tmp/ts-bau.json','--config','_messgeraet/ts/knip.json','--reporter','json','--include','files,exports,nsExports,types,classMembers,enumMembers,duplicates,unresolved']);
  result.knip=knip;
  if(knip.fehler||knip.signal||![0,1].includes(knip.rc))throw Error('knip-Runnerabbruch');
  const k=JSON.parse(knip.stdout);
  if(!Array.isArray(k.files)||!Array.isArray(k.issues)||k.issues.some(i=>i.unresolved?.length))throw Error('knip-Nachweis fehlt/Import unaufgelöst');
  const dead=new Set();
  for(const f of struktur.dateien) {
   const issue=k.issues.find(i=>i.file===f.pfad), names=new Set([...(issue?.exports||[]),...(issue?.nsExports||[])].map(x=>x.name));
   const unused=reports.find(r=>r.filePath.replace('/werk/','')===f.pfad).messages
     .filter(m=>m.ruleId==='@typescript-eslint/no-unused-vars');
   for(const fn of f.funktionen) {
    // Diagnose muss den Deklarationsnamen treffen; Parameter/Typ/Variable zählen nicht.
    const innen=unused.some(m=>m.line===fn.name_zeile && m.column===fn.name_spalte);
    if(!k.files.includes(f.pfad) && !names.has(fn.name) && !innen)continue;
    const id=f.pfad+':'+fn.zeile+':'+fn.name;
    if(!dead.has(id)){dead.add(id);result.tote.push({datei:f.pfad,name:fn.name,zeile:fn.zeile,quelle:k.files.includes(f.pfad)?'knip/files':names.has(fn.name)?'knip/exports':'eslint/unused-function'});}
   }
  }
  result.abdeckung.knip={beendet:true,dateien:files,entry:config.entry,project:config.project,bezugsart:'explizite Projektpopulation; erfolgreicher knip-Gesamtlauf'};
  result.gueltig=true;
 }catch(e){result.grund=String(e.message||e);}
 return result;
}
