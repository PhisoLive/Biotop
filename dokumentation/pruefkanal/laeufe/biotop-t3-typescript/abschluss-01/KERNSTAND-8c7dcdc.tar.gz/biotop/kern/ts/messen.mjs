import path from 'node:path';
import {struktur} from './ast.mjs';
import {baulauf} from './bau.mjs';
import {testlauf} from './testlauf.mjs';
import {statik} from './statik.mjs';
import {referenz} from './referenz.mjs';
export function messen(req) {
 const out={gueltig:false,grund:'',bereiche:{},werk:{},abdeckung:{},belege:{},kammeraufrufe:1};
 try {
  if(req.paket!=='src')throw Error('Unterstützte Quellwurzel: src');
  const st=struktur();
  if(!req.bereiche.length||JSON.stringify([...req.bereiche].sort())!==JSON.stringify(st.bereiche))throw Error('Bereichspopulation stimmt nicht mit AST überein');
  const bau=baulauf();out.belege.tsc=bau;
  if(!bau.gueltig)throw Error(bau.grund);
  const tests=testlauf(req);out.belege.vitest=tests;
  if(!tests.gueltig)throw Error('Vitest: '+tests.grund);
  const scan=statik(st);out.belege.statik=scan;
  if(!scan.gueltig)throw Error('Statik: '+scan.grund);
  out.abdeckung={tsc:{beendet:true,dateien:bau.dateien},vitest:{beendet:true,dateien:[...new Set(Object.keys(tests.faelle).map(n=>n.split('::')[0]))]},...scan.abdeckung};
  const fehl=Object.keys(tests.faelle).filter(id=>!tests.faelle[id].ok).sort();
  function bereich(id) {
   const f=path.basename(id.split('::')[0]);
   if(f.startsWith('test_vertrag_'))return req.bereiche.find(b=>f.endsWith('_'+b+'.test.ts'));
   return req.bereiche.find(b=>f==='test_'+b+'.test.ts'||f.startsWith('test_'+b+'_')||f.startsWith('test_immun_'+b+'_'));
  }
  const ohne=Object.keys(tests.faelle).filter(id=>!bereich(id));
  if(ohne.length)throw Error('Testfälle ohne Bereich: '+ohne.join(', '));
  for(const b of req.bereiche) {
   const faelle=Object.entries(tests.faelle).filter(([id])=>bereich(id)===b);
   if(!faelle.length)throw Error('Testnachweis für Bereich fehlt: '+b);
   const sicherheit=scan.sicherheit.filter(f=>f.datei.startsWith('src/'+b+'/'));
   const tote=scan.tote.filter(f=>f.datei.startsWith('src/'+b+'/'));
   const funcs=st.dateien.filter(f=>f.pfad.startsWith('src/'+b+'/')).flatMap(f=>f.funktionen.map(fn=>({...fn,pfad:f.pfad})));
   funcs.sort((a,b)=>(b.ende-b.zeile)-(a.ende-a.zeile));
   out.bereiche[b]={tests_bestanden:faelle.filter(([,v])=>v.ok).length,tests_fehlgeschlagen:faelle.filter(([,v])=>!v.ok).length,tests_gesamt:faelle.length,
    sicherheit_punkte:sicherheit.reduce((a,x)=>a+x.punkte,0),sicherheit_befunde:sicherheit,sicherheit_fehler:'',tote_funktionen:tote.length,tote_liste:tote,
    groesste_funktion:funcs.length?funcs[0].ende-funcs[0].zeile+1:0,groesste_funktion_name:funcs.length?funcs[0].pfad+':'+funcs[0].name:'',laufzeit_ms:null};
  }
  const kanten=[...new Set(st.dateien.flatMap(f=>f.imports.filter(i=>i.split('/')[1]!==f.pfad.split('/')[1]).map(i=>f.pfad.split('/')[1]+'|'+i.split('/')[1])))].sort().map(k=>k.split('|'));
  let zyklen=0;
  for(const start of req.bereiche){const todo=[start],seen=new Set();let cyclic=false;while(todo.length&&!cyclic){const n=todo.pop();for(const [a,b]of kanten)if(a===n){if(b===start){cyclic=true;break;}if(!seen.has(b)){seen.add(b);todo.push(b);}}}if(cyclic)zyklen++;}
  out.werk={baut:bau.baut,bau_fehler:bau.baut?'':bau.prozess.stdout,bauzeit_ms:bau.bauzeit_ms,test_rc:tests.rc,pytest_rc:tests.rc,
   pytest_rc_hinweis:'Kompatibilitätsalias von Vitest test_rc; kein pytest-Lauf',tests_fehlgeschlagen_ids:fehl,
   tests_fehlgeschlagen_liste:fehl.map(id=>path.basename(id.split('::')[0])+'::'+id.split('::').slice(1).join('::')),tests_ohne_bereich:ohne,zyklen,kanten};
  if(req.referenzlast) {
   const ref=referenz(req.referenzlast,'laufzeit',req.bereiche);out.belege.referenz=ref;
   if(!ref.gueltig)throw Error('Referenzlast: '+ref.grund);
   for(const b of req.bereiche)Object.assign(out.bereiche[b],ref.bereiche[b]);
  }
  out.kernmass=Object.values(out.bereiche).reduce((a,b)=>a-b.tests_fehlgeschlagen-b.sicherheit_punkte-b.tote_funktionen,0);
  out.gueltig=true;
 }catch(e){out.grund=String(e.message||e);}
 return out;
}
