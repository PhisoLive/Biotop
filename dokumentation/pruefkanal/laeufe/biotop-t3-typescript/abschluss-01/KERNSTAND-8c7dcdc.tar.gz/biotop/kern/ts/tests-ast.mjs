import {ts,parse} from './ast.mjs';
import path from 'node:path';
export function testsAst(code,behalten=null,zeuge=null) {
  const sf=parse(code), imports=new Map(), quellen=new Map(), tests=new Set(), suites=new Set(), expects=new Set();
  for(const s of sf.statements) if(ts.isImportDeclaration(s)&&ts.isStringLiteral(s.moduleSpecifier)) {
    for(const b of s.importClause?.namedBindings?.elements||[]) {
      const orig=(b.propertyName||b.name).text, local=b.name.text;
      if(s.moduleSpecifier.text==='vitest') {
        if(['test','it'].includes(orig))tests.add(local);
        if(['describe','suite'].includes(orig))suites.add(local);
        if(orig==='expect')expects.add(local);
      } else if(s.moduleSpecifier.text.startsWith('.')) {imports.set(local,orig);quellen.set(local,s.moduleSpecifier.text);}
    }
  }
  function root(e) {while(ts.isPropertyAccessExpression(e)||ts.isCallExpression(e))e=e.expression;return ts.isIdentifier(e)?e.text:'';}
  const blocks=[],seen=new Set();
  function inspect(n) {
    if(ts.isCallExpression(n)) {
      const r=root(n.expression);
      if(suites.has(r))throw Error('Nur flache test()/it()-Blöcke unterstützt, keine describe-Suiten');
      if(tests.has(r)) {
        if(!ts.isIdentifier(n.expression)||!ts.isExpressionStatement(n.parent)||n.parent.parent!==sf||n.arguments.length<2||!ts.isStringLiteralLike(n.arguments[0])||!(ts.isArrowFunction(n.arguments[1])||ts.isFunctionExpression(n.arguments[1])))throw Error('Nicht unterstützte Testform: nur flache benannte test()/it()-Blöcke');
        const name=n.arguments[0].text;
        if(seen.has(name))throw Error('Doppelter Testtitel: '+name);
        seen.add(name); blocks.push({name,statement:n.parent,fn:n.arguments[1]});
      }
    }
    ts.forEachChild(n,inspect);
  }
  inspect(sf);
  if(zeuge!==null) {
    const gew=blocks.find(b=>b.name===zeuge.name);
    if(!gew)throw Error('Verbraucherzeuge fehlt: '+zeuge.name);
    const edits=blocks.map(b=>({start:b.statement.getFullStart(),end:b.statement.end,text:b===gew?'\nexport const eichprobe_verbraucher = '+b.fn.getText(sf)+';\n':''}));
    for(const s of sf.statements)if(ts.isImportDeclaration(s)&&ts.isStringLiteral(s.moduleSpecifier)&&s.moduleSpecifier.text.startsWith('.')) {
      const ziel=path.posix.normalize(path.posix.join(path.posix.dirname(zeuge.von),s.moduleSpecifier.text));
      let rel=path.posix.relative(path.posix.dirname(zeuge.nach),ziel);if(!rel.startsWith('.'))rel='./'+rel;
      edits.push({start:s.moduleSpecifier.getStart(sf),end:s.moduleSpecifier.end,text:JSON.stringify(rel)});
    }
    let out=code;for(const e of edits.sort((a,b)=>b.start-a.start))out=out.slice(0,e.start)+e.text+out.slice(e.end);
    return out;
  }
  function aufrufe(fn) {
    const out=[];
    function visit(n) {
      if(ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&imports.has(n.expression.text))out.push({name:imports.get(n.expression.text),quelle:quellen.get(n.expression.text),argumente:n.arguments.map(a=>({code:a.getText(sf),leeres_array:ts.isArrayLiteralExpression(a)&&a.elements.length===0}))});
      ts.forEachChild(n,visit);
    }
    visit(fn);return out;
  }
  function behauptung(fn) {
    const bindings=new Map(),claims=[];
    function bind(n){if(ts.isVariableDeclaration(n)&&ts.isIdentifier(n.name)&&n.initializer)bindings.set(n.name.text,n.initializer);ts.forEachChild(n,bind);}
    bind(fn);
    function ziel(n,visited=new Set()) {
      if(!n)return '?';
      if(ts.isIdentifier(n)) {
        if(imports.has(n.text))return imports.get(n.text);
        if(bindings.has(n.text)&&!visited.has(n.text)){visited.add(n.text);return ziel(bindings.get(n.text),visited);}
      }
      if(ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&imports.has(n.expression.text))return imports.get(n.expression.text);
      if(ts.isCallExpression(n)&&ts.isPropertyAccessExpression(n.expression)&&ts.isIdentifier(n.expression.expression)&&imports.has(n.expression.expression.text))return imports.get(n.expression.expression.text)+'.'+n.expression.name.text;
      let found='?';ts.forEachChild(n,c=>{if(found==='?')found=ziel(c,new Set(visited));});return found;
    }
    function assertion(n) {
      if(ts.isCallExpression(n)&&ts.isPropertyAccessExpression(n.expression)) {
        const parts=[];let e=n.expression;
        while(ts.isPropertyAccessExpression(e)){parts.unshift(e.name.text);e=e.expression;}
        if(ts.isCallExpression(e)&&ts.isIdentifier(e.expression)&&expects.has(e.expression.text)) {
          const a=n.arguments[0], form=!a?'leer':ts.isNumericLiteral(a)||(ts.isPrefixUnaryExpression(a)&&ts.isNumericLiteral(a.operand))?'zahl':ts.isStringLiteralLike(a)?'text':a.kind===ts.SyntaxKind.TrueKeyword||a.kind===ts.SyntaxKind.FalseKeyword?'bool':'name';
          claims.push(ziel(e.arguments[0])+'|'+parts.join('.')+':'+form);
        }
      }
      ts.forEachChild(n,assertion);
    }
    assertion(fn);return [...new Set(claims)].sort().join('&')||'?|keine_assertion';
  }
  const result=blocks.map(b=>{
    const comment=(ts.getLeadingCommentRanges(code,b.statement.pos)||[]).map(c=>code.slice(c.pos,c.end)).join('\n');
    const text=b.name+' '+comment+' '+(ts.getLeadingCommentRanges(code,b.fn.body.pos)||[]).map(c=>code.slice(c.pos,c.end)).join(' ');
    const refs=text.match(/test_vertrag_[a-z0-9_]+(?:::[\w -]+)?|(?:verfassung(?:ssatz)?\s*(?:satz\s*)?|anhang\s*a\s*satz\s*|\bsatz\s*)\d{1,2}/gi)||[];
    return {name:b.name,code:code.slice(b.statement.getFullStart(),b.statement.end).trim(),behauptung:behauptung(b.fn),verweis:refs.join(' '),aufrufe:aufrufe(b.fn)};
  });
  if(behalten===null)return result;
  const keep=new Set(behalten);
  if(!blocks.some(b=>keep.has(b.name)))return null;
  let out=code;
  for(const b of [...blocks].reverse())if(!keep.has(b.name))out=out.slice(0,b.statement.getFullStart())+out.slice(b.statement.end);
  return out;
}
