import fs from 'node:fs';
import {deflateSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {struktur,parse,funktionen} from './ast.mjs';
import {testlauf} from './testlauf.mjs';
import {baulauf} from './bau.mjs';
import {testsAst} from './tests-ast.mjs';
import {mutanten} from './mutanten.mjs';
import {referenz} from './referenz.mjs';
import {messen} from './messen.mjs';

let result;
try {
  if(!fs.existsSync('node_modules')) fs.symlinkSync('/opt/biotop-ts/node_modules','node_modules','dir');
  const req=JSON.parse(fs.readFileSync(new URL('./anfrage.json',import.meta.url),'utf8'));
  if(req.aktion==='struktur') result={ergebnis:struktur()};
  else if(req.aktion==='quellfunktionen') result={ergebnis:funktionen(parse(req.code))};
  else if(req.aktion==='testlauf') result={ergebnis:testlauf(req)};
  else if(req.aktion==='baulauf') result={ergebnis:baulauf()};
  else if(req.aktion==='testfunktionen') result={ergebnis:testsAst(req.code)};
  else if(req.aktion==='nur_tests') result={ergebnis:testsAst(req.code,req.behalten)};
  else if(req.aktion==='verbraucherzeuge') result={ergebnis:testsAst(req.code,null,{name:req.name,von:req.von,nach:req.nach})};
  else if(req.aktion==='mutanten') result={ergebnis:mutanten(req.max_je_datei)};
  else if(req.aktion==='ref_beobachten') result={ergebnis:referenz(req.referenzlast)};
  else if(req.aktion==='messen') result={ergebnis:messen(req)};
  else throw Error('Unbekannte Adapteraktion: '+req.aktion);
} catch(e) {result={fehler:e.stack||String(e)};}
const text=JSON.stringify(result), sum=createHash('sha256').update(text).digest('hex');
const out='@@TS1:'+sum+':'+deflateSync(text).toString('base64')+'@@';
if(out.length>1900000) {console.error('TS-Transport überschreitet 1900000 Zeichen; keine verkürzte Messung');process.exitCode=70;}
else console.log(out);
