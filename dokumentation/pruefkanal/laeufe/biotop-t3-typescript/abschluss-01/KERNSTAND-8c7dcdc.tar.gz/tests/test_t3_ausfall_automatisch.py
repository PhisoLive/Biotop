"""Automatische Ausfallklärung im Lauf — die Regel mechanisch angewandt.

Lage (belegt in Lauf 35, Protokoll 17529–17535): Die Wiederholung greift, generation0
fängt den Ausfall ab und wechselt den Anbieter — aber der nächste Modellaufruf wird von
`kasse.vorpruefung` verweigert, weil ein Ausfall mit unbekanntem Verbrauch offen ist.
Der Auflösungsweg `kasse.ausfall_klaeren` existiert, wurde aber nur von Hand gerufen.
Damit tötete jeder nicht wiederholbare 429 jeden Lauf.

Entscheidung Chat-Claude: Die Klärung läuft automatisch. Das ist die Regel mechanisch
angewandt, nicht aufgeweicht:
  - Höchstfall VOLL gegen das Budget (die ganze Reservierung als Verbrauch)
  - harte Grenze unverändert — eine Klärung kann den Lauf am Budget sterben lassen
  - ein Ausfall nach dem anderen, nie mehrere auf einmal
  - jede automatische Klärung protokolliert, mit Anzahl und Summe im Bericht
Aufgeweicht wäre sie nur bei einer Buchung UNTER dem Höchstfall oder an der Grenze vorbei.

Satz 8 bleibt unberührt: der Ausfall zählt weiterhin null Beitrag.
"""
import json

import pytest

from biotop.kern import datenbank, kasse, protokoll


@pytest.fixture
def con(tmp_path, monkeypatch):
    monkeypatch.setattr(datenbank, 'DB_PFAD', tmp_path / 'p.db')
    monkeypatch.setattr(kasse, 'AUFTRAG_BUDGET_EUR', 10.0)
    monkeypatch.setattr(kasse, 'AUFTRAG_LAUF_AB', 26)
    c = datenbank.verbinden()
    c.execute("INSERT INTO laeufe(id,budget_eur,status,begonnen_am) VALUES (36,10.0,'bereit',?)",
              (protokoll.jetzt(),))
    c.commit()
    return c


def _ausfall(con, reservierung=0.0028, lauf=36):
    nr = protokoll.schreiben(con, 'modell.aufruf', lauf_id=lauf, modell='qwen/qwen3.8-flash',
                             zweck='generation0.testbau.bericht', schaetzung_eur=reservierung)
    protokoll.schreiben(con, 'modell.ausfall', lauf_id=lauf, modell='qwen/qwen3.8-flash',
                        fehler='HTTP 429 rate-limited', aufruf_nr=nr, ausfallart='infrastruktur',
                        beitraege=0, verbrauch_bekannt=False, kosten_eur=None,
                        reservierung_eur=reservierung, versuche=3, wiederholbar=True)
    return nr


def test_erzwungener_ausfall_wird_automatisch_mit_hoechstfall_gebucht(con):
    """Gegenprobe 1: Ausfall erzwingen, Lauf geht weiter, genau der Höchstfall gebucht."""
    nr = _ausfall(con, reservierung=0.0028)
    vorher = kasse.auftrag_stand(con)

    # Ohne Klärung wäre hier Schluss. Mit automatischer Klärung läuft es weiter.
    schaetzung = kasse.vorpruefung(con, 36, 'openai/gpt-5.6-luna', 1000, 500, 'test')
    assert schaetzung > 0, 'der Aufruf wurde freigegeben'

    nachher = kasse.auftrag_stand(con)
    assert nachher == pytest.approx(vorher + 0.0028), 'genau der Höchstfall, nicht weniger'

    e = [json.loads(z['inhalt']) for z in con.execute(
        "SELECT inhalt FROM protokoll WHERE art='kasse.ausfall_geklaert'")]
    assert len(e) == 1
    assert e[0]['aufruf_nr'] == nr
    assert e[0]['gebucht_eur'] == pytest.approx(0.0028)
    assert e[0]['klaerungsart'] == 'hoechstfall'
    assert e[0]['automatisch'] is True, 'die automatische Klärung ist als solche erkennbar'
    assert e[0]['beitraege'] == 0, 'Satz 8: ein Ausfall bleibt null Beitrag'


def test_klaerung_die_die_grenze_erreicht_bricht_am_budget_ab(con, monkeypatch):
    """Gegenprobe 2: Die harte Grenze bleibt hart — auch gegen die Klärung selbst."""
    monkeypatch.setattr(kasse, 'AUFTRAG_BUDGET_EUR', 0.003)
    _ausfall(con, reservierung=0.0028)
    with pytest.raises(kasse.BudgetErschoepft, match='Auftragsbudget|AUFTRAGSBUDGET'):
        kasse.vorpruefung(con, 36, 'openai/gpt-5.6-luna', 100000, 5000, 'test')
    # Die Klärung ist gebucht — der Verbrauch bleibt Verbrauch, auch wenn der Lauf stirbt.
    assert kasse.auftrag_stand(con) == pytest.approx(0.0028)


def test_mehrere_ausfaelle_werden_einzeln_geklaert(con):
    """Nie mehrere auf einmal: jeder Aufruf klärt genau einen Ausfall."""
    a = _ausfall(con)
    b = _ausfall(con)
    c_ = _ausfall(con)
    kasse.vorpruefung(con, 36, 'openai/gpt-5.6-luna', 100, 50, 'test')
    geklaert = [json.loads(z['inhalt'])['aufruf_nr'] for z in con.execute(
        "SELECT inhalt FROM protokoll WHERE art='kasse.ausfall_geklaert' ORDER BY nr")]
    assert geklaert == [a], 'nur der älteste, nicht alle drei'

    kasse.vorpruefung(con, 36, 'openai/gpt-5.6-luna', 100, 50, 'test')
    kasse.vorpruefung(con, 36, 'openai/gpt-5.6-luna', 100, 50, 'test')
    geklaert = [json.loads(z['inhalt'])['aufruf_nr'] for z in con.execute(
        "SELECT inhalt FROM protokoll WHERE art='kasse.ausfall_geklaert' ORDER BY nr")]
    assert geklaert == [a, b, c_], 'einer je Aufruf, in Reihenfolge'
    assert kasse.auftrag_stand(con) == pytest.approx(3 * 0.0028)


def test_bericht_nennt_anzahl_und_summe(con):
    _ausfall(con)
    _ausfall(con)
    kasse.vorpruefung(con, 36, 'openai/gpt-5.6-luna', 100, 50, 'test')
    kasse.vorpruefung(con, 36, 'openai/gpt-5.6-luna', 100, 50, 'test')
    b = kasse.ausfallklaerungen(con, 36)
    assert b == {'anzahl': 2, 'summe_eur': pytest.approx(0.0056), 'automatisch': 2,
                 'von_hand': 0}


def test_handklaerung_bleibt_moeglich_und_wird_unterschieden(con):
    nr = _ausfall(con)
    kasse.ausfall_klaeren(con, 36, nr, beleg='von Hand geprüft')
    e = json.loads(next(iter(con.execute(
        "SELECT inhalt FROM protokoll WHERE art='kasse.ausfall_geklaert'")))['inhalt'])
    assert e['automatisch'] is False
    assert kasse.ausfallklaerungen(con, 36) == {'anzahl': 1, 'summe_eur': pytest.approx(0.0028),
                                               'automatisch': 0, 'von_hand': 1}


def test_ohne_offenen_ausfall_bucht_die_vorpruefung_nichts(con):
    """Gegenprobe 3: Keine Klärung ohne Anlass — sonst wäre es eine Pauschalbuchung."""
    vorher = kasse.auftrag_stand(con)
    kasse.vorpruefung(con, 36, 'openai/gpt-5.6-luna', 1000, 500, 'test')
    assert kasse.auftrag_stand(con) == pytest.approx(vorher)
    assert not list(con.execute("SELECT 1 FROM protokoll WHERE art='kasse.ausfall_geklaert'"))
