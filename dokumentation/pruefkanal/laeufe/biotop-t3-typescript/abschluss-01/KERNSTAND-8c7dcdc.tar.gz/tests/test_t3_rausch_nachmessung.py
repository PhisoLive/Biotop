"""Bereichsnachmessung darf den TS-Gesamtscan nicht mit Teilpopulation rufen."""
from biotop.organe import eichung


def test_ts_nachmessung_scant_ganzes_werk_und_gibt_nur_angefragten_bereich(tmp_path,monkeypatch):
    (tmp_path/'package.json').write_text('{}')
    for b in ('a','b'):
        (tmp_path/'src'/b).mkdir(parents=True)
        (tmp_path/'src'/b/'x.ts').write_text('export const x=1;')
    def messen(w,bereiche,paket,ref):
        assert bereiche==['a','b']
        return {'gueltig':True,'bereiche':{'a':{'laufzeit_ms':1.0},'b':{'laufzeit_ms':2.0}}}
    monkeypatch.setattr(eichung.messgeraet,'messen',messen)
    assert eichung._messen_einmal(tmp_path,['b'],'src','ref')=={'b':2.0}
