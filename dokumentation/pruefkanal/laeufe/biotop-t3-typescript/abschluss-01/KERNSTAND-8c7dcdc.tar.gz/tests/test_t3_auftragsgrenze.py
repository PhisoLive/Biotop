"""Null als Auftragsgrenze ist keine Grenze — der Start muss verweigert werden.

Befund: `AUFTRAG_LAUF_AB` und `AUFTRAG_BUDGET_EUR` lesen aus der Umgebung mit Vorgabe "0".
Fehlen die Variablen, prüft `vorpruefung` die auftragsweite Grenze stillschweigend nicht —
die harte Grenze existiert dann nur auf dem Papier. Das ist dieselbe Fehlerklasse wie eine
leere Norm-Eichprobe: Abwesenheit einer Prüfung als bestandene Prüfung gelesen.

Das Setzen der Variablen behebt nur den Einzelfall. Die Fehlerklasse verschwindet erst,
wenn ein Lauf ohne scharfe Grenze gar nicht erst startet.
"""
import pytest

from biotop.kern import datenbank, kasse, protokoll


@pytest.fixture
def con(tmp_path, monkeypatch):
    monkeypatch.setattr(datenbank, 'DB_PFAD', tmp_path / 'p.db')
    c = datenbank.verbinden()
    c.execute("INSERT INTO laeufe(id,budget_eur,status,begonnen_am) VALUES (31,10.0,'bereit',?)",
              (protokoll.jetzt(),))
    c.commit()
    return c


def test_start_verweigert_wenn_budgetvariablen_fehlen(con, monkeypatch):
    monkeypatch.setattr(kasse, 'AUFTRAG_LAUF_AB', 0)
    monkeypatch.setattr(kasse, 'AUFTRAG_BUDGET_EUR', 0.0)
    with pytest.raises(kasse.AuftragsgrenzeFehlt, match='Auftragsgrenze'):
        kasse.auftragsgrenze_verlangen()


def test_start_verweigert_wenn_budget_null(con, monkeypatch):
    monkeypatch.setattr(kasse, 'AUFTRAG_LAUF_AB', 26)
    monkeypatch.setattr(kasse, 'AUFTRAG_BUDGET_EUR', 0.0)
    with pytest.raises(kasse.AuftragsgrenzeFehlt, match='BIOTOP_AUFTRAG_BUDGET_EUR'):
        kasse.auftragsgrenze_verlangen()


def test_start_verweigert_wenn_lauf_ab_null(con, monkeypatch):
    monkeypatch.setattr(kasse, 'AUFTRAG_LAUF_AB', 0)
    monkeypatch.setattr(kasse, 'AUFTRAG_BUDGET_EUR', 10.0)
    with pytest.raises(kasse.AuftragsgrenzeFehlt, match='BIOTOP_AUFTRAG_LAUF_AB'):
        kasse.auftragsgrenze_verlangen()


def test_start_erlaubt_wenn_grenze_scharf(con, monkeypatch):
    monkeypatch.setattr(kasse, 'AUFTRAG_LAUF_AB', 26)
    monkeypatch.setattr(kasse, 'AUFTRAG_BUDGET_EUR', 10.0)
    assert kasse.auftragsgrenze_verlangen() == (26, 10.0)


def test_vorpruefung_verweigert_ohne_scharfe_grenze(con, monkeypatch):
    """Die Sperre wirkt an der Stelle, die jeden Modellaufruf passiert."""
    monkeypatch.setattr(kasse, 'AUFTRAG_LAUF_AB', 0)
    monkeypatch.setattr(kasse, 'AUFTRAG_BUDGET_EUR', 0.0)
    with pytest.raises(kasse.AuftragsgrenzeFehlt):
        kasse.vorpruefung(con, 31, 'openai/gpt-5.6-luna', 1000, 500, 'test')


def test_vorpruefung_laeuft_mit_scharfer_grenze(con, monkeypatch):
    monkeypatch.setattr(kasse, 'AUFTRAG_LAUF_AB', 26)
    monkeypatch.setattr(kasse, 'AUFTRAG_BUDGET_EUR', 10.0)
    assert kasse.vorpruefung(con, 31, 'openai/gpt-5.6-luna', 1000, 500, 'test') > 0
