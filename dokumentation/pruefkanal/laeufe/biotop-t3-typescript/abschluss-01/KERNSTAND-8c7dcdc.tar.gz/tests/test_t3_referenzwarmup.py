"""Laufzeitmessung braucht Aufwärmung: JIT/GC gehören nicht in den ersten Messwert.

Belegt am echten TS-Werk in der Kammer: die Referenzlast zählt ihre Aufrufe mit.
Ohne Aufwärmung sieht das Messgerät genau `laufzeit_roh`-viele Aufrufe; mit Aufwärmung
mehr — und der Median wird aus fünf, nicht aus drei Werten gebildet.
"""
import json
from pathlib import Path

import pytest

from biotop.kern import typescript
from biotop.organe import kammer

kammer.IMAGE = 'biotop-kammer:ts1'
WERK = Path('/root/biotop/daten/werke/versandwerk-t3-02')

REF = """
import fs from 'node:fs';
function zaehle(name) {
  const p = '/tmp/ts-ref-zaehler.json';
  const d = fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : {};
  d[name] = (d[name] || 0) + 1;
  fs.writeFileSync(p, JSON.stringify(d));
}
export function last_eingang() { zaehle('eingang'); let s = 0; for (let i = 0; i < 20000; i++) s += i % 7; return s; }
export function last_tarife() { zaehle('tarife'); let s = 0; for (let i = 0; i < 20000; i++) s += i % 5; return s; }
export function last_planung() { zaehle('planung'); let s = 0; for (let i = 0; i < 20000; i++) s += i % 3; return s; }
export function last_bericht() { zaehle('bericht'); let s = 0; for (let i = 0; i < 20000; i++) s += i % 11; return s; }
export function last_zahlen() { zaehle('zahlen'); let s = 0; for (let i = 0; i < 20000; i++) s += i % 13; return s; }
export function beobachten() { return { a: 1 }; }
"""


@pytest.mark.integration
def test_laufzeitmessung_waermt_auf_und_misst_fuenf():
    bereiche = ['bericht', 'eingang', 'planung', 'tarife', 'zahlen']
    extra = {'_zaehler_leeren.mjs': "import fs from 'node:fs';fs.rmSync('/tmp/ts-ref-zaehler.json',{force:true});"}
    m = typescript.messen(WERK, bereiche, 'src', REF, dateien=extra)
    assert m['gueltig'], m['grund']
    roh = m['bereiche']['eingang']['laufzeit_roh']
    assert len(roh) == 5, f'Median aus fünf Messwerten erwartet, {len(roh)} erhalten'
    assert m['bereiche']['eingang']['laufzeit_ms'] == sorted(roh)[2]
    aufrufe = json.loads(m['belege']['referenz']['aufrufe'])
    for b in bereiche:
        assert aufrufe[b] > len(roh), (
            f'{b}: {aufrufe[b]} Aufrufe bei {len(roh)} Messwerten — keine Aufwärmung vor der Messung')
    assert all(aufrufe[b] == aufrufe['eingang'] for b in bereiche)
