"""Gestellte HTTP-Antworten am echten Adapter: keine Anbieter-Ausführung behauptet."""
import io
import json
import pytest
from biotop import anbieter
from biotop.kern import datenbank


@pytest.fixture
def db(tmp_path):
    con = datenbank.verbinden(tmp_path / 'ausfall.db')
    con.execute("INSERT INTO laeufe(id,budget_eur,status) VALUES(1,10,'angelegt')")
    yield con
    con.close()


def antwort(monkeypatch, inhalt, grund='stop', refusal=None):
    monkeypatch.setenv('OPENROUTER_API_KEY', 'gestellte-keine-anbieterkennung')
    anbieter._ADAPTER.clear()
    d = {'choices':[{'finish_reason':grund, 'message':{'content':inhalt,'refusal':refusal}}],
         'usage':{'prompt_tokens':120,'completion_tokens':4}}
    monkeypatch.setattr(anbieter.urllib.request, 'urlopen', lambda *a, **kw: io.BytesIO(json.dumps(d).encode()))


def aufrufen(db):
    return anbieter.aufrufen(db,1,'openrouter','openai/gpt-5.6-luna','Prüfung','gestellte Antwort',
                            't3.gestellter_verbundausfall',max_tokens=20)


@pytest.mark.parametrize('inhalt,grund,refusal', [('', 'stop', None), ('  ', 'stop', None),
    ('', 'refusal', 'cyber'), ('Resttext', 'content_filter', 'refused')])
def test_http_erfolg_ohne_beitrag_ist_ausfall_und_wird_abgerechnet(db,monkeypatch,inhalt,grund,refusal):
    antwort(monkeypatch,inhalt,grund,refusal)
    with pytest.raises(anbieter.AnbieterFehler):
        aufrufen(db)
    ereignisse = [(r['art'],json.loads(r['inhalt'])) for r in db.execute('SELECT * FROM protokoll')]
    ausfall = [d for art,d in ereignisse if art=='modell.ausfall']
    assert len(ausfall)==1 and ausfall[0]['beitraege']==0
    assert not any(art=='modell.antwort' for art,d in ereignisse)
    assert db.execute('SELECT count(*) FROM kasse').fetchone()[0]==1
    assert db.execute('SELECT sum(tokens_ein) FROM kasse').fetchone()[0]==120


@pytest.mark.parametrize('text',['KEIN VORSCHLAG — nichts gefunden','BEGRÜNDUNG: gültiger Text'])
def test_nutzbare_antwort_erreicht_konsument_kein_vorschlag_kein_ausfall(db,monkeypatch,text):
    antwort(monkeypatch,text)
    r=aufrufen(db)
    assert r.text==text
    assert db.execute("SELECT count(*) FROM protokoll WHERE art='modell.antwort'").fetchone()[0]==1
    assert db.execute("SELECT count(*) FROM protokoll WHERE art='modell.ausfall'").fetchone()[0]==0


def test_timeout_ist_ausfall_keine_freigabe_unbekannter_kosten(db,monkeypatch):
    """Ein Timeout ist Ausfall mit null Beitrag; sein Verbrauch bleibt unbekannt.

    Die Behandlung des unbekannten Verbrauchs hat sich geändert (Festlegung Chat-Claude):
    Statt jeden weiteren Aufruf dauerhaft zu sperren, klärt `vorpruefung` den Ausfall
    mechanisch mit dem HÖCHSTFALL — volle Reservierung gegen das Budget. Was hier
    unverändert gilt und geprüft wird: null Beitrag, Verbrauch nicht als bekannt
    ausgegeben, und die Buchung ist nicht kleiner als die Reservierung.
    """
    antwort(monkeypatch,'ungenutzt')
    def timeout(*a,**kw): raise TimeoutError('gestellter Timeout')
    monkeypatch.setattr(anbieter.urllib.request,'urlopen',timeout)
    with pytest.raises(anbieter.AnbieterFehler): aufrufen(db)
    ds=[json.loads(r[0]) for r in db.execute("SELECT inhalt FROM protokoll WHERE art='modell.ausfall'")]
    assert len(ds)==1 and ds[0]['beitraege']==0 and ds[0]['verbrauch_bekannt'] is False
    reservierung=float(ds[0]['reservierung_eur'])

    # Der nächste Aufruf klärt genau diesen Ausfall — zu Lasten des Budgets.
    antwort(monkeypatch,'jetzt nutzbar')
    aufrufen(db)
    gk=[json.loads(r[0]) for r in db.execute("SELECT inhalt FROM protokoll WHERE art='kasse.ausfall_geklaert'")]
    assert len(gk)==1, 'genau eine Klärung, nicht mehrere'
    assert gk[0]['automatisch'] is True
    assert gk[0]['beitraege']==0, 'Satz 8: der Ausfall bleibt null Beitrag'
    assert gk[0]['gebucht_eur']>=round(reservierung,6), 'Höchstfall, nicht weniger'
    gebucht=[r[0] for r in db.execute("SELECT kosten_eur FROM kasse WHERE zweck='ausfall.hoechstfall'")]
    assert gebucht and abs(gebucht[0]-reservierung)<1e-9


def test_verbund_ausfall_und_gueltiger_nachbar_durch_genesis(db,tmp_path,monkeypatch):
    from biotop.organe import genesis, landkarte, nischen, gedaechtnis, mentor
    monkeypatch.setattr(landkarte,'sicht',lambda *a:'gestelltes Werk')
    monkeypatch.setattr(gedaechtnis,'gescheiterte_wege_text',lambda *a:'keine')
    monkeypatch.setattr(mentor,'richtung_text',lambda *a:'Prüfung')
    monkeypatch.setattr(nischen,'elite',lambda *a:None)
    monkeypatch.setattr(nischen,'waehlen',lambda *a:[('openai','openai/gpt-5.6-luna'),('qwen','qwen/qwen3.8-flash')])
    valid='BEGRÜNDUNG: gestellter Kontrollbeitrag\nVERTRÄGE: keine\nDIFF:\n```diff\n--- a/paket/alpha/a.py\n+++ b/paket/alpha/a.py\n@@ -1 +1 @@\n-x = 1\n+x = 2\n```'
    antwort(monkeypatch,'')
    kontrolle=[('', 'refusal', 'cyber'),(valid, 'stop', None)]
    def senden(*a,**kw):
        text,ende,refusal=kontrolle.pop(0)
        d={'choices':[{'finish_reason':ende,'message':{'content':text,'refusal':refusal}}],
           'usage':{'prompt_tokens':120,'completion_tokens':4}}
        return io.BytesIO(json.dumps(d).encode())
    monkeypatch.setattr(anbieter.urllib.request,'urlopen',senden)
    ids=genesis.erzeugen(db,1,1,1,tmp_path,'paket','alpha',{'tests_fehlgeschlagen':0})
    ks=[dict(z) for z in db.execute('SELECT * FROM kandidaten')]
    assert len(ids)==len(ks)==1 and ks[0]['modell']=='qwen/qwen3.8-flash' and ks[0]['status']=='erzeugt'
    assert not kontrolle
    p=[dict(z) for z in db.execute('SELECT * FROM protokoll')]
    assert sum(z['art']=='modell.ausfall' for z in p)==1
    assert sum(z['art']=='modell.antwort' for z in p)==1
    assert sum(z['art']=='schwarm.kandidat' for z in p)==1
    from biotop.kern import protokoll
    assert protokoll.pruefen(db)[0]
    import os
    if os.environ.get('BIOTOP_T3_VERBUNDBELEG'):
        from pathlib import Path
        Path(os.environ['BIOTOP_T3_VERBUNDBELEG']).write_text(json.dumps({
            'art':'gestellter HTTP-Antworttransport, reale Adapter/Genesis/Kasse/Protokoll-Ausführung',
            'geltung':'Biotop-OpenRouter-Schwarm, NICHT Hermes-Träger-MoA',
            'aufrufe':2,'ausfaelle':1,'beitraege':1,'kandidaten':ks,'protokoll':p,
            'kasse':[dict(z) for z in db.execute('SELECT * FROM kasse')],
            'kostenhinweis':'simulierte Verbrauchsangaben in isolierter Prüf-DB; keine echten Anbieterbuchungen'},ensure_ascii=False,indent=2)+'\n')
