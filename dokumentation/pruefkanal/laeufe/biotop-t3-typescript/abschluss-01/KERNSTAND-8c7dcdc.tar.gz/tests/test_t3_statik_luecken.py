"""Echte ESLint-Kontrollen für generische bisher ungesehene TS-Pfade."""
import json
import os
import pytest
from pathlib import Path
from biotop.kern import typescript
from biotop.organe import kammer


@pytest.mark.integration
def test_typescript_function_prototyp_und_interne_tote_funktion(tmp_path,monkeypatch):
    monkeypatch.setattr(kammer,'IMAGE','biotop-kammer:ts1')
    (tmp_path/'package.json').write_text('{"type":"module"}')
    (tmp_path/'src/alpha').mkdir(parents=True);(tmp_path/'tests').mkdir()
    original='export function doppelt(x:number):number { return x * 2; }\n'
    (tmp_path/'src/alpha/rechner.ts').write_text(original)
    (tmp_path/'tests/test_alpha.test.ts').write_text("import {test,expect} from 'vitest'; import {doppelt} from '../src/alpha/rechner'; test('test_doppelt',()=>expect(doppelt(3)).toBe(6));")
    a=typescript.messen(tmp_path,['alpha'],'src',None)
    mut=original+"\n/* eslint-disable no-new-func, no-extend-native */\nconst unbenutzterWert=123;\nexport function auswerten(s:string){return new Function('return '+s)();}\nfunction unbenutzt(x:number){return x+7;}\nObject.defineProperty(Object.prototype,'gestellteAenderung',{value:1,configurable:true});\n"
    b=typescript.messen(tmp_path,['alpha'],'src',None,{'src/alpha/rechner.ts':mut})
    Path(os.environ.get('T3_STATIK_BELEG','/root/biotop-t3/STATIK-LUECKEN-02.json')).write_text(json.dumps({'kontrolle':a,'gegenprobe':b},ensure_ascii=False,indent=2))
    assert a['gueltig'] and b['gueltig']
    assert a['bereiche']['alpha']['sicherheit_punkte']==0
    bs=b['bereiche']['alpha']
    assert any(x['test']=='no-new-func' for x in bs['sicherheit_befunde'])
    assert any(x['test']=='no-extend-native' for x in bs['sicherheit_befunde'])
    assert any(x['name']=='unbenutzt' for x in bs['tote_liste'])
    assert not any(x['name']=='unbenutzterWert' for x in bs['tote_liste'])
    assert len([x for x in bs['tote_liste'] if x['name']=='auswerten'])==1
