"""Generation-0-Sprachnaht: Verhaltensfang ist nicht Runnerabbruch."""
import sys
from types import SimpleNamespace
import pytest
from biotop.organe import generation0 as G0


@pytest.fixture
def w(tmp_path):
    (tmp_path/'package.json').write_text('{}')
    (tmp_path/'src/alpha').mkdir(parents=True)
    (tmp_path/'src/alpha/a.ts').write_text('export function a(x:number):number{return x+1;}')
    return tmp_path


@pytest.mark.parametrize('gueltig,faelle,soll,grundmuster',[
    (True,{'tests/test_alpha.test.ts::test_a':{'ok':True,'bestaetigt':False}},False,''),
    (True,{'tests/test_alpha.test.ts::test_a':{'ok':False,'bestaetigt':True,'meldung':'AssertionError'}},True,'test_a'),
    (False,{},None,None),
    # Ein Testfehler OHNE Bestätigung im Werk (Importfehler) ist kein Verhaltensfang —
    # aber auch kein Laufabbruch. Bis Lauf 32 warf diese Stelle und beendete damit die
    # ganze Mutantenkampagne an einer einzelnen unbrauchbaren Testdatei; der Python-Zweig
    # derselben Funktion liefert für jeden Ausgang ein Tupel (Commit „Zweigklasse").
    # Geprüft wird der GRUND, nicht nur dass nichts abstürzt: sonst wäre lautes Sterben
    # gegen stilles Nichtstun getauscht und der Test würde das nicht bemerken.
    (True,{'tests/test_alpha.test.ts::test_a':{'ok':False,'bestaetigt':False,'meldung':'Importfehler'}},
     False,'ohne Bestätigung')])
def test_mutantenfang_typescript_braucht_ausgefuehrtes_verhalten(w,monkeypatch,gueltig,faelle,soll,grundmuster):
    m=SimpleNamespace(baulauf=lambda *a,**kw:{'gueltig':True,'baut':True},
                      testlauf=lambda *a,**kw:{'gueltig':gueltig,'faelle':faelle,'grund':'gestellt'})
    import biotop.kern
    monkeypatch.setitem(sys.modules,'biotop.kern.typescript',m)
    monkeypatch.setattr(biotop.kern,'typescript',m,raising=False)
    if soll is None:
        with pytest.raises(RuntimeError): G0._testlauf(w,{})
    else:
        gefangen,von=G0._testlauf(w,{})
        assert gefangen is soll
        if grundmuster:
            assert grundmuster in von, f'Grund fehlt oder nennt die Ursache nicht: {von!r}'
        else:
            assert von == '', f'bestandener Testlauf nennt keinen Grund, erhielt: {von!r}'


@pytest.mark.parametrize('bau,test,soll_grund',[
    ({'gueltig':True,'baut':False,'grund':'TS2322: Type mismatch'},None,'Typbau nicht bestanden'),
    ({'gueltig':True,'baut':True},
     {'gueltig':False,'art':'inhalt','grund':'Collection-/Suite-/Runnerfehler','faelle':{}},
     'Testnachweis unbrauchbar'),
    ({'gueltig':True,'baut':True},
     {'gueltig':True,'art':None,'faelle':{}},
     'keine ausgeführten Testfälle')])
def test_jeder_nichtfang_nennt_seine_ursache(w,monkeypatch,bau,test,soll_grund):
    """Jeder neutrale Ausgang trägt seinen Grund — sonst ist Stillstand unsichtbar.

    Die Reparatur ersetzte drei RuntimeError durch (False, Grund). Ohne Prüfung des
    Grundes wäre nicht unterscheidbar, ob der Mutant wirklich nicht gefangen wurde
    oder ob das Messgerät stillschweigend nichts getan hat.
    """
    m=SimpleNamespace(baulauf=lambda *a,**kw:bau,
                      testlauf=lambda *a,**kw:test or {'gueltig':True,'art':None,'faelle':{}})
    import biotop.kern
    monkeypatch.setitem(sys.modules,'biotop.kern.typescript',m)
    monkeypatch.setattr(biotop.kern,'typescript',m,raising=False)
    gefangen,von=G0._testlauf(w,{})
    assert gefangen is False
    assert soll_grund in von, f'erwarteter Grund {soll_grund!r} fehlt in {von!r}'
    assert 'kein Verhaltensfang' in von, f'Kennzeichnung fehlt in {von!r}'


def test_ts_blinder_mutant_erhaelt_vitest_statt_pytest(w,db_lauf,monkeypatch):
    code="import {test,expect} from 'vitest'; test('test_a',()=>expect(2).toBe(2));"
    antwort=SimpleNamespace(text='```typescript\n'+code+'\n```')
    aufrufe=[]
    def modell(*a,**kw):
        aufrufe.append(a[4]); return antwort
    monkeypatch.setattr(G0,'aufrufen',modell)
    monkeypatch.setattr(G0.nischen,'waehlen',lambda *a:[('qwen','qwen/qwen3.8-flash')])
    monkeypatch.setattr(G0.nischen,'buchen',lambda *a:None)
    def testlauf(werk,dateien,testdateien=None,**kw):
        ok='src/alpha/a.ts' not in dateien
        return {'gueltig':True,'faelle':{'tests/test_alpha_gen0_m1.test.ts::test_a':{'ok':ok,'bestaetigt':not ok}}}
    m=SimpleNamespace(testlauf=testlauf)
    import biotop.kern
    monkeypatch.setitem(sys.modules,'biotop.kern.typescript',m)
    monkeypatch.setattr(biotop.kern,'typescript',m,raising=False)
    mutant={'datei':'src/alpha/a.ts','code':'export function a(x:number){return x-1;}','zeile':1,'art':'arithmetik','beschreibung':'+ nach -'}
    r=G0.tests_evolutionieren(db_lauf,1,1,w,'src',[mutant],{id(mutant):1})
    assert list(r['neue_tests'])==['tests/test_alpha_gen0_m1.test.ts']
    assert 'Vitest' in aufrufe[0]
