"""TS-Fundneubewertung darf Testnamen/Ergebnisse nicht als Python lesen."""
import sys
from types import SimpleNamespace
import pytest
from biotop.organe import fundpruefung as F

CODE="import {test,expect} from 'vitest'; test('test_wert',()=>expect(wert(2)).toBe(4));"


@pytest.mark.parametrize('gueltig,ok,ort,meldung,erwartet',[
    (True,True,'','',(True,False)),
    (True,False,'tests/test_neubewertung_probe.test.ts','AssertionError: Abweichung',(False,False)),
    (True,False,'src/alpha/a.ts','RangeError: ungültig',(False,True)),
    (False,False,'','Sammelfehler',None)])
def test_fundneubewertung_ts_uebergibt_vitest_paar(tmp_path,monkeypatch,gueltig,ok,ort,meldung,erwartet):
    (tmp_path/'package.json').write_text('{}'); (tmp_path/'src/alpha').mkdir(parents=True)
    (tmp_path/'src/alpha/a.ts').write_text('export function wert(x:number){return x;}')
    def testlauf(w,dateien,tests):
        assert tests==['tests/test_neubewertung_probe.test.ts']
        return {'gueltig':gueltig,'grund':meldung,'faelle':{tests[0]+'::test_wert':{
            'ok':ok,'bestaetigt':not ok,'ort':ort,'meldung':meldung}},'roh':'gestellt'}
    m=SimpleNamespace(testlauf=testlauf,testfunktionen=lambda c:[{'name':'test_wert'}])
    import biotop.kern
    monkeypatch.setitem(sys.modules,'biotop.kern.typescript',m)
    monkeypatch.setattr(biotop.kern,'typescript',m,raising=False)
    assert F._testnamen(CODE)==['test_wert']
    if erwartet is None:
        with pytest.raises(RuntimeError,match='Nachweis'): F._ausfuehren(tmp_path,'probe',CODE)
    else:
        assert F._ausfuehren(tmp_path,'probe',CODE)[:2]==erwartet
