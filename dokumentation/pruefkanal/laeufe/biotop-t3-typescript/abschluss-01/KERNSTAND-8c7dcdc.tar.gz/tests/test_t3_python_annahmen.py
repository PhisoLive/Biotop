"""Prüft dauerhaft: Keine ungeschützte Python-Annahme im TypeScript-Pfad.

Lauf 31 starb an einer einzelnen solchen Stelle (gedaechtnis.aenderungsziel). Diese
Stellen einzeln zu finden, indem jeweils ein Lauf stirbt, ist der langsamste Weg —
deshalb prüft dieser Test den gesamten Kern in einem Zug und hält das Ergebnis fest.

Geprüft werden vier Annahmen, die im TS-Pfad falsch wären:
  def-Muster, .py-Endung, pytest-Auswertung, Python-Syntaxbaum.

Eine Fundstelle gilt als geschützt, wenn eine Sprachweiche in derselben Funktion
oder an jeder ihrer Aufrufstellen steht. Ungerufene Funktionen (toter Code) können
keinen Lauf töten. Fälle, deren Weiche weiter oben in der Kette steht, als eine
Textsuche auflösen kann, stehen in GEPRUEFT — mit Begründung und Zeilennachweis.
"""
import ast
import re
import subprocess
from pathlib import Path

import pytest

KERN = Path(__file__).resolve().parents[1] / 'biotop'

MUSTER = {
    'def-muster': re.compile(r'''["'](?:async\s+)?def\s|f["']def '''),
    # `.py` nur, wenn es die einzige geprüfte Endung ist — eine Liste, die .mjs/.js
    # mitführt, ist sprachneutral und kein Befund.
    'py-endung': re.compile(r'''endswith\(["']\.py["']\)|removesuffix\(["']\.py["']\)|rglob\(["']\*\.py["']\)'''),
    'pytest-auswertung': re.compile(r'''pytest_rc|pytest-nachweis|pytest_tail|['"]-m['"],\s*['"]pytest|--tb='''),
    'python-ast': re.compile(r'''\bast\.(parse|walk|unparse|FunctionDef|AsyncFunctionDef)'''),
}
WEICHE = re.compile(r'ist_typescript|sprachprofil|typescript|TypeScript|\.ts["\']|_ts\b|'
                    r'Vitest|testendung|testname_ohne|\.mjs|tests_ist_ts')

# Ungerufen und deshalb ohne Laufrisiko; benannt, damit es auffällt, wenn sich das ändert.
UNGERUFEN_ERLAUBT = {'biotop/organe/eichproben.py::_beschleunigen'}

# Von Hand geprüft: Die Weiche steht weiter oben in der Aufrufkette, als eine
# Textsuche zuverlässig auflöst. Jeder Eintrag nennt die Weiche mit Zeilennachweis.
# Neue Fundstellen gehören NICHT hierher, sondern behoben.
GEPRUEFT = {
    'biotop/kern/befundklassen.py::_immuntest_shell':
        'Gerufen nur von immuntest_code (befundklassen.py:74). immuntest_code wird in '
        'aegis.py:216 im else-Zweig gerufen; aegis.py:213 nimmt für TypeScript '
        'immuntest_typescript. Die Weiche steht damit zwei Ebenen höher.',
    'biotop/organe/eichproben.py::_funktionen':
        'Die Treffer in eichproben_ts.py:32 und :113 gelten dessen EIGENEM _funktionen '
        '(eichproben_ts.py:6), nicht diesem — Namensgleichheit. Der Treffer in '
        'eichproben.py:99 steht in _beschleunigen, das nirgends gerufen wird. Die echten '
        'Aufrufer eichproben.py:71, :149 und :411 haben die Weiche unmittelbar davor.',
}


def _funktionen_mit_annahme(wurzel):
    out = {}
    for p in sorted(Path(wurzel).rglob('*.py')):
        if '__pycache__' in p.parts:
            continue
        quelle = p.read_text()
        zeilen = quelle.splitlines()
        try:
            baum = ast.parse(quelle)
        except SyntaxError:
            continue
        for kn in ast.walk(baum):
            if not isinstance(kn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            koerper = '\n'.join(zeilen[kn.lineno - 1:(kn.end_lineno or kn.lineno)])
            if WEICHE.search(koerper):
                continue
            arten = [a for a, m in MUSTER.items() if m.search(koerper)]
            if arten:
                out[(str(p.relative_to(Path(wurzel).parent)), kn.name, kn.lineno)] = arten
    return out


def _aufrufstellen(wurzel, name, heimatdatei):
    """Aufrufstellen von `name`. Gleichnamige Funktionen in anderen Dateien zählen nur,
    wenn die Heimatdatei dort importiert oder der Aufruf qualifiziert wird."""
    modul = Path(heimatdatei).stem
    r = subprocess.run(['grep', '-rn', rf'\b{re.escape(name)}(', str(wurzel), '--include=*.py'],
                       capture_output=True, text=True)
    stellen = []
    for z in r.stdout.splitlines():
        try:
            datei, nr, inhalt = z.split(':', 2)
        except ValueError:
            continue
        if re.search(rf'def\s+{re.escape(name)}\s*\(', inhalt):
            continue
        if not re.search(rf'(?<![\w])(?:\w+\.)?{re.escape(name)}\s*\(', inhalt):
            continue
        rel = str(Path(datei).relative_to(Path(wurzel).parent))
        text = Path(datei).read_text().splitlines()
        if rel != heimatdatei:
            quelle = '\n'.join(text)
            if not (re.search(rf'import\s+{modul}\b', quelle)
                    or re.search(rf'from\s+\.{{0,2}}{modul}\s+import', quelle)
                    or f'{modul}.{name}(' in inhalt):
                continue
        i = int(nr) - 1
        umgebung = '\n'.join(text[max(0, i - 12):i + 2])
        stellen.append((f'{rel}:{nr}', bool(WEICHE.search(umgebung))))
    return stellen


def pruefen(wurzel, geprueft, ungerufen_erlaubt):
    """Gibt die Liste ungeschützter Fundstellen zurück (leer = sauber)."""
    offen = []
    for (datei, name, zeile), arten in _funktionen_mit_annahme(wurzel).items():
        stellen = _aufrufstellen(wurzel, name, datei)
        if not stellen:
            if f'{datei}::{name}' not in ungerufen_erlaubt:
                offen.append(f'{datei}:{zeile} {name}() {arten} — nirgends gerufen und '
                             'nicht in UNGERUFEN_ERLAUBT begründet')
            continue
        ungeschuetzt = [s for s, g in stellen if not g]
        if ungeschuetzt and f'{datei}::{name}' not in geprueft:
            offen.append(f'{datei}:{zeile} {name}() {arten} — ungeschützt gerufen von '
                         + ', '.join(ungeschuetzt[:4]))
    return offen


def test_keine_ungeschuetzte_python_annahme_im_kern():
    offen = pruefen(KERN, GEPRUEFT, UNGERUFEN_ERLAUBT)
    assert not offen, ('Python-Annahmen ohne Sprachweiche im TypeScript-Pfad:\n  '
                       + '\n  '.join(offen))


def test_geprueft_liste_enthaelt_nur_noch_vorhandene_stellen():
    """Die Ausnahmeliste darf nicht veralten: jeder Eintrag muss noch existieren."""
    vorhanden = {f'{d}::{n}' for (d, n, _) in _funktionen_mit_annahme(KERN)}
    veraltet = set(GEPRUEFT) - vorhanden
    assert not veraltet, f'Einträge ohne Fundstelle — bitte entfernen: {sorted(veraltet)}'
    for schluessel, grund in GEPRUEFT.items():
        assert len(grund) > 80, f'{schluessel}: Begründung zu dünn'


def _fake_kern(tmp_path, quelltext):
    fake = tmp_path / 'biotop'
    (fake / 'organe').mkdir(parents=True)
    (fake / 'organe' / 'x.py').write_text(quelltext)
    return fake


def test_der_waechter_findet_eine_eingebaute_annahme(tmp_path):
    """Gegenprobe: Ein absichtlich ungeschützter Python-Griff wird gemeldet.

    Ohne sie könnte der Wächter durch einen zu engen Suchausdruck blind sein und
    trotzdem grün melden.
    """
    fake = _fake_kern(tmp_path,
                      'import ast\n'
                      'def ziel_raten(code):\n'
                      '    return [k.name for k in ast.walk(ast.parse(code))]\n'
                      'def ruft():\n'
                      '    return ziel_raten("x")\n')
    offen = pruefen(fake, {}, set())
    assert offen and 'ziel_raten' in offen[0], offen


def test_der_waechter_schweigt_bei_geschuetzter_annahme(tmp_path):
    """Zweite Gegenprobe: derselbe Griff MIT Sprachweiche wird nicht gemeldet.

    Sonst könnte der Wächter alles melden und wäre ebenso wertlos.
    """
    fake = _fake_kern(tmp_path,
                      'import ast\n'
                      'from ..kern import sprachprofil\n'
                      'def ziel_raten(pfad, code):\n'
                      '    if sprachprofil.ist_typescript(pfad):\n'
                      '        return []\n'
                      '    return [k.name for k in ast.walk(ast.parse(code))]\n'
                      'def ruft(pfad):\n'
                      '    return ziel_raten(pfad, "x")\n')
    assert pruefen(fake, {}, set()) == []
