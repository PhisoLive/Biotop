"""Vitest transpiliert Typfehler: ein solcher Fehlschlag ist kein Mutantenfang."""
import json
from pathlib import Path
import pytest
from biotop.organe import generation0 as G0, kammer


@pytest.mark.integration
def test_typfehler_zaehlt_nicht_als_verhaltensfang(tmp_path,monkeypatch):
    monkeypatch.setattr(kammer,'IMAGE','biotop-kammer:ts1')
    (tmp_path/'package.json').write_text('{"type":"module"}')
    (tmp_path/'src/a').mkdir(parents=True);(tmp_path/'tests').mkdir()
    (tmp_path/'src/a/wert.ts').write_text('export function wert(): number {return 2;}')
    (tmp_path/'tests/test_a.test.ts').write_text("import {test,expect} from 'vitest';import {wert} from '../src/a/wert';test('zahl',()=>expect(wert()).toBe(2));")
    with pytest.raises(RuntimeError,match='Typbau'):
        G0._testlauf(tmp_path,{'src/a/wert.ts':'export function wert(): number {return "zwei";}'})
    # Gleichartige typgültige Verhaltensänderung muss weiterhin ein Fang sein.
    assert G0._testlauf(tmp_path,{'src/a/wert.ts':'export function wert(): number {return 3;}'})[0]
    assert not G0._testlauf(tmp_path,{})[0]
