import pytest
from biotop import lauf
from biotop.kern import datenbank, protokoll
from biotop.organe import genesis, vertraege


def test_missgebildete_antwort_ist_nicht_neutraler_verzicht():
    f=getattr(genesis,'antwortstatus',None)
    assert callable(f)
    assert f('KEIN VORSCHLAG — kein Fund')=='leer'
    assert f('')=='ausfall'
    assert f('irgendwas ohne Vorschlag und Format')=='ausfall'
    assert f('BEGRÜNDUNG: x\nVERTRÄGE: keine\nDIFF:\n```diff\n--- a/p/a.py\n+++ b/p/a.py\n@@ -1 +1 @@\n-a\n+b\n```')=='erzeugt'


def test_alle_ausfaelle_bestaetigen_keine_verhandlung(db_lauf,tmp_path,monkeypatch,messung):
    from pathlib import Path
    w={'id':1}
    vertraege.einlegen(db_lauf,1,tmp_path,{('alpha','beta'):'def test_vertrag():\n assert True\n'},'Unit')
    kid=db_lauf.execute("INSERT INTO kandidaten(lauf_id,generation,bereich,nische,status,diff,begruendung,vertraege) VALUES(1,1,'alpha','sicher','ueberlebt','', '', 'test_vertrag_alpha_beta')").lastrowid
    monkeypatch.setattr(genesis,'erzeugen',lambda *a,**kw:[])
    u={'status':'ueberlebt','grund':'gestellt','vertrag_verletzt':[],'vertrag_dateien':['tests/vertraege/test_vertrag_alpha_beta.py']}
    r=lauf._verhandeln(db_lauf,1,w,1,tmp_path,'paket',['alpha','beta'],[],messung(),messung(),None,{},'alpha',kid,u)
    assert r['status']=='abgelehnt'
    assert not db_lauf.execute("SELECT 1 FROM protokoll WHERE art='verhandlung.bestanden'").fetchone()
