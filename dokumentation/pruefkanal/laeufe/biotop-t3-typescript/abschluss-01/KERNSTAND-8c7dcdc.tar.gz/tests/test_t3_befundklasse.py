"""Sicherheitsklasse muss TS ausführen und Ausführung vor Ablehnung erkennen."""
import json
import os
from pathlib import Path
import pytest
from biotop.kern import datenbank, typescript
from biotop.organe import aegis, verfassung, kammer


@pytest.mark.integration
def test_typescript_immuntests_gegen_sauber_unsicher_und_spaete_ablehnung(tmp_path,monkeypatch):
    monkeypatch.setattr(kammer,'IMAGE','biotop-kammer:ts1')
    (tmp_path/'package.json').write_text('{"type":"module"}')
    (tmp_path/'src/a').mkdir(parents=True);(tmp_path/'tests').mkdir()
    sauber="export function rechnen(text:string):number {if(text==='1+2')return 3;throw new Error('unzulässig');}\n"
    (tmp_path/'src/a/rechner.ts').write_text(sauber)
    db=datenbank.verbinden(tmp_path/'d.db')
    verfassung.einlegen(db,1,'2. Keine Eingabeausführung',{'einstiege':{'no-new-func':{'a':{
        'sprache':'TypeScript','import':"import {rechnen} from '../src/a/rechner.js';",
        'aufruf':'rechnen({formel})','fehler_import':'','fehler':'Error'}}}},'Prüfung','Hermes')
    dateien=aegis.befundklassen_tests(db,1,'a',{'bereiche':{'a':{'sicherheit_befunde':[{'test':'no-new-func'}]}}})
    assert dateien and all(p.endswith('.test.ts') for p in dateien)
    varianten={'sauber':sauber,
        'unsicher':"export function rechnen(text:string):number{return new Function('return ('+text+')')();}",
        'spaet':"export function rechnen(text:string):number{new Function('return ('+text+')')();throw new Error('unzulässig');}"}
    belege={}
    for name,code in varianten.items():
        r=typescript.testlauf(tmp_path,{**dateien,'src/a/rechner.ts':code},list(dateien))
        belege[name]=r
        assert r['gueltig'] and r['faelle'],r
        assert all(x['ok'] for x in r['faelle'].values()) is (name=='sauber')
        if name=='spaet':
            assert any(not x['ok'] and 'AUSGEFUEHRT' in x['meldung'] for x in r['faelle'].values())
    Path(os.environ.get('T3_BEFUND_BELEG','/root/biotop-t3/BEFUNDKLASSE-TS.json')).write_text(json.dumps(belege,ensure_ascii=False,indent=2))
    db.close()
