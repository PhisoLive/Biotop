import hashlib
import pytest
from test_vorspann import unit_vorspann
from biotop.organe import vorspann
from biotop.kern import protokoll


def test_geaenderter_vertrag_vor_freeze_macht_eichung_ungueltig(unit_vorspann):
    con,_=unit_vorspann
    r=vorspann.ausfuehren(con,1)
    from pathlib import Path
    g=r['gegenstand']['gegenstand']
    werk=Path(r['quellen']['werk']['pfad'])
    (werk/g['vertrag_pfad']).write_text('def test_vertrag_anderer_inhalt():\n    assert True\n')
    protokoll.schreiben(con,'generation0.ergebnis',lauf_id=1,erreicht=True,gefangen_nachher=80,nicht_aequivalent=100,ziel=80)
    with pytest.raises(vorspann.VorspannFehler,match='Eichgegenstand|Verträg'):
        vorspann.verlangen(con,1,'mass')
