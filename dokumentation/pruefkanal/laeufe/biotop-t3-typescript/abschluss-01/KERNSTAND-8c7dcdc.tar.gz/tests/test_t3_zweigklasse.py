"""Fehlerklasse: Der TypeScript-Zweig wirft, wo der Python-Zweig ein Ergebnis liefert.

Lauf 31 und 32 starben an dieser Klasse an zwei Stellen (gedaechtnis.aenderungsziel,
aegis.junit_lauf). Ein Zweigvergleich über alle 25 Sprachweichen des Kerns fand drei
weitere ungeprüfte Stellen. Alle haben dieselbe Form:

    if ist_typescript(...):
        ...
        raise RuntimeError(...)      # TS: Lauf stirbt
    ...
    return None / return "?|name"    # Python: Ergebnis, Aufrufer entscheidet

Keiner der Aufrufer fängt die Ausnahme ab, jede tötet den ganzen Lauf. Was der
Python-Zweig als Ergebnis behandelt, muss der TypeScript-Zweig ebenso behandeln —
ausgenommen echte Infrastrukturfehler, die ohne Messgerät kein Urteil zulassen.
"""
from pathlib import Path

import pytest

from biotop.kern import typescript
from biotop.organe import aegis, generation0

WERK = Path('/root/biotop/daten/werke/versandwerk-t3-02')


# ---------------------------------------------------------------- _anhaengen
def test_anhaengen_ts_gibt_none_statt_zu_werfen():
    """TS-Tests gehören in eine eigene Datei — das ist ein 'nein', kein Absturz.

    Der Python-Zweig gibt bei unbrauchbarer Eingabe None zurück (SyntaxError,
    keine neuen Funktionen). Der Aufrufer aegis.py:671 prüft auf Falschheit.
    """
    alt = "import {test, expect} from 'vitest';\ntest('a', () => expect(1).toBe(1));\n"
    neu = "import {test, expect} from 'vitest';\ntest('b', () => expect(2).toBe(2));\n"
    assert aegis._anhaengen(alt, neu, {'b'}) is None


def test_anhaengen_python_bleibt_unveraendert():
    """Gegenprobe: der Python-Weg hängt weiterhin an."""
    alt = 'def test_a():\n    assert True\n'
    neu = 'def test_b():\n    assert True\n'
    r = aegis._anhaengen(alt, neu, {'test_b'})
    assert r and 'test_a' in r and 'test_b' in r


# ---------------------------------------------------------------- behauptung
def test_behauptung_ts_unableitbar_gibt_platzhalter():
    """Nicht ableitbare Behauptung ist ein Platzhalter, kein Abbruch.

    Der Python-Zweig liefert '?|name' bei SyntaxError oder fehlender Funktion.
    Die Aufrufer (aegis.py:365, 541, 728, 741, 752) bauen daraus Doppelungs-
    schlüssel — ein Platzhalter ist dort vorgesehen, eine Ausnahme nicht.
    """
    code = "import {test} from 'vitest';\ntest('vorhanden', () => {});\n"
    assert aegis.behauptung(code, 'nicht_vorhanden', 'src') == '?|nicht_vorhanden'


def test_behauptung_ts_ableitbar_liefert_schluessel():
    """Gegenprobe: eine ableitbare Behauptung liefert weiterhin ihren Schlüssel."""
    code = ("import {test, expect} from 'vitest';\n"
            "import {skalar} from '../src/tarife/preise.js';\n"
            "test('test_skalar_zahl', () => { expect(skalar(100)).toBe(100); });\n")
    schl = aegis.behauptung(code, 'test_skalar_zahl', 'src')
    assert schl and not schl.startswith('?|'), schl


def test_behauptung_python_bleibt_unveraendert():
    code = 'def test_x():\n    assert 1 == 1\n'
    assert aegis.behauptung(code, 'fehlt_hier', 'paket') == '?|fehlt_hier'


# ---------------------------------------------------------------- gen0 _testlauf
def test_gen0_typfehler_ist_kein_fang_und_kein_abbruch(monkeypatch):
    """Ein Mutant, der nicht baut, ist nicht gefangen — aber tötet den Lauf nicht.

    Der Python-Zweig kennt diesen Fall gar nicht (Python baut nicht), liefert aber
    für jeden Ausgang ein Tupel. Die Aufrufer (generation0.py:174, 207, 233)
    entpacken es sofort; eine Ausnahme dort beendet die Mutantenkampagne.
    """
    monkeypatch.setattr(typescript, 'baulauf',
                        lambda *a, **kw: {'gueltig': True, 'baut': False, 'grund': 'TS2322'})
    gefangen, von = generation0._testlauf(WERK, {'src/x.ts': 'kaputt'})
    assert gefangen is False, 'ein Typfehler ist kein Verhaltensfang'
    assert 'Typbau' in von or 'TS2322' in von


def test_gen0_unbrauchbarer_testlauf_ist_kein_fang(monkeypatch):
    """Unsammelbare Tests am Mutanten: kein Fang, kein Abbruch."""
    monkeypatch.setattr(typescript, 'baulauf',
                        lambda *a, **kw: {'gueltig': True, 'baut': True})
    monkeypatch.setattr(typescript, 'testlauf',
                        lambda *a, **kw: {'gueltig': False, 'art': 'inhalt',
                                          'grund': 'Collection-/Suite-/Runnerfehler', 'faelle': {}})
    gefangen, von = generation0._testlauf(WERK, {'src/x.ts': 'x'})
    assert gefangen is False
    assert 'Collection' in von or 'Nachweis' in von


def test_gen0_infrastrukturfehler_bleibt_abbruch(monkeypatch):
    """Gegenprobe: ohne laufendes Messgerät gibt es kein Urteil — hier MUSS geworfen werden."""
    monkeypatch.setattr(typescript, 'baulauf',
                        lambda *a, **kw: {'gueltig': True, 'baut': True})
    monkeypatch.setattr(typescript, 'testlauf',
                        lambda *a, **kw: {'gueltig': False, 'art': 'infrastruktur',
                                          'grund': 'Vitest-Runnerabbruch', 'faelle': {}})
    with pytest.raises(RuntimeError, match='Vitest|Nachweis'):
        generation0._testlauf(WERK, {'src/x.ts': 'x'})


def test_gen0_unbestaetigter_testfehler_ist_kein_fang(monkeypatch):
    """Ein Testfehler ohne Bestätigung im Werk zählt nicht als Verhaltensfang."""
    monkeypatch.setattr(typescript, 'baulauf',
                        lambda *a, **kw: {'gueltig': True, 'baut': True})
    monkeypatch.setattr(typescript, 'testlauf',
                        lambda *a, **kw: {'gueltig': True, 'art': None, 'faelle': {
                            'tests/a.test.ts::x': {'ok': False, 'bestaetigt': False,
                                                   'meldung': 'ReferenceError', 'ort': ''}}})
    gefangen, von = generation0._testlauf(WERK, {'src/x.ts': 'x'})
    assert gefangen is False, 'unbestätigter Fehler ist kein Fang'
