"""Jede neutrale Rückgabe wird mit ihrem Grund gezählt — sonst ist Schweigen unsichtbar.

Die Reparatur der Fehlerklasse (Commits a97eb45, 2e21059, c214d1d) ersetzte an vier
Stellen "laut sterben" durch "neutral zurückgeben". Gemessen an den Läufen 31, 32 und 34
war danach nur EINE der vier Stellen überhaupt zählbar, und auch die nur erschlossen:

  gedaechtnis.wiederholung  12 Enthaltungen von 63 Kandidaten — aus dem Aegis-Grund gelesen
  generation0._testlauf      0 von 172 Mutantenläufen — Grund wird nicht protokolliert
  aegis.behauptung           0 von 0 — Urteile persistieren nicht
  aegis._anhaengen           nicht belegbar — keine Protokollierung

Damit war lautes Sterben gegen stilles Nichtstun getauscht: Ein Organ, das für
TypeScript dauerhaft schweigt, sähe aus wie ein Organ, das arbeitet.

Maßstab (Chat-Claude, vor der Messung gesetzt): Eine Torzeile, die an einem Organ
hängt, gilt für TypeScript nur als belegt, wenn das Organ in MEHR ALS DER HÄLFTE
seiner Fälle geurteilt hat.

Jeder Zähler hier hat eine Gegenprobe: ein erzwungener neutraler Fall muss tatsächlich
in der Datenbank landen.
"""
import json
from pathlib import Path

import pytest

from biotop.kern import datenbank, protokoll, typescript
from biotop.organe import aegis, generation0, neutralzaehler


@pytest.fixture
def con(tmp_path, monkeypatch):
    monkeypatch.setattr(datenbank, 'DB_PFAD', tmp_path / 'p.db')
    c = datenbank.verbinden()
    c.execute("INSERT INTO laeufe(id,budget_eur,status,begonnen_am) VALUES (35,10.0,'bereit',?)",
              (protokoll.jetzt(),))
    c.commit()
    return c


@pytest.fixture
def werk(tmp_path):
    w = tmp_path / 'w'
    (w / 'src' / 'alpha').mkdir(parents=True)
    (w / 'package.json').write_text('{}')
    (w / 'src/alpha/a.ts').write_text('export function a(x:number):number{return x+1;}')
    return w


# ---------------------------------------------------------------- Schreibweg
def test_zaehler_schreibt_organ_grund_und_nenner(con):
    neutralzaehler.neutral(con, 35, 'aegis.behauptung', 'platzhalter',
                           einzelheit='test_x')
    neutralzaehler.geurteilt(con, 35, 'aegis.behauptung')
    neutralzaehler.geurteilt(con, 35, 'aegis.behauptung')
    z = neutralzaehler.stand(con, 35)
    assert z['aegis.behauptung'] == {'neutral': 1, 'geurteilt': 2, 'gesamt': 3,
                                     'anteil_geurteilt': round(2 / 3, 3),
                                     'gruende': {'platzhalter': 1}}


def test_torzeile_verlangt_mehrheit_geurteilter_faelle(con):
    """Der Maßstab steht im Kern, nicht im Bericht."""
    for _ in range(3):
        neutralzaehler.neutral(con, 35, 'x.organ', 'schweigt')
    for _ in range(2):
        neutralzaehler.geurteilt(con, 35, 'x.organ')
    assert neutralzaehler.traegt_torzeile(con, 35, 'x.organ') is False, '2 von 5 ist keine Mehrheit'
    neutralzaehler.geurteilt(con, 35, 'x.organ')
    neutralzaehler.geurteilt(con, 35, 'x.organ')
    assert neutralzaehler.traegt_torzeile(con, 35, 'x.organ') is True, '4 von 7 ist eine Mehrheit'


def test_organ_ohne_faelle_traegt_keine_torzeile(con):
    """Null Fälle sind keine Mehrheit — dieselbe Klasse wie die leere Eichprobe."""
    assert neutralzaehler.traegt_torzeile(con, 35, 'nie.gerufen') is False


# ------------------------------------------------ Gegenproben je Zählstelle
def test_gegenprobe_behauptung_platzhalter_wird_gezaehlt(con, monkeypatch):
    """Erzwungener Platzhalter muss in der Datenbank landen."""
    code = "import {test} from 'vitest';\ntest('vorhanden', () => {});\n"
    monkeypatch.setattr(aegis, '_zaehlkontext', lambda: (con, 35))
    schl = aegis.behauptung(code, 'fehlt_hier', 'src')
    assert schl == '?|fehlt_hier'
    z = neutralzaehler.stand(con, 35)
    assert z['aegis.behauptung']['neutral'] == 1
    assert z['aegis.behauptung']['gruende'] == {'behauptung_nicht_ableitbar': 1}


def test_gegenprobe_behauptung_ableitbar_zaehlt_als_geurteilt(con, monkeypatch):
    code = ("import {test, expect} from 'vitest';\n"
            "import {a} from '../src/alpha/a.js';\n"
            "test('test_a_zahl', () => { expect(a(1)).toBe(2); });\n")
    monkeypatch.setattr(aegis, '_zaehlkontext', lambda: (con, 35))
    schl = aegis.behauptung(code, 'test_a_zahl', 'src')
    assert not schl.startswith('?|')
    z = neutralzaehler.stand(con, 35)
    assert z['aegis.behauptung']['geurteilt'] == 1
    assert z['aegis.behauptung']['neutral'] == 0


def test_gegenprobe_anhaengen_none_wird_gezaehlt(con, monkeypatch):
    alt = "import {test, expect} from 'vitest';\ntest('a', () => expect(1).toBe(1));\n"
    neu = "import {test, expect} from 'vitest';\ntest('b', () => expect(2).toBe(2));\n"
    monkeypatch.setattr(aegis, '_zaehlkontext', lambda: (con, 35))
    assert aegis._anhaengen(alt, neu, {'b'}) is None
    z = neutralzaehler.stand(con, 35)
    assert z['aegis._anhaengen']['neutral'] == 1
    assert z['aegis._anhaengen']['gruende'] == {'typescript_eigene_datei': 1}


def test_gegenprobe_anhaengen_python_zaehlt_als_geurteilt(con, monkeypatch):
    monkeypatch.setattr(aegis, '_zaehlkontext', lambda: (con, 35))
    r = aegis._anhaengen('def test_a():\n    assert True\n',
                         'def test_b():\n    assert True\n', {'test_b'})
    assert r and 'test_b' in r
    assert neutralzaehler.stand(con, 35)['aegis._anhaengen']['geurteilt'] == 1


@pytest.mark.parametrize('bau,test,grund', [
    ({'gueltig': True, 'baut': False, 'grund': 'TS2322'}, None, 'typbau_nicht_bestanden'),
    ({'gueltig': True, 'baut': True},
     {'gueltig': False, 'art': 'inhalt', 'grund': 'Collection', 'faelle': {}},
     'testnachweis_unbrauchbar'),
    ({'gueltig': True, 'baut': True}, {'gueltig': True, 'faelle': {}},
     'keine_testfaelle'),
    ({'gueltig': True, 'baut': True},
     {'gueltig': True, 'faelle': {'t::x': {'ok': False, 'bestaetigt': False}}},
     'ohne_bestaetigung'),
])
def test_gegenprobe_testlauf_jeder_nichtfang_wird_gezaehlt(con, werk, monkeypatch, bau, test, grund):
    monkeypatch.setattr(typescript, 'baulauf', lambda *a, **kw: bau)
    monkeypatch.setattr(typescript, 'testlauf',
                        lambda *a, **kw: test or {'gueltig': True, 'faelle': {}})
    monkeypatch.setattr(generation0, '_zaehlkontext', lambda: (con, 35))
    gefangen, von = generation0._testlauf(werk, {})
    assert gefangen is False
    z = neutralzaehler.stand(con, 35)
    assert z['generation0._testlauf']['neutral'] == 1
    assert z['generation0._testlauf']['gruende'] == {grund: 1}


def test_gegenprobe_testlauf_echter_fang_zaehlt_als_geurteilt(con, werk, monkeypatch):
    monkeypatch.setattr(typescript, 'baulauf', lambda *a, **kw: {'gueltig': True, 'baut': True})
    monkeypatch.setattr(typescript, 'testlauf', lambda *a, **kw: {
        'gueltig': True, 'faelle': {'t::x': {'ok': False, 'bestaetigt': True}}})
    monkeypatch.setattr(generation0, '_zaehlkontext', lambda: (con, 35))
    gefangen, von = generation0._testlauf(werk, {})
    assert gefangen is True
    assert neutralzaehler.stand(con, 35)['generation0._testlauf']['geurteilt'] == 1


def test_gegenprobe_wiederholung_enthaltung_wird_gezaehlt(con, werk, monkeypatch):
    """Nicht anwendbarer TS-Diff: die Prüfung enthält sich und zählt das."""
    from biotop.organe import gedaechtnis
    monkeypatch.setattr(gedaechtnis, '_zaehlkontext', lambda: (con, 35))
    kaputt = ('--- a/src/alpha/a.ts\n+++ b/src/alpha/a.ts\n@@ -99,3 +99,3 @@\n'
              '-gibt es nicht\n+auch nicht\n')
    dateien, funktionen, _ = gedaechtnis.aenderungsziel(werk, kaputt, None)
    assert funktionen == []
    z = neutralzaehler.stand(con, 35)
    assert z['gedaechtnis.aenderungsziel']['neutral'] == 1
    assert z['gedaechtnis.aenderungsziel']['gruende'] == {'diff_nicht_anwendbar': 1}


def test_gegenprobe_wiederholung_anwendbar_zaehlt_als_geurteilt(con, werk, monkeypatch):
    from biotop.organe import gedaechtnis
    monkeypatch.setattr(gedaechtnis, '_zaehlkontext', lambda: (con, 35))
    neu = {'src/alpha/a.ts': 'export function a(x:number):number{return x+2;}'}
    diff = '--- a/src/alpha/a.ts\n+++ b/src/alpha/a.ts\n@@ -1 +1 @@\n-x+1\n+x+2\n'
    _, funktionen, _ = gedaechtnis.aenderungsziel(werk, diff, neu)
    assert funktionen == ['src/alpha/a.ts::a']
    assert neutralzaehler.stand(con, 35)['gedaechtnis.aenderungsziel']['geurteilt'] == 1


def test_zaehler_ohne_kontext_stoert_nicht(werk):
    """Ohne Lauf-Kontext (Unittest, Vorprobe) läuft alles unverändert weiter."""
    from biotop.organe import gedaechtnis
    _, funktionen, _ = gedaechtnis.aenderungsziel(
        werk, '--- a/src/alpha/a.ts\n+++ b/src/alpha/a.ts\n@@ -9,3 +9,3 @@\n-x\n+y\n', None)
    assert funktionen == []
