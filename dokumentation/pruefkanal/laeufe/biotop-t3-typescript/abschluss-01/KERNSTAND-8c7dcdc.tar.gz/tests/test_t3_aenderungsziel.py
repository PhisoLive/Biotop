"""Ein nicht anwendbarer TS-Diff ist ein Kandidatenbefund, kein Laufabbruch.

Befund aus Lauf 31, Generation 1: `gedaechtnis.wiederholung` wird vor der Aegis-Prüfung
gerufen. Ist der Diff nicht anwendbar, liefert `aegis.kandidat_dateien` None, und
`aenderungsziel` wirft für TypeScript RuntimeError — die ganze Generation stirbt.

Die Absicht hinter dem Wurf ist richtig: Für TypeScript darf das Änderungsziel NICHT
über Pythons `def`-Muster geraten werden. Falsch ist nur die Folge. Ein Kandidat mit
unbrauchbarem Diff wird von Aegis abgelehnt; die Wiederholungsprüfung hat dazu
schlicht keine Aussage und muss sich enthalten, statt den Lauf zu beenden.
"""
import pytest

from biotop.organe import gedaechtnis


def test_ts_ohne_anwendbaren_diff_ist_keine_aussage(tmp_path):
    """Kein Wurf, sondern Enthaltung: keine Funktionen, keine Wiederholung."""
    (tmp_path / 'src').mkdir()
    (tmp_path / 'src/a.ts').write_text('export function f(x: number) { return x + 1; }\n')
    kaputt = '--- a/src/a.ts\n+++ b/src/a.ts\n@@ -99,3 +99,3 @@\n-nicht vorhanden\n+auch nicht\n'
    dateien, funktionen, ansatz = gedaechtnis.aenderungsziel(tmp_path, kaputt, None)
    assert dateien == ['src/a.ts']
    assert funktionen == [], 'ohne anwendbaren Diff wird kein Ziel geraten'
    assert 'auch' in ansatz or ansatz == sorted(ansatz)


def test_ts_mit_anwendbarem_diff_nennt_die_funktion(tmp_path):
    """Gegenprobe: liegt der neue Inhalt vor, wird die berührte Funktion benannt."""
    (tmp_path / 'src').mkdir()
    (tmp_path / 'src/a.ts').write_text('export function f(x: number) { return x + 1; }\n')
    neu = {'src/a.ts': 'export function f(x: number) { return x + 2; }\n'}
    diff = '--- a/src/a.ts\n+++ b/src/a.ts\n@@ -1 +1 @@\n-  return x + 1;\n+  return x + 2;\n'
    dateien, funktionen, _ = gedaechtnis.aenderungsziel(tmp_path, diff, neu)
    assert dateien == ['src/a.ts']
    assert funktionen == ['src/a.ts::f']


def test_python_ohne_diff_raet_weiterhin_aus_dem_hunkkopf(tmp_path):
    """Der Python-Weg bleibt unverändert: dort trägt der Hunk-Kopf den Namen."""
    (tmp_path / 'p.py').write_text('def f(x):\n    return x + 1\n')
    diff = '--- a/p.py\n+++ b/p.py\n@@ -1,2 +1,2 @@ def f(x):\n-    return x + 1\n+    return x + 2\n'
    _, funktionen, _ = gedaechtnis.aenderungsziel(tmp_path, diff, None)
    assert funktionen == ['p.py::f']
