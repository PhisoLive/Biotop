"""Neue TS-Anker dürfen eingefrorenen Kernschutz nicht umgehen."""
import json
from pathlib import Path
import pytest
from biotop.organe import vorspann, verfassung
from biotop.kern import datenbank


def test_ts_pruefkonfiguration_ist_nicht_kandidatenrecht():
    for p in ('package.json','tsconfig.json','vitest.config.ts','eslint.config.mjs','knip.json'):
        e=verfassung.mechanisch_pruefen(None,'',{p:'{}'},'src','alpha')
        assert e, p


def test_ts_testabschwachung_im_diff_verboten():
    v={'regeln':{'verbotene_muster':['.skip(','.todo(','eslint-disable','@ts-ignore']}}
    assert verfassung.mechanisch_pruefen(v,'+test.skip(\'a\',()=>{})',{'tests/test_alpha_neu.test.ts':''},'src','alpha')


from test_vorspann import unit_vorspann


@pytest.mark.parametrize('erreicht,gefangen',[ (False,3), (True,80) ])
def test_generation0_erfolg_entscheidet_freeze_freigabe(unit_vorspann,erreicht,gefangen):
    # Kern-Gate mit kontrollierten Messobjekten; keine echte Eichung behauptet.
    from biotop.kern import protokoll
    con,_=unit_vorspann
    vorspann.ausfuehren(con,1)
    protokoll.schreiben(con,'generation0.ergebnis',lauf_id=1,erreicht=erreicht,gefangen_nachher=gefangen,nicht_aequivalent=100,ziel=80)
    if erreicht:
        assert vorspann.verlangen(con,1,'mass')['lauf_id']==1
    else:
        with pytest.raises(vorspann.VorspannFehler,match='Generation 0.*nicht erfolgreich'):
            vorspann.verlangen(con,1,'mass')

