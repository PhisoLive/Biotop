"""Zweite Bauart der Fehlerklasse: der TS-Zweig ruft etwas, das wirft.

Lauf 36 starb in Generation 4 mit
    TypeScriptFehler: Error: TypeScript-Syntax: '}' expected.
    ... gedaechtnis._funktionen → typescript.quellfunktionen

Der erste Zweigvergleich suchte `raise` IM TypeScript-Zweig und konnte diese Bauart
nicht sehen: Es steht kein `raise` dort, der Wurf kommt aus der gerufenen
Adapterfunktion. Der Python-Zweig derselben Funktionen fängt denselben Fall seit jeher
mit `try/except SyntaxError` ab und liefert ein leeres Ergebnis.

Alle acht Stellen verarbeiten Code, der von einem Modell stammt und syntaktisch kaputt
sein kann. Ein kaputter Modellvorschlag ist ein Befund über den Vorschlag — der
nachgelagerte Ankläger lehnt ihn ab —, kein Grund, den Lauf zu beenden.

Unverändert bleibt: messgeraet.messen wirft weiter. Dort ist ein Fehler ein
Messgerätfehler, kein Inhaltsbefund; ohne Messung gibt es kein Urteil.
"""
from pathlib import Path

import pytest

from biotop.kern import typescript
from biotop.organe import aegis, fundpruefung, gedaechtnis, generation0

KAPUTT = 'export function a(x: number): number { return x + 1;'   # '}' fehlt
KAPUTTER_TEST = "import {test} from 'vitest';\ntest('x', () => { expect(1)"


@pytest.fixture
def werk(tmp_path):
    (tmp_path / 'src' / 'alpha').mkdir(parents=True)
    (tmp_path / 'package.json').write_text('{}')
    (tmp_path / 'src/alpha/a.ts').write_text('export function a(x:number):number{return x+1;}')
    return tmp_path


def test_gedaechtnis_funktionen_bei_kaputtem_ts_liefert_leer():
    """Wie der Python-Zweig bei SyntaxError: leeres Ergebnis, kein Wurf."""
    assert gedaechtnis._funktionen(KAPUTT, 'src/a.ts') == {}


def test_gedaechtnis_funktionen_python_bleibt_unveraendert():
    assert gedaechtnis._funktionen('def f(x):\n    return x\n', 'a.py') != {}
    assert gedaechtnis._funktionen('def f(x:\n', 'a.py') == {}


def test_aegis_nur_funktionen_bei_kaputtem_ts_liefert_none():
    assert aegis.nur_funktionen(KAPUTTER_TEST, {'x'}) is None


def test_aegis_fehlende_oder_geaenderte_tests_bei_kaputtem_ts():
    r = aegis._fehlende_oder_geaenderte_tests(KAPUTTER_TEST, KAPUTTER_TEST)
    assert r == set() or r == [] or not r


def test_aegis_nennt_vertrag_bei_kaputtem_ts_ist_falsch(tmp_path, monkeypatch):
    from biotop.kern import datenbank
    monkeypatch.setattr(datenbank, 'DB_PFAD', tmp_path / 'p.db')
    con = datenbank.verbinden()
    assert aegis._nennt_vertrag(KAPUTTER_TEST, 'x', None, con, 1, 'alpha') is False


def test_aegis_behauptung_bei_kaputtem_ts_gibt_platzhalter():
    assert aegis.behauptung(KAPUTTER_TEST, 'x', 'src') == '?|x'


def test_fundpruefung_testnamen_bei_kaputtem_ts_liefert_leer():
    assert fundpruefung._testnamen(KAPUTTER_TEST) == []


def test_generation0_erzeugen_bei_kaputtem_werk_liefert_leer(werk):
    """Ein Werk, dessen Quelle nicht parst, liefert keine Mutanten — kein Absturz."""
    (werk / 'src/alpha/a.ts').write_text(KAPUTT)
    assert generation0.erzeugen(werk, 'src', ['alpha'], max_je_datei=3) == []


def test_messgeraet_wirft_weiterhin(monkeypatch, werk):
    """Gegenprobe: Ein Messgerätfehler ist KEIN Inhaltsbefund und muss werfen."""
    from biotop.kern import messgeraet

    def kaputt(*a, **kw):
        raise typescript.TypeScriptFehler('Kammerabbruch')

    monkeypatch.setattr(typescript, 'messen', kaputt)
    with pytest.raises(typescript.TypeScriptFehler):
        messgeraet.messen(werk, ['alpha'], 'src', None)


def test_gegenprobe_gueltiger_ts_code_wird_weiterhin_gelesen():
    """Sonst wäre die Reparatur ein pauschales Schweigen."""
    gut = 'export function a(x: number): number { return x + 1; }'
    assert 'a' in gedaechtnis._funktionen(gut, 'src/a.ts')
    guter_test = ("import {test, expect} from 'vitest';\n"
                  "test('test_a', () => { expect(1).toBe(1); });\n")
    assert fundpruefung._testnamen(guter_test) == ['test_a']
