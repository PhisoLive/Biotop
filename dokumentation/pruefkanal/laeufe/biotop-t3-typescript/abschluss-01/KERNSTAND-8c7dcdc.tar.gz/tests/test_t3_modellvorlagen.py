from biotop.organe import genesis, aegis


def test_typescript_vorlage_bestellt_vitest_statt_pytest():
    vorlage=getattr(genesis,'SYSTEM_TYPESCRIPT','')
    assert 'Vitest' in vorlage and '.test.ts' in vorlage
    assert 'Bestwert' in vorlage and 'bestehende Tests' in vorlage
    assert 'pytest' not in vorlage and 'bandit' not in vorlage and '__builtins__' not in vorlage


def test_typescript_angriff_bestellt_expliziten_normbezug():
    vorlage=getattr(aegis,'ANGRIFF_TYPESCRIPT','')
    assert 'Vitest' in vorlage and 'verfassung Satz' in vorlage
    assert 'KEIN ANGRIFF' in vorlage and 'pytest' not in vorlage
