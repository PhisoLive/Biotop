"""Äquivalenzprüfung: Textadapter an echter Gen0-Funktion, keine Modellaufrufe."""
import sys
from types import SimpleNamespace
from biotop.organe import generation0 as G0


def test_typescript_aequivalenz_ohne_python_referenz(db_lauf,tmp_path,monkeypatch):
    (tmp_path/'package.json').write_text('{}'); (tmp_path/'src/alpha').mkdir(parents=True)
    (tmp_path/'src/alpha/a.ts').write_text('export function a(){return 1;}')
    ms=[{'datei':'src/alpha/a.ts','code':'mut1','beschreibung':'Vergleich','zeile':1},
        {'datei':'src/alpha/a.ts','code':'mut2','beschreibung':'arithmetik','zeile':1}]
    m=SimpleNamespace(ref_beobachten=lambda w,r,dateien=None:{'gueltig':True,'sha256':'a' if not dateien or dateien['src/alpha/a.ts']=='mut1' else 'b','anzahl':8,'grund':''})
    import biotop.kern
    monkeypatch.setitem(sys.modules,'biotop.kern.typescript',m); monkeypatch.setattr(biotop.kern,'typescript',m,raising=False)
    monkeypatch.setattr(G0,'_testlauf',lambda *a:(False,''))
    r=G0.aequivalenz_pruefen(db_lauf,1,tmp_path,'export function beobachten(){}',ms)
    # Gleiches endliches Raster allein beweist keine semantische Äquivalenz.
    assert [x['aequivalent'] for x in r]==[False,False]
    assert 'Codebeleg' in r[0]['aequivalenz_beleg']
    assert 'abweichend' in r[1]['aequivalenz_beleg']
    assert all('aequivalenz_beleg' in x for x in r)
