"""Wiederholung nur bei ausdrücklich gekennzeichneter Wiederholbarkeit (T3-Messgerätkorrektur).

Befund aus Lauf 29 und 30: qwen/qwen3.8-flash lieferte HTTP 429 mit dem Anbietertext
"is temporarily rate-limited upstream. Please retry shortly". Der Adapter zählte das
sofort als Verbundausfall und sperrte den gesamten Auftrag.

Regel (Festlegung Philipp):
  - Wiederholt wird NUR, was der Anbieter ausdrücklich als wiederholbar kennzeichnet
    (HTTP 429 oder 503 mit Wiederholungshinweis im Text).
  - Höchstzahl und Wartezeit stehen VORHER fest: WIEDERHOLUNGEN, WARTEZEIT_S.
  - Danach zählt der Fehler als Ausfall wie bisher, mit null Beitrag.
  - Eine Ablehnung wird NIE wiederholt: sie ist eine Entscheidung, keine Störung.
  - Eine Zeitüberschreitung bleibt Ausfall nach Satz 8.
  - Jeder Versuch wird protokolliert und gebucht.
  - Gegenprobe: ein Fehler ohne Wiederholungshinweis zählt sofort als Ausfall.
"""
import json
import urllib.error

import pytest

from biotop import anbieter
from biotop.anbieter import AnbieterFehler
from biotop.kern import datenbank, kasse, protokoll


@pytest.fixture(autouse=True)
def kein_echter_aufruf(monkeypatch):
    """Erzwingt die Vorbedingung: kein einziger echter Anbieteraufruf in dieser Datei.

    Nicht behauptet, sondern gesperrt — jeder Versuch, die Netzschicht zu benutzen,
    lässt den Test scheitern statt still hinauszugehen.
    """
    def gesperrt(*a, **kw):
        raise AssertionError('ECHTER ANBIETERAUFRUF — in diesen Tests verboten')

    # Nur die Netzgrenze wird gesperrt. `senden` ist die zu prüfende Methode
    # und muss laufen; echte Aufrufe kann sie ohne urlopen nicht absetzen.
    monkeypatch.setattr(anbieter.urllib.request, 'urlopen', gesperrt)
    monkeypatch.delenv('OPENROUTER_API_KEY', raising=False)


class _Anbieter:
    """Zählt Versuche, liefert nach `bis_erfolg` Fehlversuchen eine gültige Antwort."""

    def __init__(self, fehler, bis_erfolg=None):
        self.fehler = fehler
        self.bis_erfolg = bis_erfolg
        self.versuche = 0

    def __call__(self, modell, system, nutzer, max_tokens, temperatur):
        self.versuche += 1
        if self.bis_erfolg is not None and self.versuche > self.bis_erfolg:
            return 'ANTWORT', 100, 20
        raise self.fehler


@pytest.fixture
def umgebung(tmp_path, monkeypatch):
    monkeypatch.setattr(datenbank, 'DB_PFAD', tmp_path / 'p.db')
    monkeypatch.setattr(kasse, 'AUFTRAG_BUDGET_EUR', 10.0)
    monkeypatch.setattr(kasse, 'AUFTRAG_LAUF_AB', 26)
    con = datenbank.verbinden()
    con.execute("INSERT INTO laeufe(id,budget_eur,status,begonnen_am) VALUES (31,10.0,'bereit',?)",
                (protokoll.jetzt(),))
    con.commit()
    pausen = []
    monkeypatch.setattr(anbieter.time, 'sleep', pausen.append)
    return con, pausen, monkeypatch


def _einsetzen(monkeypatch, fake):
    ad = anbieter.OpenRouterAdapter.__new__(anbieter.OpenRouterAdapter)
    monkeypatch.setattr(ad, '_senden_einmal', fake, raising=False)
    monkeypatch.setattr(anbieter, 'adapter', lambda name: ad)
    return ad


RATE = 'qwen/qwen3.8-flash: HTTP 429 b\'{"error":{"code":429,"metadata":{"raw":"qwen is temporarily rate-limited upstream. Please retry shortly"}}}\''


def test_gegenprobe_netzsperre_faengt_echten_aufruf(umgebung):
    """Gegenprobe zur Vorbedingung: ein ABSICHTLICH echter Aufruf muss scheitern.

    Ohne diese Probe wäre „kein echter Anbieteraufruf" eine Behauptung. Hier wird
    genau die Bibliothek gerufen, die der Adapter tatsächlich benutzt
    (`urllib.request.urlopen` in biotop.anbieter) — einmal direkt und einmal über
    den echten Adapterpfad `_senden_einmal`. Beide müssen an der Sperre scheitern.
    Schlüge die Sperre nicht an, ginge hier echter Netzverkehr hinaus und der Test
    würde es melden statt still hinauszurufen.
    """
    con, pausen, mp = umgebung

    # 1. Direkt über die Bibliothek des Adapters, an die echte Anbieter-URL.
    with pytest.raises(AssertionError, match='ECHTER ANBIETERAUFRUF'):
        anbieter.urllib.request.urlopen(
            'https://openrouter.ai/api/v1/chat/completions', timeout=5)

    # 2. Über den echten Adapterpfad, der im Betrieb das Modell ruft. `_senden_einmal`
    #    fängt Ausnahmen der Netzschicht und verpackt sie als AnbieterFehler. Ein bloßer
    #    AnbieterFehler beweist daher NICHTS: den liefert der Adapter auch bei einem
    #    echten HTTP 401. Geprüft wird deshalb, dass die Meldung der SPERRE darin steckt.
    ad = anbieter.OpenRouterAdapter.__new__(anbieter.OpenRouterAdapter)
    ad.key = 'nicht-vorhanden'
    with pytest.raises(AnbieterFehler) as gefangen:
        ad._senden_einmal('openai/gpt-5.6-luna', 's', 'n', 10, 0.0)
    assert 'ECHTER ANBIETERAUFRUF' in str(gefangen.value), (
        'Der Adapter hat einen Fehler geliefert, aber nicht den der Sperre — '
        f'der Aufruf ist womöglich hinausgegangen: {gefangen.value}')

    # 3. Der Schlüssel ist in dieser Datei nicht verfügbar — ein echter Aufruf
    #    wäre selbst ohne Sperre nicht abrechenbar.
    import os
    assert 'OPENROUTER_API_KEY' not in os.environ


def test_gegenprobe_der_gegenprobe_ein_echtes_401_wuerde_auffallen(umgebung):
    """Gegenprobe zur Probe: Bei kaputter Sperre schlägt die Prüfung an.

    Simuliert wird, was ohne Sperre passierte: Der Anbieter antwortet mit HTTP 401,
    der Adapter verpackt das in denselben AnbieterFehler-Typ. Die Prüfung aus
    Punkt 2 muss dann FEHLSCHLAGEN — sonst wäre sie blind für echten Netzverkehr.
    """
    con, pausen, mp = umgebung

    def wie_echtes_401(*a, **kw):
        raise urllib.error.HTTPError('https://openrouter.ai/api/v1/chat/completions',
                                     401, 'Unauthorized', {}, None)

    mp.setattr(anbieter.urllib.request, 'urlopen', wie_echtes_401)
    ad = anbieter.OpenRouterAdapter.__new__(anbieter.OpenRouterAdapter)
    ad.key = 'nicht-vorhanden'

    with pytest.raises(AnbieterFehler) as gefangen:
        ad._senden_einmal('openai/gpt-5.6-luna', 's', 'n', 10, 0.0)

    # Derselbe Ausnahmetyp wie bei gesperrtem Aufruf — der Typ allein trägt nichts.
    assert isinstance(gefangen.value, AnbieterFehler)
    assert 'HTTP 401' in str(gefangen.value)
    # Und genau hier wird die Prüfung aus Punkt 2 rot, wie sie soll.
    assert 'ECHTER ANBIETERAUFRUF' not in str(gefangen.value), (
        'Die Sperrmeldung darf bei einem echten Netzfehler NICHT erscheinen, '
        'sonst prüft Punkt 2 nichts')


def test_wiederholbarer_fehler_wird_wiederholt_und_gelingt(umgebung):
    con, pausen, mp = umgebung
    fake = _Anbieter(AnbieterFehler(RATE, ausfallart='infrastruktur'), bis_erfolg=2)
    ad = _einsetzen(mp, fake)
    a = anbieter.aufrufen(con, 31, 'openrouter', 'qwen/qwen3.8-flash', 's', 'n', 'test', 100, 0.2)
    assert a.text == 'ANTWORT'
    assert fake.versuche == 3, 'zwei Fehlversuche, dann Erfolg'
    assert len(pausen) == 2 and pausen == sorted(pausen), 'wachsende Wartezeit vor jedem neuen Versuch'
    # Jeder Versuch ist protokolliert.
    versuche = [json.loads(z['inhalt']) for z in con.execute(
        "SELECT inhalt FROM protokoll WHERE art='modell.wiederholung'")]
    assert len(versuche) == 2
    assert all(v['grund_wiederholbar'] for v in versuche)
    assert [v['versuch'] for v in versuche] == [1, 2]


def test_nach_hoechstzahl_bleibt_es_ausfall(umgebung):
    con, pausen, mp = umgebung
    fake = _Anbieter(AnbieterFehler(RATE, ausfallart='infrastruktur'))
    _einsetzen(mp, fake)
    with pytest.raises(AnbieterFehler, match='429'):
        anbieter.aufrufen(con, 31, 'openrouter', 'qwen/qwen3.8-flash', 's', 'n', 'test', 100, 0.2)
    assert fake.versuche == anbieter.WIEDERHOLUNGEN + 1, 'Höchstzahl eingehalten, nicht überschritten'
    ausfall = [json.loads(z['inhalt']) for z in con.execute(
        "SELECT inhalt FROM protokoll WHERE art='modell.ausfall'")]
    assert len(ausfall) == 1 and ausfall[0]['beitraege'] == 0
    assert ausfall[0]['versuche'] == anbieter.WIEDERHOLUNGEN + 1


def test_gegenprobe_fehler_ohne_wiederholungshinweis_ist_sofort_ausfall(umgebung):
    """Ein HTTP 500 ohne Hinweis auf Wiederholbarkeit wird NICHT wiederholt."""
    con, pausen, mp = umgebung
    fake = _Anbieter(AnbieterFehler('modell: HTTP 500 interner Fehler', ausfallart='infrastruktur'),
                     bis_erfolg=1)
    _einsetzen(mp, fake)
    with pytest.raises(AnbieterFehler, match='500'):
        anbieter.aufrufen(con, 31, 'openrouter', 'openai/gpt-5.6-luna', 's', 'n', 'test', 100, 0.2)
    assert fake.versuche == 1, 'kein zweiter Versuch ohne Wiederholungshinweis'
    assert not pausen


def test_ablehnung_wird_nie_wiederholt(umgebung):
    con, pausen, mp = umgebung
    fake = _Anbieter(AnbieterFehler('modell: ablehnung — kein nutzbarer Beitrag',
                                    ausfallart='ablehnung'), bis_erfolg=1)
    _einsetzen(mp, fake)
    with pytest.raises(AnbieterFehler, match='ablehnung'):
        anbieter.aufrufen(con, 31, 'openrouter', 'openai/gpt-5.6-luna', 's', 'n', 'test', 100, 0.2)
    assert fake.versuche == 1
    assert not pausen


def test_zeitueberschreitung_bleibt_ausfall_nach_satz_8(umgebung):
    con, pausen, mp = umgebung
    fake = _Anbieter(AnbieterFehler('modell: timed out nach 180 s', ausfallart='zeitueberschreitung'),
                     bis_erfolg=1)
    _einsetzen(mp, fake)
    with pytest.raises(AnbieterFehler, match='timed out'):
        anbieter.aufrufen(con, 31, 'openrouter', 'openai/gpt-5.6-luna', 's', 'n', 'test', 100, 0.2)
    assert fake.versuche == 1, 'Zeitüberschreitung wird nicht wiederholt'
    assert not pausen


def test_verbrauch_jedes_versuchs_wird_gebucht(umgebung):
    """Meldet der Anbieter beim Fehlversuch Verbrauch, wird er gebucht — auch ohne Beitrag."""
    con, pausen, mp = umgebung
    fake = _Anbieter(AnbieterFehler(RATE, verbrauch=(500, 0), ausfallart='infrastruktur'),
                     bis_erfolg=1)
    _einsetzen(mp, fake)
    a = anbieter.aufrufen(con, 31, 'openrouter', 'qwen/qwen3.8-flash', 's', 'n', 'test', 100, 0.2)
    assert a.text == 'ANTWORT'
    zwecke = [z['zweck'] for z in con.execute('SELECT zweck FROM kasse ORDER BY id')]
    assert 'test.fehlversuch' in zwecke, 'der verbrauchende Fehlversuch ist gebucht'
    assert 'test' in zwecke, 'der erfolgreiche Versuch ebenfalls'
