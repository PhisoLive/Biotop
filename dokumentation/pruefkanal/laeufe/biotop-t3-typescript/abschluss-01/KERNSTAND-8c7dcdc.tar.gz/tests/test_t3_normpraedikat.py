"""Normspeicherung am Sprachparser prüfen, nicht am Python-def-Text."""
import sys
from types import SimpleNamespace
from biotop.organe import eichproben


def test_ts_normpraedikat_erkennt_ausgefuehrten_vitest_normeintrag(monkeypatch):
    name='test_norm'; pfad='tests/test_alpha_eichprobe_norm.test.ts'
    code="import {test,expect} from 'vitest'; test('test_norm',()=>expect(2).toBe(3));"
    m=SimpleNamespace(testfunktionen=lambda c:[{'name':name}])
    import biotop.kern
    monkeypatch.setitem(sys.modules,'biotop.kern.typescript',m)
    monkeypatch.setattr(biotop.kern,'typescript',m,raising=False)
    belege={'testname':name,'testpfad':pfad,'paket':'src','ohne_verweis':True,'werk_test_vorhanden':False,
        'basis_tests':{pfad+'::'+name:{'ok':False,'bestaetigt':True,'meldung':'AssertionError: Meinung','ort':pfad}},
        'kandidat_tests':{pfad+'::'+name:{'ok':True}},
        'normeintraege':[{'status':'offen_norm','code':code}],
        'messung':{'gueltig':True,'_basis_paar':{'gueltig':True},'_dateien':{}},
        'urteil':{'status':'abgelehnt','norm':[name],'mass':{'zuwachs':0,'pareto_schlechter':[]},
                  'vertrag_verletzt':[],'verfassung_verstoesse':[]}}
    assert eichproben._bestanden('norm',belege) is True
    belege['normeintraege']=[]
    assert eichproben._bestanden('norm',belege) is False
