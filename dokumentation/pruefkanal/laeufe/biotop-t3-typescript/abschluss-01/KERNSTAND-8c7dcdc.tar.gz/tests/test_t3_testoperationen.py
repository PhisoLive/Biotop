"""Sprachnaht für Testzulassung; AST-Ableitung in separater Adapterprüfung."""
import sys
from types import SimpleNamespace
import pytest
from biotop.organe import aegis, verfassung
from biotop.kern import datenbank

CODE="import {test,expect} from 'vitest'; test('test_wert verfassung Satz 3',()=>expect(wert(2)).toBe(4));"

@pytest.fixture
def ts(monkeypatch):
    def funktionen(code):
        return [{'name':'test_wert verfassung Satz 3','code':code,'behauptung':'wert|Eq:zahl','verweis':'verfassung Satz 3'}]
    m=SimpleNamespace(testfunktionen=funktionen,nur_tests=lambda c,n: c if n else None)
    import biotop.kern
    monkeypatch.setitem(sys.modules,'biotop.kern.typescript',m)
    monkeypatch.setattr(biotop.kern,'typescript',m,raising=False)
    return m


def test_ts_fundfilter_behauptung_vertragsverweis(db_lauf,ts):
    assert aegis.nur_funktionen(CODE,{'test_wert verfassung Satz 3'})==CODE
    assert aegis.behauptung(CODE,'test_wert verfassung Satz 3','src')=='wert|Eq:zahl'
    assert aegis._nennt_vertrag(CODE,'test_wert verfassung Satz 3',{'text':'3. Korrektheit'},db_lauf,1,'alpha')
    assert not aegis._nennt_vertrag(CODE,'test_wert verfassung Satz 3',{'text':'2. Sicherheit'},db_lauf,1,'alpha')


def test_ts_testaenderung_nicht_versehentlich_als_leere_datei_uebergehen(ts):
    assert aegis._fehlende_oder_geaenderte_tests(CODE,CODE)==[]
    assert aegis._fehlende_oder_geaenderte_tests(CODE,CODE.replace('toBe(4)','toBe(5)'))


def test_ts_anhaengen_darf_keine_vorhandenen_tests_ersetzen(ts):
    assert aegis._anhaengen(CODE,CODE,set()) is None
