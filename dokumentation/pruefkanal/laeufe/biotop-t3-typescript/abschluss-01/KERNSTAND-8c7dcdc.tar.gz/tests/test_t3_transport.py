"""Vollständige Messausgabe statt unbemerktem Abschneiden."""
import subprocess
from pathlib import Path
from biotop.organe import kammer


def test_kammer_erhaelt_grosse_ausgabe_ohne_abschneiden(tmp_path,monkeypatch):
    text='KOPF-'+('a'*65000)+'-ENDE'
    monkeypatch.setattr(kammer.subprocess,'run',lambda cmd,**kw: subprocess.CompletedProcess(cmd,0,text,''))
    e=kammer.ausfuehren(tmp_path,['node','probe'])
    assert e.rc==0 and e.stdout==text


def test_kammer_uebergrosse_ausgabe_ist_lauter_fehler(tmp_path,monkeypatch):
    text='a'*2_100_000
    monkeypatch.setattr(kammer.subprocess,'run',lambda cmd,**kw: subprocess.CompletedProcess(cmd,0,text,''))
    e=kammer.ausfuehren(tmp_path,['node','probe'])
    assert e.rc!=0 and 'Ausgabelimit' in e.stderr
