"""Kernbindung umfasst die neue Werkzeugkette vor jedem Lauf."""
from pathlib import Path
import pytest
from test_vorspann import unit_vorspann
from biotop.organe import vorspann
from biotop.kern import datenbank, protokoll


def test_instrument_bindet_nichtpythonische_kernquellen(unit_vorspann,tmp_path,monkeypatch):
    con,_=unit_vorspann
    wurzel=tmp_path/'kernbestand'; (wurzel/'biotop/kern/ts').mkdir(parents=True)
    (wurzel/'kammer/typescript').mkdir(parents=True)
    for p in ('biotop/kern/ts/messen.mjs','biotop/kern/ts/konfig.json','kammer/typescript/package-lock.json',
              'kammer/typescript/Dockerfile','kammer/Dockerfile'):
        (wurzel/p).write_text('gestellter Inhalt')
    monkeypatch.setattr(vorspann,'WURZEL',wurzel)
    d=vorspann._quellen(con,1)['instrument']['dateien']
    assert set(d)=={'biotop/kern/ts/messen.mjs','biotop/kern/ts/konfig.json','kammer/typescript/package-lock.json',
                    'kammer/typescript/Dockerfile','kammer/Dockerfile'}


@pytest.mark.parametrize('geaendert', ['biotop/kern/ts/messen.mjs', 'kammer/typescript/package-lock.json'])
def test_ts_instrumentaenderung_invalidiert_versiegelten_nachweis(unit_vorspann,tmp_path,monkeypatch,geaendert):
    # Charakterisierung der neuen Bindung: kontrollierter Kernbestand,
    # echte Hashänderung, ursprünglicher Vorspann-Verbraucher.
    con,_=unit_vorspann
    wurzel=tmp_path/'instrument'; (wurzel/'biotop/kern/ts').mkdir(parents=True)
    (wurzel/'kammer/typescript/node_modules').mkdir(parents=True)
    for p in ('biotop/kern/ts/messen.mjs','kammer/typescript/package-lock.json','kammer/Dockerfile'):
        (wurzel/p).write_text('ursprünglicher Instrumentinhalt')
    ignoriert=wurzel/'kammer/typescript/node_modules/fremd.json'
    ignoriert.write_text('{}')
    monkeypatch.setattr(vorspann,'WURZEL',wurzel)
    r=vorspann.ausfuehren(con,1)
    assert vorspann.verlangen(con,1,'gen0')['nachweis_sha256']==r['nachweis_sha256']
    assert not any('node_modules' in p for p in r['quellen']['instrument']['dateien'])
    ignoriert.write_text('{"anderer_dependency_cache":true}')
    assert vorspann.verlangen(con,1,'gen0')['nachweis_sha256']==r['nachweis_sha256']
    (wurzel/geaendert).write_text('geänderter Instrumentinhalt')
    with pytest.raises(vorspann.VorspannFehler,match='Messgerät/Quellen verändert'):
        vorspann.verlangen(con,1,'gen0')
    assert con.execute('SELECT status FROM vorspann_nachweise WHERE lauf_id=1').fetchone()[0]=='ungueltig'


def test_generation0_erreicht_flag_ersetzt_nicht_80_prozent(unit_vorspann):
    con,_=unit_vorspann; vorspann.ausfuehren(con,1)
    protokoll.schreiben(con,'generation0.ergebnis',lauf_id=1,erreicht=True,gefangen_nachher=1,nicht_aequivalent=100,ziel=1)
    with pytest.raises(vorspann.VorspannFehler,match='Generation 0.*nicht erfolgreich'):
        vorspann.verlangen(con,1,'mass')
