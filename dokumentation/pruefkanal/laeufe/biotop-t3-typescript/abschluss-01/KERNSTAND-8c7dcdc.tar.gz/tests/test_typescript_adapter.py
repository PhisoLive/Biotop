"""Ausführbare Adapterverträge; nur temporäre TS-Werke, kein Anbieter/DB."""
import importlib
import json
import os
from pathlib import Path
import subprocess

import pytest

BELEGE = Path(os.environ.get("TS_ADAPTER_BELEGE", "/root/biotop-t3/adapterbau/laeufe"))


def belegen(name, wert):
    BELEGE.mkdir(parents=True, exist_ok=True)
    (BELEGE / (name + ".json")).write_text(json.dumps(wert, ensure_ascii=False, indent=2))
    return wert


def adapter():
    return importlib.import_module("biotop.kern.typescript")


@pytest.mark.integration
def test_image_werkzeuge_netzlos():
    cmd = ["docker", "run", "--rm", "--network", "none", "--read-only",
           "--tmpfs", "/tmp", "biotop-kammer:ts1", "node", "-e",
           "console.log(JSON.stringify({node:process.version,uid:process.getuid(),"
           "typescript:require('/opt/biotop-ts/node_modules/typescript/package.json').version,"
           "vitest:require('/opt/biotop-ts/node_modules/vitest/package.json').version}))"]
    p = subprocess.run(cmd, text=True, capture_output=True, timeout=45)
    belegen("image", dict(befehl=cmd, rc=p.returncode, stdout=p.stdout, stderr=p.stderr))
    assert p.returncode == 0, p.stderr
    d = json.loads(p.stdout)
    assert d["node"].startswith("v22.") and d["uid"] == 10001
    assert d["typescript"] == "5.7.3" and d["vitest"] == "2.1.8"


@pytest.fixture
def werk(tmp_path, monkeypatch):
    from biotop.organe import kammer
    monkeypatch.setattr(kammer, "IMAGE", "biotop-kammer:ts1")
    w = tmp_path / "anderes-werk"
    (w / "src" / "alpha").mkdir(parents=True)
    (w / "src" / "beta").mkdir(parents=True)
    (w / "tests").mkdir()
    (w / "package.json").write_text('{"name":"anderes-werk","type":"module"}')
    (w / "src/beta/wert.ts").write_text('export const eins = 1;\n')
    (w / "src/alpha/rechnung.ts").write_text('''// Emoji 😀 vor Offsets
import { eins } from '../beta/wert';
/** Berechnet den Betrag. */
export function betrag(wert: number): number {
  return wert + eins;
}
export const doppelt = (wert: number): number => wert * 2;
''')
    return w


@pytest.mark.integration
def test_struktur_echter_ast_mit_unicode_offsets(werk):
    ts = adapter()
    assert ts.ist_typescript(werk)
    assert not ts.ist_typescript(werk / "src")
    d = belegen("struktur", ts.struktur(werk))
    assert d["bereiche"] == ["alpha", "beta"]
    quelle = next(f for f in d["dateien"] if f["pfad"] == "src/alpha/rechnung.ts")
    assert quelle["imports"] == ["src/beta/wert.ts"]
    assert [f["name"] for f in quelle["funktionen"]] == ["betrag", "doppelt"]
    f = quelle["funktionen"][0]
    code = (werk / quelle["pfad"]).read_text()
    assert code[f["start"]:f["end"]].startswith("export function betrag")
    assert code[f["body_start"]:f["body_end"]].startswith("{")
    assert f["params"][0]["type"] == "number" and f["type"] == "number"
    assert code[f["returns"][0]["start"]:f["returns"][0]["end"]] == "return wert + eins;"
    assert f["zweck"] == "Berechnet den Betrag."
    assert d["offset_unit"] == "unicode_codepoints"


def schreibe_test(werk, inhalt):
    (werk / 'tests/test_alpha.test.ts').write_text(inhalt)


@pytest.mark.integration
def test_vitest_sauberer_pass_stabile_vollidentitaet(werk):
    schreibe_test(werk, "import {test,expect,describe} from 'vitest';\n"
                  "describe('Gruppe',()=>{test('Beschreibung mit Leerzeichen',function andererName(){expect(1+1).toBe(2)})});")
    d = belegen('vitest-pass', adapter().testlauf(werk))
    assert d['gueltig'], d
    assert d['rc'] == 0
    assert list(d['faelle']) == ['tests/test_alpha.test.ts::Gruppe > Beschreibung mit Leerzeichen']
    assert d['faelle'][next(iter(d['faelle']))] == dict(ok=True,bestaetigt=False,meldung='',ort='')
    assert d['nachweis']['beendet'] and len(d['nachweis']['gesammelt']) == 1


@pytest.mark.integration
def test_typbau_pass_und_echter_typfehler(werk):
    ts = adapter()
    gut = belegen('bau-pass', ts.baulauf(werk))
    assert gut['gueltig'] and gut['baut'] and gut['rc'] == 0
    schlecht = belegen('bau-typfehler', ts.baulauf(werk, {'src/beta/wert.ts':'export const eins: number = "falsch";'}))
    assert schlecht['gueltig'] and not schlecht['baut'] and schlecht['rc'] != 0
    assert 'TS2322' in schlecht['prozess']['stdout']


@pytest.mark.integration
def test_assertionfehler_von_testfehler_und_werkabsturz_trennen(werk):
    schreibe_test(werk, "import {test,expect} from 'vitest';\n"
                  "import {betrag} from '../src/alpha/rechnung';\n"
                  "test('Zusicherung',()=>expect(betrag(1)).toBe(99));\n"
                  "test('Testfehler',()=>{throw new TypeError('eigener Testfehler')});\n"
                  "test('Werkabsturz',()=>betrag(2));")
    d = belegen('assertion-und-fehler', adapter().testlauf(werk, {'src/alpha/rechnung.ts':
                 'export function betrag(n:number){if(n===2)throw new Error("Werkfehler");return n+1;}'}))
    assert d['gueltig'] and d['rc'] == 1, d
    a,b,c = [d['faelle']['tests/test_alpha.test.ts::'+n] for n in ['Zusicherung','Testfehler','Werkabsturz']]
    assert not a['ok'] and a['bestaetigt'] and a['meldung'].startswith('AssertionError:')
    assert a['ort'] == 'tests/test_alpha.test.ts'
    assert not b['ok'] and not b['bestaetigt']
    assert not c['ok'] and c['bestaetigt'] and c['ort'] == 'src/alpha/rechnung.ts'


@pytest.mark.integration
@pytest.mark.parametrize('fall,code', [
    ('skip', "test.skip('nicht ausgeführt',()=>expect(1).toBe(1));"),
    ('todo', "test.todo('später');"),
    ('leer', ''),
    ('collection', "import './fehlt';"),
    ('runner', "process.exit(23);"),
    ('doppelt', "test('Kontrolle',()=>expect(1).toBe(1));"),
    ('hook', "import {beforeEach} from 'vitest'; beforeEach(()=>{throw new Error('Hookabbruch')});"),
])
def test_unvollstaendige_laeufe_nie_gruen(werk,fall,code):
    kontroll = "test('Kontrolle',()=>expect(1).toBe(1));" if fall != 'leer' else ''
    schreibe_test(werk,"import {test,expect} from 'vitest';\n"+kontroll+code)
    d=belegen('ungueltig-'+fall,adapter().testlauf(werk))
    assert d['gueltig'] is False and d['grund'] and not d['faelle'], d


@pytest.mark.integration
def test_leere_pflichtdatei_neben_gruenem_nachbarn(werk):
    schreibe_test(werk,"import {test,expect} from 'vitest'; test('lebt',()=>expect(1).toBe(1));")
    (werk/'tests/test_beta.test.ts').write_text('export const leer=1;')
    d=belegen('leere-pflichtdatei',adapter().testlauf(werk))
    assert not d['gueltig'], d


@pytest.mark.integration
def test_ast_testfunktionen_filter_behautung_und_verweis(werk):
    ts=adapter()
    code="""import {test, it, expect} from 'vitest';
import {betrag as rechne} from '../src/alpha/rechnung';
const hilfe = (n:number)=>n;
/** Verfassung Satz 2 */
test('Betrag stimmt', function andererName(){const wert=rechne(hilfe(1));expect(wert).toBe(2)});
it('nicht behalten',()=>expect(rechne(2)).not.toBe(0));
"""
    d=belegen('testfunktionen',ts.testfunktionen(code))
    assert [f['name'] for f in d]==['Betrag stimmt','nicht behalten']
    assert d[0]['behauptung']=='betrag|toBe:zahl'
    assert d[1]['behauptung']=='betrag|not.toBe:zahl'
    assert 'Verfassung Satz 2' in d[0]['verweis']
    gefiltert=ts.nur_tests(code,{'Betrag stimmt'})
    assert 'const hilfe' in gefiltert and 'import {betrag as rechne}' in gefiltert
    assert 'andererName' in gefiltert and 'nicht behalten' not in gefiltert
    assert ts.nur_tests(code,set()) is None
    with pytest.raises(ValueError, match='flach|unterstützt'):
        ts.testfunktionen("import {describe,test} from 'vitest';describe('a',()=>test('b',()=>{}));")
    schreibe_test(werk,gefiltert)
    assert ts.testlauf(werk)['gueltig']


@pytest.mark.integration
def test_mutanten_aus_ast_bauen_und_fallen(werk):
    ts=adapter()
    schreibe_test(werk,"import {test,expect} from 'vitest'; import {betrag,doppelt} from '../src/alpha/rechnung'; test('betrag',()=>expect(betrag(1)).toBe(2)); test('doppelt',()=>expect(doppelt(3)).toBe(6));")
    ms=belegen('mutanten',ts.mutanten(werk,max_je_datei=3))
    assert len(ms)>=2
    assert len({(m['datei'],m['code']) for m in ms})==len(ms)
    m=next(m for m in ms if m['datei']=='src/alpha/rechnung.ts' and m['art']=='arithmetik')
    assert 'return wert - eins' in m['code']
    bau=belegen('mutant-bau',ts.baulauf(werk,{m['datei']:m['code']}))
    assert bau['gueltig'] and bau['baut']
    lauf=belegen('mutant-test',ts.testlauf(werk,{m['datei']:m['code']}))
    assert lauf['gueltig'] and lauf['rc']==1
    assert lauf['faelle']['tests/test_alpha.test.ts::betrag']['bestaetigt']


@pytest.mark.integration
def test_referenzbeobachtung_kanonisch_und_nicht_zeitbasiert(werk):
    ts=adapter()
    ref="import {betrag} from './src/alpha/rechnung'; export function beobachten(){return [{b:betrag(2),a:1},betrag(3)];}"
    a=belegen('referenz-a',ts.ref_beobachten(werk,ref))
    b=belegen('referenz-b',ts.ref_beobachten(werk,ref.replace('{b:betrag(2),a:1}','{a:1,b:betrag(2)}')))
    c=belegen('referenz-veraendert',ts.ref_beobachten(werk,ref,{'src/beta/wert.ts':'export const eins=2;'}))
    assert a['gueltig'] and b['gueltig'] and c['gueltig'], (a,b,c)
    assert a['anzahl']==2 and len(a['sha256'])==64
    assert a['sha256']==b['sha256'] and a['sha256']!=c['sha256']
    fehler=belegen('referenz-fehler',ts.ref_beobachten(werk,"export function beobachten(){throw new Error('abgebrochen')}"))
    assert not fehler['gueltig'] and fehler['grund']
    fehlwert=ts.ref_beobachten(werk,"export function beobachten(){return [undefined]}" )
    assert not fehlwert['gueltig']


@pytest.mark.integration
def test_messen_ein_container_echte_statik_positive_und_negative_probe(werk):
    from biotop.organe import kammer
    ts=adapter()
    schreibe_test(werk,"import {test,expect} from 'vitest'; import {betrag,doppelt} from '../src/alpha/rechnung'; test('betrag',()=>expect(betrag(1)).toBe(2)); test('doppelt',()=>expect(doppelt(3)).toBe(6));")
    (werk/'tests/test_beta.test.ts').write_text("import {test,expect} from 'vitest'; import {eins} from '../src/beta/wert';test('eins',()=>expect(eins).toBe(1));")
    with kammer.zaehlung() as aufrufe:
        m=belegen('messung-sauber',ts.messen(werk,['alpha','beta'],'src',None))
    assert len(aufrufe)==1 and m['kammeraufrufe']==1
    assert m['gueltig'],m
    assert m['werk']['baut'] and m['werk']['test_rc']==0 and m['werk']['pytest_rc']==0
    assert m['werk']['tests_fehlgeschlagen_ids']==[] and m['kernmass']==0
    for tool in ['tsc','vitest','eslint','knip']:
        assert m['abdeckung'][tool]['beendet'] and m['abdeckung'][tool]['dateien']
    assert m['bereiche']['alpha']['tests_gesamt']==2 and m['bereiche']['beta']['tests_gesamt']==1
    source=(werk/'src/alpha/rechnung.ts').read_text()+"\nexport function unsicher(text:string){return eval(text)}\nexport function tot(){return 7}\n"
    p=belegen('messung-befunde',ts.messen(werk,['alpha','beta'],'src',None,{'src/alpha/rechnung.ts':source}))
    assert p['gueltig'],p
    assert p['bereiche']['alpha']['sicherheit_punkte']>=10
    assert any(x['test']=='security/detect-eval-with-expression' for x in p['bereiche']['alpha']['sicherheit_befunde'])
    assert p['bereiche']['alpha']['tote_funktionen']==2
    assert p['kernmass']<m['kernmass']


@pytest.mark.integration
def test_laufzeit_median_drei_durchlaeufe_und_fehlender_export(werk):
    ts=adapter()
    schreibe_test(werk,"import {test,expect} from 'vitest'; import {betrag,doppelt} from '../src/alpha/rechnung';test('betrag',()=>{expect(betrag(1)).toBe(2);expect(doppelt(2)).toBe(4)});")
    (werk/'tests/test_beta.test.ts').write_text("import {test,expect} from 'vitest';import {eins} from '../src/beta/wert';test('eins',()=>expect(eins).toBe(1));")
    ref="""import {betrag} from './src/alpha/rechnung';
export function last_alpha(){let s=0; for(let i=0;i<10000;i++)s+=betrag(i);return s;}
export function last_beta(){let s=0;for(let i=0;i<10000;i++)s+=i;return s;}
"""
    m=belegen('laufzeit-median',ts.messen(werk,['alpha','beta'],'src',ref))
    assert m['gueltig'],m
    for b in ['alpha','beta']:
        werte=m['bereiche'][b]['laufzeit_roh']
        assert len(werte)==3 and all(x>0 for x in werte)
        assert m['bereiche'][b]['laufzeit_ms']==sorted(werte)[1]
    n=belegen('laufzeit-export-fehlt',ts.messen(werk,['alpha','beta'],'src',ref.replace('last_beta','andere_funktion')))
    assert not n['gueltig'] and 'last_beta' in n['grund']


@pytest.mark.integration
def test_knip_darf_gitignore_nicht_als_messfilter_nutzen(werk):
    ts=adapter()
    schreibe_test(werk,"import {test,expect} from 'vitest';import {betrag,doppelt} from '../src/alpha/rechnung';test('lebt',()=>{expect(betrag(1)).toBe(2);expect(doppelt(2)).toBe(4)});")
    (werk/'tests/test_beta.test.ts').write_text("import {test,expect} from 'vitest';import {eins} from '../src/beta/wert';test('eins',()=>expect(eins).toBe(1));")
    (werk/'src/alpha/tot.ts').write_text('export function verborgen(){return 3}')
    (werk/'.gitignore').write_text('src/alpha/tot.ts\n')
    m=belegen('knip-ignore-gegenprobe',ts.messen(werk,['alpha','beta'],'src',None))
    assert m['gueltig'], m
    assert m['bereiche']['alpha']['tote_funktionen']==1


@pytest.mark.integration
def test_grosser_vitest_beleg_vollstaendig_oder_laut_abgelehnt(werk):
    import random
    rng = random.Random(182)
    titel = ['Fall '+str(i)+' '+('lange unverwechselbare Beschreibung '*3) for i in range(220)]
    code = "import {test,expect} from 'vitest';\n" + '\n'.join('test('+json.dumps(n)+',()=>expect(1).toBe(1));' for n in titel)
    schreibe_test(werk, code)
    d=belegen('vitest-gross-vollstaendig', adapter().testlauf(werk))
    assert d['gueltig'],d
    ids=['tests/test_alpha.test.ts::'+n for n in titel]
    assert len(json.dumps(ids))>20000 and sorted(d['faelle'])==sorted(ids)
    assert len(d['roh']['stdout'])<20000
    zufall = [''.join(rng.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=300)) for _ in range(110)]
    schreibe_test(werk,"import {test,expect} from 'vitest';\n"+'\n'.join('test('+json.dumps(n)+',()=>expect(1).toBe(1));' for n in zufall))
    e=belegen('vitest-gross-erweiterte-grenze',adapter().testlauf(werk))
    assert e['gueltig'] and sorted(e['faelle']) == sorted('tests/test_alpha.test.ts::'+n for n in zufall)
    assert 19500 < len(e['roh']['stdout']) < 1900000


@pytest.mark.integration
def test_ts_transportrahmen_unter_und_ueber_neuer_grenze(werk):
    import random
    rng=random.Random(821)
    for laenge,soll in ((1_500_000,True),(2_500_000,False)):
        text=''.join(rng.choices('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',k=laenge))
        code="import {test,expect} from 'vitest';test('grosser Quellbeleg',()=>expect("+json.dumps(text)+").toBe('a'));"
        if soll:
            d=adapter().testfunktionen(code)
            assert len(d)==1 and text in d[0]['code']
            belegen('transport-unter-neuer-grenze',{'quellzeichen':len(code),'vollstaendig':text in d[0]['code']})
        else:
            with pytest.raises(adapter().TypeScriptFehler,match='1900000') as fehler:
                adapter().testfunktionen(code)
            belegen('transport-ueber-neuer-grenze',{'quellzeichen':len(code),'fehler':str(fehler.value)})


@pytest.mark.integration
@pytest.mark.parametrize('abbruch', ['exit', 'zeitlimit'])
def test_aeusserer_kammerabbruch_trotz_vollstaendigem_beleg(werk,monkeypatch,abbruch):
    from biotop.organe import kammer
    original=kammer.ausfuehren
    schreibe_test(werk,"import {test,expect} from 'vitest';test('grün',()=>expect(1).toBe(1));")
    def umhuellt(werk,befehl,zeitlimit_s=None,dateien=None):
        return original(werk,['sh','-c','node _messgeraet/ts/main.mjs; '+('exit 23' if abbruch=='exit' else 'sleep 30')],
                        zeitlimit_s=3 if abbruch=='zeitlimit' else 120,dateien=dateien)
    monkeypatch.setattr(kammer,'ausfuehren',umhuellt)
    d=belegen('kammerabbruch-'+abbruch,adapter().testlauf(werk))
    assert not d['gueltig'] and not d['faelle']
    assert '@@TS1:' in d['grund'] and ('23' if abbruch=='exit' else 'Zeitlimit') in d['grund']


@pytest.mark.integration
def test_crlf_offsets_passen_zu_python_read_text(werk):
    p=werk/'src/alpha/rechnung.ts'
    p.write_bytes(p.read_bytes().replace(b'\n',b'\r\n'))
    d=adapter().struktur(werk)
    f=next(x for x in d['dateien'] if x['pfad']=='src/alpha/rechnung.ts')['funktionen'][0]
    assert p.read_text()[f['body_start']:f['body_end']].startswith('{\n')


@pytest.mark.integration
def test_referenz_dist_wird_frisch_gebaut_objektbeobachtung(werk):
    ts=adapter()
    (werk/'dist/alpha').mkdir(parents=True)
    (werk/'dist/alpha/rechnung.js').write_text('export function betrag(){return 999;}')
    ref="import {betrag} from './dist/alpha/rechnung.js';export function beobachten(){return {summe:betrag(2),form:{b:2,a:1}}}"
    a=belegen('referenz-dist',ts.ref_beobachten(werk,ref))
    assert a['gueltig'] and a['anzahl']==2, a
    b=belegen('referenz-dist-direkt',ts.ref_beobachten(werk,ref.replace('./dist/alpha/rechnung.js','./src/alpha/rechnung')))
    assert b['gueltig'] and a['sha256']==b['sha256'], (a,b)
    c=belegen('referenz-dist-geaendert',ts.ref_beobachten(werk,ref,{'src/beta/wert.ts':'export const eins=2;'}))
    assert c['gueltig'] and c['sha256']!=a['sha256']
    assert (werk/'dist/alpha/rechnung.js').read_text().endswith('999;}')
