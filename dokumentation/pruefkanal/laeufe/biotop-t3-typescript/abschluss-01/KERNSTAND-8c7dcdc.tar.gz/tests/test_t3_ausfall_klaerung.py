"""Ein ungeklärter Anbieterausfall sperrt den Auftrag — mit Klärungsweg, ohne Lockerung.

Lage: `kasse.vorpruefung` verweigert jeden weiteren Aufruf, solange ein `modell.ausfall`
mit `verbrauch_bekannt=False` im Protokoll steht. Das ist richtig — ein Timeout kann beim
Anbieter Verbrauch erzeugt haben, und der darf nicht am Budget vorbei. Ohne Klärungsweg ist
es aber ein Deadlock: der Auftrag bleibt für immer gesperrt.

Der Klärungsweg darf die Regel NICHT lockern. Er muss den Zweifel zu Lasten des Budgets
auflösen: die volle Reservierung wird als tatsächlicher Verbrauch gebucht (Höchstfall),
mit Beleg im Protokoll. Erst dann läuft der Auftrag weiter.
"""
import json

import pytest

from biotop.kern import datenbank, kasse, protokoll


@pytest.fixture
def con(tmp_path, monkeypatch):
    monkeypatch.setattr(datenbank, 'DB_PFAD', tmp_path / 'p.db')
    monkeypatch.setattr(kasse, 'AUFTRAG_BUDGET_EUR', 10.0)
    monkeypatch.setattr(kasse, 'AUFTRAG_LAUF_AB', 26)
    c = datenbank.verbinden()
    c.execute("INSERT INTO laeufe(id,budget_eur,status,begonnen_am) VALUES (29,10.0,'bereit',?)",
              (protokoll.jetzt(),))
    c.commit()
    return c


def _ausfall(con, reservierung=0.0028):
    nr = protokoll.schreiben(con, 'modell.aufruf', lauf_id=29, modell='qwen/qwen3.8-flash',
                             zweck='generation0.testbau.bericht', schaetzung_eur=reservierung)
    protokoll.schreiben(con, 'modell.ausfall', lauf_id=29, modell='qwen/qwen3.8-flash',
                        fehler='HTTP 429', aufruf_nr=nr, ausfallart='infrastruktur', beitraege=0,
                        verbrauch_bekannt=False, kosten_eur=None, reservierung_eur=reservierung)
    return nr


def test_ungeklaerter_ausfall_wird_beim_naechsten_aufruf_geklaert(con):
    """Ein offener Ausfall sperrt nicht mehr dauerhaft, sondern wird mechanisch geklärt.

    Bis zur Festlegung von Chat-Claude warf `vorpruefung` hier dauerhaft und tötete
    damit jeden Lauf, dessen Anbieter zeitweise gedrosselt war. Die Regel selbst ist
    unverändert: voller Höchstfall, harte Grenze, einer je Aufruf.
    """
    nr = _ausfall(con)
    vorher = kasse.stand(con, 29)['ausgegeben_eur']
    kasse.vorpruefung(con, 29, 'openai/gpt-5.6-luna', 1000, 500, 'test')
    nachher = kasse.stand(con, 29)['ausgegeben_eur']
    assert nachher == pytest.approx(vorher + 0.0028), 'Höchstfall gebucht, nicht weniger'
    e = [json.loads(z['inhalt']) for z in con.execute(
        "SELECT inhalt FROM protokoll WHERE art='kasse.ausfall_geklaert'")]
    assert len(e) == 1 and e[0]['aufruf_nr'] == nr and e[0]['automatisch'] is True


def test_klaerung_bucht_hoechstfall_und_gibt_frei(con):
    nr = _ausfall(con, reservierung=0.0028)
    vorher = kasse.stand(con, 29)['ausgegeben_eur']

    gebucht = kasse.ausfall_klaeren(con, 29, nr, beleg='Anbieterabrechnung 2026-09-21')

    # Höchstfall gebucht: die volle Reservierung, nicht weniger.
    assert gebucht == pytest.approx(0.0028)
    nachher = kasse.stand(con, 29)['ausgegeben_eur']
    assert nachher == pytest.approx(vorher + 0.0028)

    # Erst jetzt läuft der Auftrag weiter.
    kasse.vorpruefung(con, 29, 'openai/gpt-5.6-luna', 1000, 500, 'test')

    # Der Beleg steht im Protokoll, mit Höchstfall-Kennzeichnung.
    eintraege = [json.loads(z['inhalt']) for z in con.execute(
        "SELECT inhalt FROM protokoll WHERE art='kasse.ausfall_geklaert'")]
    assert len(eintraege) == 1
    assert eintraege[0]['aufruf_nr'] == nr
    assert eintraege[0]['gebucht_eur'] == pytest.approx(0.0028)
    assert eintraege[0]['klaerungsart'] == 'hoechstfall'
    assert eintraege[0]['beitraege'] == 0


def test_klaerung_eines_ausfalls_gibt_andere_nicht_frei(con):
    """Einer je Aufruf: zwei offene Ausfälle brauchen zwei Vorprüfungen."""
    nr1 = _ausfall(con)
    nr2 = _ausfall(con)
    kasse.ausfall_klaeren(con, 29, nr1, beleg='von Hand geprüft')
    # Der zweite ist noch offen — die nächste Vorprüfung klärt genau ihn, nicht mehr.
    kasse.vorpruefung(con, 29, 'openai/gpt-5.6-luna', 1000, 500, 'test')
    geklaert = [json.loads(z['inhalt'])['aufruf_nr'] for z in con.execute(
        "SELECT inhalt FROM protokoll WHERE art='kasse.ausfall_geklaert' ORDER BY nr")]
    assert geklaert == [nr1, nr2]
    assert kasse.stand(con, 29)['ausgegeben_eur'] == pytest.approx(2 * 0.0028)


def test_klaerung_ohne_passenden_ausfall_wird_abgewiesen(con):
    with pytest.raises(ValueError, match='kein ungeklärter Ausfall'):
        kasse.ausfall_klaeren(con, 29, 999999, beleg='erfunden')


def test_klaerung_zaehlt_gegen_das_auftragsbudget(con, monkeypatch):
    """Der Höchstfall darf das Budget sprengen — dann bricht der Lauf ab, wie vorgesehen."""
    monkeypatch.setattr(kasse, 'AUFTRAG_BUDGET_EUR', 0.001)
    nr = _ausfall(con, reservierung=0.0028)
    kasse.ausfall_klaeren(con, 29, nr, beleg='geprüft')
    with pytest.raises(kasse.BudgetErschoepft, match='AUFTRAGSBUDGET|Auftragsbudget'):
        kasse.vorpruefung(con, 29, 'openai/gpt-5.6-luna', 1000, 500, 'test')
