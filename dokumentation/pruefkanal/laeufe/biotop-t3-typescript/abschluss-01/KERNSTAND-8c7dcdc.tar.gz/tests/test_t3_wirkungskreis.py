from biotop.organe import aegis, landkarte


def test_tatsaechliche_geaenderte_dateien_erweitern_den_wirkungskreis():
    f=getattr(aegis,'wirkungskreis_dateien',None)
    assert callable(f)
    kanten=[('bericht','planung'),('planung','tarife'),('bericht','zahlen')]
    assert f('tarife',{'src/zahlen/a.ts':'neu'},'src',kanten)==['bericht','planung','tarife','zahlen']
    assert f('tarife',{},'src',kanten)==['bericht','planung','tarife']


def test_aegis_benutzt_gesamten_dateisatz_auch_extra(db_lauf,tmp_path,monkeypatch,messung):
    kid=db_lauf.execute("INSERT INTO kandidaten(lauf_id,generation,bereich,nische,status,diff) VALUES(1,1,'alpha','sicher','erzeugt','gestellt')").lastrowid
    monkeypatch.setattr(aegis,'kandidat_dateien',lambda *a:{'paket/alpha/a.py':'x=1'})
    monkeypatch.setattr(aegis,'_angriff',lambda *a,**kw:(None,'gestellt',None))
    monkeypatch.setattr(aegis.messgeraet,'messen',lambda *a,**kw:messung())
    r=aegis.pruefen(db_lauf,1,1,kid,tmp_path,'paket',['alpha','beta'],[],messung(),messung(),None,{},extra_code={'paket/beta/b.py':'x=2'})
    assert r['wirkungskreis']==['alpha','beta']
