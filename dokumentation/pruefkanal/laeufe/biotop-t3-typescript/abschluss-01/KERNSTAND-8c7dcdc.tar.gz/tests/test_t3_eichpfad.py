"""Die TS-Eichprobe durchläuft Aegis, nicht einen Ersatzfilter."""
import json
import os
from pathlib import Path
import pytest
from biotop.kern import datenbank, typescript
from biotop.organe import eichproben, kammer, vertraege, verfassung


@pytest.fixture
def paar(tmp_path, monkeypatch):
    monkeypatch.setattr(kammer, 'IMAGE', 'biotop-kammer:ts1')
    werk = tmp_path/'werk'
    kammer._kopie(Path('/root/versandwerk-t3-02'), werk)
    con = datenbank.verbinden(tmp_path/'eichung.db')
    con.executescript(verfassung.SCHEMA)
    con.execute("INSERT INTO laeufe(id,werk_id,budget_eur,status,mass) VALUES(1,1,0,'angelegt',NULL)")
    vp = 'tests/vertraege/test_vertrag_planung_tarife.test.ts'
    vertraege.einlegen(con, 1, werk, {('planung','tarife'):(werk/vp).read_text()}, 'isolierte TS-Eichfixture')
    verfassung.einlegen(con, 1, Path('/root/biotop-t3/VERFASSUNG-T3-02.md').read_text(),
                       {'uebungswerk':True,'tragender_pfad':[['planung','tarife']]}, 'verfassung-02', 'bestätigter Prüfgegenstand')
    s = typescript.struktur(werk)
    b = typescript.messen(werk,s['bereiche'],'src',None)
    assert b['gueltig']
    g = {'von_bereich':'planung','nach_bereich':'tarife','vertrag_pfad':vp}
    yield con,werk,s['bereiche'],b,g
    con.close()


@pytest.mark.integration
@pytest.mark.parametrize('name',['nebenwirkung','regression','norm','vertrag'])
def test_echtes_t3_paar(paar, name):
    db,w,bereiche,basis,g = paar
    vor = list(db.iterdump())
    dateien = {str(p.relative_to(w)):p.read_bytes() for p in w.rglob('*') if p.is_file()}
    ziel = Path(os.environ.get('T3_EICH_BELEGE','/root/biotop-t3/eichbau'))
    ziel.mkdir(parents=True,exist_ok=True)
    for gegen in (False, True):
        e = eichproben._einzelprobe(db,1,1,w,'src',bereiche,[],basis,basis,None,{},-1,g,name,gegen)
        (ziel/f'{name}-{int(gegen)}.json').write_text(json.dumps(e,ensure_ascii=False,indent=2))
        assert e['ausgefuehrt'] and e['pruefbar'], e['grund']
        assert e['bestanden'] is (not gegen), e['grund']
        if name in ('nebenwirkung','regression'):
            m=e['belege']['urteil']['mass']
            assert any(s.startswith('tarife.tests_fehlgeschlagen:') for s in m['pareto_schlechter']) is (not gegen)
        if name=='vertrag':
            assert eichproben._vertrag_pruefbar(e['belege'],gegen)
    assert list(db.iterdump())==vor
    assert {str(p.relative_to(w)):p.read_bytes() for p in w.rglob('*') if p.is_file()}==dateien
