"""TS-Projektgedächtnis: Namen statt generischem src, AST statt Pythondef."""
from pathlib import Path
import pytest
from biotop.kern import datenbank
from biotop.organe import gedaechtnis as G, kammer, eichproben


def test_werkidentitaet_ist_nicht_src(tmp_path):
    db=datenbank.verbinden(tmp_path/'db')
    db.execute("INSERT INTO werke(id,name,sprache,bericht) VALUES(1,'versand','TypeScript','{\"paket\":\"src\",\"werkidentitaet\":\"versandwerk\"}')")
    db.execute("INSERT INTO werke(id,name,sprache,bericht) VALUES(2,'anderes','TypeScript','{\"paket\":\"src\",\"werkidentitaet\":\"anders\"}')")
    assert G.werkname(db,1)=='versandwerk'
    assert G.werkname(db,1)!=G.werkname(db,2)
    db.close()


@pytest.mark.integration
def test_ts_aenderungsziel_ohne_datei_fallback(tmp_path,monkeypatch):
    monkeypatch.setattr(kammer,'IMAGE','biotop-kammer:ts1')
    rel='src/a/wert.ts';p=tmp_path/rel;p.parent.mkdir(parents=True)
    (tmp_path/'package.json').write_text('{"name":"versandwerk","type":"module"}')
    alt='export function wert(x:number){return x+1;}\nexport function gleich(){return 2;}\n'
    neu=alt.replace('x+1','x-1')
    p.write_text(alt);diff=eichproben._diff(rel,alt,neu)
    for angewandt in ({rel:neu},None):
        _,fs,_=G.aenderungsziel(tmp_path,diff,angewandt)
        assert fs==[rel+'::wert']
    _,fs,_=G.aenderungsziel(tmp_path,'',{})
    assert fs==[]
