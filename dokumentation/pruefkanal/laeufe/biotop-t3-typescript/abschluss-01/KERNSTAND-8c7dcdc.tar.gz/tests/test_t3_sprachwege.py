"""Integration an den vorhandenen Organ-Eingängen, nicht Ersatzlauf."""
import json
from pathlib import Path
from biotop.organe import aufnahme, landkarte, genesis, vertraege


def werk(tmp_path):
    (tmp_path/'package.json').write_text(json.dumps({'name':'probe','type':'module'}))
    for b in ('alpha','beta'):
        p=tmp_path/'src'/b; p.mkdir(parents=True)
        (p/'rechnen.ts').write_text('export function wert(x: number): number { return x + 1; }\n')
    return tmp_path


def test_aufnahme_erkennt_typescript_wurzel(tmp_path):
    assert aufnahme._paket(werk(tmp_path)) == 'src'


def test_bereiche_und_dateien_sind_nicht_auf_python_beschraenkt(tmp_path):
    w=werk(tmp_path)
    assert landkarte.bereiche_finden(w,'src')==['alpha','beta']
    assert [p.name for p in landkarte.dateien_je_bereich(w,'src','beta')]==['rechnen.ts']


def test_schwarm_sieht_typescript_quelle_und_vitest_test(tmp_path):
    w=werk(tmp_path); (w/'tests').mkdir()
    (w/'tests/test_alpha.test.ts').write_text("import {test,expect} from 'vitest';\ntest('test_alpha',()=>expect(1).toBe(1));\n")
    s=genesis._quelltext(w,'src','alpha')
    assert 'rechnen.ts' in s and 'export function wert' in s and 'test_alpha.test.ts' in s


def test_vertragspfad_fuer_typescript_ohne_python_datei(db_lauf,tmp_path):
    w=werk(tmp_path)
    code="import {test,expect} from 'vitest'; test('test_vertrag',()=>expect(1).toBe(1));"
    pfade=vertraege.einlegen(db_lauf,1,w,{('alpha','beta'):code},'gestellte Strukturprobe')
    assert pfade==['tests/vertraege/test_vertrag_alpha_beta.test.ts']
    assert not (w/'tests/vertraege/__init__.py').exists()
