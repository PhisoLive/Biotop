"""Der Zähler muss im ECHTEN Lauf ankommen, nicht nur im Unittest.

Gegenprobe zur Gegenprobe: Die Zählertests ersetzen `_zaehlkontext` von außen. Damit
ist bewiesen, dass die Zählstellen buchen — nicht, dass `lauf.generation()` und
`lauf.generation0()` den Kontext tatsächlich setzen. Genau diese Lücke hat vorher
dazu geführt, dass drei von vier Stellen schwiegen, ohne dass es auffiel.
"""
import sqlite3

import pytest

from biotop import lauf as L
from biotop.kern import datenbank, protokoll
from biotop.organe import aegis, gedaechtnis, generation0, neutralzaehler


@pytest.fixture(autouse=True)
def kontext_zuruecksetzen():
    """Der Kontext ist Modulzustand — nach jedem Test zurück auf leer."""
    yield
    aegis.zaehlkontext_setzen(None, None)
    gedaechtnis.zaehlkontext_setzen(None, None)
    generation0.zaehlkontext_setzen(None, None)


def test_generation_setzt_zaehlkontext_in_allen_drei_organen(tmp_path, monkeypatch):
    monkeypatch.setattr(datenbank, 'DB_PFAD', tmp_path / 'p.db')
    con = datenbank.verbinden()
    con.execute("INSERT INTO laeufe(id,budget_eur,status,begonnen_am) VALUES (77,10.0,'bereit',?)",
                (protokoll.jetzt(),))
    con.commit()
    monkeypatch.setattr(L, '_vorspann_verlangen', lambda *a, **kw: {'nachweis_sha256': 'x'})

    # Der Lauf bricht gleich danach ab (kein Werk) — der Kontext muss trotzdem stehen.
    with pytest.raises(Exception):
        L.generation(con, 77)

    assert aegis._zaehlkontext() == (con, 77), 'aegis ohne Zählkontext'
    assert gedaechtnis._zaehlkontext() == (con, 77), 'gedaechtnis ohne Zählkontext'
    assert generation0._zaehlkontext() == (con, 77), 'generation0 ohne Zählkontext'


def test_ohne_lauf_bucht_niemand(tmp_path, monkeypatch):
    """Gegenprobe: Ohne Kontext läuft alles, aber nichts wird gezählt."""
    monkeypatch.setattr(datenbank, 'DB_PFAD', tmp_path / 'q.db')
    con = datenbank.verbinden()
    aegis.zaehlkontext_setzen(None, None)
    alt = "import {test, expect} from 'vitest';\ntest('a', () => expect(1).toBe(1));\n"
    assert aegis._anhaengen(alt, alt, {'a'}) is None      # läuft durch
    neutralzaehler._tabelle(con)
    assert con.execute('SELECT COUNT(*) FROM neutralzaehler').fetchone()[0] == 0


def test_zaehlerfehler_beendet_keinen_lauf(tmp_path, monkeypatch):
    """Ein Messinstrument darf das Gemessene nicht anhalten."""
    class KaputteDB:
        def execute(self, *a, **kw):
            raise sqlite3.OperationalError('Datenbank weg')

    aegis.zaehlkontext_setzen(KaputteDB(), 99)
    alt = "import {test, expect} from 'vitest';\ntest('a', () => expect(1).toBe(1));\n"
    assert aegis._anhaengen(alt, alt, {'a'}) is None      # kein Absturz
