"""Ein unbrauchbarer Angriffstest ist ein Kandidatenbefund, kein Laufabbruch.

Befund aus Lauf 32, Generation 3: Der Lauf starb mit
RuntimeError "Vitest-Ausführungsnachweis unbrauchbar: Collection-/Suite-/Runnerfehler".

Aegis lässt ein Modell einen Angriffstest schreiben und führt ihn aus. Schreibt das
Modell eine Datei, die Vitest nicht sammeln kann (Syntaxfehler, fehlender Import,
.skip), meldet der Adapter `gueltig=False` — und `junit_lauf` warf. Der Python-Pfad
derselben Funktion behandelt genau diesen Fall seit jeher korrekt: er gibt
`{datei::*: {ok: False, bestaetigt: False, meldung: ...}}` zurück, der Angriff zählt
als nicht bestätigt, der Kandidat wird normal beurteilt.

Zu unterscheiden sind zwei Dinge, die der Adapter bisher gleich behandelte:
  INHALT        — die gelieferte Testdatei ist unbrauchbar (Sammlung, Skip, leer).
                  Befund über den Angriff, kein Abbruch.
  INFRASTRUKTUR — Runner abgestürzt, JUnit unlesbar, Kammer tot.
                  Bleibt ein Abbruch: ohne Messgerät kein Urteil.
"""
import pytest

from biotop.organe import aegis, kammer
from biotop.kern import typescript

kammer.IMAGE = 'biotop-kammer:ts1'
from pathlib import Path

WERK = Path('/root/biotop/daten/werke/versandwerk-t3-02')


@pytest.mark.integration
def test_unsammelbarer_angriffstest_ist_befund_kein_abbruch():
    """Ein Testfile mit Syntaxfehler: Ergebnis statt Ausnahme."""
    ad = 'tests/test_bericht_immun_aegis_kaputt.test.ts'
    kaputt = "import {test} from 'vitest';\ntest('x', () => { this is no javascript )\n"
    r = aegis.junit_lauf(WERK, 'src', {ad: kaputt}, [ad])
    assert r, 'Rückgabe statt Ausnahme erwartet'
    schluessel = f'{ad}::*'
    assert schluessel in r, f'Sammelfehler-Eintrag erwartet, erhalten: {list(r)[:3]}'
    assert r[schluessel]['ok'] is False
    assert r[schluessel]['bestaetigt'] is False, 'ein unsammelbarer Test bestätigt nichts'
    assert 'Sammel' in r[schluessel]['meldung'] or 'Collection' in r[schluessel]['meldung']


@pytest.mark.integration
def test_gueltiger_angriffstest_liefert_weiterhin_einzelfaelle():
    """Gegenprobe: ein sammelbarer Test wird normal ausgewertet, nicht pauschal."""
    ad = 'tests/test_bericht_immun_aegis_gut.test.ts'
    gut = ("import {test, expect} from 'vitest';\n"
           "test('test_bericht_immun_aegis_gut_trifft', () => { expect(1 + 1).toBe(2); });\n")
    r = aegis.junit_lauf(WERK, 'src', {ad: gut}, [ad])
    assert f'{ad}::*' not in r, 'kein Sammelfehler bei gültiger Datei'
    treffer = [k for k in r if k.startswith(ad + '::')]
    assert treffer, f'Einzelfall erwartet, erhalten: {list(r)[:3]}'
    assert r[treffer[0]]['ok'] is True


def test_infrastrukturfehler_bleibt_abbruch(monkeypatch):
    """Ein toter Runner ist kein Befund über den Angriff — dort MUSS geworfen werden."""
    def kaputte_kammer(*a, **kw):
        return {'gueltig': False, 'grund': 'Vitest-Runnerabbruch', 'faelle': {},
                'art': 'infrastruktur', 'rc': None}

    monkeypatch.setattr(typescript, 'testlauf', kaputte_kammer)
    with pytest.raises(RuntimeError, match='unbrauchbar'):
        aegis.junit_lauf(WERK, 'src', {'tests/x.test.ts': 'x'}, ['tests/x.test.ts'])


def test_inhaltsfehler_wird_nicht_geworfen(monkeypatch):
    """Spiegelbild: als Inhalt gekennzeichnet → Rückgabe, kein Wurf."""
    def unsammelbar(*a, **kw):
        return {'gueltig': False, 'grund': 'Collection-/Suite-/Runnerfehler', 'faelle': {},
                'art': 'inhalt', 'rc': 1}

    monkeypatch.setattr(typescript, 'testlauf', unsammelbar)
    r = aegis.junit_lauf(WERK, 'src', {'tests/x.test.ts': 'x'}, ['tests/x.test.ts'])
    assert r['tests/x.test.ts::*']['ok'] is False
    assert r['tests/x.test.ts::*']['bestaetigt'] is False
