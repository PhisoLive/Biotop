"""Sprachadapter-Verkabelung; gestellte Adapterantwort, keine Kammerbehauptung."""
import json
import sys
import types
import pytest
from biotop.kern import messgeraet, datenbank
from biotop.organe import aufnahme, landkarte, aegis, generation0


@pytest.fixture
def ts_werk(tmp_path):
    tmp_path=tmp_path/'werk'; tmp_path.mkdir()
    (tmp_path/'package.json').write_text('{"type":"module"}')
    (tmp_path/'src'/'alpha').mkdir(parents=True)
    (tmp_path/'src'/'beta').mkdir(parents=True)
    (tmp_path/'src/alpha/a.ts').write_text("import { b } from '../beta/b';\nexport function a(x: number): number { return b(x); }\n")
    (tmp_path/'src/beta/b.ts').write_text('export function b(x: number): number { return x + 1; }\n')
    (tmp_path/'tests').mkdir()
    (tmp_path/'tests/test_alpha.test.ts').write_text("import {test,expect} from 'vitest'; test('test_a',()=>expect(1).toBe(1));\n")
    return tmp_path


@pytest.fixture
def adapter(monkeypatch):
    aufrufe=[]
    s={'bereiche':['alpha','beta'],'dateien':[
        {'pfad':'src/alpha/a.ts','funktionen':[{'name':'a','zeile':2,'ende':2,'signatur':'a(x: number): number','zweck':'berechnet'}],
         'imports':['src/beta/b.ts']},
        {'pfad':'src/beta/b.ts','funktionen':[{'name':'b','zeile':1,'ende':1,'signatur':'b(x: number): number','zweck':'berechnet'}],'imports':[]}]}
    def struktur(w): aufrufe.append('struktur'); return s
    def messen(*a,**kw): aufrufe.append('messen'); return {'gueltig':True,'werk':{'baut':True},'adapterbeleg':'gestelltes Messobjekt'}
    def testlauf(*a,**kw):
        aufrufe.append('testlauf'); return {'gueltig':True,'grund':'','rc':0,'faelle':{'tests/test_alpha.test.ts::test_a':{'ok':True,'bestaetigt':False,'meldung':''}},'roh':'gestellter Vitest-Beleg'}
    m=types.SimpleNamespace(struktur=struktur,messen=messen,testlauf=testlauf)
    monkeypatch.setitem(sys.modules,'biotop.kern.typescript',m)
    import biotop.kern
    monkeypatch.setattr(biotop.kern,'typescript',m,raising=False)
    return aufrufe


def test_messgeraet_fuehrt_typescript_adapter_aus(ts_werk,adapter):
    m=messgeraet.messen(ts_werk,['alpha','beta'],'src',None)
    assert m['gueltig'] and m['adapterbeleg']=='gestelltes Messobjekt'
    assert adapter==['messen']


def test_junit_verbraucher_leitet_typescript_an_vitest(ts_werk,adapter):
    r=aegis.junit_lauf(ts_werk,'src',{},['tests/test_alpha.test.ts'])
    assert r['tests/test_alpha.test.ts::test_a']['ok'] is True
    assert adapter==['testlauf']


def test_aufnahme_prueft_ts_statt_falsches_keine_tests(ts_werk,adapter,monkeypatch,tmp_path):
    con=datenbank.verbinden(tmp_path/'a.db')
    monkeypatch.setattr(aufnahme,'WERKE',tmp_path/'aufgenommen')
    monkeypatch.setattr(aufnahme,'_ethik',lambda *a:{'urteil':'UNBEDENKLICH','begruendung':'gestellte Strukturprobe'})
    r=aufnahme.aufnehmen(con,'t3',str(ts_werk),1)
    assert r['baut'] is True and r['paket']=='src' and r['sprache']=='TypeScript'
    assert r['erster_testlauf']['gesamt']==1 and r['erster_testlauf']['bestanden']==1
    assert r['bereiche_schaetzung']==['alpha','beta']
    assert r['werkidentitaet']=='t3'
    con.close()


def test_landkarte_strassen_aus_ast_adapter(ts_werk,adapter):
    kanten=landkarte.strassen(ts_werk,'src',['alpha','beta'])
    assert ('src.alpha.a','src.beta.b','import') in kanten
    assert landkarte.funktionen(ts_werk/'src/alpha/a.ts')[0]['name']=='a'
    vertr=landkarte.vertraege_ableiten(ts_werk,'src','alpha')
    assert len(vertr)==1 and vertr[0]['herkunft']=='abgeleitet'
