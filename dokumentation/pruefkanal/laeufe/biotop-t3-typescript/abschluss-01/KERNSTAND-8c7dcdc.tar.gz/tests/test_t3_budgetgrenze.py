"""Vorabgrenze reserviert auch nicht-ASCII Eingaben konservativ."""
from biotop.anbieter import _tokens_schaetzen


def test_tokenobergrenze_nicht_nur_zeichen_dritteln():
    text='🧪漢字' * 100
    assert _tokens_schaetzen(text) >= len(text.encode('utf-8'))
    assert _tokens_schaetzen('') > 0
