"""Direkte Elternprüfung; identische Suite, privater Temp-/DB-Bestand, Netzsperre."""
from pathlib import Path
import os, sys, json, sqlite3, hashlib, time, socket, tempfile, contextlib, gzip
import xml.etree.ElementTree as ET
P=Path('/root/reparatur-02');R=Path('/root/biotop');name=sys.argv[1]
assert name.replace('-','').isalnum()
O=P/'belege';assert not (O/(name+'.json')).exists()
os.environ.update(PYTHONPATH=str(R),PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(P/'temp'),BIOTOP_DB=str(P/'unbenutzt.db'),BIOTOP_EICHWERK='/root/reparatur-01/teil-eichung/werk-lauf25-kopie',BIOTOP_EICHDB='/root/reparatur-01/ausgang.db',BIOTOP_EICHWERK_ID='22',BIOTOP_EICHBELEG=str(O/(name+'-eichpaare.json')))
os.chdir(R);sys.path.insert(0,str(R));sys.dont_write_bytecode=True;tempfile.tempdir=os.environ['TMPDIR']
def verboten(*a,**k):raise AssertionError('Reparatur02: Modell-/Netzaufruf gesperrt')
socket.socket.connect=verboten;socket.create_connection=verboten
import pytest
from biotop.organe import kammer
start=json.loads((P/'AUSGANG.json').read_text())
with sqlite3.connect(f'file:{R}/daten/biotop.db?mode=ro',uri=True) as c:
    kosten=c.execute('SELECT COALESCE(SUM(kosten_eur),0) FROM kasse WHERE id>?',(start['kasse']['max_id'],)).fetchone()[0]
assert kosten < start['budget_eur']
quellen={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in start['quellen']}
sammlung=[];berichte=[]
class Nachweis:
    @pytest.hookimpl(trylast=True)
    def pytest_collection_finish(self,session):sammlung.extend(i.nodeid for i in session.items)
    def pytest_runtest_logreport(self,report):berichte.append({'nodeid':report.nodeid,'phase':report.when,'outcome':report.outcome})
args=sys.argv[2:] or ['-v','--tb=short']
args += ['--junitxml='+str(O/(name+'.xml'))]
t=time.monotonic()
with (O/(name+'.txt')).open('x') as out,contextlib.redirect_stdout(out),contextlib.redirect_stderr(out),kammer.zaehlung() as zaehler:
    print('BEFEHL:',sys.executable,*sys.argv,'\nPYTEST:',args,'\nQUELLWURZEL:',R)
    rc=int(pytest.main(args,plugins=[Nachweis()]))
    print('RUECKGABEWERT:',rc)
with gzip.open(O/(name+'-kammern.json.gz'),'wt',encoding='utf-8') as f:json.dump(zaehler,f,ensure_ascii=False)
r={'rc':rc,'dauer_s':time.monotonic()-t,'sammlung':sammlung,'berichte':berichte,'testsuites':[n.attrib for n in ET.parse(O/(name+'.xml')).getroot().iter('testsuite')],'kammerlaeufe':len(zaehler),'quellen':quellen,'netz_gesperrt':True,'art':'Elterncode, private Eigenfixtures und bestehendes kopiertes Eichwerk; keine natürliche Kampagne'}
assert quellen=={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in start['quellen']}
(O/(name+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k not in ('quellen','sammlung','berichte')},ensure_ascii=False))
sys.exit(rc)
